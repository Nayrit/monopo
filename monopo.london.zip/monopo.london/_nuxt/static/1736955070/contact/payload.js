__NUXT_JSONP__("/contact", (function(a, b, c, d, e, f, g) {
    return {
        data: [{
            document: {
                contact: [{
                    type: a,
                    text: c,
                    spans: []
                }],
                contact_email: [{
                    label: "contact@monopo.london",
                    link: {
                        link_type: d,
                        key: "428084d8-07d8-4245-8149-6bab33cf4fee",
                        url: "mailto:contact@monopo.london",
                        target: e
                    }
                }],
                address: [{
                    type: a,
                    text: "116 Commercial Street\nUNIT D104\nE1 6NF, London\nUnited Kingdom",
                    spans: []
                }],
                google_maps: [{
                    label: "view on google maps",
                    link: {
                        link_type: d,
                        key: "9b54b468-5491-44ab-9cbe-a21607cad39e",
                        url: "https:\u002F\u002Fwww.google.com\u002Fmaps\u002Fplace\u002Fmonopo+London\u002F@51.5297868,-0.0608025,15z\u002Fdata=!4m12!1m6!3m5!1s0x0:0xacde0bf63be54a11!2smonopo+London!8m2!3d51.5204201!4d-0.0743371!3m4!1s0x0:0xacde0bf63be54a11!8m2!3d51.5204201!4d-0.0743371",
                        target: e
                    }
                }],
                form_title: [{
                    type: "heading2",
                    text: "Let’s make your project a reality",
                    spans: []
                }],
                form_paragraph: [{
                    type: a,
                    text: c,
                    spans: []
                }],
                careers_title: [{
                    type: f,
                    text: "Producer \u002F Project manager",
                    spans: [],
                    direction: b
                }],
                careers_paragraph: [{
                    type: a,
                    text: "We are hiring a new producer to join our team full time on-site in London from February. In this role, you’ll collaborate closely with creative teams, clients, and external partners to transform ambitious ideas into reality. We’re looking for someone with at least three years of experience in a creative agency, ideally in account management, production, or project management roles.\nTo apply, share your CV, portfolio and cover letter via jobs@monopo.london before January 22nd.",
                    spans: [{
                        start: 440,
                        end: 459,
                        type: g
                    }],
                    direction: b
                }],
                freelance_title: [{
                    type: f,
                    text: "Freelance collaborators",
                    spans: []
                }],
                freelance_paragraph: [{
                    type: a,
                    text: "We are always looking for talented freelance collaborators. Please get in touch with us if you are a freelance designer, photographer, developer, director, copywriter, juggler, meme artist, or influencer. We want to hear about your skills and passions, no matter how niche they are. You can reach us via freelance@monopo.london.",
                    spans: [{
                        start: 304,
                        end: 328,
                        type: g
                    }],
                    direction: b
                }],
                meta_title: "monopo london | Contact us",
                meta_description: "monopo london 116 Commercial Street, UNIT D104, E1 6NF, Spitalfieds, London, United Kingdom."
            }
        }],
        fetch: {},
        mutations: []
    }
}("paragraph", "ltr", "Feel free to reach out if you want to collaborate with us, or simply have a chat.", "Web", "_blank", "heading3", "strong")));