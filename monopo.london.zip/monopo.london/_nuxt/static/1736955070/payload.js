__NUXT_JSONP__("/", (function(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R) {
    return {
        data: [{
            document: {
                title: [{
                    line_one: "We are a brand",
                    line_two: "of collective",
                    line_three: "creativity"
                }],
                title_japanese: [{
                    line_one: "私たちは",
                    line_two: "創造性を結集した",
                    line_three: "ブランド"
                }],
                gradient: "\u003Cmonopo-gradient color1=\"#16254b\" color2=\"#23418a\" color3=\"#aadfd9\" color4=\"#e64f0f\" colorsize=\"0.75\" colorspacing=\"0.52\" colorrotation=\"-0.381592653589793\" colorspread=\"4.52\" coloroffset=\"-0.7741174697875977,-0.20644775390624992\" displacement=\"4.66\" seed=\"-0.06\" position=\"-0.2816110610961914,-0.43914794921875\" zoom=\"0.72\" spacing=\"4.27\"\u003E\u003C\u002Fmonopo-gradient\u003E",
                manifesto: [{
                    manifesto_title: [{
                        type: v,
                        text: "Based in London",
                        spans: []
                    }],
                    manifesto_text: "Born in Tokyo"
                }, {
                    manifesto_title: [{
                        type: v,
                        text: "Design-driven",
                        spans: []
                    }],
                    manifesto_text: "creative agency"
                }, {
                    manifesto_title: [{
                        type: v,
                        text: "Branding, digital",
                        spans: []
                    }],
                    manifesto_text: "and communications"
                }],
                projects: [{
                    project: {
                        id: "ZtiLFBAAACYAXg8Q",
                        type: l,
                        tags: [],
                        lang: c,
                        slug: "hotel-onitsuka-tiger--brand-activation",
                        first_publication_date: "2024-09-04T17:29:59+0000",
                        last_publication_date: "2024-09-06T09:50:09+0000",
                        uid: "hotel-onitsuka-tiger",
                        data: {
                            image_homepage: {
                                dimensions: {
                                    width: m,
                                    height: n
                                },
                                alt: a,
                                copyright: a,
                                url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002FZtiLp7zzk9ZrW_ms_Hotel_Onitsuka_Tiger_Homepage_Cover_1900px.jpg?auto=format,compress&rect=0,0,1900,1188&w=950&h=594",
                                id: w,
                                edit: {
                                    x: b,
                                    y: b,
                                    zoom: g,
                                    background: h
                                },
                                retina: {
                                    dimensions: {
                                        width: o,
                                        height: p
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002FZtiLp7zzk9ZrW_ms_Hotel_Onitsuka_Tiger_Homepage_Cover_1900px.jpg?auto=format,compress&rect=0,0,1900,1188&w=1900&h=1188",
                                    id: w,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: g,
                                        background: h
                                    }
                                },
                                thumb: {
                                    dimensions: {
                                        width: q,
                                        height: r
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002FZtiLp7zzk9ZrW_ms_Hotel_Onitsuka_Tiger_Homepage_Cover_1900px.jpg?auto=format,compress&rect=158,0,1584,1188&w=4&h=3",
                                    id: w,
                                    edit: {
                                        x: B,
                                        y: b,
                                        zoom: g,
                                        background: h
                                    }
                                }
                            },
                            gradient: "\u003Cmonopo-gradient color1=\"#FFCD00\" color2=\"#FFCD00\" color3=\"#FFCD00\" color4=\"#000000\" colorsize=\"1.54\" colorspacing=\"0.52\" colorrotation=\"-0.381592653589793\" colorspread=\"4.52\" coloroffset=\"-0.7741174697875977,-0.20644775390624992\" displacement=\"4.66\" seed=\"-0.06\" position=\"-0.2816110610961914,-0.43914794921875\" zoom=\"0.72\" spacing=\"4.27\"\u003E\u003C\u002Fmonopo-gradient\u003E",
                            title: [{
                                type: s,
                                text: "HOTEL ONITSUKA TIGER ‣ Brand activation",
                                spans: [],
                                direction: C
                            }],
                            categories: [{
                                category: {
                                    id: D,
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: E,
                                    first_publication_date: F,
                                    last_publication_date: G,
                                    uid: H,
                                    link_type: d,
                                    key: "37110b0b-873d-4033-85bb-c45e24bb9cf3",
                                    isBroken: e
                                }
                            }, {
                                category: {
                                    id: "ZtiLKBAAACQAXhDZ",
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: I,
                                    first_publication_date: J,
                                    last_publication_date: J,
                                    uid: I,
                                    link_type: d,
                                    key: "201fe987-3079-4722-923f-2a21831cff67",
                                    isBroken: e
                                }
                            }, {
                                category: {
                                    id: K,
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: t,
                                    first_publication_date: u,
                                    last_publication_date: u,
                                    uid: t,
                                    link_type: d,
                                    key: "4d68c5a4-22df-4417-bc3e-ef428f179882",
                                    isBroken: e
                                }
                            }]
                        },
                        link_type: d,
                        key: "ecfa54b3-6b31-4b14-92f8-988c86c8937b",
                        isBroken: e
                    }
                }, {
                    project: {
                        id: "ZtszNhAAACAATTkf",
                        type: l,
                        tags: [],
                        lang: c,
                        slug: "kodama-capital-branding",
                        first_publication_date: "2024-09-06T16:54:02+0000",
                        last_publication_date: "2024-09-12T10:36:07+0000",
                        uid: "kodama-capital",
                        data: {
                            image_homepage: {
                                dimensions: {
                                    width: m,
                                    height: n
                                },
                                alt: a,
                                copyright: a,
                                url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002FZtsscRoQrfVKlzPB_Kodama-Capital_Homepage_Cover_1900px.jpg?auto=format,compress&rect=0,0,1900,1188&w=950&h=594",
                                id: x,
                                edit: {
                                    x: b,
                                    y: b,
                                    zoom: g,
                                    background: h
                                },
                                retina: {
                                    dimensions: {
                                        width: o,
                                        height: p
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002FZtsscRoQrfVKlzPB_Kodama-Capital_Homepage_Cover_1900px.jpg?auto=format,compress&rect=0,0,1900,1188&w=1900&h=1188",
                                    id: x,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: g,
                                        background: h
                                    }
                                },
                                thumb: {
                                    dimensions: {
                                        width: q,
                                        height: r
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002FZtsscRoQrfVKlzPB_Kodama-Capital_Homepage_Cover_1900px.jpg?auto=format,compress&rect=158,0,1584,1188&w=4&h=3",
                                    id: x,
                                    edit: {
                                        x: B,
                                        y: b,
                                        zoom: g,
                                        background: h
                                    }
                                }
                            },
                            gradient: "\u003Cmonopo-gradient color1=\"#405B10\" color2=\"#BBB99D\" color3=\"#A79F47\" color4=\"#405B10\" colorsize=\"1.54\" colorspacing=\"0.52\" colorrotation=\"-0.381592653589793\" colorspread=\"4.52\" coloroffset=\"-0.7741174697875977,-0.20644775390624992\" displacement=\"4.66\" seed=\"-0.06\" position=\"-0.2816110610961914,-0.43914794921875\" zoom=\"0.72\" spacing=\"4.27\"\u003E\u003C\u002Fmonopo-gradient\u003E",
                            title: [{
                                type: s,
                                text: "KODAMA CAPITAL\u2028‣ BRANDING",
                                spans: [],
                                direction: C
                            }],
                            categories: [{
                                category: {
                                    id: y,
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: i,
                                    first_publication_date: j,
                                    last_publication_date: j,
                                    uid: i,
                                    link_type: d,
                                    key: "14d26095-f560-46ac-9f96-bf68abc72edb",
                                    isBroken: e
                                }
                            }, {
                                category: {
                                    id: "YMISgRMAACMAamE-",
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: L,
                                    first_publication_date: M,
                                    last_publication_date: M,
                                    uid: L,
                                    link_type: d,
                                    key: "959e06d5-5705-40a1-9cdd-d9dc85140a25",
                                    isBroken: e
                                }
                            }]
                        },
                        link_type: d,
                        key: "d1d0bfe2-7190-4b95-bdae-f71d540b1313",
                        isBroken: e
                    }
                }, {
                    project: {
                        id: "ZRKo5xAAACEAb1kF",
                        type: l,
                        tags: [],
                        lang: c,
                        slug: "yonex-all-england--brand-universe",
                        first_publication_date: "2023-09-26T17:20:08+0000",
                        last_publication_date: "2023-09-27T22:05:39+0000",
                        uid: "yonex-all-england-brand-identity",
                        data: {
                            image_homepage: {
                                dimensions: {
                                    width: m,
                                    height: n
                                },
                                alt: "Yonex All England Open Badminton Championships - Brand universe",
                                copyright: a,
                                url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fa2d5acbc-ce3a-4100-ab83-4e721f2d0aa7_Yonex-all-england_brand_identity_HOMEPAGE_cover_HD.jpg?auto=compress,format&rect=0,0,1900,1188&w=950&h=594",
                                id: z,
                                edit: {
                                    x: b,
                                    y: b,
                                    zoom: N,
                                    background: k
                                },
                                retina: {
                                    dimensions: {
                                        width: o,
                                        height: p
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fa2d5acbc-ce3a-4100-ab83-4e721f2d0aa7_Yonex-all-england_brand_identity_HOMEPAGE_cover_HD.jpg?auto=compress,format&rect=0,0,1900,1188&w=1900&h=1188",
                                    id: z,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: g,
                                        background: k
                                    }
                                },
                                thumb: {
                                    dimensions: {
                                        width: q,
                                        height: r
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fa2d5acbc-ce3a-4100-ab83-4e721f2d0aa7_Yonex-all-england_brand_identity_HOMEPAGE_cover_HD.jpg?auto=compress,format&rect=0,0,1584,1188&w=4&h=3",
                                    id: z,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: O,
                                        background: k
                                    }
                                }
                            },
                            gradient: "\u003Cmonopo-gradient color1=\"#00FF18\" color2=\"#00FF18\" color3=\"#3036FC\" color4=\"#3036FC\" colorsize=\"1.54\" colorspacing=\"0.52\" colorrotation=\"-0.381592653589793\" colorspread=\"4.52\" coloroffset=\"-0.7741174697875977,-0.20644775390624992\" displacement=\"4.66\" seed=\"-0.06\" position=\"-0.2816110610961914,-0.43914794921875\" zoom=\"0.72\" spacing=\"4.27\"\u003E\u003C\u002Fmonopo-gradient\u003E",
                            title: [{
                                type: s,
                                text: "Yonex All England ‣ Brand Universe",
                                spans: []
                            }],
                            categories: [{
                                category: {
                                    id: y,
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: i,
                                    first_publication_date: j,
                                    last_publication_date: j,
                                    uid: i,
                                    link_type: d,
                                    key: "24d07b44-f6ed-4367-b9d3-45eadcc3f73d",
                                    isBroken: e
                                }
                            }, {
                                category: {
                                    id: "YMISNRMAACQAamBB",
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: P,
                                    first_publication_date: Q,
                                    last_publication_date: Q,
                                    uid: P,
                                    link_type: d,
                                    key: "81c6a8f8-ee9c-466f-98a2-a3fc74465fac",
                                    isBroken: e
                                }
                            }, {
                                category: {
                                    id: D,
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: E,
                                    first_publication_date: F,
                                    last_publication_date: G,
                                    uid: H,
                                    link_type: d,
                                    key: "b63b28fa-4ff2-4164-aa07-68ab765844af",
                                    isBroken: e
                                }
                            }]
                        },
                        link_type: d,
                        key: "6df6c0a7-a9a0-4194-a60c-b5439a285d1c",
                        isBroken: e
                    }
                }, {
                    project: {
                        id: "ZD7QXBYAACsAYBFG",
                        type: l,
                        tags: [],
                        lang: c,
                        slug: "ghost-messaging--brand-universe",
                        first_publication_date: "2023-04-21T07:48:56+0000",
                        last_publication_date: "2023-06-12T14:33:31+0000",
                        uid: "ghost-messaging-app-brand-identity",
                        data: {
                            image_homepage: {
                                dimensions: {
                                    width: m,
                                    height: n
                                },
                                alt: "Ghost messaging app - brand identity",
                                copyright: a,
                                url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F2e8b5d09-0825-497d-8b7f-f74bd49a8ca7_Ghost_Messaging_App_Branding_Homepage_Cover_1900px.jpg?auto=compress,format&rect=0,0,1900,1188&w=950&h=594",
                                id: A,
                                edit: {
                                    x: b,
                                    y: b,
                                    zoom: N,
                                    background: k
                                },
                                retina: {
                                    dimensions: {
                                        width: o,
                                        height: p
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F2e8b5d09-0825-497d-8b7f-f74bd49a8ca7_Ghost_Messaging_App_Branding_Homepage_Cover_1900px.jpg?auto=compress,format&rect=0,0,1900,1188&w=1900&h=1188",
                                    id: A,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: g,
                                        background: k
                                    }
                                },
                                thumb: {
                                    dimensions: {
                                        width: q,
                                        height: r
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F2e8b5d09-0825-497d-8b7f-f74bd49a8ca7_Ghost_Messaging_App_Branding_Homepage_Cover_1900px.jpg?auto=compress,format&rect=0,0,1584,1188&w=4&h=3",
                                    id: A,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: O,
                                        background: k
                                    }
                                }
                            },
                            gradient: "\u003Cmonopo-gradient color1=\"#7C50FF\" color2=\"#7C50FF\" color3=\"#FF96D8\" color4=\"#45ABED\" colorsize=\"1.54\" colorspacing=\"0.52\" colorrotation=\"-0.381592653589793\" colorspread=\"4.52\" coloroffset=\"-0.7741174697875977,-0.20644775390624992\" displacement=\"4.66\" seed=\"-0.06\" position=\"-0.2816110610961914,-0.43914794921875\" zoom=\"0.72\" spacing=\"4.27\"\u003E\u003C\u002Fmonopo-gradient\u003E",
                            title: [{
                                type: s,
                                text: "Ghost Messaging ‣ Brand Universe",
                                spans: []
                            }],
                            categories: [{
                                category: {
                                    id: y,
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: i,
                                    first_publication_date: j,
                                    last_publication_date: j,
                                    uid: i,
                                    link_type: d,
                                    key: "bd2bcc09-f104-4d1c-b244-c0ee808728d0",
                                    isBroken: e
                                }
                            }, {
                                category: {
                                    id: K,
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: t,
                                    first_publication_date: u,
                                    last_publication_date: u,
                                    uid: t,
                                    link_type: d,
                                    key: "8ee676da-b5c2-42cd-9d1b-e27b6a1db2bb",
                                    isBroken: e
                                }
                            }, {
                                category: {
                                    id: "YMISKBMAACIAamAA",
                                    type: f,
                                    tags: [],
                                    lang: c,
                                    slug: R,
                                    first_publication_date: "2021-06-10T13:22:50+0000",
                                    last_publication_date: "2022-07-01T17:04:00+0000",
                                    uid: R,
                                    link_type: d,
                                    key: "88eac79e-7bb7-4c60-9bf8-af2b84f97ce3",
                                    isBroken: e
                                }
                            }]
                        },
                        link_type: d,
                        key: "b53f6d80-e770-451e-b713-62f497120838",
                        isBroken: e
                    }
                }]
            }
        }],
        fetch: {},
        mutations: []
    }
}(null, 0, "en-gb", "Document", false, "category", 1, "transparent", "brand-design", "2021-06-10T13:22:34+0000", "#fff", "project", 950, 594, 1900, 1188, 4, 3, "heading1", "illustration", "2022-07-01T16:56:38+0000", "heading5", "ZtiLp7zzk9ZrW_ms", "ZtsscRoQrfVKlzPB", "YMISFhMAACEAal_B", "ZRSmuBEAACIAz9fs", "ZD7SHxYAAC0AYBkP", 158, "ltr", "YMISWBMAACEAamDk", "campaign", "2021-06-10T13:23:44+0000", "2024-09-05T13:25:11+0000", "campaigns", "spatial", "2024-09-04T17:30:12+0000", "Yr8nPhEAACEA1cFp", "photography", "2021-06-10T13:24:20+0000", .5, .0025252525252525255, "video", "2021-06-10T13:23:05+0000", "digital")));