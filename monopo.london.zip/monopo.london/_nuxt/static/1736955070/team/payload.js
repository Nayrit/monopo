__NUXT_JSONP__("/team", (function(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, A, B, C, D, E) {
    return {
        data: [{
            document: {
                title: [{
                    line_one: [{
                        type: j,
                        text: "We seek",
                        spans: []
                    }],
                    line_two: [{
                        type: j,
                        text: "unique",
                        spans: []
                    }],
                    line_three: [{
                        type: j,
                        text: "perspectives",
                        spans: []
                    }]
                }],
                baseline: "[ a city-based global network ]",
                gradient: "\u003Cmonopo-gradient color1=\"#47AFFF\" color2=\"#5E68E8\" color3=\"#4D24AE\" color4=\"#3957C0\" colorsize=\"0.58\" colorspacing=\"0.52\" colorrotation=\"-0.381592653589793\" colorspread=\"4.52\" coloroffset=\"-0.7741174697875977,-0.20644775390624992\" displacement=\"4.66\" seed=\"-0.06\" position=\"-0.2816110610961914,-0.43914794921875\" zoom=\"0.72\" spacing=\"4.27\"\u003E\u003C\u002Fmonopo-gradient\u003E",
                introduction_text: [{
                    type: d,
                    text: y,
                    spans: []
                }],
                members_title: [{
                    type: f,
                    text: "Meet our london team",
                    spans: []
                }],
                we_are_title: [{
                    line_one: "We are a collective",
                    line_two: "for global",
                    line_three: "creative talent",
                    line_four: "seeking safe harbour."
                }],
                we_are_baseline: "[ A safe space for independent spirits. ]",
                we_are_text: [{
                    type: d,
                    text: "Our structure empowers creative minds to bring their whole selves to projects. We work in a flat hierarchy that encourages people to deepen their expertise and widen their interests.",
                    spans: []
                }],
                we_are_image: {
                    dimensions: {
                        width: 420,
                        height: 236
                    },
                    alt: a,
                    copyright: a,
                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F27538a20-c22f-4f48-9d3d-7cc1dbdb353a_monopo_london_team2_.jpeg?auto=compress,format&rect=0,0,840,472&w=420&h=236",
                    id: k,
                    edit: {
                        x: b,
                        y: b,
                        zoom: g,
                        background: c
                    },
                    retina: {
                        dimensions: {
                            width: 840,
                            height: 472
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F27538a20-c22f-4f48-9d3d-7cc1dbdb353a_monopo_london_team2_.jpeg?auto=compress,format&rect=0,0,840,472&w=840&h=472",
                        id: k,
                        edit: {
                            x: b,
                            y: b,
                            zoom: h,
                            background: c
                        }
                    },
                    thumb: {
                        dimensions: {
                            width: e,
                            height: i
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F27538a20-c22f-4f48-9d3d-7cc1dbdb353a_monopo_london_team2_.jpeg?auto=compress,format&rect=0,0,840,420&w=4&h=2",
                        id: k,
                        edit: {
                            x: b,
                            y: b,
                            zoom: .004761904761904762,
                            background: c
                        }
                    }
                },
                tokyo_founders_date: "2011",
                tokyo_founders_title: [{
                    type: f,
                    text: "Founded in Tokyo by Yoshi & shun",
                    spans: []
                }],
                tokyo_founders: [{
                    name: "Yoshiyuki Sasaki"
                }, {
                    name: "Shun okada"
                }],
                tokyo_founders_text: [{
                    type: d,
                    text: "monopo was founded in Tokyo in 2011 as a digital design agency. Yoshi and Shun, both bass players, felt that the digital space was losing its groove. It was creating characterless brands. Anonymous businesses. A sea of sameness. Together with a collective of artists and engineers, they set up monopo to bring personality back to brands.",
                    spans: []
                }],
                tokyo_founders_image: {
                    dimensions: {
                        width: z,
                        height: 490
                    },
                    alt: a,
                    copyright: a,
                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F2c748be8-ad2c-4f02-b42d-63d2bcd93f90_02_Yoshi-Shun.jpg?auto=compress,format&rect=4,0,1450,973&w=730&h=490",
                    id: l,
                    edit: {
                        x: -2,
                        y: b,
                        zoom: .5035971223021583,
                        background: c
                    },
                    retina: {
                        dimensions: {
                            width: A,
                            height: 980
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F2c748be8-ad2c-4f02-b42d-63d2bcd93f90_02_Yoshi-Shun.jpg?auto=compress,format&rect=4,0,1450,973&w=1460&h=980",
                        id: l,
                        edit: {
                            x: -4,
                            y: b,
                            zoom: 1.0071942446043165,
                            background: c
                        }
                    },
                    thumb: {
                        dimensions: {
                            width: e,
                            height: 3
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F2c748be8-ad2c-4f02-b42d-63d2bcd93f90_02_Yoshi-Shun.jpg?auto=compress,format&rect=0,0,1297,973&w=4&h=3",
                        id: l,
                        edit: {
                            x: b,
                            y: b,
                            zoom: .003083247687564234,
                            background: c
                        }
                    }
                },
                london_founders_date: "2019",
                london_founders_title: [{
                    type: f,
                    text: "London office founded by Mélanie & Mattijs",
                    spans: []
                }],
                london_founders: [{
                    name: "Mélanie hubert-crozet"
                }, {
                    name: "Mattijs Devroedt"
                }],
                london_founders_text: [{
                    type: d,
                    text: "The London office was founded in 2019 by Mélanie and Mattijs. Their combined backgrounds in digital design and advertising strategy allowed monopo london to attract a diverse range of projects from the start. Both Mélanie and Mattijs have spent several years living and working in Tokyo as well as London and are always looking to create a bridge between the two cities.",
                    spans: []
                }],
                london_founders_image: {
                    dimensions: {
                        width: 516,
                        height: 794
                    },
                    alt: a,
                    copyright: a,
                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fa227651f-d180-4147-9e6f-9eb2acc01e34_Mell%26Matt-photo.jpg?auto=compress,format&rect=0,0,1032,1588&w=516&h=794",
                    id: m,
                    edit: {
                        x: b,
                        y: b,
                        zoom: g,
                        background: c
                    },
                    retina: {
                        dimensions: {
                            width: 1032,
                            height: 1588
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fa227651f-d180-4147-9e6f-9eb2acc01e34_Mell%26Matt-photo.jpg?auto=compress,format&rect=0,0,1032,1588&w=1032&h=1588",
                        id: m,
                        edit: {
                            x: b,
                            y: b,
                            zoom: h,
                            background: c
                        }
                    },
                    thumb: {
                        dimensions: {
                            width: e,
                            height: 6
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fa227651f-d180-4147-9e6f-9eb2acc01e34_Mell%26Matt-photo.jpg?auto=compress,format&rect=0,0,1032,1548&w=4&h=6",
                        id: m,
                        edit: {
                            x: b,
                            y: b,
                            zoom: .003875968992248062,
                            background: c
                        }
                    }
                },
                places: [{
                    number_of_members: [{
                        type: d,
                        text: "6 members\nin London",
                        spans: []
                    }],
                    link: {
                        link_type: "Any"
                    },
                    link_label: a
                }, {
                    number_of_members: [{
                        type: d,
                        text: "30 members\nin Tokyo",
                        spans: []
                    }],
                    link: {
                        link_type: n,
                        key: "d98f5990-95bd-4178-86c8-3f892bd44c2c",
                        url: "https:\u002F\u002Fmonopo.co.jp\u002F",
                        target: o
                    },
                    link_label: "visit tokyo website"
                }, {
                    number_of_members: [{
                        type: d,
                        text: "2 members\nin New York",
                        spans: []
                    }],
                    link: {
                        link_type: n,
                        key: "f8cf30a3-1a7f-42a5-b858-51dca94659a6",
                        url: "https:\u002F\u002Fmonopo.nyc\u002F",
                        target: o
                    },
                    link_label: "visit NYC website"
                }, {
                    number_of_members: [{
                        type: d,
                        text: "2 members\nin Saigon",
                        spans: []
                    }],
                    link: {
                        link_type: n,
                        key: "98681d50-f06a-41a2-9f68-697ad7ee14db",
                        url: "https:\u002F\u002Fmonopo.vn\u002F",
                        target: o
                    },
                    link_label: "visit Saigon website"
                }],
                community_title: [{
                    type: f,
                    text: "A community of talented independent spirits",
                    spans: []
                }],
                community_text: [{
                    type: d,
                    text: "The community is where we find the kind of diversity of expertise that can never be brought in house. We collaborate with specialists that bring unique perspectives and skills.",
                    spans: []
                }],
                community_list: [{
                    label: "Developers"
                }, {
                    label: "3D artists"
                }, {
                    label: "Illustrators"
                }, {
                    label: "Motion designers"
                }, {
                    label: "Photographers"
                }, {
                    label: "Film directors"
                }, {
                    label: "Copywriters"
                }, {
                    label: "Strategists"
                }, {
                    label: "Musicians"
                }, {
                    label: B
                }, {
                    label: "Models"
                }, {
                    label: "Influencers"
                }, {
                    label: C
                }, {
                    label: B
                }, {
                    label: C
                }, {
                    label: "PR agencies"
                }, {
                    label: "Research agencies"
                }, {
                    label: "Media agencies"
                }, {
                    label: "Architects"
                }, {
                    label: "You?"
                }],
                community_image: {
                    dimensions: {
                        width: z,
                        height: 432
                    },
                    alt: a,
                    copyright: a,
                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F25707cc9-7b5d-4a85-8dd7-d137f5e35fa2_community.jpg?auto=compress,format&rect=0,0,1458,863&w=730&h=432",
                    id: p,
                    edit: {
                        x: b,
                        y: b,
                        zoom: .5005793742757821,
                        background: c
                    },
                    retina: {
                        dimensions: {
                            width: A,
                            height: 864
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F25707cc9-7b5d-4a85-8dd7-d137f5e35fa2_community.jpg?auto=compress,format&rect=1,0,1458,863&w=1460&h=864",
                        id: p,
                        edit: {
                            x: -1,
                            y: b,
                            zoom: 1.0011587485515643,
                            background: c
                        }
                    },
                    thumb: {
                        dimensions: {
                            width: e,
                            height: i
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F25707cc9-7b5d-4a85-8dd7-d137f5e35fa2_community.jpg?auto=compress,format&rect=0,0,1460,730&w=4&h=2",
                        id: p,
                        edit: {
                            x: b,
                            y: b,
                            zoom: .0027397260273972603,
                            background: c
                        }
                    }
                },
                studio_title: [{
                    type: f,
                    text: "A peek inside our Spitalfields studio →",
                    spans: []
                }],
                studio_gallery: [{
                    image: {
                        dimensions: {
                            width: q,
                            height: r
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc26b5d48-4e59-47af-83d2-271e09919ed7_monopo_london_office_01_t.jpeg?auto=compress,format&rect=0,0,2060,1158&w=1030&h=579",
                        id: s,
                        edit: {
                            x: b,
                            y: b,
                            zoom: g,
                            background: c
                        },
                        retina: {
                            dimensions: {
                                width: t,
                                height: u
                            },
                            alt: a,
                            copyright: a,
                            url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc26b5d48-4e59-47af-83d2-271e09919ed7_monopo_london_office_01_t.jpeg?auto=compress,format&rect=0,0,2060,1158&w=2060&h=1158",
                            id: s,
                            edit: {
                                x: b,
                                y: b,
                                zoom: h,
                                background: c
                            }
                        },
                        thumb: {
                            dimensions: {
                                width: e,
                                height: i
                            },
                            alt: a,
                            copyright: a,
                            url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc26b5d48-4e59-47af-83d2-271e09919ed7_monopo_london_office_01_t.jpeg?auto=compress,format&rect=0,0,2060,1030&w=4&h=2",
                            id: s,
                            edit: {
                                x: b,
                                y: b,
                                zoom: v,
                                background: c
                            }
                        }
                    }
                }, {
                    image: {
                        dimensions: {
                            width: q,
                            height: r
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F99fbc00e-8812-4bbb-ae85-461dcdc3ad83_monopo_london_office_02_t.jpeg?auto=compress,format&rect=0,0,2060,1158&w=1030&h=579",
                        id: w,
                        edit: {
                            x: b,
                            y: b,
                            zoom: g,
                            background: c
                        },
                        retina: {
                            dimensions: {
                                width: t,
                                height: u
                            },
                            alt: a,
                            copyright: a,
                            url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F99fbc00e-8812-4bbb-ae85-461dcdc3ad83_monopo_london_office_02_t.jpeg?auto=compress,format&rect=0,0,2060,1158&w=2060&h=1158",
                            id: w,
                            edit: {
                                x: b,
                                y: b,
                                zoom: h,
                                background: c
                            }
                        },
                        thumb: {
                            dimensions: {
                                width: e,
                                height: i
                            },
                            alt: a,
                            copyright: a,
                            url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F99fbc00e-8812-4bbb-ae85-461dcdc3ad83_monopo_london_office_02_t.jpeg?auto=compress,format&rect=0,0,2060,1030&w=4&h=2",
                            id: w,
                            edit: {
                                x: b,
                                y: b,
                                zoom: v,
                                background: c
                            }
                        }
                    }
                }, {
                    image: {
                        dimensions: {
                            width: q,
                            height: r
                        },
                        alt: a,
                        copyright: a,
                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F60ebb3f4-9cc4-451d-90da-39c176a4e5b5_monopo_london_office_03_t.jpeg?auto=compress,format&rect=0,0,2060,1158&w=1030&h=579",
                        id: x,
                        edit: {
                            x: b,
                            y: b,
                            zoom: g,
                            background: c
                        },
                        retina: {
                            dimensions: {
                                width: t,
                                height: u
                            },
                            alt: a,
                            copyright: a,
                            url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F60ebb3f4-9cc4-451d-90da-39c176a4e5b5_monopo_london_office_03_t.jpeg?auto=compress,format&rect=0,0,2060,1158&w=2060&h=1158",
                            id: x,
                            edit: {
                                x: b,
                                y: b,
                                zoom: h,
                                background: c
                            }
                        },
                        thumb: {
                            dimensions: {
                                width: e,
                                height: i
                            },
                            alt: a,
                            copyright: a,
                            url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F60ebb3f4-9cc4-451d-90da-39c176a4e5b5_monopo_london_office_03_t.jpeg?auto=compress,format&rect=0,0,2060,1030&w=4&h=2",
                            id: x,
                            edit: {
                                x: b,
                                y: b,
                                zoom: v,
                                background: c
                            }
                        }
                    }
                }],
                jobs_title: [{
                    type: f,
                    text: "We would love to work with you.",
                    spans: []
                }],
                careers_title: [{
                    type: D,
                    text: "Open applications",
                    spans: []
                }],
                careers_paragraph: [{
                    type: d,
                    text: "We don’t have open vacancies at the moment, but that can change quickly. If you are interested in submitting an open application, we very much look forward to receiving it. You can share your CV, portfolio and cover letter via contact@monopo.london.",
                    spans: [{
                        start: 227,
                        end: 249,
                        type: E
                    }]
                }],
                freelance_title: [{
                    type: D,
                    text: "Freelance collaborators",
                    spans: []
                }],
                freelance_paragraph: [{
                    type: d,
                    text: "We are always looking for talented freelance collaborators. Please get in touch with us if you are a freelance designer, photographer, developer, director, copywriter, juggler, meme artist, or influencer. We want to hear about your skills and passions, no matter how niche they are. You can reach us via contact@monopo.london\n\n",
                    spans: [{
                        start: 304,
                        end: 327,
                        type: E
                    }]
                }],
                meta_title: "monopo london | Team",
                meta_description: y
            }
        }],
        fetch: {},
        mutations: []
    }
}(null, 0, "#fff", "paragraph", 4, "heading2", .5, 1, 2, "heading1", "YOgtpBMAACEApq1Q", "YNsb8xAAACUAO86c", "YNsdXBAAACMAO9TW", "Web", "_blank", "YNseZBAAACQAO9kr", 1030, 579, "YT-iOREAACMA54vz", 2060, 1158, .001941747572815534, "YT-iOhEAACUA54v5", "YT-iOREAACIA54v0", "We collaborate as a collective of individuals bringing their whole self to a project and, together, create work that none of us would be able to do on our own.", 730, 1460, "Artists", "Event agencies", "heading3", "strong")));