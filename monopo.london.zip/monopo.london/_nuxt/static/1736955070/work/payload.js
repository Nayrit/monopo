__NUXT_JSONP__("/work", (function(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z, _, $, aa, ab, ac, ad, ae, af, ag, ah) {
    return {
        data: [{
            document: {
                subtitle: [{
                    type: B,
                    text: "Our work",
                    spans: []
                }],
                title: [{
                    type: r,
                    text: "We choose a different → starting point",
                    spans: []
                }],
                japanese_title: a,
                paragraph: [{
                    type: "paragraph",
                    text: "Every project is a chance to try something new. Look at something with a fresh perspective. Do something for the first time.",
                    spans: []
                }],
                gradient: "\u003Cmonopo-gradient color1=\"#CF0F02\" color2=\"#FFBB4D\" color3=\"#65D7E1\" color4=\"#017FF7\" colorsize=\"0.75\" colorspacing=\"0.52\" colorrotation=\"-0.381592653589793\" colorspread=\"4.52\" coloroffset=\"-0.7741174697875977,-0.20644775390624992\" displacement=\"4.66\" seed=\"-0.06\" position=\"-0.2816110610961914,-0.43914794921875\" zoom=\"0.72\" spacing=\"4.27\"\u003E\u003C\u002Fmonopo-gradient\u003E",
                collections: [{
                    collection_subtitle: [{
                        type: I,
                        text: J,
                        spans: []
                    }],
                    collection_title: [{
                        type: B,
                        text: "Integrated Campaigns",
                        spans: []
                    }],
                    collection_project_one: {
                        id: "YPBECBMAACEAya3J",
                        type: s,
                        tags: [],
                        lang: f,
                        slug: "onefinestay--unlock-your-dream-stay-campaign",
                        first_publication_date: "2021-07-15T14:20:39+0000",
                        last_publication_date: "2021-10-10T21:20:27+0000",
                        uid: "onefinestay-unlock-your-dream-campaign",
                        data: {
                            thumbnail: [{
                                image: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fabb53b73-caae-41d2-9031-f889aa27780d_onefinestay_thumb.jpeg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: K,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fabb53b73-caae-41d2-9031-f889aa27780d_onefinestay_thumb.jpeg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: K,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fabb53b73-caae-41d2-9031-f889aa27780d_onefinestay_thumb.jpeg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: K,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                },
                                image_reveal: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F33b736fe-816e-4944-9c5f-31e5064a35b5_onefinestay_thumb_reveal.jpeg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: L,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F33b736fe-816e-4944-9c5f-31e5064a35b5_onefinestay_thumb_reveal.jpeg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: L,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F33b736fe-816e-4944-9c5f-31e5064a35b5_onefinestay_thumb_reveal.jpeg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: L,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                }
                            }],
                            title: [{
                                type: r,
                                text: "onefinestay ‣ Unlock your dream stay Campaign",
                                spans: []
                            }],
                            categories: [{
                                category: {
                                    id: t,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: u,
                                    first_publication_date: v,
                                    last_publication_date: w,
                                    uid: x,
                                    link_type: e,
                                    key: "a30e4edf-8aaa-4269-b51d-415dd8c5682c",
                                    isBroken: d
                                }
                            }]
                        },
                        link_type: e,
                        key: "ade937d2-3dbd-40ca-9ce5-054e4faff96c",
                        isBroken: d,
                        isHide: d
                    },
                    collection_project_two: {
                        id: "YPgMaBMAACAA67mj",
                        type: s,
                        tags: [],
                        lang: f,
                        slug: "yonex-astrox-88-sd-launch-campaign",
                        first_publication_date: "2021-07-21T12:04:28+0000",
                        last_publication_date: "2021-09-19T20:34:24+0000",
                        uid: "yonex-astrox-88sd-launch-campaign",
                        data: {
                            thumbnail: [{
                                image: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc2f98f36-1aab-4644-8b2c-756722e4ca90_thumbnail3.jpg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: M,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc2f98f36-1aab-4644-8b2c-756722e4ca90_thumbnail3.jpg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: M,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc2f98f36-1aab-4644-8b2c-756722e4ca90_thumbnail3.jpg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: M,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                },
                                image_reveal: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F3382f7b3-acec-4b10-b9d6-dcb9882559cb_thumbnail4.jpg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: N,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F3382f7b3-acec-4b10-b9d6-dcb9882559cb_thumbnail4.jpg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: N,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F3382f7b3-acec-4b10-b9d6-dcb9882559cb_thumbnail4.jpg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: N,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                }
                            }],
                            title: [{
                                type: r,
                                text: "YONEX ASTROX 88 S&D Launch Campaign",
                                spans: []
                            }],
                            categories: [{
                                category: {
                                    id: t,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: u,
                                    first_publication_date: v,
                                    last_publication_date: w,
                                    uid: x,
                                    link_type: e,
                                    key: "63d8b0f7-30af-4cd1-8fbc-68ae587365c2",
                                    isBroken: d
                                }
                            }, {
                                category: {
                                    id: y,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: q,
                                    first_publication_date: z,
                                    last_publication_date: A,
                                    uid: q,
                                    link_type: e,
                                    key: "7c7dac31-006b-4a16-b122-47642fd876aa",
                                    isBroken: d
                                }
                            }, {
                                category: {
                                    id: _,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: C,
                                    first_publication_date: D,
                                    last_publication_date: D,
                                    uid: C,
                                    link_type: e,
                                    key: "3f7d36d7-b17a-41ea-b779-50eea7495079",
                                    isBroken: d
                                }
                            }]
                        },
                        link_type: e,
                        key: "1ff32e9b-2652-44b8-8d8c-450ac1ce6eea",
                        isBroken: d,
                        isHide: d
                    },
                    collection_project_three: {
                        id: "YRq4VBAAACEANtvz",
                        type: s,
                        tags: [],
                        lang: f,
                        slug: "canada-goose--the-art-of-film-ar-tour-berlin",
                        first_publication_date: "2021-08-16T19:11:21+0000",
                        last_publication_date: "2021-10-10T21:19:59+0000",
                        uid: "canada-goose-the-art-of-film-berlin-2021",
                        data: {
                            thumbnail: [{
                                image: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc01e934a-f10f-4f1e-a1e2-353e33d5f3ba_canadagoose_theartoffilm_thumb_01+%281%29.jpeg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: O,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc01e934a-f10f-4f1e-a1e2-353e33d5f3ba_canadagoose_theartoffilm_thumb_01+%281%29.jpeg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: O,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc01e934a-f10f-4f1e-a1e2-353e33d5f3ba_canadagoose_theartoffilm_thumb_01+%281%29.jpeg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: O,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                },
                                image_reveal: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fb03e73d7-59ef-4ca0-9600-2b6618c02fbd_CG_thumbnail_reveal_img.jpg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: P,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fb03e73d7-59ef-4ca0-9600-2b6618c02fbd_CG_thumbnail_reveal_img.jpg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: P,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fb03e73d7-59ef-4ca0-9600-2b6618c02fbd_CG_thumbnail_reveal_img.jpg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: P,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                }
                            }],
                            title: [{
                                type: r,
                                text: "Canada Goose ‣ The Art of Film AR Tour Berlin",
                                spans: []
                            }],
                            categories: [{
                                category: {
                                    id: t,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: u,
                                    first_publication_date: v,
                                    last_publication_date: w,
                                    uid: x,
                                    link_type: e,
                                    key: "4c05dd71-8809-4200-989a-1b2b1e09f4fa",
                                    isBroken: d
                                }
                            }, {
                                category: {
                                    id: y,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: q,
                                    first_publication_date: z,
                                    last_publication_date: A,
                                    uid: q,
                                    link_type: e,
                                    key: "f63a1f39-0ce3-427b-b165-e58e459500ba",
                                    isBroken: d
                                }
                            }, {
                                category: {
                                    id: _,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: C,
                                    first_publication_date: D,
                                    last_publication_date: D,
                                    uid: C,
                                    link_type: e,
                                    key: "726b4466-9acd-474b-9928-ad4b7b64eab3",
                                    isBroken: d
                                }
                            }]
                        },
                        link_type: e,
                        key: "d1688cf5-7a6a-4589-8952-17725f7968a9",
                        isBroken: d,
                        isHide: d
                    }
                }, {
                    collection_subtitle: [{
                        type: I,
                        text: J,
                        spans: []
                    }],
                    collection_title: [{
                        type: B,
                        text: "The medium is the message",
                        spans: []
                    }],
                    collection_project_one: {
                        id: "YMI20BMAACQAav5l",
                        type: s,
                        tags: [],
                        lang: f,
                        slug: "super-dan-origin--digital-graphic-novel",
                        first_publication_date: "2021-06-10T15:59:15+0000",
                        last_publication_date: "2022-07-01T16:58:42+0000",
                        uid: "super-dan-origin",
                        data: {
                            thumbnail: [{
                                image: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fd2bd0fd3-59e7-4968-a91d-799655716459_superdanorigin_lindan_thumb_1.jpeg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: Q,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fd2bd0fd3-59e7-4968-a91d-799655716459_superdanorigin_lindan_thumb_1.jpeg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: Q,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fd2bd0fd3-59e7-4968-a91d-799655716459_superdanorigin_lindan_thumb_1.jpeg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: Q,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                },
                                image_reveal: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Feba00c54-4e2c-41de-83f1-2da22ec7fa76_superdanorigin_lindan_thumb_2.jpeg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: R,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Feba00c54-4e2c-41de-83f1-2da22ec7fa76_superdanorigin_lindan_thumb_2.jpeg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: R,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Feba00c54-4e2c-41de-83f1-2da22ec7fa76_superdanorigin_lindan_thumb_2.jpeg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: R,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                }
                            }],
                            title: [{
                                type: r,
                                text: "SUPER DAN ORIGIN ‣ DIGITAL GRAPHIC NOVEL",
                                spans: []
                            }],
                            categories: [{
                                category: {
                                    id: t,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: u,
                                    first_publication_date: v,
                                    last_publication_date: w,
                                    uid: x,
                                    link_type: e,
                                    key: "1100d561-64bc-40af-84d4-8618d9579d9f",
                                    isBroken: d
                                }
                            }, {
                                category: {
                                    id: $,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: E,
                                    first_publication_date: F,
                                    last_publication_date: F,
                                    uid: E,
                                    link_type: e,
                                    key: "1dfc38aa-87d7-410e-9658-6b55f541489b",
                                    isBroken: d
                                }
                            }]
                        },
                        link_type: e,
                        key: "13f94833-f311-4a35-a3a9-88deac285970",
                        isBroken: d
                    },
                    collection_project_two: {
                        id: "YOTQTRMAACIAmF44",
                        type: s,
                        tags: [],
                        lang: f,
                        slug: "canada-goose--city-sense-urban-excursion-guides",
                        first_publication_date: "2021-07-06T22:18:17+0000",
                        last_publication_date: "2021-10-10T21:29:59+0000",
                        uid: "canada-goose-city-sense-urban-excursion-guides",
                        data: {
                            thumbnail: [{
                                image: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F7f176883-4850-4bbc-8b2d-244651892779_citysense_thumb1.jpeg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: S,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F7f176883-4850-4bbc-8b2d-244651892779_citysense_thumb1.jpeg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: S,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F7f176883-4850-4bbc-8b2d-244651892779_citysense_thumb1.jpeg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: S,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                },
                                image_reveal: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fe9cc1a6b-cb87-49cb-a535-ed9205454dad_citysense_thumb2.jpeg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: T,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fe9cc1a6b-cb87-49cb-a535-ed9205454dad_citysense_thumb2.jpeg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: T,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fe9cc1a6b-cb87-49cb-a535-ed9205454dad_citysense_thumb2.jpeg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: T,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                }
                            }],
                            title: [{
                                type: r,
                                text: "Canada Goose ‣ City Sense: Urban excursion guides",
                                spans: []
                            }],
                            categories: [{
                                category: {
                                    id: aa,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: G,
                                    first_publication_date: H,
                                    last_publication_date: H,
                                    uid: G,
                                    link_type: e,
                                    key: "f6908df5-6ad1-4b1b-8c74-0f321b0f027b",
                                    isBroken: d
                                }
                            }]
                        },
                        link_type: e,
                        key: "5fd545b0-07b0-4536-bde1-80937de46c88",
                        isBroken: d
                    },
                    collection_project_three: {
                        id: "YOg5URMAACIApuFv",
                        type: "broken_type",
                        tags: [],
                        lang: a,
                        slug: "-",
                        first_publication_date: a,
                        last_publication_date: a,
                        link_type: e,
                        key: "7548b628-ff27-4310-9f53-803286c6ef57",
                        isBroken: true
                    }
                }, {
                    collection_subtitle: [{
                        type: I,
                        text: J,
                        spans: []
                    }],
                    collection_title: [{
                        type: B,
                        text: "Bringing personality to digital",
                        spans: []
                    }],
                    collection_project_one: {
                        id: "YQrA5hIAACkAGhaG",
                        type: s,
                        tags: [],
                        lang: f,
                        slug: "we-are-third--brand-identity-and-website",
                        first_publication_date: "2021-08-04T16:32:01+0000",
                        last_publication_date: "2022-07-01T16:57:33+0000",
                        uid: "we-are-third-website",
                        data: {
                            thumbnail: [{
                                image: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F7147d9e9-6b09-495a-9a62-04945b8c5aa0_thumbnail_workpage.jpg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: U,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F7147d9e9-6b09-495a-9a62-04945b8c5aa0_thumbnail_workpage.jpg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: U,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F7147d9e9-6b09-495a-9a62-04945b8c5aa0_thumbnail_workpage.jpg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: U,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                },
                                image_reveal: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc4d1ae7b-7f11-48a3-9590-88d0fdb8b083_thumbnail_workpage_reveal.jpg?auto=compress,format&rect=0,0,1200,1436&w=600&h=718",
                                    id: V,
                                    edit: {
                                        x: b,
                                        y: b,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc4d1ae7b-7f11-48a3-9590-88d0fdb8b083_thumbnail_workpage_reveal.jpg?auto=compress,format&rect=0,0,1200,1436&w=1200&h=1436",
                                        id: V,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc4d1ae7b-7f11-48a3-9590-88d0fdb8b083_thumbnail_workpage_reveal.jpg?auto=compress,format&rect=0,0,1149,1436&w=4&h=5",
                                        id: V,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: p,
                                            background: c
                                        }
                                    }
                                }
                            }],
                            title: [{
                                type: r,
                                text: "We Are Third ‣ Brand identity and Website",
                                spans: []
                            }],
                            categories: [{
                                category: {
                                    id: aa,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: G,
                                    first_publication_date: H,
                                    last_publication_date: H,
                                    uid: G,
                                    link_type: e,
                                    key: "71f94e8e-ad31-491a-90e4-32018436757a",
                                    isBroken: d
                                }
                            }, {
                                category: {
                                    id: y,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: q,
                                    first_publication_date: z,
                                    last_publication_date: A,
                                    uid: q,
                                    link_type: e,
                                    key: "a4a7e08a-8b5d-45ef-aab7-179937e33393",
                                    isBroken: d
                                }
                            }, {
                                category: {
                                    id: $,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: E,
                                    first_publication_date: F,
                                    last_publication_date: F,
                                    uid: E,
                                    link_type: e,
                                    key: "4a8d7012-b0a7-404d-8082-ab2d148f4c52",
                                    isBroken: d
                                }
                            }]
                        },
                        link_type: e,
                        key: "484e9cd8-d0e6-4334-9c46-c67c6b9cf11b",
                        isBroken: d
                    },
                    collection_project_two: {
                        id: "YMITzxMAACQAamSa",
                        type: s,
                        tags: [],
                        lang: f,
                        slug: "lin-dan-x-yonex--the-memories-we-shared-campaign",
                        first_publication_date: "2021-06-10T14:15:06+0000",
                        last_publication_date: "2021-10-10T21:23:38+0000",
                        uid: "lin-dan-x-yonex-the-memories-we-shared",
                        data: {
                            thumbnail: [{
                                image: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc3ad8502-68ab-437b-901c-d155e95a9adb_Lin+Dan+x+Yonex.jpg?auto=compress,format&rect=0,23,1159,1387&w=600&h=718",
                                    id: W,
                                    edit: {
                                        x: b,
                                        y: ab,
                                        zoom: ac,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc3ad8502-68ab-437b-901c-d155e95a9adb_Lin+Dan+x+Yonex.jpg?auto=compress,format&rect=0,24,1159,1387&w=1200&h=1436",
                                        id: W,
                                        edit: {
                                            x: b,
                                            y: ad,
                                            zoom: ae,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Fc3ad8502-68ab-437b-901c-d155e95a9adb_Lin+Dan+x+Yonex.jpg?auto=compress,format&rect=0,0,1148,1435&w=4&h=5",
                                        id: W,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: af,
                                            background: c
                                        }
                                    }
                                },
                                image_reveal: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Ff468a913-c9ff-496a-9489-74276c333ade_Lin+Dan+x+Yonex+-+1.jpg?auto=compress,format&rect=1017,0,1806,2161&w=600&h=718",
                                    id: X,
                                    edit: {
                                        x: -338,
                                        y: b,
                                        zoom: .3322535863026377,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Ff468a913-c9ff-496a-9489-74276c333ade_Lin+Dan+x+Yonex+-+1.jpg?auto=compress,format&rect=1017,0,1806,2161&w=1200&h=1436",
                                        id: X,
                                        edit: {
                                            x: -676,
                                            y: b,
                                            zoom: .6645071726052754,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: 2
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Ff468a913-c9ff-496a-9489-74276c333ade_Lin+Dan+x+Yonex+-+1.jpg?auto=compress,format&rect=0,0,3840,1920&w=4&h=2",
                                        id: X,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: .0010416666666666667,
                                            background: c
                                        }
                                    }
                                }
                            }],
                            title: [{
                                type: r,
                                text: "Lin Dan x Yonex ‣ The Memories We Shared Campaign",
                                spans: []
                            }],
                            categories: [{
                                category: {
                                    id: t,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: u,
                                    first_publication_date: v,
                                    last_publication_date: w,
                                    uid: x,
                                    link_type: e,
                                    key: "1bf746f8-baa6-422f-b31a-0e085b01a34d",
                                    isBroken: d
                                }
                            }, {
                                category: {
                                    id: y,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: q,
                                    first_publication_date: z,
                                    last_publication_date: A,
                                    uid: q,
                                    link_type: e,
                                    key: "b2cef6ae-1da5-4f5d-8c43-096303494c68",
                                    isBroken: d
                                }
                            }]
                        },
                        link_type: e,
                        key: "a29c5589-c1df-4e22-88de-1d30fd9d3077",
                        isBroken: d
                    },
                    collection_project_three: {
                        id: "YMI1pBMAACQAavkf",
                        type: s,
                        tags: [],
                        lang: f,
                        slug: "jetro-japanese-green-tea--us-campaign-website",
                        first_publication_date: "2021-06-10T15:54:52+0000",
                        last_publication_date: "2021-10-10T21:28:11+0000",
                        uid: "ocha-jetro-japanese-green-tea",
                        data: {
                            thumbnail: [{
                                image: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Ffd9c2092-e0db-4590-837e-497f6086a601_japanese_green_tea.jpg?auto=compress,format&rect=0,23,1159,1387&w=600&h=718",
                                    id: Y,
                                    edit: {
                                        x: b,
                                        y: ab,
                                        zoom: ac,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Ffd9c2092-e0db-4590-837e-497f6086a601_japanese_green_tea.jpg?auto=compress,format&rect=0,24,1159,1387&w=1200&h=1436",
                                        id: Y,
                                        edit: {
                                            x: b,
                                            y: ad,
                                            zoom: ae,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002Ffd9c2092-e0db-4590-837e-497f6086a601_japanese_green_tea.jpg?auto=compress,format&rect=0,0,1148,1435&w=4&h=5",
                                        id: Y,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: af,
                                            background: c
                                        }
                                    }
                                },
                                image_reveal: {
                                    dimensions: {
                                        width: h,
                                        height: i
                                    },
                                    alt: a,
                                    copyright: a,
                                    url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F337ab41d-a98b-4f18-ae49-83f644fe7b7c_Japanese_green_tea_matcha_photography_stillife.jpeg?auto=compress,format&rect=0,32,1200,1436&w=600&h=718",
                                    id: Z,
                                    edit: {
                                        x: b,
                                        y: -16,
                                        zoom: n,
                                        background: c
                                    },
                                    retina: {
                                        dimensions: {
                                            width: j,
                                            height: k
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F337ab41d-a98b-4f18-ae49-83f644fe7b7c_Japanese_green_tea_matcha_photography_stillife.jpeg?auto=compress,format&rect=0,32,1200,1436&w=1200&h=1436",
                                        id: Z,
                                        edit: {
                                            x: b,
                                            y: -32,
                                            zoom: o,
                                            background: c
                                        }
                                    },
                                    thumb: {
                                        dimensions: {
                                            width: l,
                                            height: m
                                        },
                                        alt: a,
                                        copyright: a,
                                        url: "https:\u002F\u002Fimages.prismic.io\u002Fmonopolondon\u002F337ab41d-a98b-4f18-ae49-83f644fe7b7c_Japanese_green_tea_matcha_photography_stillife.jpeg?auto=compress,format&rect=0,0,1200,1500&w=4&h=5",
                                        id: Z,
                                        edit: {
                                            x: b,
                                            y: b,
                                            zoom: .0033333333333333335,
                                            background: c
                                        }
                                    }
                                }
                            }],
                            title: [{
                                type: r,
                                text: "JETRO Japanese Green Tea ‣ US Campaign Website",
                                spans: []
                            }],
                            categories: [{
                                category: {
                                    id: t,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: u,
                                    first_publication_date: v,
                                    last_publication_date: w,
                                    uid: x,
                                    link_type: e,
                                    key: "a7f918dc-904f-40e7-89ec-0900529b8b2c",
                                    isBroken: d
                                }
                            }, {
                                category: {
                                    id: y,
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: q,
                                    first_publication_date: z,
                                    last_publication_date: A,
                                    uid: q,
                                    link_type: e,
                                    key: "90443444-ea0f-4d8e-8366-76dfa658a250",
                                    isBroken: d
                                }
                            }, {
                                category: {
                                    id: "YMISgRMAACMAamE-",
                                    type: g,
                                    tags: [],
                                    lang: f,
                                    slug: ag,
                                    first_publication_date: ah,
                                    last_publication_date: ah,
                                    uid: ag,
                                    link_type: e,
                                    key: "01cdb816-818f-46f8-a631-a3be7aad01dd",
                                    isBroken: d
                                }
                            }]
                        },
                        link_type: e,
                        key: "2ad1dde1-69e1-4f5c-bbcd-cfd32fa7f350",
                        isBroken: d
                    }
                }],
                meta_title: a,
                meta_description: a
            }
        }],
        fetch: {},
        mutations: []
    }
}(null, 0, "#fff", false, "Document", "en-gb", "category", 600, 718, 1200, 1436, 4, 5, .5, 1, .003481894150417827, "digital", "heading1", "project", "YMISWBMAACEAamDk", "campaign", "2021-06-10T13:23:44+0000", "2024-09-05T13:25:11+0000", "campaigns", "YMISKBMAACIAamAA", "2021-06-10T13:22:50+0000", "2022-07-01T17:04:00+0000", "heading2", "video", "2021-06-10T13:23:05+0000", "illustration", "2022-07-01T16:56:38+0000", "brand-design", "2021-06-10T13:22:34+0000", "heading3", "What we could do together", "YPBDXBMAACEAyarM", "YPBDXBMAACEAyarJ", "YQlk7BIAACYAFC5Z", "YQlk7BIAACgAFC5a", "YRq80hAAACEANu_C", "YTo87BEAACIA0BcO", "YT5zAhEAACQA4nkM", "YT53XxEAACIA4ow9", "YT6BchEAACUA4rhL", "YT6BcREAACUA4rhG", "YT80qREAACIA5crn", "YT80qREAACMA5cro", "YMIeOBMAACEAapJT", "YMIWghMAACEAanAY", "YMI1mxMAACIAavj8", "YORPpBMAACEAlj6U", "YMISNRMAACQAamBB", "Yr8nPhEAACEA1cFp", "YMISFhMAACEAal_B", -11, .5176876617773943, -25, 1.0353753235547887, .003484320557491289, "photography", "2021-06-10T13:24:20+0000")));