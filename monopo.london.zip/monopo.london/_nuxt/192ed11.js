(window.webpackJsonp = window.webpackJsonp || []).push([
    [0], {
        477: function(module, exports, __webpack_require__) {
            var __WEBPACK_AMD_DEFINE_RESULT__, root, factory;
            "undefined" != typeof navigator && (root = window || {}, factory = function(window) {
                "use strict";
                var svgNS = "http://www.w3.org/2000/svg",
                    locationHref = "",
                    initialDefaultFrame = -999999,
                    _useWebWorker = !1,
                    subframeEnabled = !0,
                    idPrefix = "",
                    expressionsPlugin, isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent),
                    cachedColors = {},
                    bmRnd, bmPow = Math.pow,
                    bmSqrt = Math.sqrt,
                    bmFloor = Math.floor,
                    bmMax = Math.max,
                    bmMin = Math.min,
                    BMMath = {};

                function ProjectInterface() {
                    return {}
                }! function() {
                    var i, t = ["abs", "acos", "acosh", "asin", "asinh", "atan", "atanh", "atan2", "ceil", "cbrt", "expm1", "clz32", "cos", "cosh", "exp", "floor", "fround", "hypot", "imul", "log", "log1p", "log2", "log10", "max", "min", "pow", "random", "round", "sign", "sin", "sinh", "sqrt", "tan", "tanh", "trunc", "E", "LN10", "LN2", "LOG10E", "LOG2E", "PI", "SQRT1_2", "SQRT2"],
                        e = t.length;
                    for (i = 0; i < e; i += 1) BMMath[t[i]] = Math[t[i]]
                }(), BMMath.random = Math.random, BMMath.abs = function(t) {
                    if ("object" == typeof t && t.length) {
                        var i, e = createSizedArray(t.length),
                            r = t.length;
                        for (i = 0; i < r; i += 1) e[i] = Math.abs(t[i]);
                        return e
                    }
                    return Math.abs(t)
                };
                var defaultCurveSegments = 150,
                    degToRads = Math.PI / 180,
                    roundCorner = .5519;

                function roundValues(t) {
                    bmRnd = t ? Math.round : function(t) {
                        return t
                    }
                }

                function styleDiv(element) {
                    element.style.position = "absolute", element.style.top = 0, element.style.left = 0, element.style.display = "block", element.style.transformOrigin = "0 0", element.style.webkitTransformOrigin = "0 0", element.style.backfaceVisibility = "visible", element.style.webkitBackfaceVisibility = "visible", element.style.transformStyle = "preserve-3d", element.style.webkitTransformStyle = "preserve-3d", element.style.mozTransformStyle = "preserve-3d"
                }

                function BMEnterFrameEvent(t, e, r, n) {
                    this.type = t, this.currentTime = e, this.totalTime = r, this.direction = n < 0 ? -1 : 1
                }

                function BMCompleteEvent(t, e) {
                    this.type = t, this.direction = e < 0 ? -1 : 1
                }

                function BMCompleteLoopEvent(t, e, r, n) {
                    this.type = t, this.currentLoop = r, this.totalLoops = e, this.direction = n < 0 ? -1 : 1
                }

                function BMSegmentStartEvent(t, e, r) {
                    this.type = t, this.firstFrame = e, this.totalFrames = r
                }

                function BMDestroyEvent(t, e) {
                    this.type = t, this.target = e
                }

                function BMRenderFrameErrorEvent(t, e) {
                    this.type = "renderFrameError", this.nativeError = t, this.currentTime = e
                }

                function BMConfigErrorEvent(t) {
                    this.type = "configError", this.nativeError = t
                }

                function BMAnimationConfigErrorEvent(t, e) {
                    this.type = t, this.nativeError = e
                }
                roundValues(!1);
                var createElementID = (_count = 0, function() {
                        return idPrefix + "__lottie_element_" + (_count += 1)
                    }),
                    _count;

                function HSVtoRGB(t, s, e) {
                    var r, g, b, i, n, p, q, o;
                    switch (p = e * (1 - s), q = e * (1 - (n = 6 * t - (i = Math.floor(6 * t))) * s), o = e * (1 - (1 - n) * s), i % 6) {
                        case 0:
                            r = e, g = o, b = p;
                            break;
                        case 1:
                            r = q, g = e, b = p;
                            break;
                        case 2:
                            r = p, g = e, b = o;
                            break;
                        case 3:
                            r = p, g = q, b = e;
                            break;
                        case 4:
                            r = o, g = p, b = e;
                            break;
                        case 5:
                            r = e, g = p, b = q
                    }
                    return [r, g, b]
                }

                function RGBtoHSV(t, g, b) {
                    var e, r = Math.max(t, g, b),
                        n = Math.min(t, g, b),
                        o = r - n,
                        s = 0 === r ? 0 : o / r,
                        h = r / 255;
                    switch (r) {
                        case n:
                            e = 0;
                            break;
                        case t:
                            e = g - b + o * (g < b ? 6 : 0), e /= 6 * o;
                            break;
                        case g:
                            e = b - t + 2 * o, e /= 6 * o;
                            break;
                        case b:
                            e = t - g + 4 * o, e /= 6 * o
                    }
                    return [e, s, h]
                }

                function addSaturationToRGB(t, e) {
                    var r = RGBtoHSV(255 * t[0], 255 * t[1], 255 * t[2]);
                    return r[1] += e, r[1] > 1 ? r[1] = 1 : r[1] <= 0 && (r[1] = 0), HSVtoRGB(r[0], r[1], r[2])
                }

                function addBrightnessToRGB(t, e) {
                    var r = RGBtoHSV(255 * t[0], 255 * t[1], 255 * t[2]);
                    return r[2] += e, r[2] > 1 ? r[2] = 1 : r[2] < 0 && (r[2] = 0), HSVtoRGB(r[0], r[1], r[2])
                }

                function addHueToRGB(t, e) {
                    var r = RGBtoHSV(255 * t[0], 255 * t[1], 255 * t[2]);
                    return r[0] += e / 360, r[0] > 1 ? r[0] -= 1 : r[0] < 0 && (r[0] += 1), HSVtoRGB(r[0], r[1], r[2])
                }
                var rgbToHex = function() {
                    var i, t, e = [];
                    for (i = 0; i < 256; i += 1) t = i.toString(16), e[i] = 1 === t.length ? "0" + t : t;
                    return function(t, g, b) {
                        return t < 0 && (t = 0), g < 0 && (g = 0), b < 0 && (b = 0), "#" + e[t] + e[g] + e[b]
                    }
                }();

                function BaseEvent() {}
                BaseEvent.prototype = {
                    triggerEvent: function(t, e) {
                        if (this._cbs[t])
                            for (var r = this._cbs[t], i = 0; i < r.length; i += 1) r[i](e)
                    },
                    addEventListener: function(t, e) {
                        return this._cbs[t] || (this._cbs[t] = []), this._cbs[t].push(e),
                            function() {
                                this.removeEventListener(t, e)
                            }.bind(this)
                    },
                    removeEventListener: function(t, e) {
                        if (e) {
                            if (this._cbs[t]) {
                                for (var i = 0, r = this._cbs[t].length; i < r;) this._cbs[t][i] === e && (this._cbs[t].splice(i, 1), i -= 1, r -= 1), i += 1;
                                this._cbs[t].length || (this._cbs[t] = null)
                            }
                        } else this._cbs[t] = null
                    }
                };
                var createTypedArray = function() {
                    function t(t, e) {
                        var r, i = 0,
                            n = [];
                        switch (t) {
                            case "int16":
                            case "uint8c":
                                r = 1;
                                break;
                            default:
                                r = 1.1
                        }
                        for (i = 0; i < e; i += 1) n.push(r);
                        return n
                    }
                    return "function" == typeof Uint8ClampedArray && "function" == typeof Float32Array ? function(e, r) {
                        return "float32" === e ? new Float32Array(r) : "int16" === e ? new Int16Array(r) : "uint8c" === e ? new Uint8ClampedArray(r) : t(e, r)
                    } : t
                }();

                function createSizedArray(t) {
                    return Array.apply(null, {
                        length: t
                    })
                }

                function createNS(t) {
                    return document.createElementNS(svgNS, t)
                }

                function createTag(t) {
                    return document.createElement(t)
                }

                function DynamicPropertyContainer() {}
                DynamicPropertyContainer.prototype = {
                    addDynamicProperty: function(t) {
                        -1 === this.dynamicProperties.indexOf(t) && (this.dynamicProperties.push(t), this.container.addDynamicProperty(this), this._isAnimated = !0)
                    },
                    iterateDynamicProperties: function() {
                        var i;
                        this._mdf = !1;
                        var t = this.dynamicProperties.length;
                        for (i = 0; i < t; i += 1) this.dynamicProperties[i].getValue(), this.dynamicProperties[i]._mdf && (this._mdf = !0)
                    },
                    initDynamicPropertyContainer: function(t) {
                        this.container = t, this.dynamicProperties = [], this._mdf = !1, this._isAnimated = !1
                    }
                };
                var getBlendMode = (blendModeEnums = {
                        0: "source-over",
                        1: "multiply",
                        2: "screen",
                        3: "overlay",
                        4: "darken",
                        5: "lighten",
                        6: "color-dodge",
                        7: "color-burn",
                        8: "hard-light",
                        9: "soft-light",
                        10: "difference",
                        11: "exclusion",
                        12: "hue",
                        13: "saturation",
                        14: "color",
                        15: "luminosity"
                    }, function(t) {
                        return blendModeEnums[t] || ""
                    }),
                    blendModeEnums, lineCapEnum = {
                        1: "butt",
                        2: "round",
                        3: "square"
                    },
                    lineJoinEnum = {
                        1: "miter",
                        2: "round",
                        3: "bevel"
                    },
                    Matrix = function() {
                        var t = Math.cos,
                            e = Math.sin,
                            r = Math.tan,
                            n = Math.round;

                        function o() {
                            return this.props[0] = 1, this.props[1] = 0, this.props[2] = 0, this.props[3] = 0, this.props[4] = 0, this.props[5] = 1, this.props[6] = 0, this.props[7] = 0, this.props[8] = 0, this.props[9] = 0, this.props[10] = 1, this.props[11] = 0, this.props[12] = 0, this.props[13] = 0, this.props[14] = 0, this.props[15] = 1, this
                        }

                        function h(r) {
                            if (0 === r) return this;
                            var n = t(r),
                                o = e(r);
                            return this._t(n, -o, 0, 0, o, n, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
                        }

                        function l(r) {
                            if (0 === r) return this;
                            var n = t(r),
                                o = e(r);
                            return this._t(1, 0, 0, 0, 0, n, -o, 0, 0, o, n, 0, 0, 0, 0, 1)
                        }

                        function m(r) {
                            if (0 === r) return this;
                            var n = t(r),
                                o = e(r);
                            return this._t(n, 0, o, 0, 0, 1, 0, 0, -o, 0, n, 0, 0, 0, 0, 1)
                        }

                        function f(r) {
                            if (0 === r) return this;
                            var n = t(r),
                                o = e(r);
                            return this._t(n, -o, 0, 0, o, n, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
                        }

                        function c(t, e) {
                            return this._t(1, e, t, 1, 0, 0)
                        }

                        function d(t, e) {
                            return this.shear(r(t), r(e))
                        }

                        function y(n, o) {
                            var h = t(o),
                                l = e(o);
                            return this._t(h, l, 0, 0, -l, h, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(1, 0, 0, 0, r(n), 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(h, -l, 0, 0, l, h, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
                        }

                        function v(t, e, r) {
                            return r || 0 === r || (r = 1), 1 === t && 1 === e && 1 === r ? this : this._t(t, 0, 0, 0, 0, e, 0, 0, 0, 0, r, 0, 0, 0, 0, 1)
                        }

                        function P(a, b, t, e, r, n, g, o, i, h, l, m, f, c, d, p) {
                            return this.props[0] = a, this.props[1] = b, this.props[2] = t, this.props[3] = e, this.props[4] = r, this.props[5] = n, this.props[6] = g, this.props[7] = o, this.props[8] = i, this.props[9] = h, this.props[10] = l, this.props[11] = m, this.props[12] = f, this.props[13] = c, this.props[14] = d, this.props[15] = p, this
                        }

                        function E(t, e, r) {
                            return r = r || 0, 0 !== t || 0 !== e || 0 !== r ? this._t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, t, e, r, 1) : this
                        }

                        function x(t, e, r, n, o, h, l, h2, m, f, c, d, y, v, P, E) {
                            var x = this.props;
                            if (1 === t && 0 === e && 0 === r && 0 === n && 0 === o && 1 === h && 0 === l && 0 === h2 && 0 === m && 0 === f && 1 === c && 0 === d) return x[12] = x[12] * t + x[15] * y, x[13] = x[13] * h + x[15] * v, x[14] = x[14] * c + x[15] * P, x[15] *= E, this._identityCalculated = !1, this;
                            var S = x[0],
                                A = x[1],
                                C = x[2],
                                _ = x[3],
                                T = x[4],
                                k = x[5],
                                D = x[6],
                                h1 = x[7],
                                M = x[8],
                                F = x[9],
                                w = x[10],
                                I = x[11],
                                V = x[12],
                                R = x[13],
                                B = x[14],
                                L = x[15];
                            return x[0] = S * t + A * o + C * m + _ * y, x[1] = S * e + A * h + C * f + _ * v, x[2] = S * r + A * l + C * c + _ * P, x[3] = S * n + A * h2 + C * d + _ * E, x[4] = T * t + k * o + D * m + h1 * y, x[5] = T * e + k * h + D * f + h1 * v, x[6] = T * r + k * l + D * c + h1 * P, x[7] = T * n + k * h2 + D * d + h1 * E, x[8] = M * t + F * o + w * m + I * y, x[9] = M * e + F * h + w * f + I * v, x[10] = M * r + F * l + w * c + I * P, x[11] = M * n + F * h2 + w * d + I * E, x[12] = V * t + R * o + B * m + L * y, x[13] = V * e + R * h + B * f + L * v, x[14] = V * r + R * l + B * c + L * P, x[15] = V * n + R * h2 + B * d + L * E, this._identityCalculated = !1, this
                        }

                        function S() {
                            return this._identityCalculated || (this._identity = !(1 !== this.props[0] || 0 !== this.props[1] || 0 !== this.props[2] || 0 !== this.props[3] || 0 !== this.props[4] || 1 !== this.props[5] || 0 !== this.props[6] || 0 !== this.props[7] || 0 !== this.props[8] || 0 !== this.props[9] || 1 !== this.props[10] || 0 !== this.props[11] || 0 !== this.props[12] || 0 !== this.props[13] || 0 !== this.props[14] || 1 !== this.props[15]), this._identityCalculated = !0), this._identity
                        }

                        function A(t) {
                            for (var i = 0; i < 16;) {
                                if (t.props[i] !== this.props[i]) return !1;
                                i += 1
                            }
                            return !0
                        }

                        function C(t) {
                            var i;
                            for (i = 0; i < 16; i += 1) t.props[i] = this.props[i];
                            return t
                        }

                        function _(t) {
                            var i;
                            for (i = 0; i < 16; i += 1) this.props[i] = t[i]
                        }

                        function T(t, e, r) {
                            return {
                                x: t * this.props[0] + e * this.props[4] + r * this.props[8] + this.props[12],
                                y: t * this.props[1] + e * this.props[5] + r * this.props[9] + this.props[13],
                                z: t * this.props[2] + e * this.props[6] + r * this.props[10] + this.props[14]
                            }
                        }

                        function k(t, e, r) {
                            return t * this.props[0] + e * this.props[4] + r * this.props[8] + this.props[12]
                        }

                        function D(t, e, r) {
                            return t * this.props[1] + e * this.props[5] + r * this.props[9] + this.props[13]
                        }

                        function M(t, e, r) {
                            return t * this.props[2] + e * this.props[6] + r * this.props[10] + this.props[14]
                        }

                        function F() {
                            var t = this.props[0] * this.props[5] - this.props[1] * this.props[4],
                                a = this.props[5] / t,
                                b = -this.props[1] / t,
                                e = -this.props[4] / t,
                                r = this.props[0] / t,
                                n = (this.props[4] * this.props[13] - this.props[5] * this.props[12]) / t,
                                o = -(this.props[0] * this.props[13] - this.props[1] * this.props[12]) / t,
                                h = new Matrix;
                            return h.props[0] = a, h.props[1] = b, h.props[4] = e, h.props[5] = r, h.props[12] = n, h.props[13] = o, h
                        }

                        function w(t) {
                            return this.getInverseMatrix().applyToPointArray(t[0], t[1], t[2] || 0)
                        }

                        function I(t) {
                            var i, e = t.length,
                                r = [];
                            for (i = 0; i < e; i += 1) r[i] = w(t[i]);
                            return r
                        }

                        function V(t, e, r) {
                            var n = createTypedArray("float32", 6);
                            if (this.isIdentity()) n[0] = t[0], n[1] = t[1], n[2] = e[0], n[3] = e[1], n[4] = r[0], n[5] = r[1];
                            else {
                                var o = this.props[0],
                                    h = this.props[1],
                                    l = this.props[4],
                                    m = this.props[5],
                                    f = this.props[12],
                                    c = this.props[13];
                                n[0] = t[0] * o + t[1] * l + f, n[1] = t[0] * h + t[1] * m + c, n[2] = e[0] * o + e[1] * l + f, n[3] = e[0] * h + e[1] * m + c, n[4] = r[0] * o + r[1] * l + f, n[5] = r[0] * h + r[1] * m + c
                            }
                            return n
                        }

                        function R(t, e, r) {
                            return this.isIdentity() ? [t, e, r] : [t * this.props[0] + e * this.props[4] + r * this.props[8] + this.props[12], t * this.props[1] + e * this.props[5] + r * this.props[9] + this.props[13], t * this.props[2] + e * this.props[6] + r * this.props[10] + this.props[14]]
                        }

                        function B(t, e) {
                            if (this.isIdentity()) return t + "," + e;
                            var r = this.props;
                            return Math.round(100 * (t * r[0] + e * r[4] + r[12])) / 100 + "," + Math.round(100 * (t * r[1] + e * r[5] + r[13])) / 100
                        }

                        function L() {
                            for (var i = 0, t = this.props, e = "matrix3d("; i < 16;) e += n(1e4 * t[i]) / 1e4, e += 15 === i ? ")" : ",", i += 1;
                            return e
                        }

                        function G(t) {
                            return t < 1e-6 && t > 0 || t > -1e-6 && t < 0 ? n(1e4 * t) / 1e4 : t
                        }

                        function z() {
                            var t = this.props;
                            return "matrix(" + G(t[0]) + "," + G(t[1]) + "," + G(t[4]) + "," + G(t[5]) + "," + G(t[12]) + "," + G(t[13]) + ")"
                        }
                        return function() {
                            this.reset = o, this.rotate = h, this.rotateX = l, this.rotateY = m, this.rotateZ = f, this.skew = d, this.skewFromAxis = y, this.shear = c, this.scale = v, this.setTransform = P, this.translate = E, this.transform = x, this.applyToPoint = T, this.applyToX = k, this.applyToY = D, this.applyToZ = M, this.applyToPointArray = R, this.applyToTriplePoints = V, this.applyToPointStringified = B, this.toCSS = L, this.to2dCSS = z, this.clone = C, this.cloneFromProps = _, this.equals = A, this.inversePoints = I, this.inversePoint = w, this.getInverseMatrix = F, this._t = this.transform, this.isIdentity = S, this._identity = !0, this._identityCalculated = !1, this.props = createTypedArray("float32", 16), this.reset()
                        }
                    }();
                ! function(t, e) {
                    var r = this,
                        n = 256,
                        o = e.pow(n, 6),
                        h = e.pow(2, 52),
                        l = 2 * h,
                        mask = 255;

                    function m(t) {
                        var e, r = t.length,
                            o = this,
                            i = 0,
                            h = o.i = o.j = 0,
                            s = o.S = [];
                        for (r || (t = [r++]); i < n;) s[i] = i++;
                        for (i = 0; i < n; i++) s[i] = s[h = mask & h + t[i % r] + (e = s[i])], s[h] = e;
                        o.g = function(t) {
                            for (var e, r = 0, i = o.i, h = o.j, s = o.S; t--;) e = s[i = mask & i + 1], r = r * n + s[mask & (s[i] = s[h = mask & h + e]) + (s[h] = e)];
                            return o.i = i, o.j = h, r
                        }
                    }

                    function f(t, e) {
                        return e.i = t.i, e.j = t.j, e.S = t.S.slice(), e
                    }

                    function c(t, e) {
                        var r, n = [],
                            o = typeof t;
                        if (e && "object" == o)
                            for (r in t) try {
                                n.push(c(t[r], e - 1))
                            } catch (t) {}
                        return n.length ? n : "string" == o ? t : t + "\0"
                    }

                    function d(t, e) {
                        for (var r, n = t + "", o = 0; o < n.length;) e[mask & o] = mask & (r ^= 19 * e[mask & o]) + n.charCodeAt(o++);
                        return y(e)
                    }

                    function y(a) {
                        return String.fromCharCode.apply(0, a)
                    }
                    e.seedrandom = function(v, P, E) {
                        var x = [],
                            S = d(c((P = !0 === P ? {
                                entropy: !0
                            } : P || {}).entropy ? [v, y(t)] : null === v ? function() {
                                try {
                                    var e = new Uint8Array(n);
                                    return (r.crypto || r.msCrypto).getRandomValues(e), y(e)
                                } catch (e) {
                                    var o = r.navigator,
                                        h = o && o.plugins;
                                    return [+new Date, r, h, r.screen, y(t)]
                                }
                            }() : v, 3), x),
                            A = new m(x),
                            C = function() {
                                for (var t = A.g(6), e = o, r = 0; t < h;) t = (t + r) * n, e *= n, r = A.g(1);
                                for (; t >= l;) t /= 2, e /= 2, r >>>= 1;
                                return (t + r) / e
                            };
                        return C.int32 = function() {
                            return 0 | A.g(4)
                        }, C.quick = function() {
                            return A.g(4) / 4294967296
                        }, C.double = C, d(y(A.S), t), (P.pass || E || function(t, r, n, o) {
                            return o && (o.S && f(o, A), t.state = function() {
                                return f(A, {})
                            }), n ? (e.random = t, r) : t
                        })(C, S, "global" in P ? P.global : this == e, P.state)
                    }, d(e.random(), t)
                }([], BMMath);
                var BezierFactory = function() {
                    var t = {
                            getBezierEasing: function(a, b, t, r, n) {
                                var o = n || ("bez_" + a + "_" + b + "_" + t + "_" + r).replace(/\./g, "p");
                                if (e[o]) return e[o];
                                var h = new c([a, b, t, r]);
                                return e[o] = h, h
                            }
                        },
                        e = {},
                        r = .1,
                        n = "function" == typeof Float32Array;

                    function o(t, e) {
                        return 1 - 3 * e + 3 * t
                    }

                    function h(t, e) {
                        return 3 * e - 6 * t
                    }

                    function l(t) {
                        return 3 * t
                    }

                    function m(t, e, r) {
                        return ((o(e, r) * t + h(e, r)) * t + l(e)) * t
                    }

                    function f(t, e, r) {
                        return 3 * o(e, r) * t * t + 2 * h(e, r) * t + l(e)
                    }

                    function c(t) {
                        this._p = t, this._mSampleValues = n ? new Float32Array(11) : new Array(11), this._precomputed = !1, this.get = this.get.bind(this)
                    }
                    return c.prototype = {
                        get: function(t) {
                            var e = this._p[0],
                                r = this._p[1],
                                n = this._p[2],
                                o = this._p[3];
                            return this._precomputed || this._precompute(), e === r && n === o ? t : 0 === t ? 0 : 1 === t ? 1 : m(this._getTForX(t), r, o)
                        },
                        _precompute: function() {
                            var t = this._p[0],
                                e = this._p[1],
                                r = this._p[2],
                                n = this._p[3];
                            this._precomputed = !0, t === e && r === n || this._calcSampleValues()
                        },
                        _calcSampleValues: function() {
                            for (var t = this._p[0], e = this._p[2], i = 0; i < 11; ++i) this._mSampleValues[i] = m(i * r, t, e)
                        },
                        _getTForX: function(t) {
                            for (var e = this._p[0], n = this._p[2], o = this._mSampleValues, h = 0, l = 1; 10 !== l && o[l] <= t; ++l) h += r;
                            var c = h + (t - o[--l]) / (o[l + 1] - o[l]) * r,
                                d = f(c, e, n);
                            return d >= .001 ? function(t, e, r, n) {
                                for (var i = 0; i < 4; ++i) {
                                    var o = f(e, r, n);
                                    if (0 === o) return e;
                                    e -= (m(e, r, n) - t) / o
                                }
                                return e
                            }(t, c, e, n) : 0 === d ? c : function(t, e, r, n, o) {
                                var h, l, i = 0;
                                do {
                                    (h = m(l = e + (r - e) / 2, n, o) - t) > 0 ? r = l : e = l
                                } while (Math.abs(h) > 1e-7 && ++i < 10);
                                return l
                            }(t, h, h + r, e, n)
                        }
                    }, t
                }();

                function extendPrototype(t, e) {
                    var i, r, n = t.length;
                    for (i = 0; i < n; i += 1)
                        for (var o in r = t[i].prototype) Object.prototype.hasOwnProperty.call(r, o) && (e.prototype[o] = r[o])
                }

                function getDescriptor(object, t) {
                    return Object.getOwnPropertyDescriptor(object, t)
                }

                function createProxyFunction(t) {
                    function e() {}
                    return e.prototype = t, e
                }

                function bezFunction() {
                    var t = Math;

                    function e(t, e, r, n, o, h) {
                        var l = t * n + e * o + r * h - o * n - h * t - r * e;
                        return l > -.001 && l < .001
                    }
                    var r = function(t, e, r, n) {
                        var o, i, h, l, m, f, c = defaultCurveSegments,
                            d = 0,
                            y = [],
                            v = [],
                            P = bezierLengthPool.newElement();
                        for (h = r.length, o = 0; o < c; o += 1) {
                            for (m = o / (c - 1), f = 0, i = 0; i < h; i += 1) l = bmPow(1 - m, 3) * t[i] + 3 * bmPow(1 - m, 2) * m * r[i] + 3 * (1 - m) * bmPow(m, 2) * n[i] + bmPow(m, 3) * e[i], y[i] = l, null !== v[i] && (f += bmPow(y[i] - v[i], 2)), v[i] = y[i];
                            f && (d += f = bmSqrt(f)), P.percents[o] = m, P.lengths[o] = d
                        }
                        return P.addedLength = d, P
                    };

                    function n(t) {
                        this.segmentLength = 0, this.points = new Array(t)
                    }

                    function o(t, e) {
                        this.partialLength = t, this.point = e
                    }
                    var h, l = (h = {}, function(t, r, l, m) {
                        var f = (t[0] + "_" + t[1] + "_" + r[0] + "_" + r[1] + "_" + l[0] + "_" + l[1] + "_" + m[0] + "_" + m[1]).replace(/\./g, "p");
                        if (!h[f]) {
                            var c, i, d, y, v, P, E, x = defaultCurveSegments,
                                S = 0,
                                A = null;
                            2 === t.length && (t[0] !== r[0] || t[1] !== r[1]) && e(t[0], t[1], r[0], r[1], t[0] + l[0], t[1] + l[1]) && e(t[0], t[1], r[0], r[1], r[0] + m[0], r[1] + m[1]) && (x = 2);
                            var C = new n(x);
                            for (d = l.length, c = 0; c < x; c += 1) {
                                for (E = createSizedArray(d), v = c / (x - 1), P = 0, i = 0; i < d; i += 1) y = bmPow(1 - v, 3) * t[i] + 3 * bmPow(1 - v, 2) * v * (t[i] + l[i]) + 3 * (1 - v) * bmPow(v, 2) * (r[i] + m[i]) + bmPow(v, 3) * r[i], E[i] = y, null !== A && (P += bmPow(E[i] - A[i], 2));
                                S += P = bmSqrt(P), C.points[c] = new o(P, E), A = E
                            }
                            C.segmentLength = S, h[f] = C
                        }
                        return h[f]
                    });

                    function m(t, e) {
                        var r = e.percents,
                            n = e.lengths,
                            o = r.length,
                            h = bmFloor((o - 1) * t),
                            l = t * e.addedLength,
                            m = 0;
                        if (h === o - 1 || 0 === h || l === n[h]) return r[h];
                        for (var f = n[h] > l ? -1 : 1, c = !0; c;)
                            if (n[h] <= l && n[h + 1] > l ? (m = (l - n[h]) / (n[h + 1] - n[h]), c = !1) : h += f, h < 0 || h >= o - 1) {
                                if (h === o - 1) return r[h];
                                c = !1
                            }
                        return r[h] + (r[h + 1] - r[h]) * m
                    }
                    var f = createTypedArray("float32", 8);
                    return {
                        getSegmentsLength: function(t) {
                            var i, e = segmentsLengthPool.newElement(),
                                n = t.c,
                                o = t.v,
                                h = t.o,
                                l = t.i,
                                m = t._length,
                                f = e.lengths,
                                c = 0;
                            for (i = 0; i < m - 1; i += 1) f[i] = r(o[i], o[i + 1], h[i], l[i + 1]), c += f[i].addedLength;
                            return n && m && (f[i] = r(o[i], o[0], h[i], l[0]), c += f[i].addedLength), e.totalLength = c, e
                        },
                        getNewSegment: function(e, r, n, o, h, l, c) {
                            h < 0 ? h = 0 : h > 1 && (h = 1);
                            var i, d = m(h, c),
                                y = m(l = l > 1 ? 1 : l, c),
                                v = e.length,
                                P = 1 - d,
                                E = 1 - y,
                                x = P * P * P,
                                S = d * P * P * 3,
                                A = d * d * P * 3,
                                C = d * d * d,
                                _ = P * P * E,
                                T = d * P * E + P * d * E + P * P * y,
                                k = d * d * E + P * d * y + d * P * y,
                                D = d * d * y,
                                M = P * E * E,
                                F = d * E * E + P * y * E + P * E * y,
                                w = d * y * E + P * y * y + d * E * y,
                                I = d * y * y,
                                V = E * E * E,
                                R = y * E * E + E * y * E + E * E * y,
                                B = y * y * E + E * y * y + y * E * y,
                                L = y * y * y;
                            for (i = 0; i < v; i += 1) f[4 * i] = t.round(1e3 * (x * e[i] + S * n[i] + A * o[i] + C * r[i])) / 1e3, f[4 * i + 1] = t.round(1e3 * (_ * e[i] + T * n[i] + k * o[i] + D * r[i])) / 1e3, f[4 * i + 2] = t.round(1e3 * (M * e[i] + F * n[i] + w * o[i] + I * r[i])) / 1e3, f[4 * i + 3] = t.round(1e3 * (V * e[i] + R * n[i] + B * o[i] + L * r[i])) / 1e3;
                            return f
                        },
                        getPointInSegment: function(e, r, n, o, h, l) {
                            var f = m(h, l),
                                c = 1 - f;
                            return [t.round(1e3 * (c * c * c * e[0] + (f * c * c + c * f * c + c * c * f) * n[0] + (f * f * c + c * f * f + f * c * f) * o[0] + f * f * f * r[0])) / 1e3, t.round(1e3 * (c * c * c * e[1] + (f * c * c + c * f * c + c * c * f) * n[1] + (f * f * c + c * f * f + f * c * f) * o[1] + f * f * f * r[1])) / 1e3]
                        },
                        buildBezierData: l,
                        pointOnLine2D: e,
                        pointOnLine3D: function(r, n, o, h, l, m, f, c, d) {
                            if (0 === o && 0 === m && 0 === d) return e(r, n, h, l, f, c);
                            var y, v = t.sqrt(t.pow(h - r, 2) + t.pow(l - n, 2) + t.pow(m - o, 2)),
                                P = t.sqrt(t.pow(f - r, 2) + t.pow(c - n, 2) + t.pow(d - o, 2)),
                                E = t.sqrt(t.pow(f - h, 2) + t.pow(c - l, 2) + t.pow(d - m, 2));
                            return (y = v > P ? v > E ? v - P - E : E - P - v : E > P ? E - P - v : P - v - E) > -1e-4 && y < 1e-4
                        }
                    }
                }! function() {
                    for (var t = 0, e = ["ms", "moz", "webkit", "o"], r = 0; r < e.length && !window.requestAnimationFrame; ++r) window.requestAnimationFrame = window[e[r] + "RequestAnimationFrame"], window.cancelAnimationFrame = window[e[r] + "CancelAnimationFrame"] || window[e[r] + "CancelRequestAnimationFrame"];
                    window.requestAnimationFrame || (window.requestAnimationFrame = function(e) {
                        var r = (new Date).getTime(),
                            n = Math.max(0, 16 - (r - t)),
                            o = setTimeout((function() {
                                e(r + n)
                            }), n);
                        return t = r + n, o
                    }), window.cancelAnimationFrame || (window.cancelAnimationFrame = function(t) {
                        clearTimeout(t)
                    })
                }();
                var bez = bezFunction(),
                    dataManager = function() {
                        var t, e, r = 1,
                            n = [],
                            o = {
                                onmessage: function() {},
                                postMessage: function(path) {
                                    t({
                                        data: path
                                    })
                                }
                            },
                            h = {
                                postMessage: function(data) {
                                    o.onmessage({
                                        data: data
                                    })
                                }
                            };

                        function l() {
                            e || (e = function(e) {
                                if (window.Worker && window.Blob && _useWebWorker) {
                                    var r = new Blob(["var _workerSelf = self; self.onmessage = ", e.toString()], {
                                            type: "text/javascript"
                                        }),
                                        n = URL.createObjectURL(r);
                                    return new Worker(n)
                                }
                                return t = e, o
                            }((function(t) {
                                if (h.dataManager || (h.dataManager = function() {
                                        function t(o, h) {
                                            var l, i, m, f, c, d, v = o.length;
                                            for (i = 0; i < v; i += 1)
                                                if ("ks" in (l = o[i]) && !l.completed) {
                                                    if (l.completed = !0, l.tt && (o[i - 1].td = l.tt), l.hasMask) {
                                                        var P = l.masksProperties;
                                                        for (f = P.length, m = 0; m < f; m += 1)
                                                            if (P[m].pt.k.i) n(P[m].pt.k);
                                                            else
                                                                for (d = P[m].pt.k.length, c = 0; c < d; c += 1) P[m].pt.k[c].s && n(P[m].pt.k[c].s[0]), P[m].pt.k[c].e && n(P[m].pt.k[c].e[0])
                                                    }
                                                    0 === l.ty ? (l.layers = e(l.refId, h), t(l.layers, h)) : 4 === l.ty ? r(l.shapes) : 5 === l.ty && y(l)
                                                }
                                        }

                                        function e(t, e) {
                                            for (var i = 0, r = e.length; i < r;) {
                                                if (e[i].id === t) return e[i].layers.__used ? JSON.parse(JSON.stringify(e[i].layers)) : (e[i].layers.__used = !0, e[i].layers);
                                                i += 1
                                            }
                                            return null
                                        }

                                        function r(t) {
                                            var i, e, o;
                                            for (i = t.length - 1; i >= 0; i -= 1)
                                                if ("sh" === t[i].ty)
                                                    if (t[i].ks.k.i) n(t[i].ks.k);
                                                    else
                                                        for (o = t[i].ks.k.length, e = 0; e < o; e += 1) t[i].ks.k[e].s && n(t[i].ks.k[e].s[0]), t[i].ks.k[e].e && n(t[i].ks.k[e].e[0]);
                                            else "gr" === t[i].ty && r(t[i].it)
                                        }

                                        function n(path) {
                                            var i, t = path.i.length;
                                            for (i = 0; i < t; i += 1) path.i[i][0] += path.v[i][0], path.i[i][1] += path.v[i][1], path.o[i][0] += path.v[i][0], path.o[i][1] += path.v[i][1]
                                        }

                                        function o(t, e) {
                                            var r = e ? e.split(".") : [100, 100, 100];
                                            return t[0] > r[0] || !(r[0] > t[0]) && (t[1] > r[1] || !(r[1] > t[1]) && (t[2] > r[2] || !(r[2] > t[2]) && null))
                                        }
                                        var h, l = function() {
                                                var t = [4, 4, 14];

                                                function e(t) {
                                                    var i, e, r, n = t.length;
                                                    for (i = 0; i < n; i += 1) 5 === t[i].ty && (r = void 0, r = (e = t[i]).t.d, e.t.d = {
                                                        k: [{
                                                            s: r,
                                                            t: 0
                                                        }]
                                                    })
                                                }
                                                return function(r) {
                                                    if (o(t, r.v) && (e(r.layers), r.assets)) {
                                                        var i, n = r.assets.length;
                                                        for (i = 0; i < n; i += 1) r.assets[i].layers && e(r.assets[i].layers)
                                                    }
                                                }
                                            }(),
                                            m = (h = [4, 7, 99], function(t) {
                                                if (t.chars && !o(h, t.v)) {
                                                    var i, e, r, l, m, f = t.chars.length;
                                                    for (i = 0; i < f; i += 1)
                                                        if (t.chars[i].data && t.chars[i].data.shapes)
                                                            for (r = (m = t.chars[i].data.shapes[0].it).length, e = 0; e < r; e += 1)(l = m[e].ks.k).__converted || (n(m[e].ks.k), l.__converted = !0)
                                                }
                                            }),
                                            f = function() {
                                                var t = [5, 7, 15];

                                                function e(t) {
                                                    var i, e, r = t.length;
                                                    for (i = 0; i < r; i += 1) 5 === t[i].ty && (e = void 0, "number" == typeof(e = t[i].t.p).a && (e.a = {
                                                        a: 0,
                                                        k: e.a
                                                    }), "number" == typeof e.p && (e.p = {
                                                        a: 0,
                                                        k: e.p
                                                    }), "number" == typeof e.r && (e.r = {
                                                        a: 0,
                                                        k: e.r
                                                    }))
                                                }
                                                return function(r) {
                                                    if (o(t, r.v) && (e(r.layers), r.assets)) {
                                                        var i, n = r.assets.length;
                                                        for (i = 0; i < n; i += 1) r.assets[i].layers && e(r.assets[i].layers)
                                                    }
                                                }
                                            }(),
                                            c = function() {
                                                var t = [4, 1, 9];

                                                function e(t) {
                                                    var i, r, n, o = t.length;
                                                    for (i = 0; i < o; i += 1)
                                                        if ("gr" === t[i].ty) e(t[i].it);
                                                        else if ("fl" === t[i].ty || "st" === t[i].ty)
                                                        if (t[i].c.k && t[i].c.k[0].i)
                                                            for (n = t[i].c.k.length, r = 0; r < n; r += 1) t[i].c.k[r].s && (t[i].c.k[r].s[0] /= 255, t[i].c.k[r].s[1] /= 255, t[i].c.k[r].s[2] /= 255, t[i].c.k[r].s[3] /= 255), t[i].c.k[r].e && (t[i].c.k[r].e[0] /= 255, t[i].c.k[r].e[1] /= 255, t[i].c.k[r].e[2] /= 255, t[i].c.k[r].e[3] /= 255);
                                                        else t[i].c.k[0] /= 255, t[i].c.k[1] /= 255, t[i].c.k[2] /= 255, t[i].c.k[3] /= 255
                                                }

                                                function r(t) {
                                                    var i, r = t.length;
                                                    for (i = 0; i < r; i += 1) 4 === t[i].ty && e(t[i].shapes)
                                                }
                                                return function(e) {
                                                    if (o(t, e.v) && (r(e.layers), e.assets)) {
                                                        var i, n = e.assets.length;
                                                        for (i = 0; i < n; i += 1) e.assets[i].layers && r(e.assets[i].layers)
                                                    }
                                                }
                                            }(),
                                            d = function() {
                                                var t = [4, 4, 18];

                                                function e(t) {
                                                    var i, r, n;
                                                    for (i = t.length - 1; i >= 0; i -= 1)
                                                        if ("sh" === t[i].ty)
                                                            if (t[i].ks.k.i) t[i].ks.k.c = t[i].closed;
                                                            else
                                                                for (n = t[i].ks.k.length, r = 0; r < n; r += 1) t[i].ks.k[r].s && (t[i].ks.k[r].s[0].c = t[i].closed), t[i].ks.k[r].e && (t[i].ks.k[r].e[0].c = t[i].closed);
                                                    else "gr" === t[i].ty && e(t[i].it)
                                                }

                                                function r(t) {
                                                    var r, i, n, o, h, l, m = t.length;
                                                    for (i = 0; i < m; i += 1) {
                                                        if ((r = t[i]).hasMask) {
                                                            var f = r.masksProperties;
                                                            for (o = f.length, n = 0; n < o; n += 1)
                                                                if (f[n].pt.k.i) f[n].pt.k.c = f[n].cl;
                                                                else
                                                                    for (l = f[n].pt.k.length, h = 0; h < l; h += 1) f[n].pt.k[h].s && (f[n].pt.k[h].s[0].c = f[n].cl), f[n].pt.k[h].e && (f[n].pt.k[h].e[0].c = f[n].cl)
                                                        }
                                                        4 === r.ty && e(r.shapes)
                                                    }
                                                }
                                                return function(e) {
                                                    if (o(t, e.v) && (r(e.layers), e.assets)) {
                                                        var i, n = e.assets.length;
                                                        for (i = 0; i < n; i += 1) e.assets[i].layers && r(e.assets[i].layers)
                                                    }
                                                }
                                            }();

                                        function y(data) {
                                            0 !== data.t.a.length || "m" in data.t.p || (data.singleShape = !0)
                                        }
                                        var v = {
                                            completeData: function(e) {
                                                e.__complete || (c(e), l(e), m(e), f(e), d(e), t(e.layers, e.assets), e.__complete = !0)
                                            }
                                        };
                                        return v.checkColors = c, v.checkChars = m, v.checkPathProperties = f, v.checkShapes = d, v.completeLayers = t, v
                                    }()), h.assetLoader || (h.assetLoader = function() {
                                        function t(t) {
                                            var e = t.getResponseHeader("content-type");
                                            return e && "json" === t.responseType && -1 !== e.indexOf("json") || t.response && "object" == typeof t.response ? t.response : t.response && "string" == typeof t.response ? JSON.parse(t.response) : t.responseText ? JSON.parse(t.responseText) : null
                                        }
                                        return {
                                            load: function(path, e, r, n) {
                                                var o, h = new XMLHttpRequest;
                                                try {
                                                    h.responseType = "json"
                                                } catch (t) {}
                                                h.onreadystatechange = function() {
                                                    if (4 === h.readyState)
                                                        if (200 === h.status) o = t(h), r(o);
                                                        else try {
                                                            o = t(h), r(o)
                                                        } catch (t) {
                                                            n && n(t)
                                                        }
                                                };
                                                try {
                                                    h.open("GET", path, !0)
                                                } catch (t) {
                                                    h.open("GET", e + "/" + path, !0)
                                                }
                                                h.send()
                                            }
                                        }
                                    }()), "loadAnimation" === t.data.type) h.assetLoader.load(t.data.path, t.data.fullPath, (function(data) {
                                    h.dataManager.completeData(data), h.postMessage({
                                        id: t.data.id,
                                        payload: data,
                                        status: "success"
                                    })
                                }), (function() {
                                    h.postMessage({
                                        id: t.data.id,
                                        status: "error"
                                    })
                                }));
                                else if ("complete" === t.data.type) {
                                    var e = t.data.animation;
                                    h.dataManager.completeData(e), h.postMessage({
                                        id: t.data.id,
                                        payload: e,
                                        status: "success"
                                    })
                                } else "loadData" === t.data.type && h.assetLoader.load(t.data.path, t.data.fullPath, (function(data) {
                                    h.postMessage({
                                        id: t.data.id,
                                        payload: data,
                                        status: "success"
                                    })
                                }), (function() {
                                    h.postMessage({
                                        id: t.data.id,
                                        status: "error"
                                    })
                                }))
                            })), e.onmessage = function(t) {
                                var data = t.data,
                                    e = data.id,
                                    r = n[e];
                                n[e] = null, "success" === data.status ? r.onComplete(data.payload) : r.onError && r.onError()
                            })
                        }

                        function m(t, e) {
                            var o = "processId_" + (r += 1);
                            return n[o] = {
                                onComplete: t,
                                onError: e
                            }, o
                        }
                        return {
                            loadAnimation: function(path, t, r) {
                                l();
                                var n = m(t, r);
                                e.postMessage({
                                    type: "loadAnimation",
                                    path: path,
                                    fullPath: window.location.origin + window.location.pathname,
                                    id: n
                                })
                            },
                            loadData: function(path, t, r) {
                                l();
                                var n = m(t, r);
                                e.postMessage({
                                    type: "loadData",
                                    path: path,
                                    fullPath: window.location.origin + window.location.pathname,
                                    id: n
                                })
                            },
                            completeAnimation: function(t, r, n) {
                                l();
                                var o = m(r, n);
                                e.postMessage({
                                    type: "complete",
                                    animation: t,
                                    id: o
                                })
                            }
                        }
                    }();

                function getFontProperties(t) {
                    for (var e = t.fStyle ? t.fStyle.split(" ") : [], r = "normal", n = "normal", o = e.length, i = 0; i < o; i += 1) switch (e[i].toLowerCase()) {
                        case "italic":
                            n = "italic";
                            break;
                        case "bold":
                            r = "700";
                            break;
                        case "black":
                            r = "900";
                            break;
                        case "medium":
                            r = "500";
                            break;
                        case "regular":
                        case "normal":
                            r = "400";
                            break;
                        case "light":
                        case "thin":
                            r = "200"
                    }
                    return {
                        style: n,
                        weight: t.fWeight || r
                    }
                }
                var FontManager = function() {
                        var t = {
                                w: 0,
                                size: 0,
                                shapes: []
                            },
                            e = [];
                        e = e.concat([2304, 2305, 2306, 2307, 2362, 2363, 2364, 2364, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2383, 2387, 2388, 2389, 2390, 2391, 2402, 2403]);
                        var r = ["d83cdffb", "d83cdffc", "d83cdffd", "d83cdffe", "d83cdfff"],
                            n = [65039, 8205];

                        function o(t, e) {
                            var r = createTag("span");
                            r.setAttribute("aria-hidden", !0), r.style.fontFamily = e;
                            var n = createTag("span");
                            n.innerText = "giItT1WQy@!-/#", r.style.position = "absolute", r.style.left = "-10000px", r.style.top = "-10000px", r.style.fontSize = "300px", r.style.fontVariant = "normal", r.style.fontStyle = "normal", r.style.fontWeight = "normal", r.style.letterSpacing = "0", r.appendChild(n), document.body.appendChild(r);
                            var o = n.offsetWidth;
                            return n.style.fontFamily = function(t) {
                                var i, e = t.split(","),
                                    r = e.length,
                                    n = [];
                                for (i = 0; i < r; i += 1) "sans-serif" !== e[i] && "monospace" !== e[i] && n.push(e[i]);
                                return n.join(",")
                            }(t) + ", " + e, {
                                node: n,
                                w: o,
                                parent: r
                            }
                        }

                        function h(t, e) {
                            var r = createNS("text");
                            r.style.fontSize = "100px";
                            var n = getFontProperties(e);
                            return r.setAttribute("font-family", e.fFamily), r.setAttribute("font-style", n.style), r.setAttribute("font-weight", n.weight), r.textContent = "1", e.fClass ? (r.style.fontFamily = "inherit", r.setAttribute("class", e.fClass)) : r.style.fontFamily = e.fFamily, t.appendChild(r), createTag("canvas").getContext("2d").font = e.fWeight + " " + e.fStyle + " 100px " + e.fFamily, r
                        }
                        var l = function() {
                            this.fonts = [], this.chars = null, this.typekitLoaded = 0, this.isLoaded = !1, this._warned = !1, this.initTime = Date.now(), this.setIsLoadedBinded = this.setIsLoaded.bind(this), this.checkLoadedFontsBinded = this.checkLoadedFonts.bind(this)
                        };
                        l.isModifier = function(t, e) {
                            var n = t.toString(16) + e.toString(16);
                            return -1 !== r.indexOf(n)
                        }, l.isZeroWidthJoiner = function(t, e) {
                            return e ? t === n[0] && e === n[1] : t === n[1]
                        }, l.isCombinedCharacter = function(t) {
                            return -1 !== e.indexOf(t)
                        };
                        var m = {
                            addChars: function(t) {
                                if (t) {
                                    var i;
                                    this.chars || (this.chars = []);
                                    var e, r, n = t.length,
                                        o = this.chars.length;
                                    for (i = 0; i < n; i += 1) {
                                        for (e = 0, r = !1; e < o;) this.chars[e].style === t[i].style && this.chars[e].fFamily === t[i].fFamily && this.chars[e].ch === t[i].ch && (r = !0), e += 1;
                                        r || (this.chars.push(t[i]), o += 1)
                                    }
                                }
                            },
                            addFonts: function(t, defs) {
                                if (t) {
                                    if (this.chars) return this.isLoaded = !0, void(this.fonts = t.list);
                                    var i, e = t.list,
                                        r = e.length,
                                        n = r;
                                    for (i = 0; i < r; i += 1) {
                                        var l, m, f = !0;
                                        if (e[i].loaded = !1, e[i].monoCase = o(e[i].fFamily, "monospace"), e[i].sansCase = o(e[i].fFamily, "sans-serif"), e[i].fPath) {
                                            if ("p" === e[i].fOrigin || 3 === e[i].origin) {
                                                if ((l = document.querySelectorAll('style[f-forigin="p"][f-family="' + e[i].fFamily + '"], style[f-origin="3"][f-family="' + e[i].fFamily + '"]')).length > 0 && (f = !1), f) {
                                                    var s = createTag("style");
                                                    s.setAttribute("f-forigin", e[i].fOrigin), s.setAttribute("f-origin", e[i].origin), s.setAttribute("f-family", e[i].fFamily), s.type = "text/css", s.innerText = "@font-face {font-family: " + e[i].fFamily + "; font-style: normal; src: url('" + e[i].fPath + "');}", defs.appendChild(s)
                                                }
                                            } else if ("g" === e[i].fOrigin || 1 === e[i].origin) {
                                                for (l = document.querySelectorAll('link[f-forigin="g"], link[f-origin="1"]'), m = 0; m < l.length; m += 1) - 1 !== l[m].href.indexOf(e[i].fPath) && (f = !1);
                                                if (f) {
                                                    var c = createTag("link");
                                                    c.setAttribute("f-forigin", e[i].fOrigin), c.setAttribute("f-origin", e[i].origin), c.type = "text/css", c.rel = "stylesheet", c.href = e[i].fPath, document.body.appendChild(c)
                                                }
                                            } else if ("t" === e[i].fOrigin || 2 === e[i].origin) {
                                                for (l = document.querySelectorAll('script[f-forigin="t"], script[f-origin="2"]'), m = 0; m < l.length; m += 1) e[i].fPath === l[m].src && (f = !1);
                                                if (f) {
                                                    var d = createTag("link");
                                                    d.setAttribute("f-forigin", e[i].fOrigin), d.setAttribute("f-origin", e[i].origin), d.setAttribute("rel", "stylesheet"), d.setAttribute("href", e[i].fPath), defs.appendChild(d)
                                                }
                                            }
                                        } else e[i].loaded = !0, n -= 1;
                                        e[i].helper = h(defs, e[i]), e[i].cache = {}, this.fonts.push(e[i])
                                    }
                                    0 === n ? this.isLoaded = !0 : setTimeout(this.checkLoadedFonts.bind(this), 100)
                                } else this.isLoaded = !0
                            },
                            getCharData: function(e, style, r) {
                                for (var i = 0, n = this.chars.length; i < n;) {
                                    if (this.chars[i].ch === e && this.chars[i].style === style && this.chars[i].fFamily === r) return this.chars[i];
                                    i += 1
                                }
                                return ("string" == typeof e && 13 !== e.charCodeAt(0) || !e) && console && console.warn && !this._warned && (this._warned = !0, console.warn("Missing character from exported characters list: ", e, style, r)), t
                            },
                            getFontByName: function(t) {
                                for (var i = 0, e = this.fonts.length; i < e;) {
                                    if (this.fonts[i].fName === t) return this.fonts[i];
                                    i += 1
                                }
                                return this.fonts[0]
                            },
                            measureText: function(t, e, r) {
                                var n = this.getFontByName(e),
                                    o = t.charCodeAt(0);
                                if (!n.cache[o + 1]) {
                                    var h = n.helper;
                                    if (" " === t) {
                                        h.textContent = "|" + t + "|";
                                        var l = h.getComputedTextLength();
                                        h.textContent = "||";
                                        var m = h.getComputedTextLength();
                                        n.cache[o + 1] = (l - m) / 100
                                    } else h.textContent = t, n.cache[o + 1] = h.getComputedTextLength() / 100
                                }
                                return n.cache[o + 1] * r
                            },
                            checkLoadedFonts: function() {
                                var i, t, e, r = this.fonts.length,
                                    n = r;
                                for (i = 0; i < r; i += 1) this.fonts[i].loaded ? n -= 1 : "n" === this.fonts[i].fOrigin || 0 === this.fonts[i].origin ? this.fonts[i].loaded = !0 : (t = this.fonts[i].monoCase.node, e = this.fonts[i].monoCase.w, t.offsetWidth !== e ? (n -= 1, this.fonts[i].loaded = !0) : (t = this.fonts[i].sansCase.node, e = this.fonts[i].sansCase.w, t.offsetWidth !== e && (n -= 1, this.fonts[i].loaded = !0)), this.fonts[i].loaded && (this.fonts[i].sansCase.parent.parentNode.removeChild(this.fonts[i].sansCase.parent), this.fonts[i].monoCase.parent.parentNode.removeChild(this.fonts[i].monoCase.parent)));
                                0 !== n && Date.now() - this.initTime < 5e3 ? setTimeout(this.checkLoadedFontsBinded, 20) : setTimeout(this.setIsLoadedBinded, 10)
                            },
                            setIsLoaded: function() {
                                this.isLoaded = !0
                            }
                        };
                        return l.prototype = m, l
                    }(),
                    PropertyFactory = function() {
                        var t = initialDefaultFrame,
                            e = Math.abs;

                        function r(t, e) {
                            var r, o = this.offsetTime;
                            "multidimensional" === this.propType && (r = createTypedArray("float32", this.pv.length));
                            for (var h, l, m, f, c, d, y, v, P, E = e.lastIndex, i = E, x = this.keyframes.length - 1, S = !0; S;) {
                                if (h = this.keyframes[i], l = this.keyframes[i + 1], i === x - 1 && t >= l.t - o) {
                                    h.h && (h = l), E = 0;
                                    break
                                }
                                if (l.t - o > t) {
                                    E = i;
                                    break
                                }
                                i < x - 1 ? i += 1 : (E = 0, S = !1)
                            }
                            m = this.keyframesMetadata[i] || {};
                            var A, C, _, T, k, D, M, F, w, I, V = l.t - o,
                                R = h.t - o;
                            if (h.to) {
                                m.bezierData || (m.bezierData = bez.buildBezierData(h.s, l.s || h.e, h.to, h.ti));
                                var B = m.bezierData;
                                if (t >= V || t < R) {
                                    var L = t >= V ? B.points.length - 1 : 0;
                                    for (c = B.points[L].point.length, f = 0; f < c; f += 1) r[f] = B.points[L].point[f]
                                } else {
                                    m.__fnct ? P = m.__fnct : (P = BezierFactory.getBezierEasing(h.o.x, h.o.y, h.i.x, h.i.y, h.n).get, m.__fnct = P), d = P((t - R) / (V - R));
                                    var G, z = B.segmentLength * d,
                                        N = e.lastFrame < t && e._lastKeyframeIndex === i ? e._lastAddedLength : 0;
                                    for (v = e.lastFrame < t && e._lastKeyframeIndex === i ? e._lastPoint : 0, S = !0, y = B.points.length; S;) {
                                        if (N += B.points[v].partialLength, 0 === z || 0 === d || v === B.points.length - 1) {
                                            for (c = B.points[v].point.length, f = 0; f < c; f += 1) r[f] = B.points[v].point[f];
                                            break
                                        }
                                        if (z >= N && z < N + B.points[v + 1].partialLength) {
                                            for (G = (z - N) / B.points[v + 1].partialLength, c = B.points[v].point.length, f = 0; f < c; f += 1) r[f] = B.points[v].point[f] + (B.points[v + 1].point[f] - B.points[v].point[f]) * G;
                                            break
                                        }
                                        v < y - 1 ? v += 1 : S = !1
                                    }
                                    e._lastPoint = v, e._lastAddedLength = N - B.points[v].partialLength, e._lastKeyframeIndex = i
                                }
                            } else {
                                var O, H, j, W, Y;
                                if (x = h.s.length, A = l.s || h.e, this.sh && 1 !== h.h)
                                    if (t >= V) r[0] = A[0], r[1] = A[1], r[2] = A[2];
                                    else if (t <= R) r[0] = h.s[0], r[1] = h.s[1], r[2] = h.s[2];
                                else {
                                    var X = n(h.s),
                                        K = n(A);
                                    C = r, _ = function(a, b, t) {
                                        var e, r, n, o, h, l = [],
                                            m = a[0],
                                            f = a[1],
                                            c = a[2],
                                            d = a[3],
                                            y = b[0],
                                            v = b[1],
                                            P = b[2],
                                            E = b[3];
                                        return (r = m * y + f * v + c * P + d * E) < 0 && (r = -r, y = -y, v = -v, P = -P, E = -E), 1 - r > 1e-6 ? (e = Math.acos(r), n = Math.sin(e), o = Math.sin((1 - t) * e) / n, h = Math.sin(t * e) / n) : (o = 1 - t, h = t), l[0] = o * m + h * y, l[1] = o * f + h * v, l[2] = o * c + h * P, l[3] = o * d + h * E, l
                                    }(X, K, (t - R) / (V - R)), T = _[0], k = _[1], D = _[2], M = _[3], F = Math.atan2(2 * k * M - 2 * T * D, 1 - 2 * k * k - 2 * D * D), w = Math.asin(2 * T * k + 2 * D * M), I = Math.atan2(2 * T * M - 2 * k * D, 1 - 2 * T * T - 2 * D * D), C[0] = F / degToRads, C[1] = w / degToRads, C[2] = I / degToRads
                                } else
                                    for (i = 0; i < x; i += 1) 1 !== h.h && (t >= V ? d = 1 : t < R ? d = 0 : (h.o.x.constructor === Array ? (m.__fnct || (m.__fnct = []), m.__fnct[i] ? P = m.__fnct[i] : (O = void 0 === h.o.x[i] ? h.o.x[0] : h.o.x[i], H = void 0 === h.o.y[i] ? h.o.y[0] : h.o.y[i], j = void 0 === h.i.x[i] ? h.i.x[0] : h.i.x[i], W = void 0 === h.i.y[i] ? h.i.y[0] : h.i.y[i], P = BezierFactory.getBezierEasing(O, H, j, W).get, m.__fnct[i] = P)) : m.__fnct ? P = m.__fnct : (O = h.o.x, H = h.o.y, j = h.i.x, W = h.i.y, P = BezierFactory.getBezierEasing(O, H, j, W).get, h.keyframeMetadata = P), d = P((t - R) / (V - R)))), A = l.s || h.e, Y = 1 === h.h ? h.s[i] : h.s[i] + (A[i] - h.s[i]) * d, "multidimensional" === this.propType ? r[i] = Y : r = Y
                            }
                            return e.lastIndex = E, r
                        }

                        function n(t) {
                            var e = t[0] * degToRads,
                                r = t[1] * degToRads,
                                n = t[2] * degToRads,
                                o = Math.cos(e / 2),
                                h = Math.cos(r / 2),
                                l = Math.cos(n / 2),
                                m = Math.sin(e / 2),
                                f = Math.sin(r / 2),
                                c = Math.sin(n / 2);
                            return [m * f * l + o * h * c, m * h * l + o * f * c, o * f * l - m * h * c, o * h * l - m * f * c]
                        }

                        function o() {
                            var e = this.comp.renderedFrame - this.offsetTime,
                                r = this.keyframes[0].t - this.offsetTime,
                                n = this.keyframes[this.keyframes.length - 1].t - this.offsetTime;
                            if (!(e === this._caching.lastFrame || this._caching.lastFrame !== t && (this._caching.lastFrame >= n && e >= n || this._caching.lastFrame < r && e < r))) {
                                this._caching.lastFrame >= e && (this._caching._lastKeyframeIndex = -1, this._caching.lastIndex = 0);
                                var o = this.interpolateValue(e, this._caching);
                                this.pv = o
                            }
                            return this._caching.lastFrame = e, this.pv
                        }

                        function h(t) {
                            var r;
                            if ("unidimensional" === this.propType) r = t * this.mult, e(this.v - r) > 1e-5 && (this.v = r, this._mdf = !0);
                            else
                                for (var i = 0, n = this.v.length; i < n;) r = t[i] * this.mult, e(this.v[i] - r) > 1e-5 && (this.v[i] = r, this._mdf = !0), i += 1
                        }

                        function l() {
                            if (this.elem.globalData.frameId !== this.frameId && this.effectsSequence.length)
                                if (this.lock) this.setVValue(this.pv);
                                else {
                                    var i;
                                    this.lock = !0, this._mdf = this._isFirstFrame;
                                    var t = this.effectsSequence.length,
                                        e = this.kf ? this.pv : this.data.k;
                                    for (i = 0; i < t; i += 1) e = this.effectsSequence[i](e);
                                    this.setVValue(e), this._isFirstFrame = !1, this.lock = !1, this.frameId = this.elem.globalData.frameId
                                }
                        }

                        function m(t) {
                            this.effectsSequence.push(t), this.container.addDynamicProperty(this)
                        }

                        function f(t, data, e, r) {
                            this.propType = "unidimensional", this.mult = e || 1, this.data = data, this.v = e ? data.k * e : data.k, this.pv = data.k, this._mdf = !1, this.elem = t, this.container = r, this.comp = t.comp, this.k = !1, this.kf = !1, this.vel = 0, this.effectsSequence = [], this._isFirstFrame = !0, this.getValue = l, this.setVValue = h, this.addEffect = m
                        }

                        function c(t, data, e, r) {
                            var i;
                            this.propType = "multidimensional", this.mult = e || 1, this.data = data, this._mdf = !1, this.elem = t, this.container = r, this.comp = t.comp, this.k = !1, this.kf = !1, this.frameId = -1;
                            var n = data.k.length;
                            for (this.v = createTypedArray("float32", n), this.pv = createTypedArray("float32", n), this.vel = createTypedArray("float32", n), i = 0; i < n; i += 1) this.v[i] = data.k[i] * this.mult, this.pv[i] = data.k[i];
                            this._isFirstFrame = !0, this.effectsSequence = [], this.getValue = l, this.setVValue = h, this.addEffect = m
                        }

                        function d(e, data, n, f) {
                            this.propType = "unidimensional", this.keyframes = data.k, this.keyframesMetadata = [], this.offsetTime = e.data.st, this.frameId = -1, this._caching = {
                                lastFrame: t,
                                lastIndex: 0,
                                value: 0,
                                _lastKeyframeIndex: -1
                            }, this.k = !0, this.kf = !0, this.data = data, this.mult = n || 1, this.elem = e, this.container = f, this.comp = e.comp, this.v = t, this.pv = t, this._isFirstFrame = !0, this.getValue = l, this.setVValue = h, this.interpolateValue = r, this.effectsSequence = [o.bind(this)], this.addEffect = m
                        }

                        function y(e, data, n, f) {
                            var i;
                            this.propType = "multidimensional";
                            var s, c, d, y, v = data.k.length;
                            for (i = 0; i < v - 1; i += 1) data.k[i].to && data.k[i].s && data.k[i + 1] && data.k[i + 1].s && (s = data.k[i].s, c = data.k[i + 1].s, d = data.k[i].to, y = data.k[i].ti, (2 === s.length && (s[0] !== c[0] || s[1] !== c[1]) && bez.pointOnLine2D(s[0], s[1], c[0], c[1], s[0] + d[0], s[1] + d[1]) && bez.pointOnLine2D(s[0], s[1], c[0], c[1], c[0] + y[0], c[1] + y[1]) || 3 === s.length && (s[0] !== c[0] || s[1] !== c[1] || s[2] !== c[2]) && bez.pointOnLine3D(s[0], s[1], s[2], c[0], c[1], c[2], s[0] + d[0], s[1] + d[1], s[2] + d[2]) && bez.pointOnLine3D(s[0], s[1], s[2], c[0], c[1], c[2], c[0] + y[0], c[1] + y[1], c[2] + y[2])) && (data.k[i].to = null, data.k[i].ti = null), s[0] === c[0] && s[1] === c[1] && 0 === d[0] && 0 === d[1] && 0 === y[0] && 0 === y[1] && (2 === s.length || s[2] === c[2] && 0 === d[2] && 0 === y[2]) && (data.k[i].to = null, data.k[i].ti = null));
                            this.effectsSequence = [o.bind(this)], this.data = data, this.keyframes = data.k, this.keyframesMetadata = [], this.offsetTime = e.data.st, this.k = !0, this.kf = !0, this._isFirstFrame = !0, this.mult = n || 1, this.elem = e, this.container = f, this.comp = e.comp, this.getValue = l, this.setVValue = h, this.interpolateValue = r, this.frameId = -1;
                            var P = data.k[0].s.length;
                            for (this.v = createTypedArray("float32", P), this.pv = createTypedArray("float32", P), i = 0; i < P; i += 1) this.v[i] = t, this.pv[i] = t;
                            this._caching = {
                                lastFrame: t,
                                lastIndex: 0,
                                value: createTypedArray("float32", P)
                            }, this.addEffect = m
                        }
                        return {
                            getProp: function(t, data, e, r, n) {
                                var p;
                                if (data.k.length)
                                    if ("number" == typeof data.k[0]) p = new c(t, data, r, n);
                                    else switch (e) {
                                        case 0:
                                            p = new d(t, data, r, n);
                                            break;
                                        case 1:
                                            p = new y(t, data, r, n)
                                    } else p = new f(t, data, r, n);
                                return p.effectsSequence.length && n.addDynamicProperty(p), p
                            }
                        }
                    }(),
                    TransformPropertyFactory = function() {
                        var t = [0, 0];

                        function e(t, data, e) {
                            if (this.elem = t, this.frameId = -1, this.propType = "transform", this.data = data, this.v = new Matrix, this.pre = new Matrix, this.appliedTransformations = 0, this.initDynamicPropertyContainer(e || t), data.p && data.p.s ? (this.px = PropertyFactory.getProp(t, data.p.x, 0, 0, this), this.py = PropertyFactory.getProp(t, data.p.y, 0, 0, this), data.p.z && (this.pz = PropertyFactory.getProp(t, data.p.z, 0, 0, this))) : this.p = PropertyFactory.getProp(t, data.p || {
                                    k: [0, 0, 0]
                                }, 1, 0, this), data.rx) {
                                if (this.rx = PropertyFactory.getProp(t, data.rx, 0, degToRads, this), this.ry = PropertyFactory.getProp(t, data.ry, 0, degToRads, this), this.rz = PropertyFactory.getProp(t, data.rz, 0, degToRads, this), data.or.k[0].ti) {
                                    var i, r = data.or.k.length;
                                    for (i = 0; i < r; i += 1) data.or.k[i].to = null, data.or.k[i].ti = null
                                }
                                this.or = PropertyFactory.getProp(t, data.or, 1, degToRads, this), this.or.sh = !0
                            } else this.r = PropertyFactory.getProp(t, data.r || {
                                k: 0
                            }, 0, degToRads, this);
                            data.sk && (this.sk = PropertyFactory.getProp(t, data.sk, 0, degToRads, this), this.sa = PropertyFactory.getProp(t, data.sa, 0, degToRads, this)), this.a = PropertyFactory.getProp(t, data.a || {
                                k: [0, 0, 0]
                            }, 1, 0, this), this.s = PropertyFactory.getProp(t, data.s || {
                                k: [100, 100, 100]
                            }, 1, .01, this), data.o ? this.o = PropertyFactory.getProp(t, data.o, 0, .01, t) : this.o = {
                                _mdf: !1,
                                v: 1
                            }, this._isDirty = !0, this.dynamicProperties.length || this.getValue(!0)
                        }
                        return e.prototype = {
                            applyToMatrix: function(t) {
                                var e = this._mdf;
                                this.iterateDynamicProperties(), this._mdf = this._mdf || e, this.a && t.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.s && t.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && t.skewFromAxis(-this.sk.v, this.sa.v), this.r ? t.rotate(-this.r.v) : t.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.data.p.s ? this.data.p.z ? t.translate(this.px.v, this.py.v, -this.pz.v) : t.translate(this.px.v, this.py.v, 0) : t.translate(this.p.v[0], this.p.v[1], -this.p.v[2])
                            },
                            getValue: function(e) {
                                if (this.elem.globalData.frameId !== this.frameId) {
                                    if (this._isDirty && (this.precalculateMatrix(), this._isDirty = !1), this.iterateDynamicProperties(), this._mdf || e) {
                                        var r;
                                        if (this.v.cloneFromProps(this.pre.props), this.appliedTransformations < 1 && this.v.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations < 2 && this.v.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && this.appliedTransformations < 3 && this.v.skewFromAxis(-this.sk.v, this.sa.v), this.r && this.appliedTransformations < 4 ? this.v.rotate(-this.r.v) : !this.r && this.appliedTransformations < 4 && this.v.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.autoOriented) {
                                            var n, o;
                                            if (r = this.elem.globalData.frameRate, this.p && this.p.keyframes && this.p.getValueAtTime) this.p._caching.lastFrame + this.p.offsetTime <= this.p.keyframes[0].t ? (n = this.p.getValueAtTime((this.p.keyframes[0].t + .01) / r, 0), o = this.p.getValueAtTime(this.p.keyframes[0].t / r, 0)) : this.p._caching.lastFrame + this.p.offsetTime >= this.p.keyframes[this.p.keyframes.length - 1].t ? (n = this.p.getValueAtTime(this.p.keyframes[this.p.keyframes.length - 1].t / r, 0), o = this.p.getValueAtTime((this.p.keyframes[this.p.keyframes.length - 1].t - .05) / r, 0)) : (n = this.p.pv, o = this.p.getValueAtTime((this.p._caching.lastFrame + this.p.offsetTime - .01) / r, this.p.offsetTime));
                                            else if (this.px && this.px.keyframes && this.py.keyframes && this.px.getValueAtTime && this.py.getValueAtTime) {
                                                n = [], o = [];
                                                var h = this.px,
                                                    l = this.py;
                                                h._caching.lastFrame + h.offsetTime <= h.keyframes[0].t ? (n[0] = h.getValueAtTime((h.keyframes[0].t + .01) / r, 0), n[1] = l.getValueAtTime((l.keyframes[0].t + .01) / r, 0), o[0] = h.getValueAtTime(h.keyframes[0].t / r, 0), o[1] = l.getValueAtTime(l.keyframes[0].t / r, 0)) : h._caching.lastFrame + h.offsetTime >= h.keyframes[h.keyframes.length - 1].t ? (n[0] = h.getValueAtTime(h.keyframes[h.keyframes.length - 1].t / r, 0), n[1] = l.getValueAtTime(l.keyframes[l.keyframes.length - 1].t / r, 0), o[0] = h.getValueAtTime((h.keyframes[h.keyframes.length - 1].t - .01) / r, 0), o[1] = l.getValueAtTime((l.keyframes[l.keyframes.length - 1].t - .01) / r, 0)) : (n = [h.pv, l.pv], o[0] = h.getValueAtTime((h._caching.lastFrame + h.offsetTime - .01) / r, h.offsetTime), o[1] = l.getValueAtTime((l._caching.lastFrame + l.offsetTime - .01) / r, l.offsetTime))
                                            } else n = o = t;
                                            this.v.rotate(-Math.atan2(n[1] - o[1], n[0] - o[0]))
                                        }
                                        this.data.p && this.data.p.s ? this.data.p.z ? this.v.translate(this.px.v, this.py.v, -this.pz.v) : this.v.translate(this.px.v, this.py.v, 0) : this.v.translate(this.p.v[0], this.p.v[1], -this.p.v[2])
                                    }
                                    this.frameId = this.elem.globalData.frameId
                                }
                            },
                            precalculateMatrix: function() {
                                if (!this.a.k && (this.pre.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations = 1, !this.s.effectsSequence.length)) {
                                    if (this.pre.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.appliedTransformations = 2, this.sk) {
                                        if (this.sk.effectsSequence.length || this.sa.effectsSequence.length) return;
                                        this.pre.skewFromAxis(-this.sk.v, this.sa.v), this.appliedTransformations = 3
                                    }
                                    this.r ? this.r.effectsSequence.length || (this.pre.rotate(-this.r.v), this.appliedTransformations = 4) : this.rz.effectsSequence.length || this.ry.effectsSequence.length || this.rx.effectsSequence.length || this.or.effectsSequence.length || (this.pre.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.appliedTransformations = 4)
                                }
                            },
                            autoOrient: function() {}
                        }, extendPrototype([DynamicPropertyContainer], e), e.prototype.addDynamicProperty = function(t) {
                            this._addDynamicProperty(t), this.elem.addDynamicProperty(t), this._isDirty = !0
                        }, e.prototype._addDynamicProperty = DynamicPropertyContainer.prototype.addDynamicProperty, {
                            getTransformProperty: function(t, data, r) {
                                return new e(t, data, r)
                            }
                        }
                    }();

                function ShapePath() {
                    this.c = !1, this._length = 0, this._maxLength = 8, this.v = createSizedArray(this._maxLength), this.o = createSizedArray(this._maxLength), this.i = createSizedArray(this._maxLength)
                }
                ShapePath.prototype.setPathData = function(t, e) {
                    this.c = t, this.setLength(e);
                    for (var i = 0; i < e;) this.v[i] = pointPool.newElement(), this.o[i] = pointPool.newElement(), this.i[i] = pointPool.newElement(), i += 1
                }, ShapePath.prototype.setLength = function(t) {
                    for (; this._maxLength < t;) this.doubleArrayLength();
                    this._length = t
                }, ShapePath.prototype.doubleArrayLength = function() {
                    this.v = this.v.concat(createSizedArray(this._maxLength)), this.i = this.i.concat(createSizedArray(this._maxLength)), this.o = this.o.concat(createSizedArray(this._maxLength)), this._maxLength *= 2
                }, ShapePath.prototype.setXYAt = function(t, e, r, n, o) {
                    var h;
                    switch (this._length = Math.max(this._length, n + 1), this._length >= this._maxLength && this.doubleArrayLength(), r) {
                        case "v":
                            h = this.v;
                            break;
                        case "i":
                            h = this.i;
                            break;
                        case "o":
                            h = this.o;
                            break;
                        default:
                            h = []
                    }(!h[n] || h[n] && !o) && (h[n] = pointPool.newElement()), h[n][0] = t, h[n][1] = e
                }, ShapePath.prototype.setTripleAt = function(t, e, r, n, o, h, l, m) {
                    this.setXYAt(t, e, "v", l, m), this.setXYAt(r, n, "o", l, m), this.setXYAt(o, h, "i", l, m)
                }, ShapePath.prototype.reverse = function() {
                    var t = new ShapePath;
                    t.setPathData(this.c, this._length);
                    var e = this.v,
                        r = this.o,
                        n = this.i,
                        o = 0;
                    this.c && (t.setTripleAt(e[0][0], e[0][1], n[0][0], n[0][1], r[0][0], r[0][1], 0, !1), o = 1);
                    var i, h = this._length - 1,
                        l = this._length;
                    for (i = o; i < l; i += 1) t.setTripleAt(e[h][0], e[h][1], n[h][0], n[h][1], r[h][0], r[h][1], i, !1), h -= 1;
                    return t
                };
                var ShapePropertyFactory = function() {
                        var t = -999999;

                        function e(t, e, r) {
                            var n, o, h, l, m, f, c, d, y, v = r.lastIndex,
                                P = this.keyframes;
                            if (t < P[0].t - this.offsetTime) n = P[0].s[0], h = !0, v = 0;
                            else if (t >= P[P.length - 1].t - this.offsetTime) n = P[P.length - 1].s ? P[P.length - 1].s[0] : P[P.length - 2].e[0], h = !0;
                            else {
                                for (var E, x, S, i = v, A = P.length - 1, C = !0; C && (E = P[i], !((x = P[i + 1]).t - this.offsetTime > t));) i < A - 1 ? i += 1 : C = !1;
                                if (S = this.keyframesMetadata[i] || {}, v = i, !(h = 1 === E.h)) {
                                    if (t >= x.t - this.offsetTime) d = 1;
                                    else if (t < E.t - this.offsetTime) d = 0;
                                    else {
                                        var _;
                                        S.__fnct ? _ = S.__fnct : (_ = BezierFactory.getBezierEasing(E.o.x, E.o.y, E.i.x, E.i.y).get, S.__fnct = _), d = _((t - (E.t - this.offsetTime)) / (x.t - this.offsetTime - (E.t - this.offsetTime)))
                                    }
                                    o = x.s ? x.s[0] : E.e[0]
                                }
                                n = E.s[0]
                            }
                            for (f = e._length, c = n.i[0].length, r.lastIndex = v, l = 0; l < f; l += 1)
                                for (m = 0; m < c; m += 1) y = h ? n.i[l][m] : n.i[l][m] + (o.i[l][m] - n.i[l][m]) * d, e.i[l][m] = y, y = h ? n.o[l][m] : n.o[l][m] + (o.o[l][m] - n.o[l][m]) * d, e.o[l][m] = y, y = h ? n.v[l][m] : n.v[l][m] + (o.v[l][m] - n.v[l][m]) * d, e.v[l][m] = y
                        }

                        function r() {
                            var e = this.comp.renderedFrame - this.offsetTime,
                                r = this.keyframes[0].t - this.offsetTime,
                                n = this.keyframes[this.keyframes.length - 1].t - this.offsetTime,
                                o = this._caching.lastFrame;
                            return o !== t && (o < r && e < r || o > n && e > n) || (this._caching.lastIndex = o < e ? this._caching.lastIndex : 0, this.interpolateShape(e, this.pv, this._caching)), this._caching.lastFrame = e, this.pv
                        }

                        function n() {
                            this.paths = this.localShapeCollection
                        }

                        function o(t) {
                            (function(t, e) {
                                if (t._length !== e._length || t.c !== e.c) return !1;
                                var i, r = t._length;
                                for (i = 0; i < r; i += 1)
                                    if (t.v[i][0] !== e.v[i][0] || t.v[i][1] !== e.v[i][1] || t.o[i][0] !== e.o[i][0] || t.o[i][1] !== e.o[i][1] || t.i[i][0] !== e.i[i][0] || t.i[i][1] !== e.i[i][1]) return !1;
                                return !0
                            })(this.v, t) || (this.v = shapePool.clone(t), this.localShapeCollection.releaseShapes(), this.localShapeCollection.addShape(this.v), this._mdf = !0, this.paths = this.localShapeCollection)
                        }

                        function h() {
                            if (this.elem.globalData.frameId !== this.frameId)
                                if (this.effectsSequence.length)
                                    if (this.lock) this.setVValue(this.pv);
                                    else {
                                        var t, i;
                                        this.lock = !0, this._mdf = !1, t = this.kf ? this.pv : this.data.ks ? this.data.ks.k : this.data.pt.k;
                                        var e = this.effectsSequence.length;
                                        for (i = 0; i < e; i += 1) t = this.effectsSequence[i](t);
                                        this.setVValue(t), this.lock = !1, this.frameId = this.elem.globalData.frameId
                                    }
                            else this._mdf = !1
                        }

                        function l(t, data, e) {
                            this.propType = "shape", this.comp = t.comp, this.container = t, this.elem = t, this.data = data, this.k = !1, this.kf = !1, this._mdf = !1;
                            var r = 3 === e ? data.pt.k : data.ks.k;
                            this.v = shapePool.clone(r), this.pv = shapePool.clone(this.v), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.reset = n, this.effectsSequence = []
                        }

                        function m(t) {
                            this.effectsSequence.push(t), this.container.addDynamicProperty(this)
                        }

                        function f(e, data, o) {
                            this.propType = "shape", this.comp = e.comp, this.elem = e, this.container = e, this.offsetTime = e.data.st, this.keyframes = 3 === o ? data.pt.k : data.ks.k, this.keyframesMetadata = [], this.k = !0, this.kf = !0;
                            var h = this.keyframes[0].s[0].i.length;
                            this.v = shapePool.newElement(), this.v.setPathData(this.keyframes[0].s[0].c, h), this.pv = shapePool.clone(this.v), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.lastFrame = t, this.reset = n, this._caching = {
                                lastFrame: t,
                                lastIndex: 0
                            }, this.effectsSequence = [r.bind(this)]
                        }
                        l.prototype.interpolateShape = e, l.prototype.getValue = h, l.prototype.setVValue = o, l.prototype.addEffect = m, f.prototype.getValue = h, f.prototype.interpolateShape = e, f.prototype.setVValue = o, f.prototype.addEffect = m;
                        var c = function() {
                                var t = roundCorner;

                                function e(t, data) {
                                    this.v = shapePool.newElement(), this.v.setPathData(!0, 4), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.localShapeCollection.addShape(this.v), this.d = data.d, this.elem = t, this.comp = t.comp, this.frameId = -1, this.initDynamicPropertyContainer(t), this.p = PropertyFactory.getProp(t, data.p, 1, 0, this), this.s = PropertyFactory.getProp(t, data.s, 1, 0, this), this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertEllToPath())
                                }
                                return e.prototype = {
                                    reset: n,
                                    getValue: function() {
                                        this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertEllToPath())
                                    },
                                    convertEllToPath: function() {
                                        var e = this.p.v[0],
                                            r = this.p.v[1],
                                            n = this.s.v[0] / 2,
                                            o = this.s.v[1] / 2,
                                            h = 3 !== this.d,
                                            l = this.v;
                                        l.v[0][0] = e, l.v[0][1] = r - o, l.v[1][0] = h ? e + n : e - n, l.v[1][1] = r, l.v[2][0] = e, l.v[2][1] = r + o, l.v[3][0] = h ? e - n : e + n, l.v[3][1] = r, l.i[0][0] = h ? e - n * t : e + n * t, l.i[0][1] = r - o, l.i[1][0] = h ? e + n : e - n, l.i[1][1] = r - o * t, l.i[2][0] = h ? e + n * t : e - n * t, l.i[2][1] = r + o, l.i[3][0] = h ? e - n : e + n, l.i[3][1] = r + o * t, l.o[0][0] = h ? e + n * t : e - n * t, l.o[0][1] = r - o, l.o[1][0] = h ? e + n : e - n, l.o[1][1] = r + o * t, l.o[2][0] = h ? e - n * t : e + n * t, l.o[2][1] = r + o, l.o[3][0] = h ? e - n : e + n, l.o[3][1] = r - o * t
                                    }
                                }, extendPrototype([DynamicPropertyContainer], e), e
                            }(),
                            d = function() {
                                function t(t, data) {
                                    this.v = shapePool.newElement(), this.v.setPathData(!0, 0), this.elem = t, this.comp = t.comp, this.data = data, this.frameId = -1, this.d = data.d, this.initDynamicPropertyContainer(t), 1 === data.sy ? (this.ir = PropertyFactory.getProp(t, data.ir, 0, 0, this), this.is = PropertyFactory.getProp(t, data.is, 0, .01, this), this.convertToPath = this.convertStarToPath) : this.convertToPath = this.convertPolygonToPath, this.pt = PropertyFactory.getProp(t, data.pt, 0, 0, this), this.p = PropertyFactory.getProp(t, data.p, 1, 0, this), this.r = PropertyFactory.getProp(t, data.r, 0, degToRads, this), this.or = PropertyFactory.getProp(t, data.or, 0, 0, this), this.os = PropertyFactory.getProp(t, data.os, 0, .01, this), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertToPath())
                                }
                                return t.prototype = {
                                    reset: n,
                                    getValue: function() {
                                        this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertToPath())
                                    },
                                    convertStarToPath: function() {
                                        var i, t, e, r, n = 2 * Math.floor(this.pt.v),
                                            o = 2 * Math.PI / n,
                                            h = !0,
                                            l = this.or.v,
                                            m = this.ir.v,
                                            f = this.os.v,
                                            c = this.is.v,
                                            d = 2 * Math.PI * l / (2 * n),
                                            y = 2 * Math.PI * m / (2 * n),
                                            v = -Math.PI / 2;
                                        v += this.r.v;
                                        var P = 3 === this.data.d ? -1 : 1;
                                        for (this.v._length = 0, i = 0; i < n; i += 1) {
                                            e = h ? f : c, r = h ? d : y;
                                            var E = (t = h ? l : m) * Math.cos(v),
                                                x = t * Math.sin(v),
                                                S = 0 === E && 0 === x ? 0 : x / Math.sqrt(E * E + x * x),
                                                A = 0 === E && 0 === x ? 0 : -E / Math.sqrt(E * E + x * x);
                                            E += +this.p.v[0], x += +this.p.v[1], this.v.setTripleAt(E, x, E - S * r * e * P, x - A * r * e * P, E + S * r * e * P, x + A * r * e * P, i, !0), h = !h, v += o * P
                                        }
                                    },
                                    convertPolygonToPath: function() {
                                        var i, t = Math.floor(this.pt.v),
                                            e = 2 * Math.PI / t,
                                            r = this.or.v,
                                            n = this.os.v,
                                            o = 2 * Math.PI * r / (4 * t),
                                            h = .5 * -Math.PI,
                                            l = 3 === this.data.d ? -1 : 1;
                                        for (h += this.r.v, this.v._length = 0, i = 0; i < t; i += 1) {
                                            var m = r * Math.cos(h),
                                                f = r * Math.sin(h),
                                                c = 0 === m && 0 === f ? 0 : f / Math.sqrt(m * m + f * f),
                                                d = 0 === m && 0 === f ? 0 : -m / Math.sqrt(m * m + f * f);
                                            m += +this.p.v[0], f += +this.p.v[1], this.v.setTripleAt(m, f, m - c * o * n * l, f - d * o * n * l, m + c * o * n * l, f + d * o * n * l, i, !0), h += e * l
                                        }
                                        this.paths.length = 0, this.paths[0] = this.v
                                    }
                                }, extendPrototype([DynamicPropertyContainer], t), t
                            }(),
                            y = function() {
                                function t(t, data) {
                                    this.v = shapePool.newElement(), this.v.c = !0, this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.elem = t, this.comp = t.comp, this.frameId = -1, this.d = data.d, this.initDynamicPropertyContainer(t), this.p = PropertyFactory.getProp(t, data.p, 1, 0, this), this.s = PropertyFactory.getProp(t, data.s, 1, 0, this), this.r = PropertyFactory.getProp(t, data.r, 0, 0, this), this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertRectToPath())
                                }
                                return t.prototype = {
                                    convertRectToPath: function() {
                                        var t = this.p.v[0],
                                            e = this.p.v[1],
                                            r = this.s.v[0] / 2,
                                            n = this.s.v[1] / 2,
                                            o = bmMin(r, n, this.r.v),
                                            h = o * (1 - roundCorner);
                                        this.v._length = 0, 2 === this.d || 1 === this.d ? (this.v.setTripleAt(t + r, e - n + o, t + r, e - n + o, t + r, e - n + h, 0, !0), this.v.setTripleAt(t + r, e + n - o, t + r, e + n - h, t + r, e + n - o, 1, !0), 0 !== o ? (this.v.setTripleAt(t + r - o, e + n, t + r - o, e + n, t + r - h, e + n, 2, !0), this.v.setTripleAt(t - r + o, e + n, t - r + h, e + n, t - r + o, e + n, 3, !0), this.v.setTripleAt(t - r, e + n - o, t - r, e + n - o, t - r, e + n - h, 4, !0), this.v.setTripleAt(t - r, e - n + o, t - r, e - n + h, t - r, e - n + o, 5, !0), this.v.setTripleAt(t - r + o, e - n, t - r + o, e - n, t - r + h, e - n, 6, !0), this.v.setTripleAt(t + r - o, e - n, t + r - h, e - n, t + r - o, e - n, 7, !0)) : (this.v.setTripleAt(t - r, e + n, t - r + h, e + n, t - r, e + n, 2), this.v.setTripleAt(t - r, e - n, t - r, e - n + h, t - r, e - n, 3))) : (this.v.setTripleAt(t + r, e - n + o, t + r, e - n + h, t + r, e - n + o, 0, !0), 0 !== o ? (this.v.setTripleAt(t + r - o, e - n, t + r - o, e - n, t + r - h, e - n, 1, !0), this.v.setTripleAt(t - r + o, e - n, t - r + h, e - n, t - r + o, e - n, 2, !0), this.v.setTripleAt(t - r, e - n + o, t - r, e - n + o, t - r, e - n + h, 3, !0), this.v.setTripleAt(t - r, e + n - o, t - r, e + n - h, t - r, e + n - o, 4, !0), this.v.setTripleAt(t - r + o, e + n, t - r + o, e + n, t - r + h, e + n, 5, !0), this.v.setTripleAt(t + r - o, e + n, t + r - h, e + n, t + r - o, e + n, 6, !0), this.v.setTripleAt(t + r, e + n - o, t + r, e + n - o, t + r, e + n - h, 7, !0)) : (this.v.setTripleAt(t - r, e - n, t - r + h, e - n, t - r, e - n, 1, !0), this.v.setTripleAt(t - r, e + n, t - r, e + n - h, t - r, e + n, 2, !0), this.v.setTripleAt(t + r, e + n, t + r - h, e + n, t + r, e + n, 3, !0)))
                                    },
                                    getValue: function() {
                                        this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertRectToPath())
                                    },
                                    reset: n
                                }, extendPrototype([DynamicPropertyContainer], t), t
                            }(),
                            v = {
                                getShapeProp: function(t, data, e) {
                                    var r;
                                    return 3 === e || 4 === e ? r = (3 === e ? data.pt : data.ks).k.length ? new f(t, data, e) : new l(t, data, e) : 5 === e ? r = new y(t, data) : 6 === e ? r = new c(t, data) : 7 === e && (r = new d(t, data)), r.k && t.addDynamicProperty(r), r
                                },
                                getConstructorFunction: function() {
                                    return l
                                },
                                getKeyframedConstructorFunction: function() {
                                    return f
                                }
                            };
                        return v
                    }(),
                    ShapeModifiers = (ob = {}, modifiers = {}, ob.registerModifier = function(t, e) {
                        modifiers[t] || (modifiers[t] = e)
                    }, ob.getModifier = function(t, e, data) {
                        return new modifiers[t](e, data)
                    }, ob),
                    ob, modifiers;

                function ShapeModifier() {}

                function TrimModifier() {}

                function RoundCornersModifier() {}

                function PuckerAndBloatModifier() {}

                function RepeaterModifier() {}

                function ShapeCollection() {
                    this._length = 0, this._maxLength = 4, this.shapes = createSizedArray(this._maxLength)
                }

                function DashProperty(t, data, e, r) {
                    var i;
                    this.elem = t, this.frameId = -1, this.dataProps = createSizedArray(data.length), this.renderer = e, this.k = !1, this.dashStr = "", this.dashArray = createTypedArray("float32", data.length ? data.length - 1 : 0), this.dashoffset = createTypedArray("float32", 1), this.initDynamicPropertyContainer(r);
                    var n, o = data.length || 0;
                    for (i = 0; i < o; i += 1) n = PropertyFactory.getProp(t, data[i].v, 0, 0, this), this.k = n.k || this.k, this.dataProps[i] = {
                        n: data[i].n,
                        p: n
                    };
                    this.k || this.getValue(!0), this._isAnimated = this.k
                }

                function GradientProperty(t, data, e) {
                    this.data = data, this.c = createTypedArray("uint8c", 4 * data.p);
                    var r = data.k.k[0].s ? data.k.k[0].s.length - 4 * data.p : data.k.k.length - 4 * data.p;
                    this.o = createTypedArray("float32", r), this._cmdf = !1, this._omdf = !1, this._collapsable = this.checkCollapsable(), this._hasOpacity = r, this.initDynamicPropertyContainer(e), this.prop = PropertyFactory.getProp(t, data.k, 1, null, this), this.k = this.prop.k, this.getValue(!0)
                }
                ShapeModifier.prototype.initModifierProperties = function() {}, ShapeModifier.prototype.addShapeToModifier = function() {}, ShapeModifier.prototype.addShape = function(data) {
                    if (!this.closed) {
                        data.sh.container.addDynamicProperty(data.sh);
                        var t = {
                            shape: data.sh,
                            data: data,
                            localShapeCollection: shapeCollectionPool.newShapeCollection()
                        };
                        this.shapes.push(t), this.addShapeToModifier(t), this._isAnimated && data.setAsAnimated()
                    }
                }, ShapeModifier.prototype.init = function(t, data) {
                    this.shapes = [], this.elem = t, this.initDynamicPropertyContainer(t), this.initModifierProperties(t, data), this.frameId = initialDefaultFrame, this.closed = !1, this.k = !1, this.dynamicProperties.length ? this.k = !0 : this.getValue(!0)
                }, ShapeModifier.prototype.processKeys = function() {
                    this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties())
                }, extendPrototype([DynamicPropertyContainer], ShapeModifier), extendPrototype([ShapeModifier], TrimModifier), TrimModifier.prototype.initModifierProperties = function(t, data) {
                    this.s = PropertyFactory.getProp(t, data.s, 0, .01, this), this.e = PropertyFactory.getProp(t, data.e, 0, .01, this), this.o = PropertyFactory.getProp(t, data.o, 0, 0, this), this.sValue = 0, this.eValue = 0, this.getValue = this.processKeys, this.m = data.m, this._isAnimated = !!this.s.effectsSequence.length || !!this.e.effectsSequence.length || !!this.o.effectsSequence.length
                }, TrimModifier.prototype.addShapeToModifier = function(t) {
                    t.pathsData = []
                }, TrimModifier.prototype.calculateShapeEdges = function(s, t, e, r, n) {
                    var o = [];
                    t <= 1 ? o.push({
                        s: s,
                        e: t
                    }) : s >= 1 ? o.push({
                        s: s - 1,
                        e: t - 1
                    }) : (o.push({
                        s: s,
                        e: 1
                    }), o.push({
                        s: 0,
                        e: t - 1
                    }));
                    var i, h, l = [],
                        m = o.length;
                    for (i = 0; i < m; i += 1) {
                        var f, c;
                        (h = o[i]).e * n < r || h.s * n > r + e || (f = h.s * n <= r ? 0 : (h.s * n - r) / e, c = h.e * n >= r + e ? 1 : (h.e * n - r) / e, l.push([f, c]))
                    }
                    return l.length || l.push([0, 0]), l
                }, TrimModifier.prototype.releasePathsData = function(t) {
                    var i, e = t.length;
                    for (i = 0; i < e; i += 1) segmentsLengthPool.release(t[i]);
                    return t.length = 0, t
                }, TrimModifier.prototype.processShapes = function(t) {
                    var s, e, r, i;
                    if (this._mdf || t) {
                        var n = this.o.v % 360 / 360;
                        if (n < 0 && (n += 1), (s = this.s.v > 1 ? 1 + n : this.s.v < 0 ? 0 + n : this.s.v + n) > (e = this.e.v > 1 ? 1 + n : this.e.v < 0 ? 0 + n : this.e.v + n)) {
                            var o = s;
                            s = e, e = o
                        }
                        s = 1e-4 * Math.round(1e4 * s), e = 1e-4 * Math.round(1e4 * e), this.sValue = s, this.eValue = e
                    } else s = this.sValue, e = this.eValue;
                    var h, l, m, f, c, d = this.shapes.length,
                        y = 0;
                    if (e === s)
                        for (i = 0; i < d; i += 1) this.shapes[i].localShapeCollection.releaseShapes(), this.shapes[i].shape._mdf = !0, this.shapes[i].shape.paths = this.shapes[i].localShapeCollection, this._mdf && (this.shapes[i].pathsData.length = 0);
                    else if (1 === e && 0 === s || 0 === e && 1 === s) {
                        if (this._mdf)
                            for (i = 0; i < d; i += 1) this.shapes[i].pathsData.length = 0, this.shapes[i].shape._mdf = !0
                    } else {
                        var v, P, E = [];
                        for (i = 0; i < d; i += 1)
                            if ((v = this.shapes[i]).shape._mdf || this._mdf || t || 2 === this.m) {
                                if (l = (r = v.shape.paths)._length, c = 0, !v.shape._mdf && v.pathsData.length) c = v.totalShapeLength;
                                else {
                                    for (m = this.releasePathsData(v.pathsData), h = 0; h < l; h += 1) f = bez.getSegmentsLength(r.shapes[h]), m.push(f), c += f.totalLength;
                                    v.totalShapeLength = c, v.pathsData = m
                                }
                                y += c, v.shape._mdf = !0
                            } else v.shape.paths = v.localShapeCollection;
                        var x, S = s,
                            A = e,
                            C = 0;
                        for (i = d - 1; i >= 0; i -= 1)
                            if ((v = this.shapes[i]).shape._mdf) {
                                for ((P = v.localShapeCollection).releaseShapes(), 2 === this.m && d > 1 ? (x = this.calculateShapeEdges(s, e, v.totalShapeLength, C, y), C += v.totalShapeLength) : x = [
                                        [S, A]
                                    ], l = x.length, h = 0; h < l; h += 1) {
                                    S = x[h][0], A = x[h][1], E.length = 0, A <= 1 ? E.push({
                                        s: v.totalShapeLength * S,
                                        e: v.totalShapeLength * A
                                    }) : S >= 1 ? E.push({
                                        s: v.totalShapeLength * (S - 1),
                                        e: v.totalShapeLength * (A - 1)
                                    }) : (E.push({
                                        s: v.totalShapeLength * S,
                                        e: v.totalShapeLength
                                    }), E.push({
                                        s: 0,
                                        e: v.totalShapeLength * (A - 1)
                                    }));
                                    var _ = this.addShapes(v, E[0]);
                                    if (E[0].s !== E[0].e) {
                                        if (E.length > 1)
                                            if (v.shape.paths.shapes[v.shape.paths._length - 1].c) {
                                                var T = _.pop();
                                                this.addPaths(_, P), _ = this.addShapes(v, E[1], T)
                                            } else this.addPaths(_, P), _ = this.addShapes(v, E[1]);
                                        this.addPaths(_, P)
                                    }
                                }
                                v.shape.paths = P
                            }
                    }
                }, TrimModifier.prototype.addPaths = function(t, e) {
                    var i, r = t.length;
                    for (i = 0; i < r; i += 1) e.addShape(t[i])
                }, TrimModifier.prototype.addSegment = function(t, e, r, n, o, h, l) {
                    o.setXYAt(e[0], e[1], "o", h), o.setXYAt(r[0], r[1], "i", h + 1), l && o.setXYAt(t[0], t[1], "v", h), o.setXYAt(n[0], n[1], "v", h + 1)
                }, TrimModifier.prototype.addSegmentFromArray = function(t, e, r, n) {
                    e.setXYAt(t[1], t[5], "o", r), e.setXYAt(t[2], t[6], "i", r + 1), n && e.setXYAt(t[0], t[4], "v", r), e.setXYAt(t[3], t[7], "v", r + 1)
                }, TrimModifier.prototype.addShapes = function(t, e, r) {
                    var i, n, o, h, l, m, f, c, d = t.pathsData,
                        y = t.shape.paths.shapes,
                        v = t.shape.paths._length,
                        P = 0,
                        E = [],
                        x = !0;
                    for (r ? (l = r._length, c = r._length) : (r = shapePool.newElement(), l = 0, c = 0), E.push(r), i = 0; i < v; i += 1) {
                        for (m = d[i].lengths, r.c = y[i].c, o = y[i].c ? m.length : m.length + 1, n = 1; n < o; n += 1)
                            if (P + (h = m[n - 1]).addedLength < e.s) P += h.addedLength, r.c = !1;
                            else {
                                if (P > e.e) {
                                    r.c = !1;
                                    break
                                }
                                e.s <= P && e.e >= P + h.addedLength ? (this.addSegment(y[i].v[n - 1], y[i].o[n - 1], y[i].i[n], y[i].v[n], r, l, x), x = !1) : (f = bez.getNewSegment(y[i].v[n - 1], y[i].v[n], y[i].o[n - 1], y[i].i[n], (e.s - P) / h.addedLength, (e.e - P) / h.addedLength, m[n - 1]), this.addSegmentFromArray(f, r, l, x), x = !1, r.c = !1), P += h.addedLength, l += 1
                            }
                        if (y[i].c && m.length) {
                            if (h = m[n - 1], P <= e.e) {
                                var S = m[n - 1].addedLength;
                                e.s <= P && e.e >= P + S ? (this.addSegment(y[i].v[n - 1], y[i].o[n - 1], y[i].i[0], y[i].v[0], r, l, x), x = !1) : (f = bez.getNewSegment(y[i].v[n - 1], y[i].v[0], y[i].o[n - 1], y[i].i[0], (e.s - P) / S, (e.e - P) / S, m[n - 1]), this.addSegmentFromArray(f, r, l, x), x = !1, r.c = !1)
                            } else r.c = !1;
                            P += h.addedLength, l += 1
                        }
                        if (r._length && (r.setXYAt(r.v[c][0], r.v[c][1], "i", c), r.setXYAt(r.v[r._length - 1][0], r.v[r._length - 1][1], "o", r._length - 1)), P > e.e) break;
                        i < v - 1 && (r = shapePool.newElement(), x = !0, E.push(r), l = 0)
                    }
                    return E
                }, ShapeModifiers.registerModifier("tm", TrimModifier), extendPrototype([ShapeModifier], RoundCornersModifier), RoundCornersModifier.prototype.initModifierProperties = function(t, data) {
                    this.getValue = this.processKeys, this.rd = PropertyFactory.getProp(t, data.r, 0, null, this), this._isAnimated = !!this.rd.effectsSequence.length
                }, RoundCornersModifier.prototype.processPath = function(path, t) {
                    var i, e = shapePool.newElement();
                    e.c = path.c;
                    var r, n, o, h, l, m, f, c, d, y, v, P, E = path._length,
                        x = 0;
                    for (i = 0; i < E; i += 1) r = path.v[i], o = path.o[i], n = path.i[i], r[0] === o[0] && r[1] === o[1] && r[0] === n[0] && r[1] === n[1] ? 0 !== i && i !== E - 1 || path.c ? (h = 0 === i ? path.v[E - 1] : path.v[i - 1], m = (l = Math.sqrt(Math.pow(r[0] - h[0], 2) + Math.pow(r[1] - h[1], 2))) ? Math.min(l / 2, t) / l : 0, f = v = r[0] + (h[0] - r[0]) * m, c = P = r[1] - (r[1] - h[1]) * m, d = f - (f - r[0]) * roundCorner, y = c - (c - r[1]) * roundCorner, e.setTripleAt(f, c, d, y, v, P, x), x += 1, h = i === E - 1 ? path.v[0] : path.v[i + 1], m = (l = Math.sqrt(Math.pow(r[0] - h[0], 2) + Math.pow(r[1] - h[1], 2))) ? Math.min(l / 2, t) / l : 0, f = d = r[0] + (h[0] - r[0]) * m, c = y = r[1] + (h[1] - r[1]) * m, v = f - (f - r[0]) * roundCorner, P = c - (c - r[1]) * roundCorner, e.setTripleAt(f, c, d, y, v, P, x), x += 1) : (e.setTripleAt(r[0], r[1], o[0], o[1], n[0], n[1], x), x += 1) : (e.setTripleAt(path.v[i][0], path.v[i][1], path.o[i][0], path.o[i][1], path.i[i][0], path.i[i][1], x), x += 1);
                    return e
                }, RoundCornersModifier.prototype.processShapes = function(t) {
                    var e, i, r, n, o, h, l = this.shapes.length,
                        m = this.rd.v;
                    if (0 !== m)
                        for (i = 0; i < l; i += 1) {
                            if (h = (o = this.shapes[i]).localShapeCollection, o.shape._mdf || this._mdf || t)
                                for (h.releaseShapes(), o.shape._mdf = !0, e = o.shape.paths.shapes, n = o.shape.paths._length, r = 0; r < n; r += 1) h.addShape(this.processPath(e[r], m));
                            o.shape.paths = o.localShapeCollection
                        }
                    this.dynamicProperties.length || (this._mdf = !1)
                }, ShapeModifiers.registerModifier("rd", RoundCornersModifier), extendPrototype([ShapeModifier], PuckerAndBloatModifier), PuckerAndBloatModifier.prototype.initModifierProperties = function(t, data) {
                    this.getValue = this.processKeys, this.amount = PropertyFactory.getProp(t, data.a, 0, null, this), this._isAnimated = !!this.amount.effectsSequence.length
                }, PuckerAndBloatModifier.prototype.processPath = function(path, t) {
                    var e = t / 100,
                        r = [0, 0],
                        n = path._length,
                        i = 0;
                    for (i = 0; i < n; i += 1) r[0] += path.v[i][0], r[1] += path.v[i][1];
                    r[0] /= n, r[1] /= n;
                    var o, h, l, m, f, c, d = shapePool.newElement();
                    for (d.c = path.c, i = 0; i < n; i += 1) o = path.v[i][0] + (r[0] - path.v[i][0]) * e, h = path.v[i][1] + (r[1] - path.v[i][1]) * e, l = path.o[i][0] + (r[0] - path.o[i][0]) * -e, m = path.o[i][1] + (r[1] - path.o[i][1]) * -e, f = path.i[i][0] + (r[0] - path.i[i][0]) * -e, c = path.i[i][1] + (r[1] - path.i[i][1]) * -e, d.setTripleAt(o, h, l, m, f, c, i);
                    return d
                }, PuckerAndBloatModifier.prototype.processShapes = function(t) {
                    var e, i, r, n, o, h, l = this.shapes.length,
                        m = this.amount.v;
                    if (0 !== m)
                        for (i = 0; i < l; i += 1) {
                            if (h = (o = this.shapes[i]).localShapeCollection, o.shape._mdf || this._mdf || t)
                                for (h.releaseShapes(), o.shape._mdf = !0, e = o.shape.paths.shapes, n = o.shape.paths._length, r = 0; r < n; r += 1) h.addShape(this.processPath(e[r], m));
                            o.shape.paths = o.localShapeCollection
                        }
                    this.dynamicProperties.length || (this._mdf = !1)
                }, ShapeModifiers.registerModifier("pb", PuckerAndBloatModifier), extendPrototype([ShapeModifier], RepeaterModifier), RepeaterModifier.prototype.initModifierProperties = function(t, data) {
                    this.getValue = this.processKeys, this.c = PropertyFactory.getProp(t, data.c, 0, null, this), this.o = PropertyFactory.getProp(t, data.o, 0, null, this), this.tr = TransformPropertyFactory.getTransformProperty(t, data.tr, this), this.so = PropertyFactory.getProp(t, data.tr.so, 0, .01, this), this.eo = PropertyFactory.getProp(t, data.tr.eo, 0, .01, this), this.data = data, this.dynamicProperties.length || this.getValue(!0), this._isAnimated = !!this.dynamicProperties.length, this.pMatrix = new Matrix, this.rMatrix = new Matrix, this.sMatrix = new Matrix, this.tMatrix = new Matrix, this.matrix = new Matrix
                }, RepeaterModifier.prototype.applyTransforms = function(t, e, r, n, o, h) {
                    var l = h ? -1 : 1,
                        m = n.s.v[0] + (1 - n.s.v[0]) * (1 - o),
                        f = n.s.v[1] + (1 - n.s.v[1]) * (1 - o);
                    t.translate(n.p.v[0] * l * o, n.p.v[1] * l * o, n.p.v[2]), e.translate(-n.a.v[0], -n.a.v[1], n.a.v[2]), e.rotate(-n.r.v * l * o), e.translate(n.a.v[0], n.a.v[1], n.a.v[2]), r.translate(-n.a.v[0], -n.a.v[1], n.a.v[2]), r.scale(h ? 1 / m : m, h ? 1 / f : f), r.translate(n.a.v[0], n.a.v[1], n.a.v[2])
                }, RepeaterModifier.prototype.init = function(t, e, r, n) {
                    for (this.elem = t, this.arr = e, this.pos = r, this.elemsData = n, this._currentCopies = 0, this._elements = [], this._groups = [], this.frameId = -1, this.initDynamicPropertyContainer(t), this.initModifierProperties(t, e[r]); r > 0;) r -= 1, this._elements.unshift(e[r]);
                    this.dynamicProperties.length ? this.k = !0 : this.getValue(!0)
                }, RepeaterModifier.prototype.resetElements = function(t) {
                    var i, e = t.length;
                    for (i = 0; i < e; i += 1) t[i]._processed = !1, "gr" === t[i].ty && this.resetElements(t[i].it)
                }, RepeaterModifier.prototype.cloneElements = function(t) {
                    var e = JSON.parse(JSON.stringify(t));
                    return this.resetElements(e), e
                }, RepeaterModifier.prototype.changeGroupRender = function(t, e) {
                    var i, r = t.length;
                    for (i = 0; i < r; i += 1) t[i]._render = e, "gr" === t[i].ty && this.changeGroupRender(t[i].it, e)
                }, RepeaterModifier.prototype.processShapes = function(t) {
                    var e, r, i, n, o, h = !1;
                    if (this._mdf || t) {
                        var l, m = Math.ceil(this.c.v);
                        if (this._groups.length < m) {
                            for (; this._groups.length < m;) {
                                var f = {
                                    it: this.cloneElements(this._elements),
                                    ty: "gr"
                                };
                                f.it.push({
                                    a: {
                                        a: 0,
                                        ix: 1,
                                        k: [0, 0]
                                    },
                                    nm: "Transform",
                                    o: {
                                        a: 0,
                                        ix: 7,
                                        k: 100
                                    },
                                    p: {
                                        a: 0,
                                        ix: 2,
                                        k: [0, 0]
                                    },
                                    r: {
                                        a: 1,
                                        ix: 6,
                                        k: [{
                                            s: 0,
                                            e: 0,
                                            t: 0
                                        }, {
                                            s: 0,
                                            e: 0,
                                            t: 1
                                        }]
                                    },
                                    s: {
                                        a: 0,
                                        ix: 3,
                                        k: [100, 100]
                                    },
                                    sa: {
                                        a: 0,
                                        ix: 5,
                                        k: 0
                                    },
                                    sk: {
                                        a: 0,
                                        ix: 4,
                                        k: 0
                                    },
                                    ty: "tr"
                                }), this.arr.splice(0, 0, f), this._groups.splice(0, 0, f), this._currentCopies += 1
                            }
                            this.elem.reloadShapes(), h = !0
                        }
                        for (o = 0, i = 0; i <= this._groups.length - 1; i += 1) {
                            if (l = o < m, this._groups[i]._render = l, this.changeGroupRender(this._groups[i].it, l), !l) {
                                var c = this.elemsData[i].it,
                                    d = c[c.length - 1];
                                0 !== d.transform.op.v ? (d.transform.op._mdf = !0, d.transform.op.v = 0) : d.transform.op._mdf = !1
                            }
                            o += 1
                        }
                        this._currentCopies = m;
                        var y = this.o.v,
                            v = y % 1,
                            P = y > 0 ? Math.floor(y) : Math.ceil(y),
                            E = this.pMatrix.props,
                            x = this.rMatrix.props,
                            S = this.sMatrix.props;
                        this.pMatrix.reset(), this.rMatrix.reset(), this.sMatrix.reset(), this.tMatrix.reset(), this.matrix.reset();
                        var A, C, _ = 0;
                        if (y > 0) {
                            for (; _ < P;) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !1), _ += 1;
                            v && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, v, !1), _ += v)
                        } else if (y < 0) {
                            for (; _ > P;) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !0), _ -= 1;
                            v && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, -v, !0), _ -= v)
                        }
                        for (i = 1 === this.data.m ? 0 : this._currentCopies - 1, n = 1 === this.data.m ? 1 : -1, o = this._currentCopies; o;) {
                            if (C = (r = (e = this.elemsData[i].it)[e.length - 1].transform.mProps.v.props).length, e[e.length - 1].transform.mProps._mdf = !0, e[e.length - 1].transform.op._mdf = !0, e[e.length - 1].transform.op.v = 1 === this._currentCopies ? this.so.v : this.so.v + (this.eo.v - this.so.v) * (i / (this._currentCopies - 1)), 0 !== _) {
                                for ((0 !== i && 1 === n || i !== this._currentCopies - 1 && -1 === n) && this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !1), this.matrix.transform(x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[7], x[8], x[9], x[10], x[11], x[12], x[13], x[14], x[15]), this.matrix.transform(S[0], S[1], S[2], S[3], S[4], S[5], S[6], S[7], S[8], S[9], S[10], S[11], S[12], S[13], S[14], S[15]), this.matrix.transform(E[0], E[1], E[2], E[3], E[4], E[5], E[6], E[7], E[8], E[9], E[10], E[11], E[12], E[13], E[14], E[15]), A = 0; A < C; A += 1) r[A] = this.matrix.props[A];
                                this.matrix.reset()
                            } else
                                for (this.matrix.reset(), A = 0; A < C; A += 1) r[A] = this.matrix.props[A];
                            _ += 1, o -= 1, i += n
                        }
                    } else
                        for (o = this._currentCopies, i = 0, n = 1; o;) r = (e = this.elemsData[i].it)[e.length - 1].transform.mProps.v.props, e[e.length - 1].transform.mProps._mdf = !1, e[e.length - 1].transform.op._mdf = !1, o -= 1, i += n;
                    return h
                }, RepeaterModifier.prototype.addShape = function() {}, ShapeModifiers.registerModifier("rp", RepeaterModifier), ShapeCollection.prototype.addShape = function(t) {
                    this._length === this._maxLength && (this.shapes = this.shapes.concat(createSizedArray(this._maxLength)), this._maxLength *= 2), this.shapes[this._length] = t, this._length += 1
                }, ShapeCollection.prototype.releaseShapes = function() {
                    var i;
                    for (i = 0; i < this._length; i += 1) shapePool.release(this.shapes[i]);
                    this._length = 0
                }, DashProperty.prototype.getValue = function(t) {
                    if ((this.elem.globalData.frameId !== this.frameId || t) && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf = this._mdf || t, this._mdf)) {
                        var i = 0,
                            e = this.dataProps.length;
                        for ("svg" === this.renderer && (this.dashStr = ""), i = 0; i < e; i += 1) "o" !== this.dataProps[i].n ? "svg" === this.renderer ? this.dashStr += " " + this.dataProps[i].p.v : this.dashArray[i] = this.dataProps[i].p.v : this.dashoffset[0] = this.dataProps[i].p.v
                    }
                }, extendPrototype([DynamicPropertyContainer], DashProperty), GradientProperty.prototype.comparePoints = function(t, e) {
                    for (var i = 0, r = this.o.length / 2; i < r;) {
                        if (Math.abs(t[4 * i] - t[4 * e + 2 * i]) > .01) return !1;
                        i += 1
                    }
                    return !0
                }, GradientProperty.prototype.checkCollapsable = function() {
                    if (this.o.length / 2 != this.c.length / 4) return !1;
                    if (this.data.k.k[0].s)
                        for (var i = 0, t = this.data.k.k.length; i < t;) {
                            if (!this.comparePoints(this.data.k.k[i].s, this.data.p)) return !1;
                            i += 1
                        } else if (!this.comparePoints(this.data.k.k, this.data.p)) return !1;
                    return !0
                }, GradientProperty.prototype.getValue = function(t) {
                    if (this.prop.getValue(), this._mdf = !1, this._cmdf = !1, this._omdf = !1, this.prop._mdf || t) {
                        var i, e, r, n = 4 * this.data.p;
                        for (i = 0; i < n; i += 1) e = i % 4 == 0 ? 100 : 255, r = Math.round(this.prop.v[i] * e), this.c[i] !== r && (this.c[i] = r, this._cmdf = !t);
                        if (this.o.length)
                            for (n = this.prop.v.length, i = 4 * this.data.p; i < n; i += 1) e = i % 2 == 0 ? 100 : 1, r = i % 2 == 0 ? Math.round(100 * this.prop.v[i]) : this.prop.v[i], this.o[i - 4 * this.data.p] !== r && (this.o[i - 4 * this.data.p] = r, this._omdf = !t);
                        this._mdf = !t
                    }
                }, extendPrototype([DynamicPropertyContainer], GradientProperty);
                var buildShapeString = function(t, e, r, n) {
                        if (0 === e) return "";
                        var i, o = t.o,
                            h = t.i,
                            l = t.v,
                            m = " M" + n.applyToPointStringified(l[0][0], l[0][1]);
                        for (i = 1; i < e; i += 1) m += " C" + n.applyToPointStringified(o[i - 1][0], o[i - 1][1]) + " " + n.applyToPointStringified(h[i][0], h[i][1]) + " " + n.applyToPointStringified(l[i][0], l[i][1]);
                        return r && e && (m += " C" + n.applyToPointStringified(o[i - 1][0], o[i - 1][1]) + " " + n.applyToPointStringified(h[0][0], h[0][1]) + " " + n.applyToPointStringified(l[0][0], l[0][1]), m += "z"), m
                    },
                    audioControllerFactory = function() {
                        function t(t) {
                            this.audios = [], this.audioFactory = t, this._volume = 1, this._isMuted = !1
                        }
                        return t.prototype = {
                                addAudio: function(audio) {
                                    this.audios.push(audio)
                                },
                                pause: function() {
                                    var i, t = this.audios.length;
                                    for (i = 0; i < t; i += 1) this.audios[i].pause()
                                },
                                resume: function() {
                                    var i, t = this.audios.length;
                                    for (i = 0; i < t; i += 1) this.audios[i].resume()
                                },
                                setRate: function(t) {
                                    var i, e = this.audios.length;
                                    for (i = 0; i < e; i += 1) this.audios[i].setRate(t)
                                },
                                createAudio: function(t) {
                                    return this.audioFactory ? this.audioFactory(t) : Howl ? new Howl({
                                        src: [t]
                                    }) : {
                                        isPlaying: !1,
                                        play: function() {
                                            this.isPlaying = !0
                                        },
                                        seek: function() {
                                            this.isPlaying = !1
                                        },
                                        playing: function() {},
                                        rate: function() {},
                                        setVolume: function() {}
                                    }
                                },
                                setAudioFactory: function(t) {
                                    this.audioFactory = t
                                },
                                setVolume: function(t) {
                                    this._volume = t, this._updateVolume()
                                },
                                mute: function() {
                                    this._isMuted = !0, this._updateVolume()
                                },
                                unmute: function() {
                                    this._isMuted = !1, this._updateVolume()
                                },
                                getVolume: function() {
                                    return this._volume
                                },
                                _updateVolume: function() {
                                    var i, t = this.audios.length;
                                    for (i = 0; i < t; i += 1) this.audios[i].volume(this._volume * (this._isMuted ? 0 : 1))
                                }
                            },
                            function() {
                                return new t
                            }
                    }(),
                    ImagePreloader = function() {
                        var t = function() {
                            var canvas = createTag("canvas");
                            canvas.width = 1, canvas.height = 1;
                            var t = canvas.getContext("2d");
                            return t.fillStyle = "rgba(0,0,0,0)", t.fillRect(0, 0, 1, 1), canvas
                        }();

                        function e() {
                            this.loadedAssets += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null)
                        }

                        function r() {
                            this.loadedFootagesCount += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null)
                        }

                        function n(t, e, r) {
                            var path = "";
                            if (t.e) path = t.p;
                            else if (e) {
                                var n = t.p; - 1 !== n.indexOf("images/") && (n = n.split("/")[1]), path = e + n
                            } else path = r, path += t.u ? t.u : "", path += t.p;
                            return path
                        }

                        function o(img) {
                            var t = 0,
                                e = setInterval(function() {
                                    (img.getBBox().width || t > 500) && (this._imageLoaded(), clearInterval(e)), t += 1
                                }.bind(this), 50)
                        }

                        function h(data) {
                            var t = {
                                    assetData: data
                                },
                                path = n(data, this.assetsPath, this.path);
                            return dataManager.loadData(path, function(e) {
                                t.img = e, this._footageLoaded()
                            }.bind(this), function() {
                                t.img = {}, this._footageLoaded()
                            }.bind(this)), t
                        }

                        function l() {
                            this._imageLoaded = e.bind(this), this._footageLoaded = r.bind(this), this.testImageLoaded = o.bind(this), this.createFootageData = h.bind(this), this.assetsPath = "", this.path = "", this.totalImages = 0, this.totalFootages = 0, this.loadedAssets = 0, this.loadedFootagesCount = 0, this.imagesLoadedCb = null, this.images = []
                        }
                        return l.prototype = {
                            loadAssets: function(t, e) {
                                var i;
                                this.imagesLoadedCb = e;
                                var r = t.length;
                                for (i = 0; i < r; i += 1) t[i].layers || (t[i].t && "seq" !== t[i].t ? 3 === t[i].t && (this.totalFootages += 1, this.images.push(this.createFootageData(t[i]))) : (this.totalImages += 1, this.images.push(this._createImageData(t[i]))))
                            },
                            setAssetsPath: function(path) {
                                this.assetsPath = path || ""
                            },
                            setPath: function(path) {
                                this.path = path || ""
                            },
                            loadedImages: function() {
                                return this.totalImages === this.loadedAssets
                            },
                            loadedFootages: function() {
                                return this.totalFootages === this.loadedFootagesCount
                            },
                            destroy: function() {
                                this.imagesLoadedCb = null, this.images.length = 0
                            },
                            getAsset: function(t) {
                                for (var i = 0, e = this.images.length; i < e;) {
                                    if (this.images[i].assetData === t) return this.images[i].img;
                                    i += 1
                                }
                                return null
                            },
                            createImgData: function(e) {
                                var path = n(e, this.assetsPath, this.path),
                                    img = createTag("img");
                                img.crossOrigin = "anonymous", img.addEventListener("load", this._imageLoaded, !1), img.addEventListener("error", function() {
                                    r.img = t, this._imageLoaded()
                                }.bind(this), !1), img.src = path;
                                var r = {
                                    img: img,
                                    assetData: e
                                };
                                return r
                            },
                            createImageData: function(e) {
                                var path = n(e, this.assetsPath, this.path),
                                    img = createNS("image");
                                isSafari ? this.testImageLoaded(img) : img.addEventListener("load", this._imageLoaded, !1), img.addEventListener("error", function() {
                                    r.img = t, this._imageLoaded()
                                }.bind(this), !1), img.setAttributeNS("http://www.w3.org/1999/xlink", "href", path), this._elementHelper.append ? this._elementHelper.append(img) : this._elementHelper.appendChild(img);
                                var r = {
                                    img: img,
                                    assetData: e
                                };
                                return r
                            },
                            imageLoaded: e,
                            footageLoaded: r,
                            setCacheType: function(t, e) {
                                "svg" === t ? (this._elementHelper = e, this._createImageData = this.createImageData.bind(this)) : this._createImageData = this.createImgData.bind(this)
                            }
                        }, l
                    }(),
                    featureSupport = function() {
                        var t = {
                            maskType: !0
                        };
                        return (/MSIE 10/i.test(navigator.userAgent) || /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) || /Edge\/\d./i.test(navigator.userAgent)) && (t.maskType = !1), t
                    }(),
                    filtersFactory = function() {
                        var t = {
                            createFilter: function(t, e) {
                                var r = createNS("filter");
                                return r.setAttribute("id", t), !0 !== e && (r.setAttribute("filterUnits", "objectBoundingBox"), r.setAttribute("x", "0%"), r.setAttribute("y", "0%"), r.setAttribute("width", "100%"), r.setAttribute("height", "100%")), r
                            },
                            createAlphaToLuminanceFilter: function() {
                                var t = createNS("feColorMatrix");
                                return t.setAttribute("type", "matrix"), t.setAttribute("color-interpolation-filters", "sRGB"), t.setAttribute("values", "0 0 0 1 0  0 0 0 1 0  0 0 0 1 0  0 0 0 1 1"), t
                            }
                        };
                        return t
                    }();

                function TextAnimatorProperty(t, e, r) {
                    this._isFirstFrame = !0, this._hasMaskedPath = !1, this._frameId = -1, this._textData = t, this._renderType = e, this._elem = r, this._animatorsData = createSizedArray(this._textData.a.length), this._pathData = {}, this._moreOptions = {
                        alignment: {}
                    }, this.renderedLetters = [], this.lettersChangedFlag = !1, this.initDynamicPropertyContainer(r)
                }

                function TextAnimatorDataProperty(t, e, r) {
                    var n = {
                            propType: !1
                        },
                        o = PropertyFactory.getProp,
                        h = e.a;
                    this.a = {
                        r: h.r ? o(t, h.r, 0, degToRads, r) : n,
                        rx: h.rx ? o(t, h.rx, 0, degToRads, r) : n,
                        ry: h.ry ? o(t, h.ry, 0, degToRads, r) : n,
                        sk: h.sk ? o(t, h.sk, 0, degToRads, r) : n,
                        sa: h.sa ? o(t, h.sa, 0, degToRads, r) : n,
                        s: h.s ? o(t, h.s, 1, .01, r) : n,
                        a: h.a ? o(t, h.a, 1, 0, r) : n,
                        o: h.o ? o(t, h.o, 0, .01, r) : n,
                        p: h.p ? o(t, h.p, 1, 0, r) : n,
                        sw: h.sw ? o(t, h.sw, 0, 0, r) : n,
                        sc: h.sc ? o(t, h.sc, 1, 0, r) : n,
                        fc: h.fc ? o(t, h.fc, 1, 0, r) : n,
                        fh: h.fh ? o(t, h.fh, 0, 0, r) : n,
                        fs: h.fs ? o(t, h.fs, 0, .01, r) : n,
                        fb: h.fb ? o(t, h.fb, 0, .01, r) : n,
                        t: h.t ? o(t, h.t, 0, 0, r) : n
                    }, this.s = TextSelectorProp.getTextSelectorProp(t, e.s, r), this.s.t = e.s.t
                }

                function LetterProps(t, e, r, n, o, p) {
                    this.o = t, this.sw = e, this.sc = r, this.fc = n, this.m = o, this.p = p, this._mdf = {
                        o: !0,
                        sw: !!e,
                        sc: !!r,
                        fc: !!n,
                        m: !0,
                        p: !0
                    }
                }

                function TextProperty(t, data) {
                    this._frameId = initialDefaultFrame, this.pv = "", this.v = "", this.kf = !1, this._isFirstFrame = !0, this._mdf = !1, this.data = data, this.elem = t, this.comp = this.elem.comp, this.keysIndex = 0, this.canResize = !1, this.minimumFontSize = 1, this.effectsSequence = [], this.currentData = {
                        ascent: 0,
                        boxWidth: this.defaultBoxWidth,
                        f: "",
                        fStyle: "",
                        fWeight: "",
                        fc: "",
                        j: "",
                        justifyOffset: "",
                        l: [],
                        lh: 0,
                        lineWidths: [],
                        ls: "",
                        of: "",
                        s: "",
                        sc: "",
                        sw: 0,
                        t: 0,
                        tr: 0,
                        sz: 0,
                        ps: null,
                        fillColorAnim: !1,
                        strokeColorAnim: !1,
                        strokeWidthAnim: !1,
                        yOffset: 0,
                        finalSize: 0,
                        finalText: [],
                        finalLineHeight: 0,
                        __complete: !1
                    }, this.copyData(this.currentData, this.data.d.k[0].s), this.searchProperty() || this.completeTextData(this.currentData)
                }
                TextAnimatorProperty.prototype.searchProperties = function() {
                    var i, t, e = this._textData.a.length,
                        r = PropertyFactory.getProp;
                    for (i = 0; i < e; i += 1) t = this._textData.a[i], this._animatorsData[i] = new TextAnimatorDataProperty(this._elem, t, this);
                    this._textData.p && "m" in this._textData.p ? (this._pathData = {
                        a: r(this._elem, this._textData.p.a, 0, 0, this),
                        f: r(this._elem, this._textData.p.f, 0, 0, this),
                        l: r(this._elem, this._textData.p.l, 0, 0, this),
                        r: r(this._elem, this._textData.p.r, 0, 0, this),
                        p: r(this._elem, this._textData.p.p, 0, 0, this),
                        m: this._elem.maskManager.getMaskProperty(this._textData.p.m)
                    }, this._hasMaskedPath = !0) : this._hasMaskedPath = !1, this._moreOptions.alignment = r(this._elem, this._textData.m.a, 1, 0, this)
                }, TextAnimatorProperty.prototype.getMeasures = function(t, e) {
                    if (this.lettersChangedFlag = e, this._mdf || this._isFirstFrame || e || this._hasMaskedPath && this._pathData.m._mdf) {
                        this._isFirstFrame = !1;
                        var r, n, i, o, h, l, m, f, c, d, y, v, P, E, x, S, A, C, mask, _ = this._moreOptions.alignment.v,
                            T = this._animatorsData,
                            k = this._textData,
                            D = this.mHelper,
                            M = this._renderType,
                            F = this.renderedLetters.length,
                            w = t.l;
                        if (this._hasMaskedPath) {
                            if (mask = this._pathData.m, !this._pathData.n || this._pathData._mdf) {
                                var I, V = mask.v;
                                for (this._pathData.r.v && (V = V.reverse()), h = {
                                        tLength: 0,
                                        segments: []
                                    }, o = V._length - 1, S = 0, i = 0; i < o; i += 1) I = bez.buildBezierData(V.v[i], V.v[i + 1], [V.o[i][0] - V.v[i][0], V.o[i][1] - V.v[i][1]], [V.i[i + 1][0] - V.v[i + 1][0], V.i[i + 1][1] - V.v[i + 1][1]]), h.tLength += I.segmentLength, h.segments.push(I), S += I.segmentLength;
                                i = o, mask.v.c && (I = bez.buildBezierData(V.v[i], V.v[0], [V.o[i][0] - V.v[i][0], V.o[i][1] - V.v[i][1]], [V.i[0][0] - V.v[0][0], V.i[0][1] - V.v[0][1]]), h.tLength += I.segmentLength, h.segments.push(I), S += I.segmentLength), this._pathData.pi = h
                            }
                            if (h = this._pathData.pi, l = this._pathData.f.v, y = 0, d = 1, f = 0, c = !0, E = h.segments, l < 0 && mask.v.c)
                                for (h.tLength < Math.abs(l) && (l = -Math.abs(l) % h.tLength), d = (P = E[y = E.length - 1].points).length - 1; l < 0;) l += P[d].partialLength, (d -= 1) < 0 && (d = (P = E[y -= 1].points).length - 1);
                            v = (P = E[y].points)[d - 1], x = (m = P[d]).partialLength
                        }
                        o = w.length, r = 0, n = 0;
                        var R, B, L, G, z, N = 1.2 * t.finalSize * .714,
                            O = !0;
                        L = T.length;
                        var H, j, W, Y, X, K, J, $, Z, U, Q, tt, et = -1,
                            it = l,
                            st = y,
                            at = d,
                            nt = -1,
                            ot = "",
                            ht = this.defaultPropsArray;
                        if (2 === t.j || 1 === t.j) {
                            var lt = 0,
                                pt = 0,
                                mt = 2 === t.j ? -.5 : -1,
                                ft = 0,
                                ct = !0;
                            for (i = 0; i < o; i += 1)
                                if (w[i].n) {
                                    for (lt && (lt += pt); ft < i;) w[ft].animatorJustifyOffset = lt, ft += 1;
                                    lt = 0, ct = !0
                                } else {
                                    for (B = 0; B < L; B += 1)(R = T[B].a).t.propType && (ct && 2 === t.j && (pt += R.t.v * mt), (z = T[B].s.getMult(w[i].anIndexes[B], k.a[B].s.totalChars)).length ? lt += R.t.v * z[0] * mt : lt += R.t.v * z * mt);
                                    ct = !1
                                }
                            for (lt && (lt += pt); ft < i;) w[ft].animatorJustifyOffset = lt, ft += 1
                        }
                        for (i = 0; i < o; i += 1) {
                            if (D.reset(), Y = 1, w[i].n) r = 0, n += t.yOffset, n += O ? 1 : 0, l = it, O = !1, this._hasMaskedPath && (d = at, v = (P = E[y = st].points)[d - 1], x = (m = P[d]).partialLength, f = 0), ot = "", Q = "", Z = "", tt = "", ht = this.defaultPropsArray;
                            else {
                                if (this._hasMaskedPath) {
                                    if (nt !== w[i].line) {
                                        switch (t.j) {
                                            case 1:
                                                l += S - t.lineWidths[w[i].line];
                                                break;
                                            case 2:
                                                l += (S - t.lineWidths[w[i].line]) / 2
                                        }
                                        nt = w[i].line
                                    }
                                    et !== w[i].ind && (w[et] && (l += w[et].extra), l += w[i].an / 2, et = w[i].ind), l += _[0] * w[i].an * .005;
                                    var ut = 0;
                                    for (B = 0; B < L; B += 1)(R = T[B].a).p.propType && ((z = T[B].s.getMult(w[i].anIndexes[B], k.a[B].s.totalChars)).length ? ut += R.p.v[0] * z[0] : ut += R.p.v[0] * z), R.a.propType && ((z = T[B].s.getMult(w[i].anIndexes[B], k.a[B].s.totalChars)).length ? ut += R.a.v[0] * z[0] : ut += R.a.v[0] * z);
                                    for (c = !0, this._pathData.a.v && (l = .5 * w[0].an + (S - this._pathData.f.v - .5 * w[0].an - .5 * w[w.length - 1].an) * et / (o - 1), l += this._pathData.f.v); c;) f + x >= l + ut || !P ? (A = (l + ut - f) / m.partialLength, j = v.point[0] + (m.point[0] - v.point[0]) * A, W = v.point[1] + (m.point[1] - v.point[1]) * A, D.translate(-_[0] * w[i].an * .005, -_[1] * N * .01), c = !1) : P && (f += m.partialLength, (d += 1) >= P.length && (d = 0, E[y += 1] ? P = E[y].points : mask.v.c ? (d = 0, P = E[y = 0].points) : (f -= m.partialLength, P = null)), P && (v = m, x = (m = P[d]).partialLength));
                                    H = w[i].an / 2 - w[i].add, D.translate(-H, 0, 0)
                                } else H = w[i].an / 2 - w[i].add, D.translate(-H, 0, 0), D.translate(-_[0] * w[i].an * .005, -_[1] * N * .01, 0);
                                for (B = 0; B < L; B += 1)(R = T[B].a).t.propType && (z = T[B].s.getMult(w[i].anIndexes[B], k.a[B].s.totalChars), 0 === r && 0 === t.j || (this._hasMaskedPath ? z.length ? l += R.t.v * z[0] : l += R.t.v * z : z.length ? r += R.t.v * z[0] : r += R.t.v * z));
                                for (t.strokeWidthAnim && (K = t.sw || 0), t.strokeColorAnim && (X = t.sc ? [t.sc[0], t.sc[1], t.sc[2]] : [0, 0, 0]), t.fillColorAnim && t.fc && (J = [t.fc[0], t.fc[1], t.fc[2]]), B = 0; B < L; B += 1)(R = T[B].a).a.propType && ((z = T[B].s.getMult(w[i].anIndexes[B], k.a[B].s.totalChars)).length ? D.translate(-R.a.v[0] * z[0], -R.a.v[1] * z[1], R.a.v[2] * z[2]) : D.translate(-R.a.v[0] * z, -R.a.v[1] * z, R.a.v[2] * z));
                                for (B = 0; B < L; B += 1)(R = T[B].a).s.propType && ((z = T[B].s.getMult(w[i].anIndexes[B], k.a[B].s.totalChars)).length ? D.scale(1 + (R.s.v[0] - 1) * z[0], 1 + (R.s.v[1] - 1) * z[1], 1) : D.scale(1 + (R.s.v[0] - 1) * z, 1 + (R.s.v[1] - 1) * z, 1));
                                for (B = 0; B < L; B += 1) {
                                    if (R = T[B].a, z = T[B].s.getMult(w[i].anIndexes[B], k.a[B].s.totalChars), R.sk.propType && (z.length ? D.skewFromAxis(-R.sk.v * z[0], R.sa.v * z[1]) : D.skewFromAxis(-R.sk.v * z, R.sa.v * z)), R.r.propType && (z.length ? D.rotateZ(-R.r.v * z[2]) : D.rotateZ(-R.r.v * z)), R.ry.propType && (z.length ? D.rotateY(R.ry.v * z[1]) : D.rotateY(R.ry.v * z)), R.rx.propType && (z.length ? D.rotateX(R.rx.v * z[0]) : D.rotateX(R.rx.v * z)), R.o.propType && (z.length ? Y += (R.o.v * z[0] - Y) * z[0] : Y += (R.o.v * z - Y) * z), t.strokeWidthAnim && R.sw.propType && (z.length ? K += R.sw.v * z[0] : K += R.sw.v * z), t.strokeColorAnim && R.sc.propType)
                                        for ($ = 0; $ < 3; $ += 1) z.length ? X[$] += (R.sc.v[$] - X[$]) * z[0] : X[$] += (R.sc.v[$] - X[$]) * z;
                                    if (t.fillColorAnim && t.fc) {
                                        if (R.fc.propType)
                                            for ($ = 0; $ < 3; $ += 1) z.length ? J[$] += (R.fc.v[$] - J[$]) * z[0] : J[$] += (R.fc.v[$] - J[$]) * z;
                                        R.fh.propType && (J = z.length ? addHueToRGB(J, R.fh.v * z[0]) : addHueToRGB(J, R.fh.v * z)), R.fs.propType && (J = z.length ? addSaturationToRGB(J, R.fs.v * z[0]) : addSaturationToRGB(J, R.fs.v * z)), R.fb.propType && (J = z.length ? addBrightnessToRGB(J, R.fb.v * z[0]) : addBrightnessToRGB(J, R.fb.v * z))
                                    }
                                }
                                for (B = 0; B < L; B += 1)(R = T[B].a).p.propType && (z = T[B].s.getMult(w[i].anIndexes[B], k.a[B].s.totalChars), this._hasMaskedPath ? z.length ? D.translate(0, R.p.v[1] * z[0], -R.p.v[2] * z[1]) : D.translate(0, R.p.v[1] * z, -R.p.v[2] * z) : z.length ? D.translate(R.p.v[0] * z[0], R.p.v[1] * z[1], -R.p.v[2] * z[2]) : D.translate(R.p.v[0] * z, R.p.v[1] * z, -R.p.v[2] * z));
                                if (t.strokeWidthAnim && (Z = K < 0 ? 0 : K), t.strokeColorAnim && (U = "rgb(" + Math.round(255 * X[0]) + "," + Math.round(255 * X[1]) + "," + Math.round(255 * X[2]) + ")"), t.fillColorAnim && t.fc && (Q = "rgb(" + Math.round(255 * J[0]) + "," + Math.round(255 * J[1]) + "," + Math.round(255 * J[2]) + ")"), this._hasMaskedPath) {
                                    if (D.translate(0, -t.ls), D.translate(0, _[1] * N * .01 + n, 0), this._pathData.p.v) {
                                        C = (m.point[1] - v.point[1]) / (m.point[0] - v.point[0]);
                                        var yt = 180 * Math.atan(C) / Math.PI;
                                        m.point[0] < v.point[0] && (yt += 180), D.rotate(-yt * Math.PI / 180)
                                    }
                                    D.translate(j, W, 0), l -= _[0] * w[i].an * .005, w[i + 1] && et !== w[i + 1].ind && (l += w[i].an / 2, l += .001 * t.tr * t.finalSize)
                                } else {
                                    switch (D.translate(r, n, 0), t.ps && D.translate(t.ps[0], t.ps[1] + t.ascent, 0), t.j) {
                                        case 1:
                                            D.translate(w[i].animatorJustifyOffset + t.justifyOffset + (t.boxWidth - t.lineWidths[w[i].line]), 0, 0);
                                            break;
                                        case 2:
                                            D.translate(w[i].animatorJustifyOffset + t.justifyOffset + (t.boxWidth - t.lineWidths[w[i].line]) / 2, 0, 0)
                                    }
                                    D.translate(0, -t.ls), D.translate(H, 0, 0), D.translate(_[0] * w[i].an * .005, _[1] * N * .01, 0), r += w[i].l + .001 * t.tr * t.finalSize
                                }
                                "html" === M ? ot = D.toCSS() : "svg" === M ? ot = D.to2dCSS() : ht = [D.props[0], D.props[1], D.props[2], D.props[3], D.props[4], D.props[5], D.props[6], D.props[7], D.props[8], D.props[9], D.props[10], D.props[11], D.props[12], D.props[13], D.props[14], D.props[15]], tt = Y
                            }
                            F <= i ? (G = new LetterProps(tt, Z, U, Q, ot, ht), this.renderedLetters.push(G), F += 1, this.lettersChangedFlag = !0) : (G = this.renderedLetters[i], this.lettersChangedFlag = G.update(tt, Z, U, Q, ot, ht) || this.lettersChangedFlag)
                        }
                    }
                }, TextAnimatorProperty.prototype.getValue = function() {
                    this._elem.globalData.frameId !== this._frameId && (this._frameId = this._elem.globalData.frameId, this.iterateDynamicProperties())
                }, TextAnimatorProperty.prototype.mHelper = new Matrix, TextAnimatorProperty.prototype.defaultPropsArray = [], extendPrototype([DynamicPropertyContainer], TextAnimatorProperty), LetterProps.prototype.update = function(t, e, r, n, o, p) {
                    this._mdf.o = !1, this._mdf.sw = !1, this._mdf.sc = !1, this._mdf.fc = !1, this._mdf.m = !1, this._mdf.p = !1;
                    var h = !1;
                    return this.o !== t && (this.o = t, this._mdf.o = !0, h = !0), this.sw !== e && (this.sw = e, this._mdf.sw = !0, h = !0), this.sc !== r && (this.sc = r, this._mdf.sc = !0, h = !0), this.fc !== n && (this.fc = n, this._mdf.fc = !0, h = !0), this.m !== o && (this.m = o, this._mdf.m = !0, h = !0), !p.length || this.p[0] === p[0] && this.p[1] === p[1] && this.p[4] === p[4] && this.p[5] === p[5] && this.p[12] === p[12] && this.p[13] === p[13] || (this.p = p, this._mdf.p = !0, h = !0), h
                }, TextProperty.prototype.defaultBoxWidth = [0, 0], TextProperty.prototype.copyData = function(t, data) {
                    for (var s in data) Object.prototype.hasOwnProperty.call(data, s) && (t[s] = data[s]);
                    return t
                }, TextProperty.prototype.setCurrentData = function(data) {
                    data.__complete || this.completeTextData(data), this.currentData = data, this.currentData.boxWidth = this.currentData.boxWidth || this.defaultBoxWidth, this._mdf = !0
                }, TextProperty.prototype.searchProperty = function() {
                    return this.searchKeyframes()
                }, TextProperty.prototype.searchKeyframes = function() {
                    return this.kf = this.data.d.k.length > 1, this.kf && this.addEffect(this.getKeyframeValue.bind(this)), this.kf
                }, TextProperty.prototype.addEffect = function(t) {
                    this.effectsSequence.push(t), this.elem.addDynamicProperty(this)
                }, TextProperty.prototype.getValue = function(t) {
                    if (this.elem.globalData.frameId !== this.frameId && this.effectsSequence.length || t) {
                        this.currentData.t = this.data.d.k[this.keysIndex].s.t;
                        var e = this.currentData,
                            r = this.keysIndex;
                        if (this.lock) this.setCurrentData(this.currentData);
                        else {
                            var i;
                            this.lock = !0, this._mdf = !1;
                            var n = this.effectsSequence.length,
                                o = t || this.data.d.k[this.keysIndex].s;
                            for (i = 0; i < n; i += 1) o = r !== this.keysIndex ? this.effectsSequence[i](o, o.t) : this.effectsSequence[i](this.currentData, o.t);
                            e !== o && this.setCurrentData(o), this.v = this.currentData, this.pv = this.v, this.lock = !1, this.frameId = this.elem.globalData.frameId
                        }
                    }
                }, TextProperty.prototype.getKeyframeValue = function() {
                    for (var t = this.data.d.k, e = this.elem.comp.renderedFrame, i = 0, r = t.length; i <= r - 1 && !(i === r - 1 || t[i + 1].t > e);) i += 1;
                    return this.keysIndex !== i && (this.keysIndex = i), this.data.d.k[this.keysIndex].s
                }, TextProperty.prototype.buildFinalText = function(text) {
                    for (var t, e, r = [], i = 0, n = text.length, o = !1; i < n;) t = text.charCodeAt(i), FontManager.isCombinedCharacter(t) ? r[r.length - 1] += text.charAt(i) : t >= 55296 && t <= 56319 ? (e = text.charCodeAt(i + 1)) >= 56320 && e <= 57343 ? (o || FontManager.isModifier(t, e) ? (r[r.length - 1] += text.substr(i, 2), o = !1) : r.push(text.substr(i, 2)), i += 1) : r.push(text.charAt(i)) : t > 56319 ? (e = text.charCodeAt(i + 1), FontManager.isZeroWidthJoiner(t, e) ? (o = !0, r[r.length - 1] += text.substr(i, 2), i += 1) : r.push(text.charAt(i))) : FontManager.isZeroWidthJoiner(t) ? (r[r.length - 1] += text.charAt(i), o = !0) : r.push(text.charAt(i)), i += 1;
                    return r
                }, TextProperty.prototype.completeTextData = function(t) {
                    t.__complete = !0;
                    var i, e, r, n, o, h, l, m = this.elem.globalData.fontManager,
                        data = this.data,
                        f = [],
                        c = 0,
                        d = data.m.g,
                        y = 0,
                        v = 0,
                        P = 0,
                        E = [],
                        x = 0,
                        S = 0,
                        A = m.getFontByName(t.f),
                        C = 0,
                        _ = getFontProperties(A);
                    t.fWeight = _.weight, t.fStyle = _.style, t.finalSize = t.s, t.finalText = this.buildFinalText(t.t), e = t.finalText.length, t.finalLineHeight = t.lh;
                    var T, k = t.tr / 1e3 * t.finalSize;
                    if (t.sz)
                        for (var D, M, F = !0, w = t.sz[0], I = t.sz[1]; F;) {
                            D = 0, x = 0, e = (M = this.buildFinalText(t.t)).length, k = t.tr / 1e3 * t.finalSize;
                            var V = -1;
                            for (i = 0; i < e; i += 1) T = M[i].charCodeAt(0), r = !1, " " === M[i] ? V = i : 13 !== T && 3 !== T || (x = 0, r = !0, D += t.finalLineHeight || 1.2 * t.finalSize), m.chars ? (l = m.getCharData(M[i], A.fStyle, A.fFamily), C = r ? 0 : l.w * t.finalSize / 100) : C = m.measureText(M[i], t.f, t.finalSize), x + C > w && " " !== M[i] ? (-1 === V ? e += 1 : i = V, D += t.finalLineHeight || 1.2 * t.finalSize, M.splice(i, V === i ? 1 : 0, "\r"), V = -1, x = 0) : (x += C, x += k);
                            D += A.ascent * t.finalSize / 100, this.canResize && t.finalSize > this.minimumFontSize && I < D ? (t.finalSize -= 1, t.finalLineHeight = t.finalSize * t.lh / t.s) : (t.finalText = M, e = t.finalText.length, F = !1)
                        }
                    x = -k, C = 0;
                    var R, B = 0;
                    for (i = 0; i < e; i += 1)
                        if (r = !1, 13 === (T = (R = t.finalText[i]).charCodeAt(0)) || 3 === T ? (B = 0, E.push(x), S = x > S ? x : S, x = -2 * k, n = "", r = !0, P += 1) : n = R, m.chars ? (l = m.getCharData(R, A.fStyle, m.getFontByName(t.f).fFamily), C = r ? 0 : l.w * t.finalSize / 100) : C = m.measureText(n, t.f, t.finalSize), " " === R ? B += C + k : (x += C + k + B, B = 0), f.push({
                                l: C,
                                an: C,
                                add: y,
                                n: r,
                                anIndexes: [],
                                val: n,
                                line: P,
                                animatorJustifyOffset: 0
                            }), 2 == d) {
                            if (y += C, "" === n || " " === n || i === e - 1) {
                                for ("" !== n && " " !== n || (y -= C); v <= i;) f[v].an = y, f[v].ind = c, f[v].extra = C, v += 1;
                                c += 1, y = 0
                            }
                        } else if (3 == d) {
                        if (y += C, "" === n || i === e - 1) {
                            for ("" === n && (y -= C); v <= i;) f[v].an = y, f[v].ind = c, f[v].extra = C, v += 1;
                            y = 0, c += 1
                        }
                    } else f[c].ind = c, f[c].extra = 0, c += 1;
                    if (t.l = f, S = x > S ? x : S, E.push(x), t.sz) t.boxWidth = t.sz[0], t.justifyOffset = 0;
                    else switch (t.boxWidth = S, t.j) {
                        case 1:
                            t.justifyOffset = -t.boxWidth;
                            break;
                        case 2:
                            t.justifyOffset = -t.boxWidth / 2;
                            break;
                        default:
                            t.justifyOffset = 0
                    }
                    t.lineWidths = E;
                    var L, G, z, N, O = data.a;
                    h = O.length;
                    var H = [];
                    for (o = 0; o < h; o += 1) {
                        for ((L = O[o]).a.sc && (t.strokeColorAnim = !0), L.a.sw && (t.strokeWidthAnim = !0), (L.a.fc || L.a.fh || L.a.fs || L.a.fb) && (t.fillColorAnim = !0), N = 0, z = L.s.b, i = 0; i < e; i += 1)(G = f[i]).anIndexes[o] = N, (1 == z && "" !== G.val || 2 == z && "" !== G.val && " " !== G.val || 3 == z && (G.n || " " == G.val || i == e - 1) || 4 == z && (G.n || i == e - 1)) && (1 === L.s.rn && H.push(N), N += 1);
                        data.a[o].s.totalChars = N;
                        var j, W = -1;
                        if (1 === L.s.rn)
                            for (i = 0; i < e; i += 1) W != (G = f[i]).anIndexes[o] && (W = G.anIndexes[o], j = H.splice(Math.floor(Math.random() * H.length), 1)[0]), G.anIndexes[o] = j
                    }
                    t.yOffset = t.finalLineHeight || 1.2 * t.finalSize, t.ls = t.ls || 0, t.ascent = A.ascent * t.finalSize / 100
                }, TextProperty.prototype.updateDocumentData = function(t, e) {
                    e = void 0 === e ? this.keysIndex : e;
                    var r = this.copyData({}, this.data.d.k[e].s);
                    r = this.copyData(r, t), this.data.d.k[e].s = r, this.recalculate(e), this.elem.addDynamicProperty(this)
                }, TextProperty.prototype.recalculate = function(t) {
                    var e = this.data.d.k[t].s;
                    e.__complete = !1, this.keysIndex = 0, this._isFirstFrame = !0, this.getValue(e)
                }, TextProperty.prototype.canResizeFont = function(t) {
                    this.canResize = t, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this)
                }, TextProperty.prototype.setMinimumFontSize = function(t) {
                    this.minimumFontSize = Math.floor(t) || 1, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this)
                };
                var TextSelectorProp = function() {
                        var t = Math.max,
                            e = Math.min,
                            r = Math.floor;

                        function n(t, data) {
                            this._currentTextLength = -1, this.k = !1, this.data = data, this.elem = t, this.comp = t.comp, this.finalS = 0, this.finalE = 0, this.initDynamicPropertyContainer(t), this.s = PropertyFactory.getProp(t, data.s || {
                                k: 0
                            }, 0, 0, this), this.e = "e" in data ? PropertyFactory.getProp(t, data.e, 0, 0, this) : {
                                v: 100
                            }, this.o = PropertyFactory.getProp(t, data.o || {
                                k: 0
                            }, 0, 0, this), this.xe = PropertyFactory.getProp(t, data.xe || {
                                k: 0
                            }, 0, 0, this), this.ne = PropertyFactory.getProp(t, data.ne || {
                                k: 0
                            }, 0, 0, this), this.sm = PropertyFactory.getProp(t, data.sm || {
                                k: 100
                            }, 0, 0, this), this.a = PropertyFactory.getProp(t, data.a, 0, .01, this), this.dynamicProperties.length || this.getValue()
                        }
                        return n.prototype = {
                            getMult: function(n) {
                                this._currentTextLength !== this.elem.textProperty.currentData.l.length && this.getValue();
                                var o = 0,
                                    h = 0,
                                    l = 1,
                                    m = 1;
                                this.ne.v > 0 ? o = this.ne.v / 100 : h = -this.ne.v / 100, this.xe.v > 0 ? l = 1 - this.xe.v / 100 : m = 1 + this.xe.v / 100;
                                var f = BezierFactory.getBezierEasing(o, h, l, m).get,
                                    c = 0,
                                    s = this.finalS,
                                    d = this.finalE,
                                    y = this.data.sh;
                                if (2 === y) c = f(c = d === s ? n >= d ? 1 : 0 : t(0, e(.5 / (d - s) + (n - s) / (d - s), 1)));
                                else if (3 === y) c = f(c = d === s ? n >= d ? 0 : 1 : 1 - t(0, e(.5 / (d - s) + (n - s) / (d - s), 1)));
                                else if (4 === y) d === s ? c = 0 : (c = t(0, e(.5 / (d - s) + (n - s) / (d - s), 1))) < .5 ? c *= 2 : c = 1 - 2 * (c - .5), c = f(c);
                                else if (5 === y) {
                                    if (d === s) c = 0;
                                    else {
                                        var v = d - s,
                                            P = -v / 2 + (n = e(t(0, n + .5 - s), d - s)),
                                            a = v / 2;
                                        c = Math.sqrt(1 - P * P / (a * a))
                                    }
                                    c = f(c)
                                } else 6 === y ? (d === s ? c = 0 : (n = e(t(0, n + .5 - s), d - s), c = (1 + Math.cos(Math.PI + 2 * Math.PI * n / (d - s))) / 2), c = f(c)) : (n >= r(s) && (c = t(0, e(n - s < 0 ? e(d, 1) - (s - n) : d - n, 1))), c = f(c));
                                if (100 !== this.sm.v) {
                                    var E = .01 * this.sm.v;
                                    0 === E && (E = 1e-8);
                                    var x = .5 - .5 * E;
                                    c < x ? c = 0 : (c = (c - x) / E) > 1 && (c = 1)
                                }
                                return c * this.a.v
                            },
                            getValue: function(t) {
                                this.iterateDynamicProperties(), this._mdf = t || this._mdf, this._currentTextLength = this.elem.textProperty.currentData.l.length || 0, t && 2 === this.data.r && (this.e.v = this._currentTextLength);
                                var e = 2 === this.data.r ? 1 : 100 / this.data.totalChars,
                                    r = this.o.v / e,
                                    s = this.s.v / e + r,
                                    n = this.e.v / e + r;
                                if (s > n) {
                                    var o = s;
                                    s = n, n = o
                                }
                                this.finalS = s, this.finalE = n
                            }
                        }, extendPrototype([DynamicPropertyContainer], n), {
                            getTextSelectorProp: function(t, data, e) {
                                return new n(t, data, e)
                            }
                        }
                    }(),
                    poolFactory = function(t, e, r) {
                        var n = 0,
                            o = t,
                            h = createSizedArray(o);
                        return {
                            newElement: function() {
                                return n ? h[n -= 1] : e()
                            },
                            release: function(element) {
                                n === o && (h = pooling.double(h), o *= 2), r && r(element), h[n] = element, n += 1
                            }
                        }
                    },
                    pooling = {
                        double: function(t) {
                            return t.concat(createSizedArray(t.length))
                        }
                    },
                    pointPool = poolFactory(8, (function() {
                        return createTypedArray("float32", 2)
                    })),
                    shapePool = (factory = poolFactory(4, (function() {
                        return new ShapePath
                    }), (function(t) {
                        var i, e = t._length;
                        for (i = 0; i < e; i += 1) pointPool.release(t.v[i]), pointPool.release(t.i[i]), pointPool.release(t.o[i]), t.v[i] = null, t.i[i] = null, t.o[i] = null;
                        t._length = 0, t.c = !1
                    })), factory.clone = function(t) {
                        var i, e = factory.newElement(),
                            r = void 0 === t._length ? t.v.length : t._length;
                        for (e.setLength(r), e.c = t.c, i = 0; i < r; i += 1) e.setTripleAt(t.v[i][0], t.v[i][1], t.o[i][0], t.o[i][1], t.i[i][0], t.i[i][1], i);
                        return e
                    }, factory),
                    factory, shapeCollectionPool = function() {
                        var t = {
                                newShapeCollection: function() {
                                    return e ? n[e -= 1] : new ShapeCollection
                                },
                                release: function(t) {
                                    var i, o = t._length;
                                    for (i = 0; i < o; i += 1) shapePool.release(t.shapes[i]);
                                    t._length = 0, e === r && (n = pooling.double(n), r *= 2), n[e] = t, e += 1
                                }
                            },
                            e = 0,
                            r = 4,
                            n = createSizedArray(r);
                        return t
                    }(),
                    segmentsLengthPool = poolFactory(8, (function() {
                        return {
                            lengths: [],
                            totalLength: 0
                        }
                    }), (function(element) {
                        var i, t = element.lengths.length;
                        for (i = 0; i < t; i += 1) bezierLengthPool.release(element.lengths[i]);
                        element.lengths.length = 0
                    })),
                    bezierLengthPool = poolFactory(8, (function() {
                        return {
                            addedLength: 0,
                            percents: createTypedArray("float32", defaultCurveSegments),
                            lengths: createTypedArray("float32", defaultCurveSegments)
                        }
                    })),
                    markerParser = function() {
                        function t(t) {
                            for (var line, e = t.split("\r\n"), r = {}, n = 0, i = 0; i < e.length; i += 1) 2 === (line = e[i].split(":")).length && (r[line[0]] = line[1].trim(), n += 1);
                            if (0 === n) throw new Error;
                            return r
                        }
                        return function(e) {
                            for (var r = [], i = 0; i < e.length; i += 1) {
                                var n = e[i],
                                    o = {
                                        time: n.tm,
                                        duration: n.dr
                                    };
                                try {
                                    o.payload = JSON.parse(e[i].cm)
                                } catch (r) {
                                    try {
                                        o.payload = t(e[i].cm)
                                    } catch (t) {
                                        o.payload = {
                                            name: e[i]
                                        }
                                    }
                                }
                                r.push(o)
                            }
                            return r
                        }
                    }();

                function BaseRenderer() {}

                function SVGRenderer(t, e) {
                    this.animationItem = t, this.layers = null, this.renderedFrame = -1, this.svgElement = createNS("svg");
                    var r = "";
                    if (e && e.title) {
                        var n = createNS("title"),
                            o = createElementID();
                        n.setAttribute("id", o), n.textContent = e.title, this.svgElement.appendChild(n), r += o
                    }
                    if (e && e.description) {
                        var h = createNS("desc"),
                            l = createElementID();
                        h.setAttribute("id", l), h.textContent = e.description, this.svgElement.appendChild(h), r += " " + l
                    }
                    r && this.svgElement.setAttribute("aria-labelledby", r);
                    var defs = createNS("defs");
                    this.svgElement.appendChild(defs);
                    var m = createNS("g");
                    this.svgElement.appendChild(m), this.layerElement = m, this.renderConfig = {
                        preserveAspectRatio: e && e.preserveAspectRatio || "xMidYMid meet",
                        imagePreserveAspectRatio: e && e.imagePreserveAspectRatio || "xMidYMid slice",
                        contentVisibility: e && e.contentVisibility || "visible",
                        progressiveLoad: e && e.progressiveLoad || !1,
                        hideOnTransparent: !(e && !1 === e.hideOnTransparent),
                        viewBoxOnly: e && e.viewBoxOnly || !1,
                        viewBoxSize: e && e.viewBoxSize || !1,
                        className: e && e.className || "",
                        id: e && e.id || "",
                        focusable: e && e.focusable,
                        filterSize: {
                            width: e && e.filterSize && e.filterSize.width || "100%",
                            height: e && e.filterSize && e.filterSize.height || "100%",
                            x: e && e.filterSize && e.filterSize.x || "0%",
                            y: e && e.filterSize && e.filterSize.y || "0%"
                        }
                    }, this.globalData = {
                        _mdf: !1,
                        frameNum: -1,
                        defs: defs,
                        renderConfig: this.renderConfig
                    }, this.elements = [], this.pendingElements = [], this.destroyed = !1, this.rendererType = "svg"
                }

                function CanvasRenderer(t, e) {
                    this.animationItem = t, this.renderConfig = {
                        clearCanvas: !e || void 0 === e.clearCanvas || e.clearCanvas,
                        context: e && e.context || null,
                        progressiveLoad: e && e.progressiveLoad || !1,
                        preserveAspectRatio: e && e.preserveAspectRatio || "xMidYMid meet",
                        imagePreserveAspectRatio: e && e.imagePreserveAspectRatio || "xMidYMid slice",
                        contentVisibility: e && e.contentVisibility || "visible",
                        className: e && e.className || "",
                        id: e && e.id || ""
                    }, this.renderConfig.dpr = e && e.dpr || 1, this.animationItem.wrapper && (this.renderConfig.dpr = e && e.dpr || window.devicePixelRatio || 1), this.renderedFrame = -1, this.globalData = {
                        frameNum: -1,
                        _mdf: !1,
                        renderConfig: this.renderConfig,
                        currentGlobalAlpha: -1
                    }, this.contextData = new CVContextData, this.elements = [], this.pendingElements = [], this.transformMat = new Matrix, this.completeLayers = !1, this.rendererType = "canvas"
                }

                function HybridRenderer(t, e) {
                    this.animationItem = t, this.layers = null, this.renderedFrame = -1, this.renderConfig = {
                        className: e && e.className || "",
                        imagePreserveAspectRatio: e && e.imagePreserveAspectRatio || "xMidYMid slice",
                        hideOnTransparent: !(e && !1 === e.hideOnTransparent),
                        filterSize: {
                            width: e && e.filterSize && e.filterSize.width || "400%",
                            height: e && e.filterSize && e.filterSize.height || "400%",
                            x: e && e.filterSize && e.filterSize.x || "-100%",
                            y: e && e.filterSize && e.filterSize.y || "-100%"
                        }
                    }, this.globalData = {
                        _mdf: !1,
                        frameNum: -1,
                        renderConfig: this.renderConfig
                    }, this.pendingElements = [], this.elements = [], this.threeDElements = [], this.destroyed = !1, this.camera = null, this.supports3d = !0, this.rendererType = "html"
                }

                function MaskElement(data, element, t) {
                    this.data = data, this.element = element, this.globalData = t, this.storedData = [], this.masksProperties = this.data.masksProperties || [], this.maskElement = null;
                    var i, path, defs = this.globalData.defs,
                        e = this.masksProperties ? this.masksProperties.length : 0;
                    this.viewData = createSizedArray(e), this.solidPath = "";
                    var r, n, rect, o, h, l, m = this.masksProperties,
                        f = 0,
                        c = [],
                        d = createElementID(),
                        y = "clipPath",
                        v = "clip-path";
                    for (i = 0; i < e; i += 1)
                        if (("a" !== m[i].mode && "n" !== m[i].mode || m[i].inv || 100 !== m[i].o.k || m[i].o.x) && (y = "mask", v = "mask"), "s" !== m[i].mode && "i" !== m[i].mode || 0 !== f ? rect = null : ((rect = createNS("rect")).setAttribute("fill", "#ffffff"), rect.setAttribute("width", this.element.comp.data.w || 0), rect.setAttribute("height", this.element.comp.data.h || 0), c.push(rect)), path = createNS("path"), "n" === m[i].mode) this.viewData[i] = {
                            op: PropertyFactory.getProp(this.element, m[i].o, 0, .01, this.element),
                            prop: ShapePropertyFactory.getShapeProp(this.element, m[i], 3),
                            elem: path,
                            lastPath: ""
                        }, defs.appendChild(path);
                        else {
                            var P;
                            if (f += 1, path.setAttribute("fill", "s" === m[i].mode ? "#000000" : "#ffffff"), path.setAttribute("clip-rule", "nonzero"), 0 !== m[i].x.k ? (y = "mask", v = "mask", l = PropertyFactory.getProp(this.element, m[i].x, 0, null, this.element), P = createElementID(), (o = createNS("filter")).setAttribute("id", P), (h = createNS("feMorphology")).setAttribute("operator", "erode"), h.setAttribute("in", "SourceGraphic"), h.setAttribute("radius", "0"), o.appendChild(h), defs.appendChild(o), path.setAttribute("stroke", "s" === m[i].mode ? "#000000" : "#ffffff")) : (h = null, l = null), this.storedData[i] = {
                                    elem: path,
                                    x: l,
                                    expan: h,
                                    lastPath: "",
                                    lastOperator: "",
                                    filterId: P,
                                    lastRadius: 0
                                }, "i" === m[i].mode) {
                                n = c.length;
                                var g = createNS("g");
                                for (r = 0; r < n; r += 1) g.appendChild(c[r]);
                                var mask = createNS("mask");
                                mask.setAttribute("mask-type", "alpha"), mask.setAttribute("id", d + "_" + f), mask.appendChild(path), defs.appendChild(mask), g.setAttribute("mask", "url(" + locationHref + "#" + d + "_" + f + ")"), c.length = 0, c.push(g)
                            } else c.push(path);
                            m[i].inv && !this.solidPath && (this.solidPath = this.createLayerSolidPath()), this.viewData[i] = {
                                elem: path,
                                lastPath: "",
                                op: PropertyFactory.getProp(this.element, m[i].o, 0, .01, this.element),
                                prop: ShapePropertyFactory.getShapeProp(this.element, m[i], 3),
                                invRect: rect
                            }, this.viewData[i].prop.k || this.drawPath(m[i], this.viewData[i].prop.v, this.viewData[i])
                        }
                    for (this.maskElement = createNS(y), e = c.length, i = 0; i < e; i += 1) this.maskElement.appendChild(c[i]);
                    f > 0 && (this.maskElement.setAttribute("id", d), this.element.maskedElement.setAttribute(v, "url(" + locationHref + "#" + d + ")"), defs.appendChild(this.maskElement)), this.viewData.length && this.element.addRenderableComponent(this)
                }

                function HierarchyElement() {}

                function FrameElement() {}

                function TransformElement() {}

                function RenderableElement() {}

                function RenderableDOMElement() {}

                function ProcessedElement(element, t) {
                    this.elem = element, this.pos = t
                }

                function SVGStyleData(data, t) {
                    this.data = data, this.type = data.ty, this.d = "", this.lvl = t, this._mdf = !1, this.closed = !0 === data.hd, this.pElem = createNS("path"), this.msElem = null
                }

                function SVGShapeData(t, e, r) {
                    this.caches = [], this.styles = [], this.transformers = t, this.lStr = "", this.sh = r, this.lvl = e, this._isAnimated = !!r.k;
                    for (var i = 0, n = t.length; i < n;) {
                        if (t[i].mProps.dynamicProperties.length) {
                            this._isAnimated = !0;
                            break
                        }
                        i += 1
                    }
                }

                function SVGTransformData(t, e, r) {
                    this.transform = {
                        mProps: t,
                        op: e,
                        container: r
                    }, this.elements = [], this._isAnimated = this.transform.mProps.dynamicProperties.length || this.transform.op.effectsSequence.length
                }

                function SVGStrokeStyleData(t, data, e) {
                    this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.o = PropertyFactory.getProp(t, data.o, 0, .01, this), this.w = PropertyFactory.getProp(t, data.w, 0, null, this), this.d = new DashProperty(t, data.d || {}, "svg", this), this.c = PropertyFactory.getProp(t, data.c, 1, 255, this), this.style = e, this._isAnimated = !!this._isAnimated
                }

                function SVGFillStyleData(t, data, e) {
                    this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.o = PropertyFactory.getProp(t, data.o, 0, .01, this), this.c = PropertyFactory.getProp(t, data.c, 1, 255, this), this.style = e
                }

                function SVGGradientFillStyleData(t, data, e) {
                    this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.initGradientData(t, data, e)
                }

                function SVGGradientStrokeStyleData(t, data, e) {
                    this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.w = PropertyFactory.getProp(t, data.w, 0, null, this), this.d = new DashProperty(t, data.d || {}, "svg", this), this.initGradientData(t, data, e), this._isAnimated = !!this._isAnimated
                }

                function ShapeGroupData() {
                    this.it = [], this.prevViewData = [], this.gr = createNS("g")
                }
                BaseRenderer.prototype.checkLayers = function(t) {
                    var i, data, e = this.layers.length;
                    for (this.completeLayers = !0, i = e - 1; i >= 0; i -= 1) this.elements[i] || (data = this.layers[i]).ip - data.st <= t - this.layers[i].st && data.op - data.st > t - this.layers[i].st && this.buildItem(i), this.completeLayers = !!this.elements[i] && this.completeLayers;
                    this.checkPendingElements()
                }, BaseRenderer.prototype.createItem = function(t) {
                    switch (t.ty) {
                        case 2:
                            return this.createImage(t);
                        case 0:
                            return this.createComp(t);
                        case 1:
                            return this.createSolid(t);
                        case 3:
                        default:
                            return this.createNull(t);
                        case 4:
                            return this.createShape(t);
                        case 5:
                            return this.createText(t);
                        case 6:
                            return this.createAudio(t);
                        case 13:
                            return this.createCamera(t);
                        case 15:
                            return this.createFootage(t)
                    }
                }, BaseRenderer.prototype.createCamera = function() {
                    throw new Error("You're using a 3d camera. Try the html renderer.")
                }, BaseRenderer.prototype.createAudio = function(data) {
                    return new AudioElement(data, this.globalData, this)
                }, BaseRenderer.prototype.createFootage = function(data) {
                    return new FootageElement(data, this.globalData, this)
                }, BaseRenderer.prototype.buildAllItems = function() {
                    var i, t = this.layers.length;
                    for (i = 0; i < t; i += 1) this.buildItem(i);
                    this.checkPendingElements()
                }, BaseRenderer.prototype.includeLayers = function(t) {
                    var i;
                    this.completeLayers = !1;
                    var e, r = t.length,
                        n = this.layers.length;
                    for (i = 0; i < r; i += 1)
                        for (e = 0; e < n;) {
                            if (this.layers[e].id === t[i].id) {
                                this.layers[e] = t[i];
                                break
                            }
                            e += 1
                        }
                }, BaseRenderer.prototype.setProjectInterface = function(t) {
                    this.globalData.projectInterface = t
                }, BaseRenderer.prototype.initItems = function() {
                    this.globalData.progressiveLoad || this.buildAllItems()
                }, BaseRenderer.prototype.buildElementParenting = function(element, t, e) {
                    for (var r = this.elements, n = this.layers, i = 0, o = n.length; i < o;) n[i].ind == t && (r[i] && !0 !== r[i] ? (e.push(r[i]), r[i].setAsParent(), void 0 !== n[i].parent ? this.buildElementParenting(element, n[i].parent, e) : element.setHierarchy(e)) : (this.buildItem(i), this.addPendingElement(element))), i += 1
                }, BaseRenderer.prototype.addPendingElement = function(element) {
                    this.pendingElements.push(element)
                }, BaseRenderer.prototype.searchExtraCompositions = function(t) {
                    var i, e = t.length;
                    for (i = 0; i < e; i += 1)
                        if (t[i].xt) {
                            var r = this.createComp(t[i]);
                            r.initExpressions(), this.globalData.projectInterface.registerComposition(r)
                        }
                }, BaseRenderer.prototype.setupGlobalData = function(t, e) {
                    this.globalData.fontManager = new FontManager, this.globalData.fontManager.addChars(t.chars), this.globalData.fontManager.addFonts(t.fonts, e), this.globalData.getAssetData = this.animationItem.getAssetData.bind(this.animationItem), this.globalData.getAssetsPath = this.animationItem.getAssetsPath.bind(this.animationItem), this.globalData.imageLoader = this.animationItem.imagePreloader, this.globalData.audioController = this.animationItem.audioController, this.globalData.frameId = 0, this.globalData.frameRate = t.fr, this.globalData.nm = t.nm, this.globalData.compSize = {
                        w: t.w,
                        h: t.h
                    }
                }, extendPrototype([BaseRenderer], SVGRenderer), SVGRenderer.prototype.createNull = function(data) {
                    return new NullElement(data, this.globalData, this)
                }, SVGRenderer.prototype.createShape = function(data) {
                    return new SVGShapeElement(data, this.globalData, this)
                }, SVGRenderer.prototype.createText = function(data) {
                    return new SVGTextLottieElement(data, this.globalData, this)
                }, SVGRenderer.prototype.createImage = function(data) {
                    return new IImageElement(data, this.globalData, this)
                }, SVGRenderer.prototype.createComp = function(data) {
                    return new SVGCompElement(data, this.globalData, this)
                }, SVGRenderer.prototype.createSolid = function(data) {
                    return new ISolidElement(data, this.globalData, this)
                }, SVGRenderer.prototype.configAnimation = function(t) {
                    this.svgElement.setAttribute("xmlns", "http://www.w3.org/2000/svg"), this.renderConfig.viewBoxSize ? this.svgElement.setAttribute("viewBox", this.renderConfig.viewBoxSize) : this.svgElement.setAttribute("viewBox", "0 0 " + t.w + " " + t.h), this.renderConfig.viewBoxOnly || (this.svgElement.setAttribute("width", t.w), this.svgElement.setAttribute("height", t.h), this.svgElement.style.width = "100%", this.svgElement.style.height = "100%", this.svgElement.style.transform = "translate3d(0,0,0)", this.svgElement.style.contentVisibility = this.renderConfig.contentVisibility), this.renderConfig.className && this.svgElement.setAttribute("class", this.renderConfig.className), this.renderConfig.id && this.svgElement.setAttribute("id", this.renderConfig.id), void 0 !== this.renderConfig.focusable && this.svgElement.setAttribute("focusable", this.renderConfig.focusable), this.svgElement.setAttribute("preserveAspectRatio", this.renderConfig.preserveAspectRatio), this.animationItem.wrapper.appendChild(this.svgElement);
                    var defs = this.globalData.defs;
                    this.setupGlobalData(t, defs), this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.data = t;
                    var e = createNS("clipPath"),
                        rect = createNS("rect");
                    rect.setAttribute("width", t.w), rect.setAttribute("height", t.h), rect.setAttribute("x", 0), rect.setAttribute("y", 0);
                    var r = createElementID();
                    e.setAttribute("id", r), e.appendChild(rect), this.layerElement.setAttribute("clip-path", "url(" + locationHref + "#" + r + ")"), defs.appendChild(e), this.layers = t.layers, this.elements = createSizedArray(t.layers.length)
                }, SVGRenderer.prototype.destroy = function() {
                    var i;
                    this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ""), this.layerElement = null, this.globalData.defs = null;
                    var t = this.layers ? this.layers.length : 0;
                    for (i = 0; i < t; i += 1) this.elements[i] && this.elements[i].destroy();
                    this.elements.length = 0, this.destroyed = !0, this.animationItem = null
                }, SVGRenderer.prototype.updateContainerSize = function() {}, SVGRenderer.prototype.buildItem = function(t) {
                    var e = this.elements;
                    if (!e[t] && 99 !== this.layers[t].ty) {
                        e[t] = !0;
                        var element = this.createItem(this.layers[t]);
                        e[t] = element, expressionsPlugin && (0 === this.layers[t].ty && this.globalData.projectInterface.registerComposition(element), element.initExpressions()), this.appendElementInPos(element, t), this.layers[t].tt && (this.elements[t - 1] && !0 !== this.elements[t - 1] ? element.setMatte(e[t - 1].layerId) : (this.buildItem(t - 1), this.addPendingElement(element)))
                    }
                }, SVGRenderer.prototype.checkPendingElements = function() {
                    for (; this.pendingElements.length;) {
                        var element = this.pendingElements.pop();
                        if (element.checkParenting(), element.data.tt)
                            for (var i = 0, t = this.elements.length; i < t;) {
                                if (this.elements[i] === element) {
                                    element.setMatte(this.elements[i - 1].layerId);
                                    break
                                }
                                i += 1
                            }
                    }
                }, SVGRenderer.prototype.renderFrame = function(t) {
                    if (this.renderedFrame !== t && !this.destroyed) {
                        var i;
                        null === t ? t = this.renderedFrame : this.renderedFrame = t, this.globalData.frameNum = t, this.globalData.frameId += 1, this.globalData.projectInterface.currentFrame = t, this.globalData._mdf = !1;
                        var e = this.layers.length;
                        for (this.completeLayers || this.checkLayers(t), i = e - 1; i >= 0; i -= 1)(this.completeLayers || this.elements[i]) && this.elements[i].prepareFrame(t - this.layers[i].st);
                        if (this.globalData._mdf)
                            for (i = 0; i < e; i += 1)(this.completeLayers || this.elements[i]) && this.elements[i].renderFrame()
                    }
                }, SVGRenderer.prototype.appendElementInPos = function(element, t) {
                    var e = element.getBaseElement();
                    if (e) {
                        for (var r, i = 0; i < t;) this.elements[i] && !0 !== this.elements[i] && this.elements[i].getBaseElement() && (r = this.elements[i].getBaseElement()), i += 1;
                        r ? this.layerElement.insertBefore(e, r) : this.layerElement.appendChild(e)
                    }
                }, SVGRenderer.prototype.hide = function() {
                    this.layerElement.style.display = "none"
                }, SVGRenderer.prototype.show = function() {
                    this.layerElement.style.display = "block"
                }, extendPrototype([BaseRenderer], CanvasRenderer), CanvasRenderer.prototype.createShape = function(data) {
                    return new CVShapeElement(data, this.globalData, this)
                }, CanvasRenderer.prototype.createText = function(data) {
                    return new CVTextElement(data, this.globalData, this)
                }, CanvasRenderer.prototype.createImage = function(data) {
                    return new CVImageElement(data, this.globalData, this)
                }, CanvasRenderer.prototype.createComp = function(data) {
                    return new CVCompElement(data, this.globalData, this)
                }, CanvasRenderer.prototype.createSolid = function(data) {
                    return new CVSolidElement(data, this.globalData, this)
                }, CanvasRenderer.prototype.createNull = SVGRenderer.prototype.createNull, CanvasRenderer.prototype.ctxTransform = function(t) {
                    if (1 !== t[0] || 0 !== t[1] || 0 !== t[4] || 1 !== t[5] || 0 !== t[12] || 0 !== t[13])
                        if (this.renderConfig.clearCanvas) {
                            this.transformMat.cloneFromProps(t);
                            var e = this.contextData.cTr.props;
                            this.transformMat.transform(e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7], e[8], e[9], e[10], e[11], e[12], e[13], e[14], e[15]), this.contextData.cTr.cloneFromProps(this.transformMat.props);
                            var r = this.contextData.cTr.props;
                            this.canvasContext.setTransform(r[0], r[1], r[4], r[5], r[12], r[13])
                        } else this.canvasContext.transform(t[0], t[1], t[4], t[5], t[12], t[13])
                }, CanvasRenderer.prototype.ctxOpacity = function(t) {
                    if (!this.renderConfig.clearCanvas) return this.canvasContext.globalAlpha *= t < 0 ? 0 : t, void(this.globalData.currentGlobalAlpha = this.contextData.cO);
                    this.contextData.cO *= t < 0 ? 0 : t, this.globalData.currentGlobalAlpha !== this.contextData.cO && (this.canvasContext.globalAlpha = this.contextData.cO, this.globalData.currentGlobalAlpha = this.contextData.cO)
                }, CanvasRenderer.prototype.reset = function() {
                    this.renderConfig.clearCanvas ? this.contextData.reset() : this.canvasContext.restore()
                }, CanvasRenderer.prototype.save = function(t) {
                    if (this.renderConfig.clearCanvas) {
                        t && this.canvasContext.save();
                        var i, e = this.contextData.cTr.props;
                        this.contextData._length <= this.contextData.cArrPos && this.contextData.duplicate();
                        var r = this.contextData.saved[this.contextData.cArrPos];
                        for (i = 0; i < 16; i += 1) r[i] = e[i];
                        this.contextData.savedOp[this.contextData.cArrPos] = this.contextData.cO, this.contextData.cArrPos += 1
                    } else this.canvasContext.save()
                }, CanvasRenderer.prototype.restore = function(t) {
                    if (this.renderConfig.clearCanvas) {
                        t && (this.canvasContext.restore(), this.globalData.blendMode = "source-over"), this.contextData.cArrPos -= 1;
                        var i, e = this.contextData.saved[this.contextData.cArrPos],
                            r = this.contextData.cTr.props;
                        for (i = 0; i < 16; i += 1) r[i] = e[i];
                        this.canvasContext.setTransform(e[0], e[1], e[4], e[5], e[12], e[13]), e = this.contextData.savedOp[this.contextData.cArrPos], this.contextData.cO = e, this.globalData.currentGlobalAlpha !== e && (this.canvasContext.globalAlpha = e, this.globalData.currentGlobalAlpha = e)
                    } else this.canvasContext.restore()
                }, CanvasRenderer.prototype.configAnimation = function(t) {
                    if (this.animationItem.wrapper) {
                        this.animationItem.container = createTag("canvas");
                        var e = this.animationItem.container.style;
                        e.width = "100%", e.height = "100%";
                        var r = "0px 0px 0px";
                        e.transformOrigin = r, e.mozTransformOrigin = r, e.webkitTransformOrigin = r, e["-webkit-transform"] = r, e.contentVisibility = this.renderConfig.contentVisibility, this.animationItem.wrapper.appendChild(this.animationItem.container), this.canvasContext = this.animationItem.container.getContext("2d"), this.renderConfig.className && this.animationItem.container.setAttribute("class", this.renderConfig.className), this.renderConfig.id && this.animationItem.container.setAttribute("id", this.renderConfig.id)
                    } else this.canvasContext = this.renderConfig.context;
                    this.data = t, this.layers = t.layers, this.transformCanvas = {
                        w: t.w,
                        h: t.h,
                        sx: 0,
                        sy: 0,
                        tx: 0,
                        ty: 0
                    }, this.setupGlobalData(t, document.body), this.globalData.canvasContext = this.canvasContext, this.globalData.renderer = this, this.globalData.isDashed = !1, this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.globalData.transformCanvas = this.transformCanvas, this.elements = createSizedArray(t.layers.length), this.updateContainerSize()
                }, CanvasRenderer.prototype.updateContainerSize = function() {
                    var t, e, r, n;
                    if (this.reset(), this.animationItem.wrapper && this.animationItem.container ? (t = this.animationItem.wrapper.offsetWidth, e = this.animationItem.wrapper.offsetHeight, this.animationItem.container.setAttribute("width", t * this.renderConfig.dpr), this.animationItem.container.setAttribute("height", e * this.renderConfig.dpr)) : (t = this.canvasContext.canvas.width * this.renderConfig.dpr, e = this.canvasContext.canvas.height * this.renderConfig.dpr), -1 !== this.renderConfig.preserveAspectRatio.indexOf("meet") || -1 !== this.renderConfig.preserveAspectRatio.indexOf("slice")) {
                        var o = this.renderConfig.preserveAspectRatio.split(" "),
                            h = o[1] || "meet",
                            l = o[0] || "xMidYMid",
                            m = l.substr(0, 4),
                            f = l.substr(4);
                        r = t / e, (n = this.transformCanvas.w / this.transformCanvas.h) > r && "meet" === h || n < r && "slice" === h ? (this.transformCanvas.sx = t / (this.transformCanvas.w / this.renderConfig.dpr), this.transformCanvas.sy = t / (this.transformCanvas.w / this.renderConfig.dpr)) : (this.transformCanvas.sx = e / (this.transformCanvas.h / this.renderConfig.dpr), this.transformCanvas.sy = e / (this.transformCanvas.h / this.renderConfig.dpr)), this.transformCanvas.tx = "xMid" === m && (n < r && "meet" === h || n > r && "slice" === h) ? (t - this.transformCanvas.w * (e / this.transformCanvas.h)) / 2 * this.renderConfig.dpr : "xMax" === m && (n < r && "meet" === h || n > r && "slice" === h) ? (t - this.transformCanvas.w * (e / this.transformCanvas.h)) * this.renderConfig.dpr : 0, this.transformCanvas.ty = "YMid" === f && (n > r && "meet" === h || n < r && "slice" === h) ? (e - this.transformCanvas.h * (t / this.transformCanvas.w)) / 2 * this.renderConfig.dpr : "YMax" === f && (n > r && "meet" === h || n < r && "slice" === h) ? (e - this.transformCanvas.h * (t / this.transformCanvas.w)) * this.renderConfig.dpr : 0
                    } else "none" === this.renderConfig.preserveAspectRatio ? (this.transformCanvas.sx = t / (this.transformCanvas.w / this.renderConfig.dpr), this.transformCanvas.sy = e / (this.transformCanvas.h / this.renderConfig.dpr), this.transformCanvas.tx = 0, this.transformCanvas.ty = 0) : (this.transformCanvas.sx = this.renderConfig.dpr, this.transformCanvas.sy = this.renderConfig.dpr, this.transformCanvas.tx = 0, this.transformCanvas.ty = 0);
                    this.transformCanvas.props = [this.transformCanvas.sx, 0, 0, 0, 0, this.transformCanvas.sy, 0, 0, 0, 0, 1, 0, this.transformCanvas.tx, this.transformCanvas.ty, 0, 1], this.ctxTransform(this.transformCanvas.props), this.canvasContext.beginPath(), this.canvasContext.rect(0, 0, this.transformCanvas.w, this.transformCanvas.h), this.canvasContext.closePath(), this.canvasContext.clip(), this.renderFrame(this.renderedFrame, !0)
                }, CanvasRenderer.prototype.destroy = function() {
                    var i;
                    for (this.renderConfig.clearCanvas && this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ""), i = (this.layers ? this.layers.length : 0) - 1; i >= 0; i -= 1) this.elements[i] && this.elements[i].destroy();
                    this.elements.length = 0, this.globalData.canvasContext = null, this.animationItem.container = null, this.destroyed = !0
                }, CanvasRenderer.prototype.renderFrame = function(t, e) {
                    if ((this.renderedFrame !== t || !0 !== this.renderConfig.clearCanvas || e) && !this.destroyed && -1 !== t) {
                        var i;
                        this.renderedFrame = t, this.globalData.frameNum = t - this.animationItem._isFirstFrame, this.globalData.frameId += 1, this.globalData._mdf = !this.renderConfig.clearCanvas || e, this.globalData.projectInterface.currentFrame = t;
                        var r = this.layers.length;
                        for (this.completeLayers || this.checkLayers(t), i = 0; i < r; i += 1)(this.completeLayers || this.elements[i]) && this.elements[i].prepareFrame(t - this.layers[i].st);
                        if (this.globalData._mdf) {
                            for (!0 === this.renderConfig.clearCanvas ? this.canvasContext.clearRect(0, 0, this.transformCanvas.w, this.transformCanvas.h) : this.save(), i = r - 1; i >= 0; i -= 1)(this.completeLayers || this.elements[i]) && this.elements[i].renderFrame();
                            !0 !== this.renderConfig.clearCanvas && this.restore()
                        }
                    }
                }, CanvasRenderer.prototype.buildItem = function(t) {
                    var e = this.elements;
                    if (!e[t] && 99 !== this.layers[t].ty) {
                        var element = this.createItem(this.layers[t], this, this.globalData);
                        e[t] = element, element.initExpressions()
                    }
                }, CanvasRenderer.prototype.checkPendingElements = function() {
                    for (; this.pendingElements.length;) this.pendingElements.pop().checkParenting()
                }, CanvasRenderer.prototype.hide = function() {
                    this.animationItem.container.style.display = "none"
                }, CanvasRenderer.prototype.show = function() {
                    this.animationItem.container.style.display = "block"
                }, extendPrototype([BaseRenderer], HybridRenderer), HybridRenderer.prototype.buildItem = SVGRenderer.prototype.buildItem, HybridRenderer.prototype.checkPendingElements = function() {
                    for (; this.pendingElements.length;) this.pendingElements.pop().checkParenting()
                }, HybridRenderer.prototype.appendElementInPos = function(element, t) {
                    var e = element.getBaseElement();
                    if (e) {
                        var r = this.layers[t];
                        if (r.ddd && this.supports3d) this.addTo3dContainer(e, t);
                        else if (this.threeDElements) this.addTo3dContainer(e, t);
                        else {
                            for (var n, o, i = 0; i < t;) this.elements[i] && !0 !== this.elements[i] && this.elements[i].getBaseElement && (o = this.elements[i], n = (this.layers[i].ddd ? this.getThreeDContainerByPos(i) : o.getBaseElement()) || n), i += 1;
                            n ? r.ddd && this.supports3d || this.layerElement.insertBefore(e, n) : r.ddd && this.supports3d || this.layerElement.appendChild(e)
                        }
                    }
                }, HybridRenderer.prototype.createShape = function(data) {
                    return this.supports3d ? new HShapeElement(data, this.globalData, this) : new SVGShapeElement(data, this.globalData, this)
                }, HybridRenderer.prototype.createText = function(data) {
                    return this.supports3d ? new HTextElement(data, this.globalData, this) : new SVGTextLottieElement(data, this.globalData, this)
                }, HybridRenderer.prototype.createCamera = function(data) {
                    return this.camera = new HCameraElement(data, this.globalData, this), this.camera
                }, HybridRenderer.prototype.createImage = function(data) {
                    return this.supports3d ? new HImageElement(data, this.globalData, this) : new IImageElement(data, this.globalData, this)
                }, HybridRenderer.prototype.createComp = function(data) {
                    return this.supports3d ? new HCompElement(data, this.globalData, this) : new SVGCompElement(data, this.globalData, this)
                }, HybridRenderer.prototype.createSolid = function(data) {
                    return this.supports3d ? new HSolidElement(data, this.globalData, this) : new ISolidElement(data, this.globalData, this)
                }, HybridRenderer.prototype.createNull = SVGRenderer.prototype.createNull, HybridRenderer.prototype.getThreeDContainerByPos = function(t) {
                    for (var i = 0, e = this.threeDElements.length; i < e;) {
                        if (this.threeDElements[i].startPos <= t && this.threeDElements[i].endPos >= t) return this.threeDElements[i].perspectiveElem;
                        i += 1
                    }
                    return null
                }, HybridRenderer.prototype.createThreeDContainer = function(t, e) {
                    var style, r, n = createTag("div");
                    styleDiv(n);
                    var o = createTag("div");
                    if (styleDiv(o), "3d" === e) {
                        (style = n.style).width = this.globalData.compSize.w + "px", style.height = this.globalData.compSize.h + "px";
                        var h = "50% 50%";
                        style.webkitTransformOrigin = h, style.mozTransformOrigin = h, style.transformOrigin = h;
                        var l = "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)";
                        (r = o.style).transform = l, r.webkitTransform = l
                    }
                    n.appendChild(o);
                    var m = {
                        container: o,
                        perspectiveElem: n,
                        startPos: t,
                        endPos: t,
                        type: e
                    };
                    return this.threeDElements.push(m), m
                }, HybridRenderer.prototype.build3dContainers = function() {
                    var i, t, e = this.layers.length,
                        r = "";
                    for (i = 0; i < e; i += 1) this.layers[i].ddd && 3 !== this.layers[i].ty ? ("3d" !== r && (r = "3d", t = this.createThreeDContainer(i, "3d")), t.endPos = Math.max(t.endPos, i)) : ("2d" !== r && (r = "2d", t = this.createThreeDContainer(i, "2d")), t.endPos = Math.max(t.endPos, i));
                    for (i = (e = this.threeDElements.length) - 1; i >= 0; i -= 1) this.resizerElem.appendChild(this.threeDElements[i].perspectiveElem)
                }, HybridRenderer.prototype.addTo3dContainer = function(t, e) {
                    for (var i = 0, r = this.threeDElements.length; i < r;) {
                        if (e <= this.threeDElements[i].endPos) {
                            for (var n, o = this.threeDElements[i].startPos; o < e;) this.elements[o] && this.elements[o].getBaseElement && (n = this.elements[o].getBaseElement()), o += 1;
                            n ? this.threeDElements[i].container.insertBefore(t, n) : this.threeDElements[i].container.appendChild(t);
                            break
                        }
                        i += 1
                    }
                }, HybridRenderer.prototype.configAnimation = function(t) {
                    var e = createTag("div"),
                        r = this.animationItem.wrapper,
                        style = e.style;
                    style.width = t.w + "px", style.height = t.h + "px", this.resizerElem = e, styleDiv(e), style.transformStyle = "flat", style.mozTransformStyle = "flat", style.webkitTransformStyle = "flat", this.renderConfig.className && e.setAttribute("class", this.renderConfig.className), r.appendChild(e), style.overflow = "hidden";
                    var svg = createNS("svg");
                    svg.setAttribute("width", "1"), svg.setAttribute("height", "1"), styleDiv(svg), this.resizerElem.appendChild(svg);
                    var defs = createNS("defs");
                    svg.appendChild(defs), this.data = t, this.setupGlobalData(t, svg), this.globalData.defs = defs, this.layers = t.layers, this.layerElement = this.resizerElem, this.build3dContainers(), this.updateContainerSize()
                }, HybridRenderer.prototype.destroy = function() {
                    var i;
                    this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ""), this.animationItem.container = null, this.globalData.defs = null;
                    var t = this.layers ? this.layers.length : 0;
                    for (i = 0; i < t; i += 1) this.elements[i].destroy();
                    this.elements.length = 0, this.destroyed = !0, this.animationItem = null
                }, HybridRenderer.prototype.updateContainerSize = function() {
                    var t, e, r, n, o = this.animationItem.wrapper.offsetWidth,
                        h = this.animationItem.wrapper.offsetHeight,
                        l = o / h;
                    this.globalData.compSize.w / this.globalData.compSize.h > l ? (t = o / this.globalData.compSize.w, e = o / this.globalData.compSize.w, r = 0, n = (h - this.globalData.compSize.h * (o / this.globalData.compSize.w)) / 2) : (t = h / this.globalData.compSize.h, e = h / this.globalData.compSize.h, r = (o - this.globalData.compSize.w * (h / this.globalData.compSize.h)) / 2, n = 0);
                    var style = this.resizerElem.style;
                    style.webkitTransform = "matrix3d(" + t + ",0,0,0,0," + e + ",0,0,0,0,1,0," + r + "," + n + ",0,1)", style.transform = style.webkitTransform
                }, HybridRenderer.prototype.renderFrame = SVGRenderer.prototype.renderFrame, HybridRenderer.prototype.hide = function() {
                    this.resizerElem.style.display = "none"
                }, HybridRenderer.prototype.show = function() {
                    this.resizerElem.style.display = "block"
                }, HybridRenderer.prototype.initItems = function() {
                    if (this.buildAllItems(), this.camera) this.camera.setup();
                    else {
                        var i, t = this.globalData.compSize.w,
                            e = this.globalData.compSize.h,
                            r = this.threeDElements.length;
                        for (i = 0; i < r; i += 1) {
                            var style = this.threeDElements[i].perspectiveElem.style;
                            style.webkitPerspective = Math.sqrt(Math.pow(t, 2) + Math.pow(e, 2)) + "px", style.perspective = style.webkitPerspective
                        }
                    }
                }, HybridRenderer.prototype.searchExtraCompositions = function(t) {
                    var i, e = t.length,
                        r = createTag("div");
                    for (i = 0; i < e; i += 1)
                        if (t[i].xt) {
                            var n = this.createComp(t[i], r, this.globalData.comp, null);
                            n.initExpressions(), this.globalData.projectInterface.registerComposition(n)
                        }
                }, MaskElement.prototype.getMaskProperty = function(t) {
                    return this.viewData[t].prop
                }, MaskElement.prototype.renderFrame = function(t) {
                    var i, e = this.element.finalTransform.mat,
                        r = this.masksProperties.length;
                    for (i = 0; i < r; i += 1)
                        if ((this.viewData[i].prop._mdf || t) && this.drawPath(this.masksProperties[i], this.viewData[i].prop.v, this.viewData[i]), (this.viewData[i].op._mdf || t) && this.viewData[i].elem.setAttribute("fill-opacity", this.viewData[i].op.v), "n" !== this.masksProperties[i].mode && (this.viewData[i].invRect && (this.element.finalTransform.mProp._mdf || t) && this.viewData[i].invRect.setAttribute("transform", e.getInverseMatrix().to2dCSS()), this.storedData[i].x && (this.storedData[i].x._mdf || t))) {
                            var n = this.storedData[i].expan;
                            this.storedData[i].x.v < 0 ? ("erode" !== this.storedData[i].lastOperator && (this.storedData[i].lastOperator = "erode", this.storedData[i].elem.setAttribute("filter", "url(" + locationHref + "#" + this.storedData[i].filterId + ")")), n.setAttribute("radius", -this.storedData[i].x.v)) : ("dilate" !== this.storedData[i].lastOperator && (this.storedData[i].lastOperator = "dilate", this.storedData[i].elem.setAttribute("filter", null)), this.storedData[i].elem.setAttribute("stroke-width", 2 * this.storedData[i].x.v))
                        }
                }, MaskElement.prototype.getMaskelement = function() {
                    return this.maskElement
                }, MaskElement.prototype.createLayerSolidPath = function() {
                    var path = "M0,0 ";
                    return path += " h" + this.globalData.compSize.w, path += " v" + this.globalData.compSize.h, path += " h-" + this.globalData.compSize.w, path += " v-" + this.globalData.compSize.h + " "
                }, MaskElement.prototype.drawPath = function(t, e, r) {
                    var i, n, o = " M" + e.v[0][0] + "," + e.v[0][1];
                    for (n = e._length, i = 1; i < n; i += 1) o += " C" + e.o[i - 1][0] + "," + e.o[i - 1][1] + " " + e.i[i][0] + "," + e.i[i][1] + " " + e.v[i][0] + "," + e.v[i][1];
                    if (e.c && n > 1 && (o += " C" + e.o[i - 1][0] + "," + e.o[i - 1][1] + " " + e.i[0][0] + "," + e.i[0][1] + " " + e.v[0][0] + "," + e.v[0][1]), r.lastPath !== o) {
                        var h = "";
                        r.elem && (e.c && (h = t.inv ? this.solidPath + o : o), r.elem.setAttribute("d", h)), r.lastPath = o
                    }
                }, MaskElement.prototype.destroy = function() {
                    this.element = null, this.globalData = null, this.maskElement = null, this.data = null, this.masksProperties = null
                }, HierarchyElement.prototype = {
                    initHierarchy: function() {
                        this.hierarchy = [], this._isParent = !1, this.checkParenting()
                    },
                    setHierarchy: function(t) {
                        this.hierarchy = t
                    },
                    setAsParent: function() {
                        this._isParent = !0
                    },
                    checkParenting: function() {
                        void 0 !== this.data.parent && this.comp.buildElementParenting(this, this.data.parent, [])
                    }
                }, FrameElement.prototype = {
                    initFrame: function() {
                        this._isFirstFrame = !1, this.dynamicProperties = [], this._mdf = !1
                    },
                    prepareProperties: function(t, e) {
                        var i, r = this.dynamicProperties.length;
                        for (i = 0; i < r; i += 1)(e || this._isParent && "transform" === this.dynamicProperties[i].propType) && (this.dynamicProperties[i].getValue(), this.dynamicProperties[i]._mdf && (this.globalData._mdf = !0, this._mdf = !0))
                    },
                    addDynamicProperty: function(t) {
                        -1 === this.dynamicProperties.indexOf(t) && this.dynamicProperties.push(t)
                    }
                }, TransformElement.prototype = {
                    initTransform: function() {
                        this.finalTransform = {
                            mProp: this.data.ks ? TransformPropertyFactory.getTransformProperty(this, this.data.ks, this) : {
                                o: 0
                            },
                            _matMdf: !1,
                            _opMdf: !1,
                            mat: new Matrix
                        }, this.data.ao && (this.finalTransform.mProp.autoOriented = !0), this.data.ty
                    },
                    renderTransform: function() {
                        if (this.finalTransform._opMdf = this.finalTransform.mProp.o._mdf || this._isFirstFrame, this.finalTransform._matMdf = this.finalTransform.mProp._mdf || this._isFirstFrame, this.hierarchy) {
                            var t, e = this.finalTransform.mat,
                                i = 0,
                                r = this.hierarchy.length;
                            if (!this.finalTransform._matMdf)
                                for (; i < r;) {
                                    if (this.hierarchy[i].finalTransform.mProp._mdf) {
                                        this.finalTransform._matMdf = !0;
                                        break
                                    }
                                    i += 1
                                }
                            if (this.finalTransform._matMdf)
                                for (t = this.finalTransform.mProp.v.props, e.cloneFromProps(t), i = 0; i < r; i += 1) t = this.hierarchy[i].finalTransform.mProp.v.props, e.transform(t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8], t[9], t[10], t[11], t[12], t[13], t[14], t[15])
                        }
                    },
                    globalToLocal: function(t) {
                        var e = [];
                        e.push(this.finalTransform);
                        for (var i, r = !0, n = this.comp; r;) n.finalTransform ? (n.data.hasMask && e.splice(0, 0, n.finalTransform), n = n.comp) : r = !1;
                        var o, h = e.length;
                        for (i = 0; i < h; i += 1) o = e[i].mat.applyToPointArray(0, 0, 0), t = [t[0] - o[0], t[1] - o[1], 0];
                        return t
                    },
                    mHelper: new Matrix
                }, RenderableElement.prototype = {
                    initRenderable: function() {
                        this.isInRange = !1, this.hidden = !1, this.isTransparent = !1, this.renderableComponents = []
                    },
                    addRenderableComponent: function(component) {
                        -1 === this.renderableComponents.indexOf(component) && this.renderableComponents.push(component)
                    },
                    removeRenderableComponent: function(component) {
                        -1 !== this.renderableComponents.indexOf(component) && this.renderableComponents.splice(this.renderableComponents.indexOf(component), 1)
                    },
                    prepareRenderableFrame: function(t) {
                        this.checkLayerLimits(t)
                    },
                    checkTransparency: function() {
                        this.finalTransform.mProp.o.v <= 0 ? !this.isTransparent && this.globalData.renderConfig.hideOnTransparent && (this.isTransparent = !0, this.hide()) : this.isTransparent && (this.isTransparent = !1, this.show())
                    },
                    checkLayerLimits: function(t) {
                        this.data.ip - this.data.st <= t && this.data.op - this.data.st > t ? !0 !== this.isInRange && (this.globalData._mdf = !0, this._mdf = !0, this.isInRange = !0, this.show()) : !1 !== this.isInRange && (this.globalData._mdf = !0, this.isInRange = !1, this.hide())
                    },
                    renderRenderable: function() {
                        var i, t = this.renderableComponents.length;
                        for (i = 0; i < t; i += 1) this.renderableComponents[i].renderFrame(this._isFirstFrame)
                    },
                    sourceRectAtTime: function() {
                        return {
                            top: 0,
                            left: 0,
                            width: 100,
                            height: 100
                        }
                    },
                    getLayerSize: function() {
                        return 5 === this.data.ty ? {
                            w: this.data.textData.width,
                            h: this.data.textData.height
                        } : {
                            w: this.data.width,
                            h: this.data.height
                        }
                    }
                }, extendPrototype([RenderableElement, createProxyFunction({
                    initElement: function(data, t, e) {
                        this.initFrame(), this.initBaseData(data, t, e), this.initTransform(data, t, e), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide()
                    },
                    hide: function() {
                        this.hidden || this.isInRange && !this.isTransparent || ((this.baseElement || this.layerElement).style.display = "none", this.hidden = !0)
                    },
                    show: function() {
                        this.isInRange && !this.isTransparent && (this.data.hd || ((this.baseElement || this.layerElement).style.display = "block"), this.hidden = !1, this._isFirstFrame = !0)
                    },
                    renderFrame: function() {
                        this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = !1))
                    },
                    renderInnerContent: function() {},
                    prepareFrame: function(t) {
                        this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), this.checkTransparency()
                    },
                    destroy: function() {
                        this.innerElem = null, this.destroyBaseElement()
                    }
                })], RenderableDOMElement), SVGStyleData.prototype.reset = function() {
                    this.d = "", this._mdf = !1
                }, SVGShapeData.prototype.setAsAnimated = function() {
                    this._isAnimated = !0
                }, extendPrototype([DynamicPropertyContainer], SVGStrokeStyleData), extendPrototype([DynamicPropertyContainer], SVGFillStyleData), SVGGradientFillStyleData.prototype.initGradientData = function(t, data, e) {
                    this.o = PropertyFactory.getProp(t, data.o, 0, .01, this), this.s = PropertyFactory.getProp(t, data.s, 1, null, this), this.e = PropertyFactory.getProp(t, data.e, 1, null, this), this.h = PropertyFactory.getProp(t, data.h || {
                        k: 0
                    }, 0, .01, this), this.a = PropertyFactory.getProp(t, data.a || {
                        k: 0
                    }, 0, degToRads, this), this.g = new GradientProperty(t, data.g, this), this.style = e, this.stops = [], this.setGradientData(e.pElem, data), this.setGradientOpacity(data, e), this._isAnimated = !!this._isAnimated
                }, SVGGradientFillStyleData.prototype.setGradientData = function(t, data) {
                    var e = createElementID(),
                        r = createNS(1 === data.t ? "linearGradient" : "radialGradient");
                    r.setAttribute("id", e), r.setAttribute("spreadMethod", "pad"), r.setAttribute("gradientUnits", "userSpaceOnUse");
                    var n, o, h, l = [];
                    for (h = 4 * data.g.p, o = 0; o < h; o += 4) n = createNS("stop"), r.appendChild(n), l.push(n);
                    t.setAttribute("gf" === data.ty ? "fill" : "stroke", "url(" + locationHref + "#" + e + ")"), this.gf = r, this.cst = l
                }, SVGGradientFillStyleData.prototype.setGradientOpacity = function(data, t) {
                    if (this.g._hasOpacity && !this.g._collapsable) {
                        var e, r, n, mask = createNS("mask"),
                            o = createNS("path");
                        mask.appendChild(o);
                        var h = createElementID(),
                            l = createElementID();
                        mask.setAttribute("id", l);
                        var m = createNS(1 === data.t ? "linearGradient" : "radialGradient");
                        m.setAttribute("id", h), m.setAttribute("spreadMethod", "pad"), m.setAttribute("gradientUnits", "userSpaceOnUse"), n = data.g.k.k[0].s ? data.g.k.k[0].s.length : data.g.k.k.length;
                        var f = this.stops;
                        for (r = 4 * data.g.p; r < n; r += 2)(e = createNS("stop")).setAttribute("stop-color", "rgb(255,255,255)"), m.appendChild(e), f.push(e);
                        o.setAttribute("gf" === data.ty ? "fill" : "stroke", "url(" + locationHref + "#" + h + ")"), "gs" === data.ty && (o.setAttribute("stroke-linecap", lineCapEnum[data.lc || 2]), o.setAttribute("stroke-linejoin", lineJoinEnum[data.lj || 2]), 1 === data.lj && o.setAttribute("stroke-miterlimit", data.ml)), this.of = m, this.ms = mask, this.ost = f, this.maskId = l, t.msElem = o
                    }
                }, extendPrototype([DynamicPropertyContainer], SVGGradientFillStyleData), extendPrototype([SVGGradientFillStyleData, DynamicPropertyContainer], SVGGradientStrokeStyleData);
                var SVGElementsRenderer = function() {
                    var t = new Matrix,
                        e = new Matrix;

                    function r(t, e, r) {
                        (r || e.transform.op._mdf) && e.transform.container.setAttribute("opacity", e.transform.op.v), (r || e.transform.mProps._mdf) && e.transform.container.setAttribute("transform", e.transform.mProps.v.to2dCSS())
                    }

                    function n(r, n, o) {
                        var h, l, m, f, c, d, y, v, P, E, x, S = n.styles.length,
                            A = n.lvl;
                        for (d = 0; d < S; d += 1) {
                            if (f = n.sh._mdf || o, n.styles[d].lvl < A) {
                                for (v = e.reset(), E = A - n.styles[d].lvl, x = n.transformers.length - 1; !f && E > 0;) f = n.transformers[x].mProps._mdf || f, E -= 1, x -= 1;
                                if (f)
                                    for (E = A - n.styles[d].lvl, x = n.transformers.length - 1; E > 0;) P = n.transformers[x].mProps.v.props, v.transform(P[0], P[1], P[2], P[3], P[4], P[5], P[6], P[7], P[8], P[9], P[10], P[11], P[12], P[13], P[14], P[15]), E -= 1, x -= 1
                            } else v = t;
                            if (l = (y = n.sh.paths)._length, f) {
                                for (m = "", h = 0; h < l; h += 1)(c = y.shapes[h]) && c._length && (m += buildShapeString(c, c._length, c.c, v));
                                n.caches[d] = m
                            } else m = n.caches[d];
                            n.styles[d].d += !0 === r.hd ? "" : m, n.styles[d]._mdf = f || n.styles[d]._mdf
                        }
                    }

                    function o(t, e, r) {
                        var n = e.style;
                        (e.c._mdf || r) && n.pElem.setAttribute("fill", "rgb(" + bmFloor(e.c.v[0]) + "," + bmFloor(e.c.v[1]) + "," + bmFloor(e.c.v[2]) + ")"), (e.o._mdf || r) && n.pElem.setAttribute("fill-opacity", e.o.v)
                    }

                    function h(t, e, r) {
                        l(t, e, r), m(0, e, r)
                    }

                    function l(t, e, r) {
                        var n, i, o, h, l, m = e.gf,
                            f = e.g._hasOpacity,
                            c = e.s.v,
                            d = e.e.v;
                        if (e.o._mdf || r) {
                            var y = "gf" === t.ty ? "fill-opacity" : "stroke-opacity";
                            e.style.pElem.setAttribute(y, e.o.v)
                        }
                        if (e.s._mdf || r) {
                            var v = 1 === t.t ? "x1" : "cx",
                                P = "x1" === v ? "y1" : "cy";
                            m.setAttribute(v, c[0]), m.setAttribute(P, c[1]), f && !e.g._collapsable && (e.of.setAttribute(v, c[0]), e.of.setAttribute(P, c[1]))
                        }
                        if (e.g._cmdf || r) {
                            n = e.cst;
                            var E = e.g.c;
                            for (o = n.length, i = 0; i < o; i += 1)(h = n[i]).setAttribute("offset", E[4 * i] + "%"), h.setAttribute("stop-color", "rgb(" + E[4 * i + 1] + "," + E[4 * i + 2] + "," + E[4 * i + 3] + ")")
                        }
                        if (f && (e.g._omdf || r)) {
                            var x = e.g.o;
                            for (o = (n = e.g._collapsable ? e.cst : e.ost).length, i = 0; i < o; i += 1) h = n[i], e.g._collapsable || h.setAttribute("offset", x[2 * i] + "%"), h.setAttribute("stop-opacity", x[2 * i + 1])
                        }
                        if (1 === t.t)(e.e._mdf || r) && (m.setAttribute("x2", d[0]), m.setAttribute("y2", d[1]), f && !e.g._collapsable && (e.of.setAttribute("x2", d[0]), e.of.setAttribute("y2", d[1])));
                        else if ((e.s._mdf || e.e._mdf || r) && (l = Math.sqrt(Math.pow(c[0] - d[0], 2) + Math.pow(c[1] - d[1], 2)), m.setAttribute("r", l), f && !e.g._collapsable && e.of.setAttribute("r", l)), e.e._mdf || e.h._mdf || e.a._mdf || r) {
                            l || (l = Math.sqrt(Math.pow(c[0] - d[0], 2) + Math.pow(c[1] - d[1], 2)));
                            var S = Math.atan2(d[1] - c[1], d[0] - c[0]),
                                A = e.h.v;
                            A >= 1 ? A = .99 : A <= -1 && (A = -.99);
                            var C = l * A,
                                _ = Math.cos(S + e.a.v) * C + c[0],
                                T = Math.sin(S + e.a.v) * C + c[1];
                            m.setAttribute("fx", _), m.setAttribute("fy", T), f && !e.g._collapsable && (e.of.setAttribute("fx", _), e.of.setAttribute("fy", T))
                        }
                    }

                    function m(t, e, r) {
                        var n = e.style,
                            o = e.d;
                        o && (o._mdf || r) && o.dashStr && (n.pElem.setAttribute("stroke-dasharray", o.dashStr), n.pElem.setAttribute("stroke-dashoffset", o.dashoffset[0])), e.c && (e.c._mdf || r) && n.pElem.setAttribute("stroke", "rgb(" + bmFloor(e.c.v[0]) + "," + bmFloor(e.c.v[1]) + "," + bmFloor(e.c.v[2]) + ")"), (e.o._mdf || r) && n.pElem.setAttribute("stroke-opacity", e.o.v), (e.w._mdf || r) && (n.pElem.setAttribute("stroke-width", e.w.v), n.msElem && n.msElem.setAttribute("stroke-width", e.w.v))
                    }
                    return {
                        createRenderFunction: function(data) {
                            switch (data.ty) {
                                case "fl":
                                    return o;
                                case "gf":
                                    return l;
                                case "gs":
                                    return h;
                                case "st":
                                    return m;
                                case "sh":
                                case "el":
                                case "rc":
                                case "sr":
                                    return n;
                                case "tr":
                                    return r;
                                default:
                                    return null
                            }
                        }
                    }
                }();

                function ShapeTransformManager() {
                    this.sequences = {}, this.sequenceList = [], this.transform_key_count = 0
                }

                function CVShapeData(element, data, t, e) {
                    this.styledShapes = [], this.tr = [0, 0, 0, 0, 0, 0];
                    var i, r = 4;
                    "rc" === data.ty ? r = 5 : "el" === data.ty ? r = 6 : "sr" === data.ty && (r = 7), this.sh = ShapePropertyFactory.getShapeProp(element, data, r, element);
                    var n, o = t.length;
                    for (i = 0; i < o; i += 1) t[i].closed || (n = {
                        transforms: e.addTransformSequence(t[i].transforms),
                        trNodes: []
                    }, this.styledShapes.push(n), t[i].elements.push(n))
                }

                function BaseElement() {}

                function NullElement(data, t, e) {
                    this.initFrame(), this.initBaseData(data, t, e), this.initFrame(), this.initTransform(data, t, e), this.initHierarchy()
                }

                function SVGBaseElement() {}

                function IShapeElement() {}

                function ITextElement() {}

                function ICompElement() {}

                function IImageElement(data, t, e) {
                    this.assetData = t.getAssetData(data.refId), this.initElement(data, t, e), this.sourceRect = {
                        top: 0,
                        left: 0,
                        width: this.assetData.w,
                        height: this.assetData.h
                    }
                }

                function ISolidElement(data, t, e) {
                    this.initElement(data, t, e)
                }

                function AudioElement(data, t, e) {
                    this.initFrame(), this.initRenderable(), this.assetData = t.getAssetData(data.refId), this.initBaseData(data, t, e), this._isPlaying = !1, this._canPlay = !1;
                    var r = this.globalData.getAssetsPath(this.assetData);
                    this.audio = this.globalData.audioController.createAudio(r), this._currentTime = 0, this.globalData.audioController.addAudio(this), this.tm = data.tm ? PropertyFactory.getProp(this, data.tm, 0, t.frameRate, this) : {
                        _placeholder: !0
                    }
                }

                function FootageElement(data, t, e) {
                    this.initFrame(), this.initRenderable(), this.assetData = t.getAssetData(data.refId), this.footageData = t.imageLoader.getAsset(this.assetData), this.initBaseData(data, t, e)
                }

                function SVGCompElement(data, t, e) {
                    this.layers = data.layers, this.supports3d = !0, this.completeLayers = !1, this.pendingElements = [], this.elements = this.layers ? createSizedArray(this.layers.length) : [], this.initElement(data, t, e), this.tm = data.tm ? PropertyFactory.getProp(this, data.tm, 0, t.frameRate, this) : {
                        _placeholder: !0
                    }
                }

                function SVGTextLottieElement(data, t, e) {
                    this.textSpans = [], this.renderType = "svg", this.initElement(data, t, e)
                }

                function SVGShapeElement(data, t, e) {
                    this.shapes = [], this.shapesData = data.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.initElement(data, t, e), this.prevViewData = []
                }

                function SVGTintFilter(filter, t) {
                    this.filterManager = t;
                    var e = createNS("feColorMatrix");
                    if (e.setAttribute("type", "matrix"), e.setAttribute("color-interpolation-filters", "linearRGB"), e.setAttribute("values", "0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0"), e.setAttribute("result", "f1"), filter.appendChild(e), (e = createNS("feColorMatrix")).setAttribute("type", "matrix"), e.setAttribute("color-interpolation-filters", "sRGB"), e.setAttribute("values", "1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"), e.setAttribute("result", "f2"), filter.appendChild(e), this.matrixFilter = e, 100 !== t.effectElements[2].p.v || t.effectElements[2].p.k) {
                        var r, n = createNS("feMerge");
                        filter.appendChild(n), (r = createNS("feMergeNode")).setAttribute("in", "SourceGraphic"), n.appendChild(r), (r = createNS("feMergeNode")).setAttribute("in", "f2"), n.appendChild(r)
                    }
                }

                function SVGFillFilter(filter, t) {
                    this.filterManager = t;
                    var e = createNS("feColorMatrix");
                    e.setAttribute("type", "matrix"), e.setAttribute("color-interpolation-filters", "sRGB"), e.setAttribute("values", "1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"), filter.appendChild(e), this.matrixFilter = e
                }

                function SVGGaussianBlurEffect(filter, t) {
                    filter.setAttribute("x", "-100%"), filter.setAttribute("y", "-100%"), filter.setAttribute("width", "300%"), filter.setAttribute("height", "300%"), this.filterManager = t;
                    var e = createNS("feGaussianBlur");
                    filter.appendChild(e), this.feGaussianBlur = e
                }

                function SVGStrokeEffect(t, e) {
                    this.initialized = !1, this.filterManager = e, this.elem = t, this.paths = []
                }

                function SVGTritoneFilter(filter, t) {
                    this.filterManager = t;
                    var e = createNS("feColorMatrix");
                    e.setAttribute("type", "matrix"), e.setAttribute("color-interpolation-filters", "linearRGB"), e.setAttribute("values", "0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0"), e.setAttribute("result", "f1"), filter.appendChild(e);
                    var r = createNS("feComponentTransfer");
                    r.setAttribute("color-interpolation-filters", "sRGB"), filter.appendChild(r), this.matrixFilter = r;
                    var n = createNS("feFuncR");
                    n.setAttribute("type", "table"), r.appendChild(n), this.feFuncR = n;
                    var o = createNS("feFuncG");
                    o.setAttribute("type", "table"), r.appendChild(o), this.feFuncG = o;
                    var h = createNS("feFuncB");
                    h.setAttribute("type", "table"), r.appendChild(h), this.feFuncB = h
                }

                function SVGProLevelsFilter(filter, t) {
                    this.filterManager = t;
                    var e = this.filterManager.effectElements,
                        r = createNS("feComponentTransfer");
                    (e[10].p.k || 0 !== e[10].p.v || e[11].p.k || 1 !== e[11].p.v || e[12].p.k || 1 !== e[12].p.v || e[13].p.k || 0 !== e[13].p.v || e[14].p.k || 1 !== e[14].p.v) && (this.feFuncR = this.createFeFunc("feFuncR", r)), (e[17].p.k || 0 !== e[17].p.v || e[18].p.k || 1 !== e[18].p.v || e[19].p.k || 1 !== e[19].p.v || e[20].p.k || 0 !== e[20].p.v || e[21].p.k || 1 !== e[21].p.v) && (this.feFuncG = this.createFeFunc("feFuncG", r)), (e[24].p.k || 0 !== e[24].p.v || e[25].p.k || 1 !== e[25].p.v || e[26].p.k || 1 !== e[26].p.v || e[27].p.k || 0 !== e[27].p.v || e[28].p.k || 1 !== e[28].p.v) && (this.feFuncB = this.createFeFunc("feFuncB", r)), (e[31].p.k || 0 !== e[31].p.v || e[32].p.k || 1 !== e[32].p.v || e[33].p.k || 1 !== e[33].p.v || e[34].p.k || 0 !== e[34].p.v || e[35].p.k || 1 !== e[35].p.v) && (this.feFuncA = this.createFeFunc("feFuncA", r)), (this.feFuncR || this.feFuncG || this.feFuncB || this.feFuncA) && (r.setAttribute("color-interpolation-filters", "sRGB"), filter.appendChild(r), r = createNS("feComponentTransfer")), (e[3].p.k || 0 !== e[3].p.v || e[4].p.k || 1 !== e[4].p.v || e[5].p.k || 1 !== e[5].p.v || e[6].p.k || 0 !== e[6].p.v || e[7].p.k || 1 !== e[7].p.v) && (r.setAttribute("color-interpolation-filters", "sRGB"), filter.appendChild(r), this.feFuncRComposed = this.createFeFunc("feFuncR", r), this.feFuncGComposed = this.createFeFunc("feFuncG", r), this.feFuncBComposed = this.createFeFunc("feFuncB", r))
                }

                function SVGDropShadowEffect(filter, t) {
                    var e = t.container.globalData.renderConfig.filterSize;
                    filter.setAttribute("x", e.x), filter.setAttribute("y", e.y), filter.setAttribute("width", e.width), filter.setAttribute("height", e.height), this.filterManager = t;
                    var r = createNS("feGaussianBlur");
                    r.setAttribute("in", "SourceAlpha"), r.setAttribute("result", "drop_shadow_1"), r.setAttribute("stdDeviation", "0"), this.feGaussianBlur = r, filter.appendChild(r);
                    var n = createNS("feOffset");
                    n.setAttribute("dx", "25"), n.setAttribute("dy", "0"), n.setAttribute("in", "drop_shadow_1"), n.setAttribute("result", "drop_shadow_2"), this.feOffset = n, filter.appendChild(n);
                    var o = createNS("feFlood");
                    o.setAttribute("flood-color", "#00ff00"), o.setAttribute("flood-opacity", "1"), o.setAttribute("result", "drop_shadow_3"), this.feFlood = o, filter.appendChild(o);
                    var h = createNS("feComposite");
                    h.setAttribute("in", "drop_shadow_3"), h.setAttribute("in2", "drop_shadow_2"), h.setAttribute("operator", "in"), h.setAttribute("result", "drop_shadow_4"), filter.appendChild(h);
                    var l, m = createNS("feMerge");
                    filter.appendChild(m), l = createNS("feMergeNode"), m.appendChild(l), (l = createNS("feMergeNode")).setAttribute("in", "SourceGraphic"), this.feMergeNode = l, this.feMerge = m, this.originalNodeAdded = !1, m.appendChild(l)
                }
                ShapeTransformManager.prototype = {
                    addTransformSequence: function(t) {
                        var i, e = t.length,
                            r = "_";
                        for (i = 0; i < e; i += 1) r += t[i].transform.key + "_";
                        var n = this.sequences[r];
                        return n || (n = {
                            transforms: [].concat(t),
                            finalTransform: new Matrix,
                            _mdf: !1
                        }, this.sequences[r] = n, this.sequenceList.push(n)), n
                    },
                    processSequence: function(t, e) {
                        for (var r, i = 0, n = t.transforms.length, o = e; i < n && !e;) {
                            if (t.transforms[i].transform.mProps._mdf) {
                                o = !0;
                                break
                            }
                            i += 1
                        }
                        if (o)
                            for (t.finalTransform.reset(), i = n - 1; i >= 0; i -= 1) r = t.transforms[i].transform.mProps.v.props, t.finalTransform.transform(r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15]);
                        t._mdf = o
                    },
                    processSequences: function(t) {
                        var i, e = this.sequenceList.length;
                        for (i = 0; i < e; i += 1) this.processSequence(this.sequenceList[i], t)
                    },
                    getNewKey: function() {
                        return this.transform_key_count += 1, "_" + this.transform_key_count
                    }
                }, CVShapeData.prototype.setAsAnimated = SVGShapeData.prototype.setAsAnimated, BaseElement.prototype = {
                    checkMasks: function() {
                        if (!this.data.hasMask) return !1;
                        for (var i = 0, t = this.data.masksProperties.length; i < t;) {
                            if ("n" !== this.data.masksProperties[i].mode && !1 !== this.data.masksProperties[i].cl) return !0;
                            i += 1
                        }
                        return !1
                    },
                    initExpressions: function() {
                        this.layerInterface = LayerExpressionInterface(this), this.data.hasMask && this.maskManager && this.layerInterface.registerMaskInterface(this.maskManager);
                        var t = EffectsExpressionInterface.createEffectsInterface(this, this.layerInterface);
                        this.layerInterface.registerEffectsInterface(t), 0 === this.data.ty || this.data.xt ? this.compInterface = CompExpressionInterface(this) : 4 === this.data.ty ? (this.layerInterface.shapeInterface = ShapeExpressionInterface(this.shapesData, this.itemsData, this.layerInterface), this.layerInterface.content = this.layerInterface.shapeInterface) : 5 === this.data.ty && (this.layerInterface.textInterface = TextExpressionInterface(this), this.layerInterface.text = this.layerInterface.textInterface)
                    },
                    setBlendMode: function() {
                        var t = getBlendMode(this.data.bm);
                        (this.baseElement || this.layerElement).style["mix-blend-mode"] = t
                    },
                    initBaseData: function(data, t, e) {
                        this.globalData = t, this.comp = e, this.data = data, this.layerId = createElementID(), this.data.sr || (this.data.sr = 1), this.effectsManager = new EffectsManager(this.data, this, this.dynamicProperties)
                    },
                    getType: function() {
                        return this.type
                    },
                    sourceRectAtTime: function() {}
                }, NullElement.prototype.prepareFrame = function(t) {
                    this.prepareProperties(t, !0)
                }, NullElement.prototype.renderFrame = function() {}, NullElement.prototype.getBaseElement = function() {
                    return null
                }, NullElement.prototype.destroy = function() {}, NullElement.prototype.sourceRectAtTime = function() {}, NullElement.prototype.hide = function() {}, extendPrototype([BaseElement, TransformElement, HierarchyElement, FrameElement], NullElement), SVGBaseElement.prototype = {
                    initRendererElement: function() {
                        this.layerElement = createNS("g")
                    },
                    createContainerElements: function() {
                        this.matteElement = createNS("g"), this.transformedElement = this.layerElement, this.maskedElement = this.layerElement, this._sizeChanged = !1;
                        var t, e, r, n = null;
                        if (this.data.td) {
                            if (3 == this.data.td || 1 == this.data.td) {
                                var o = createNS("mask");
                                o.setAttribute("id", this.layerId), o.setAttribute("mask-type", 3 == this.data.td ? "luminance" : "alpha"), o.appendChild(this.layerElement), n = o, this.globalData.defs.appendChild(o), featureSupport.maskType || 1 != this.data.td || (o.setAttribute("mask-type", "luminance"), t = createElementID(), e = filtersFactory.createFilter(t), this.globalData.defs.appendChild(e), e.appendChild(filtersFactory.createAlphaToLuminanceFilter()), (r = createNS("g")).appendChild(this.layerElement), n = r, o.appendChild(r), r.setAttribute("filter", "url(" + locationHref + "#" + t + ")"))
                            } else if (2 == this.data.td) {
                                var h = createNS("mask");
                                h.setAttribute("id", this.layerId), h.setAttribute("mask-type", "alpha");
                                var l = createNS("g");
                                h.appendChild(l), t = createElementID(), e = filtersFactory.createFilter(t);
                                var m = createNS("feComponentTransfer");
                                m.setAttribute("in", "SourceGraphic"), e.appendChild(m);
                                var f = createNS("feFuncA");
                                f.setAttribute("type", "table"), f.setAttribute("tableValues", "1.0 0.0"), m.appendChild(f), this.globalData.defs.appendChild(e);
                                var c = createNS("rect");
                                c.setAttribute("width", this.comp.data.w), c.setAttribute("height", this.comp.data.h), c.setAttribute("x", "0"), c.setAttribute("y", "0"), c.setAttribute("fill", "#ffffff"), c.setAttribute("opacity", "0"), l.setAttribute("filter", "url(" + locationHref + "#" + t + ")"), l.appendChild(c), l.appendChild(this.layerElement), n = l, featureSupport.maskType || (h.setAttribute("mask-type", "luminance"), e.appendChild(filtersFactory.createAlphaToLuminanceFilter()), r = createNS("g"), l.appendChild(c), r.appendChild(this.layerElement), n = r, l.appendChild(r)), this.globalData.defs.appendChild(h)
                            }
                        } else this.data.tt ? (this.matteElement.appendChild(this.layerElement), n = this.matteElement, this.baseElement = this.matteElement) : this.baseElement = this.layerElement;
                        if (this.data.ln && this.layerElement.setAttribute("id", this.data.ln), this.data.cl && this.layerElement.setAttribute("class", this.data.cl), 0 === this.data.ty && !this.data.hd) {
                            var d = createNS("clipPath"),
                                y = createNS("path");
                            y.setAttribute("d", "M0,0 L" + this.data.w + ",0 L" + this.data.w + "," + this.data.h + " L0," + this.data.h + "z");
                            var v = createElementID();
                            if (d.setAttribute("id", v), d.appendChild(y), this.globalData.defs.appendChild(d), this.checkMasks()) {
                                var P = createNS("g");
                                P.setAttribute("clip-path", "url(" + locationHref + "#" + v + ")"), P.appendChild(this.layerElement), this.transformedElement = P, n ? n.appendChild(this.transformedElement) : this.baseElement = this.transformedElement
                            } else this.layerElement.setAttribute("clip-path", "url(" + locationHref + "#" + v + ")")
                        }
                        0 !== this.data.bm && this.setBlendMode()
                    },
                    renderElement: function() {
                        this.finalTransform._matMdf && this.transformedElement.setAttribute("transform", this.finalTransform.mat.to2dCSS()), this.finalTransform._opMdf && this.transformedElement.setAttribute("opacity", this.finalTransform.mProp.o.v)
                    },
                    destroyBaseElement: function() {
                        this.layerElement = null, this.matteElement = null, this.maskManager.destroy()
                    },
                    getBaseElement: function() {
                        return this.data.hd ? null : this.baseElement
                    },
                    createRenderableComponents: function() {
                        this.maskManager = new MaskElement(this.data, this, this.globalData), this.renderableEffectsManager = new SVGEffects(this)
                    },
                    setMatte: function(t) {
                        this.matteElement && this.matteElement.setAttribute("mask", "url(" + locationHref + "#" + t + ")")
                    }
                }, IShapeElement.prototype = {
                    addShapeToModifiers: function(data) {
                        var i, t = this.shapeModifiers.length;
                        for (i = 0; i < t; i += 1) this.shapeModifiers[i].addShape(data)
                    },
                    isShapeInAnimatedModifiers: function(data) {
                        for (var t = this.shapeModifiers.length; 0 < t;)
                            if (this.shapeModifiers[0].isAnimatedWithShape(data)) return !0;
                        return !1
                    },
                    renderModifiers: function() {
                        if (this.shapeModifiers.length) {
                            var i, t = this.shapes.length;
                            for (i = 0; i < t; i += 1) this.shapes[i].sh.reset();
                            for (i = (t = this.shapeModifiers.length) - 1; i >= 0 && !this.shapeModifiers[i].processShapes(this._isFirstFrame); i -= 1);
                        }
                    },
                    searchProcessedElement: function(t) {
                        for (var e = this.processedElements, i = 0, r = e.length; i < r;) {
                            if (e[i].elem === t) return e[i].pos;
                            i += 1
                        }
                        return 0
                    },
                    addProcessedElement: function(t, e) {
                        for (var r = this.processedElements, i = r.length; i;)
                            if (r[i -= 1].elem === t) return void(r[i].pos = e);
                        r.push(new ProcessedElement(t, e))
                    },
                    prepareFrame: function(t) {
                        this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange)
                    }
                }, ITextElement.prototype.initElement = function(data, t, e) {
                    this.lettersChangedFlag = !0, this.initFrame(), this.initBaseData(data, t, e), this.textProperty = new TextProperty(this, data.t, this.dynamicProperties), this.textAnimator = new TextAnimatorProperty(data.t, this.renderType, this), this.initTransform(data, t, e), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide(), this.textAnimator.searchProperties(this.dynamicProperties)
                }, ITextElement.prototype.prepareFrame = function(t) {
                    this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), (this.textProperty._mdf || this.textProperty._isFirstFrame) && (this.buildNewText(), this.textProperty._isFirstFrame = !1, this.textProperty._mdf = !1)
                }, ITextElement.prototype.createPathShape = function(t, e) {
                    var r, n, o = e.length,
                        h = "";
                    for (r = 0; r < o; r += 1) n = e[r].ks.k, h += buildShapeString(n, n.i.length, !0, t);
                    return h
                }, ITextElement.prototype.updateDocumentData = function(t, e) {
                    this.textProperty.updateDocumentData(t, e)
                }, ITextElement.prototype.canResizeFont = function(t) {
                    this.textProperty.canResizeFont(t)
                }, ITextElement.prototype.setMinimumFontSize = function(t) {
                    this.textProperty.setMinimumFontSize(t)
                }, ITextElement.prototype.applyTextPropertiesToMatrix = function(t, e, r, n, o) {
                    switch (t.ps && e.translate(t.ps[0], t.ps[1] + t.ascent, 0), e.translate(0, -t.ls, 0), t.j) {
                        case 1:
                            e.translate(t.justifyOffset + (t.boxWidth - t.lineWidths[r]), 0, 0);
                            break;
                        case 2:
                            e.translate(t.justifyOffset + (t.boxWidth - t.lineWidths[r]) / 2, 0, 0)
                    }
                    e.translate(n, o, 0)
                }, ITextElement.prototype.buildColor = function(t) {
                    return "rgb(" + Math.round(255 * t[0]) + "," + Math.round(255 * t[1]) + "," + Math.round(255 * t[2]) + ")"
                }, ITextElement.prototype.emptyProp = new LetterProps, ITextElement.prototype.destroy = function() {}, extendPrototype([BaseElement, TransformElement, HierarchyElement, FrameElement, RenderableDOMElement], ICompElement), ICompElement.prototype.initElement = function(data, t, e) {
                    this.initFrame(), this.initBaseData(data, t, e), this.initTransform(data, t, e), this.initRenderable(), this.initHierarchy(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), !this.data.xt && t.progressiveLoad || this.buildAllItems(), this.hide()
                }, ICompElement.prototype.prepareFrame = function(t) {
                    if (this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), this.isInRange || this.data.xt) {
                        if (this.tm._placeholder) this.renderedFrame = t / this.data.sr;
                        else {
                            var e = this.tm.v;
                            e === this.data.op && (e = this.data.op - 1), this.renderedFrame = e
                        }
                        var i, r = this.elements.length;
                        for (this.completeLayers || this.checkLayers(this.renderedFrame), i = r - 1; i >= 0; i -= 1)(this.completeLayers || this.elements[i]) && (this.elements[i].prepareFrame(this.renderedFrame - this.layers[i].st), this.elements[i]._mdf && (this._mdf = !0))
                    }
                }, ICompElement.prototype.renderInnerContent = function() {
                    var i, t = this.layers.length;
                    for (i = 0; i < t; i += 1)(this.completeLayers || this.elements[i]) && this.elements[i].renderFrame()
                }, ICompElement.prototype.setElements = function(t) {
                    this.elements = t
                }, ICompElement.prototype.getElements = function() {
                    return this.elements
                }, ICompElement.prototype.destroyElements = function() {
                    var i, t = this.layers.length;
                    for (i = 0; i < t; i += 1) this.elements[i] && this.elements[i].destroy()
                }, ICompElement.prototype.destroy = function() {
                    this.destroyElements(), this.destroyBaseElement()
                }, extendPrototype([BaseElement, TransformElement, SVGBaseElement, HierarchyElement, FrameElement, RenderableDOMElement], IImageElement), IImageElement.prototype.createContent = function() {
                    var t = this.globalData.getAssetsPath(this.assetData);
                    this.innerElem = createNS("image"), this.innerElem.setAttribute("width", this.assetData.w + "px"), this.innerElem.setAttribute("height", this.assetData.h + "px"), this.innerElem.setAttribute("preserveAspectRatio", this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio), this.innerElem.setAttributeNS("http://www.w3.org/1999/xlink", "href", t), this.layerElement.appendChild(this.innerElem)
                }, IImageElement.prototype.sourceRectAtTime = function() {
                    return this.sourceRect
                }, extendPrototype([IImageElement], ISolidElement), ISolidElement.prototype.createContent = function() {
                    var rect = createNS("rect");
                    rect.setAttribute("width", this.data.sw), rect.setAttribute("height", this.data.sh), rect.setAttribute("fill", this.data.sc), this.layerElement.appendChild(rect)
                }, AudioElement.prototype.prepareFrame = function(t) {
                    if (this.prepareRenderableFrame(t, !0), this.prepareProperties(t, !0), this.tm._placeholder) this._currentTime = t / this.data.sr;
                    else {
                        var e = this.tm.v;
                        this._currentTime = e
                    }
                }, extendPrototype([RenderableElement, BaseElement, FrameElement], AudioElement), AudioElement.prototype.renderFrame = function() {
                    this.isInRange && this._canPlay && (this._isPlaying ? (!this.audio.playing() || Math.abs(this._currentTime / this.globalData.frameRate - this.audio.seek()) > .1) && this.audio.seek(this._currentTime / this.globalData.frameRate) : (this.audio.play(), this.audio.seek(this._currentTime / this.globalData.frameRate), this._isPlaying = !0))
                }, AudioElement.prototype.show = function() {}, AudioElement.prototype.hide = function() {
                    this.audio.pause(), this._isPlaying = !1
                }, AudioElement.prototype.pause = function() {
                    this.audio.pause(), this._isPlaying = !1, this._canPlay = !1
                }, AudioElement.prototype.resume = function() {
                    this._canPlay = !0
                }, AudioElement.prototype.setRate = function(t) {
                    this.audio.rate(t)
                }, AudioElement.prototype.volume = function(t) {
                    this.audio.volume(t)
                }, AudioElement.prototype.getBaseElement = function() {
                    return null
                }, AudioElement.prototype.destroy = function() {}, AudioElement.prototype.sourceRectAtTime = function() {}, AudioElement.prototype.initExpressions = function() {}, FootageElement.prototype.prepareFrame = function() {}, extendPrototype([RenderableElement, BaseElement, FrameElement], FootageElement), FootageElement.prototype.getBaseElement = function() {
                    return null
                }, FootageElement.prototype.renderFrame = function() {}, FootageElement.prototype.destroy = function() {}, FootageElement.prototype.initExpressions = function() {
                    this.layerInterface = FootageInterface(this)
                }, FootageElement.prototype.getFootageData = function() {
                    return this.footageData
                }, extendPrototype([SVGRenderer, ICompElement, SVGBaseElement], SVGCompElement), extendPrototype([BaseElement, TransformElement, SVGBaseElement, HierarchyElement, FrameElement, RenderableDOMElement, ITextElement], SVGTextLottieElement), SVGTextLottieElement.prototype.createContent = function() {
                    this.data.singleShape && !this.globalData.fontManager.chars && (this.textContainer = createNS("text"))
                }, SVGTextLottieElement.prototype.buildTextContents = function(t) {
                    for (var i = 0, e = t.length, r = [], n = ""; i < e;) t[i] === String.fromCharCode(13) || t[i] === String.fromCharCode(3) ? (r.push(n), n = "") : n += t[i], i += 1;
                    return r.push(n), r
                }, SVGTextLottieElement.prototype.buildNewText = function() {
                    var i, t, e = this.textProperty.currentData;
                    this.renderedLetters = createSizedArray(e ? e.l.length : 0), e.fc ? this.layerElement.setAttribute("fill", this.buildColor(e.fc)) : this.layerElement.setAttribute("fill", "rgba(0,0,0,0)"), e.sc && (this.layerElement.setAttribute("stroke", this.buildColor(e.sc)), this.layerElement.setAttribute("stroke-width", e.sw)), this.layerElement.setAttribute("font-size", e.finalSize);
                    var r = this.globalData.fontManager.getFontByName(e.f);
                    if (r.fClass) this.layerElement.setAttribute("class", r.fClass);
                    else {
                        this.layerElement.setAttribute("font-family", r.fFamily);
                        var n = e.fWeight,
                            o = e.fStyle;
                        this.layerElement.setAttribute("font-style", o), this.layerElement.setAttribute("font-weight", n)
                    }
                    this.layerElement.setAttribute("aria-label", e.t);
                    var h, l = e.l || [],
                        m = !!this.globalData.fontManager.chars;
                    t = l.length;
                    var f, c = this.mHelper,
                        d = "",
                        y = this.data.singleShape,
                        v = 0,
                        P = 0,
                        E = !0,
                        x = .001 * e.tr * e.finalSize;
                    if (!y || m || e.sz) {
                        var S, A, C = this.textSpans.length;
                        for (i = 0; i < t; i += 1) m && y && 0 !== i || (h = C > i ? this.textSpans[i] : createNS(m ? "path" : "text"), C <= i && (h.setAttribute("stroke-linecap", "butt"), h.setAttribute("stroke-linejoin", "round"), h.setAttribute("stroke-miterlimit", "4"), this.textSpans[i] = h, this.layerElement.appendChild(h)), h.style.display = "inherit"), c.reset(), c.scale(e.finalSize / 100, e.finalSize / 100), y && (l[i].n && (v = -x, P += e.yOffset, P += E ? 1 : 0, E = !1), this.applyTextPropertiesToMatrix(e, c, l[i].line, v, P), v += l[i].l || 0, v += x), m ? (f = (S = (A = this.globalData.fontManager.getCharData(e.finalText[i], r.fStyle, this.globalData.fontManager.getFontByName(e.f).fFamily)) && A.data || {}).shapes ? S.shapes[0].it : [], y ? d += this.createPathShape(c, f) : h.setAttribute("d", this.createPathShape(c, f))) : (y && h.setAttribute("transform", "translate(" + c.props[12] + "," + c.props[13] + ")"), h.textContent = l[i].val, h.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"));
                        y && h && h.setAttribute("d", d)
                    } else {
                        var _ = this.textContainer,
                            T = "start";
                        switch (e.j) {
                            case 1:
                                T = "end";
                                break;
                            case 2:
                                T = "middle";
                                break;
                            default:
                                T = "start"
                        }
                        _.setAttribute("text-anchor", T), _.setAttribute("letter-spacing", x);
                        var k = this.buildTextContents(e.finalText);
                        for (t = k.length, P = e.ps ? e.ps[1] + e.ascent : 0, i = 0; i < t; i += 1)(h = this.textSpans[i] || createNS("tspan")).textContent = k[i], h.setAttribute("x", 0), h.setAttribute("y", P), h.style.display = "inherit", _.appendChild(h), this.textSpans[i] = h, P += e.finalLineHeight;
                        this.layerElement.appendChild(_)
                    }
                    for (; i < this.textSpans.length;) this.textSpans[i].style.display = "none", i += 1;
                    this._sizeChanged = !0
                }, SVGTextLottieElement.prototype.sourceRectAtTime = function() {
                    if (this.prepareFrame(this.comp.renderedFrame - this.data.st), this.renderInnerContent(), this._sizeChanged) {
                        this._sizeChanged = !1;
                        var t = this.layerElement.getBBox();
                        this.bbox = {
                            top: t.y,
                            left: t.x,
                            width: t.width,
                            height: t.height
                        }
                    }
                    return this.bbox
                }, SVGTextLottieElement.prototype.renderInnerContent = function() {
                    if (!this.data.singleShape && (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), this.lettersChangedFlag || this.textAnimator.lettersChangedFlag)) {
                        var i, t;
                        this._sizeChanged = !0;
                        var e, r, n = this.textAnimator.renderedLetters,
                            o = this.textProperty.currentData.l;
                        for (t = o.length, i = 0; i < t; i += 1) o[i].n || (e = n[i], r = this.textSpans[i], e._mdf.m && r.setAttribute("transform", e.m), e._mdf.o && r.setAttribute("opacity", e.o), e._mdf.sw && r.setAttribute("stroke-width", e.sw), e._mdf.sc && r.setAttribute("stroke", e.sc), e._mdf.fc && r.setAttribute("fill", e.fc))
                    }
                }, extendPrototype([BaseElement, TransformElement, SVGBaseElement, IShapeElement, HierarchyElement, FrameElement, RenderableDOMElement], SVGShapeElement), SVGShapeElement.prototype.initSecondaryElement = function() {}, SVGShapeElement.prototype.identityMatrix = new Matrix, SVGShapeElement.prototype.buildExpressionInterface = function() {}, SVGShapeElement.prototype.createContent = function() {
                    this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], !0), this.filterUniqueShapes()
                }, SVGShapeElement.prototype.filterUniqueShapes = function() {
                    var i, t, e, style, r = this.shapes.length,
                        n = this.stylesList.length,
                        o = [],
                        h = !1;
                    for (e = 0; e < n; e += 1) {
                        for (style = this.stylesList[e], h = !1, o.length = 0, i = 0; i < r; i += 1) - 1 !== (t = this.shapes[i]).styles.indexOf(style) && (o.push(t), h = t._isAnimated || h);
                        o.length > 1 && h && this.setShapesAsAnimated(o)
                    }
                }, SVGShapeElement.prototype.setShapesAsAnimated = function(t) {
                    var i, e = t.length;
                    for (i = 0; i < e; i += 1) t[i].setAsAnimated()
                }, SVGShapeElement.prototype.createStyleElement = function(data, t) {
                    var e, r = new SVGStyleData(data, t),
                        n = r.pElem;
                    return "st" === data.ty ? e = new SVGStrokeStyleData(this, data, r) : "fl" === data.ty ? e = new SVGFillStyleData(this, data, r) : "gf" !== data.ty && "gs" !== data.ty || (e = new("gf" === data.ty ? SVGGradientFillStyleData : SVGGradientStrokeStyleData)(this, data, r), this.globalData.defs.appendChild(e.gf), e.maskId && (this.globalData.defs.appendChild(e.ms), this.globalData.defs.appendChild(e.of), n.setAttribute("mask", "url(" + locationHref + "#" + e.maskId + ")"))), "st" !== data.ty && "gs" !== data.ty || (n.setAttribute("stroke-linecap", lineCapEnum[data.lc || 2]), n.setAttribute("stroke-linejoin", lineJoinEnum[data.lj || 2]), n.setAttribute("fill-opacity", "0"), 1 === data.lj && n.setAttribute("stroke-miterlimit", data.ml)), 2 === data.r && n.setAttribute("fill-rule", "evenodd"), data.ln && n.setAttribute("id", data.ln), data.cl && n.setAttribute("class", data.cl), data.bm && (n.style["mix-blend-mode"] = getBlendMode(data.bm)), this.stylesList.push(r), this.addToAnimatedContents(data, e), e
                }, SVGShapeElement.prototype.createGroupElement = function(data) {
                    var t = new ShapeGroupData;
                    return data.ln && t.gr.setAttribute("id", data.ln), data.cl && t.gr.setAttribute("class", data.cl), data.bm && (t.gr.style["mix-blend-mode"] = getBlendMode(data.bm)), t
                }, SVGShapeElement.prototype.createTransformElement = function(data, t) {
                    var e = TransformPropertyFactory.getTransformProperty(this, data, this),
                        r = new SVGTransformData(e, e.o, t);
                    return this.addToAnimatedContents(data, r), r
                }, SVGShapeElement.prototype.createShapeElement = function(data, t, e) {
                    var r = 4;
                    "rc" === data.ty ? r = 5 : "el" === data.ty ? r = 6 : "sr" === data.ty && (r = 7);
                    var n = new SVGShapeData(t, e, ShapePropertyFactory.getShapeProp(this, data, r, this));
                    return this.shapes.push(n), this.addShapeToModifiers(n), this.addToAnimatedContents(data, n), n
                }, SVGShapeElement.prototype.addToAnimatedContents = function(data, element) {
                    for (var i = 0, t = this.animatedContents.length; i < t;) {
                        if (this.animatedContents[i].element === element) return;
                        i += 1
                    }
                    this.animatedContents.push({
                        fn: SVGElementsRenderer.createRenderFunction(data),
                        element: element,
                        data: data
                    })
                }, SVGShapeElement.prototype.setElementStyles = function(t) {
                    var e, r = t.styles,
                        n = this.stylesList.length;
                    for (e = 0; e < n; e += 1) this.stylesList[e].closed || r.push(this.stylesList[e])
                }, SVGShapeElement.prototype.reloadShapes = function() {
                    var i;
                    this._isFirstFrame = !0;
                    var t = this.itemsData.length;
                    for (i = 0; i < t; i += 1) this.prevViewData[i] = this.itemsData[i];
                    for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], !0), this.filterUniqueShapes(), t = this.dynamicProperties.length, i = 0; i < t; i += 1) this.dynamicProperties[i].getValue();
                    this.renderModifiers()
                }, SVGShapeElement.prototype.searchShapes = function(t, e, r, n, o, h, l) {
                    var i, m, f, c, d, y, v = [].concat(h),
                        P = t.length - 1,
                        E = [],
                        x = [];
                    for (i = P; i >= 0; i -= 1) {
                        if ((y = this.searchProcessedElement(t[i])) ? e[i] = r[y - 1] : t[i]._render = l, "fl" === t[i].ty || "st" === t[i].ty || "gf" === t[i].ty || "gs" === t[i].ty) y ? e[i].style.closed = !1 : e[i] = this.createStyleElement(t[i], o), t[i]._render && e[i].style.pElem.parentNode !== n && n.appendChild(e[i].style.pElem), E.push(e[i].style);
                        else if ("gr" === t[i].ty) {
                            if (y)
                                for (f = e[i].it.length, m = 0; m < f; m += 1) e[i].prevViewData[m] = e[i].it[m];
                            else e[i] = this.createGroupElement(t[i]);
                            this.searchShapes(t[i].it, e[i].it, e[i].prevViewData, e[i].gr, o + 1, v, l), t[i]._render && e[i].gr.parentNode !== n && n.appendChild(e[i].gr)
                        } else "tr" === t[i].ty ? (y || (e[i] = this.createTransformElement(t[i], n)), c = e[i].transform, v.push(c)) : "sh" === t[i].ty || "rc" === t[i].ty || "el" === t[i].ty || "sr" === t[i].ty ? (y || (e[i] = this.createShapeElement(t[i], v, o)), this.setElementStyles(e[i])) : "tm" === t[i].ty || "rd" === t[i].ty || "ms" === t[i].ty || "pb" === t[i].ty ? (y ? (d = e[i]).closed = !1 : ((d = ShapeModifiers.getModifier(t[i].ty)).init(this, t[i]), e[i] = d, this.shapeModifiers.push(d)), x.push(d)) : "rp" === t[i].ty && (y ? (d = e[i]).closed = !0 : (d = ShapeModifiers.getModifier(t[i].ty), e[i] = d, d.init(this, t, i, e), this.shapeModifiers.push(d), l = !1), x.push(d));
                        this.addProcessedElement(t[i], i + 1)
                    }
                    for (P = E.length, i = 0; i < P; i += 1) E[i].closed = !0;
                    for (P = x.length, i = 0; i < P; i += 1) x[i].closed = !0
                }, SVGShapeElement.prototype.renderInnerContent = function() {
                    var i;
                    this.renderModifiers();
                    var t = this.stylesList.length;
                    for (i = 0; i < t; i += 1) this.stylesList[i].reset();
                    for (this.renderShape(), i = 0; i < t; i += 1)(this.stylesList[i]._mdf || this._isFirstFrame) && (this.stylesList[i].msElem && (this.stylesList[i].msElem.setAttribute("d", this.stylesList[i].d), this.stylesList[i].d = "M0 0" + this.stylesList[i].d), this.stylesList[i].pElem.setAttribute("d", this.stylesList[i].d || "M0 0"))
                }, SVGShapeElement.prototype.renderShape = function() {
                    var i, t, e = this.animatedContents.length;
                    for (i = 0; i < e; i += 1) t = this.animatedContents[i], (this._isFirstFrame || t.element._isAnimated) && !0 !== t.data && t.fn(t.data, t.element, this._isFirstFrame)
                }, SVGShapeElement.prototype.destroy = function() {
                    this.destroyBaseElement(), this.shapesData = null, this.itemsData = null
                }, SVGTintFilter.prototype.renderFrame = function(t) {
                    if (t || this.filterManager._mdf) {
                        var e = this.filterManager.effectElements[0].p.v,
                            r = this.filterManager.effectElements[1].p.v,
                            n = this.filterManager.effectElements[2].p.v / 100;
                        this.matrixFilter.setAttribute("values", r[0] - e[0] + " 0 0 0 " + e[0] + " " + (r[1] - e[1]) + " 0 0 0 " + e[1] + " " + (r[2] - e[2]) + " 0 0 0 " + e[2] + " 0 0 0 " + n + " 0")
                    }
                }, SVGFillFilter.prototype.renderFrame = function(t) {
                    if (t || this.filterManager._mdf) {
                        var e = this.filterManager.effectElements[2].p.v,
                            r = this.filterManager.effectElements[6].p.v;
                        this.matrixFilter.setAttribute("values", "0 0 0 0 " + e[0] + " 0 0 0 0 " + e[1] + " 0 0 0 0 " + e[2] + " 0 0 0 " + r + " 0")
                    }
                }, SVGGaussianBlurEffect.prototype.renderFrame = function(t) {
                    if (t || this.filterManager._mdf) {
                        var e = .3 * this.filterManager.effectElements[0].p.v,
                            r = this.filterManager.effectElements[1].p.v,
                            n = 3 == r ? 0 : e,
                            o = 2 == r ? 0 : e;
                        this.feGaussianBlur.setAttribute("stdDeviation", n + " " + o);
                        var h = 1 == this.filterManager.effectElements[2].p.v ? "wrap" : "duplicate";
                        this.feGaussianBlur.setAttribute("edgeMode", h)
                    }
                }, SVGStrokeEffect.prototype.initialize = function() {
                    var path, t, i, e, r = this.elem.layerElement.children || this.elem.layerElement.childNodes;
                    for (1 === this.filterManager.effectElements[1].p.v ? (e = this.elem.maskManager.masksProperties.length, i = 0) : e = 1 + (i = this.filterManager.effectElements[0].p.v - 1), (t = createNS("g")).setAttribute("fill", "none"), t.setAttribute("stroke-linecap", "round"), t.setAttribute("stroke-dashoffset", 1); i < e; i += 1) path = createNS("path"), t.appendChild(path), this.paths.push({
                        p: path,
                        m: i
                    });
                    if (3 === this.filterManager.effectElements[10].p.v) {
                        var mask = createNS("mask"),
                            n = createElementID();
                        mask.setAttribute("id", n), mask.setAttribute("mask-type", "alpha"), mask.appendChild(t), this.elem.globalData.defs.appendChild(mask);
                        var g = createNS("g");
                        for (g.setAttribute("mask", "url(" + locationHref + "#" + n + ")"); r[0];) g.appendChild(r[0]);
                        this.elem.layerElement.appendChild(g), this.masker = mask, t.setAttribute("stroke", "#fff")
                    } else if (1 === this.filterManager.effectElements[10].p.v || 2 === this.filterManager.effectElements[10].p.v) {
                        if (2 === this.filterManager.effectElements[10].p.v)
                            for (r = this.elem.layerElement.children || this.elem.layerElement.childNodes; r.length;) this.elem.layerElement.removeChild(r[0]);
                        this.elem.layerElement.appendChild(t), this.elem.layerElement.removeAttribute("mask"), t.setAttribute("stroke", "#fff")
                    }
                    this.initialized = !0, this.pathMasker = t
                }, SVGStrokeEffect.prototype.renderFrame = function(t) {
                    var i;
                    this.initialized || this.initialize();
                    var mask, path, e = this.paths.length;
                    for (i = 0; i < e; i += 1)
                        if (-1 !== this.paths[i].m && (mask = this.elem.maskManager.viewData[this.paths[i].m], path = this.paths[i].p, (t || this.filterManager._mdf || mask.prop._mdf) && path.setAttribute("d", mask.lastPath), t || this.filterManager.effectElements[9].p._mdf || this.filterManager.effectElements[4].p._mdf || this.filterManager.effectElements[7].p._mdf || this.filterManager.effectElements[8].p._mdf || mask.prop._mdf)) {
                            var r;
                            if (0 !== this.filterManager.effectElements[7].p.v || 100 !== this.filterManager.effectElements[8].p.v) {
                                var s = .01 * Math.min(this.filterManager.effectElements[7].p.v, this.filterManager.effectElements[8].p.v),
                                    n = .01 * Math.max(this.filterManager.effectElements[7].p.v, this.filterManager.effectElements[8].p.v),
                                    o = path.getTotalLength();
                                r = "0 0 0 " + o * s + " ";
                                var h, l = o * (n - s),
                                    m = 1 + 2 * this.filterManager.effectElements[4].p.v * this.filterManager.effectElements[9].p.v * .01,
                                    f = Math.floor(l / m);
                                for (h = 0; h < f; h += 1) r += "1 " + 2 * this.filterManager.effectElements[4].p.v * this.filterManager.effectElements[9].p.v * .01 + " ";
                                r += "0 " + 10 * o + " 0 0"
                            } else r = "1 " + 2 * this.filterManager.effectElements[4].p.v * this.filterManager.effectElements[9].p.v * .01;
                            path.setAttribute("stroke-dasharray", r)
                        }
                    if ((t || this.filterManager.effectElements[4].p._mdf) && this.pathMasker.setAttribute("stroke-width", 2 * this.filterManager.effectElements[4].p.v), (t || this.filterManager.effectElements[6].p._mdf) && this.pathMasker.setAttribute("opacity", this.filterManager.effectElements[6].p.v), (1 === this.filterManager.effectElements[10].p.v || 2 === this.filterManager.effectElements[10].p.v) && (t || this.filterManager.effectElements[3].p._mdf)) {
                        var c = this.filterManager.effectElements[3].p.v;
                        this.pathMasker.setAttribute("stroke", "rgb(" + bmFloor(255 * c[0]) + "," + bmFloor(255 * c[1]) + "," + bmFloor(255 * c[2]) + ")")
                    }
                }, SVGTritoneFilter.prototype.renderFrame = function(t) {
                    if (t || this.filterManager._mdf) {
                        var e = this.filterManager.effectElements[0].p.v,
                            r = this.filterManager.effectElements[1].p.v,
                            n = this.filterManager.effectElements[2].p.v,
                            o = n[0] + " " + r[0] + " " + e[0],
                            h = n[1] + " " + r[1] + " " + e[1],
                            l = n[2] + " " + r[2] + " " + e[2];
                        this.feFuncR.setAttribute("tableValues", o), this.feFuncG.setAttribute("tableValues", h), this.feFuncB.setAttribute("tableValues", l)
                    }
                }, SVGProLevelsFilter.prototype.createFeFunc = function(t, e) {
                    var r = createNS(t);
                    return r.setAttribute("type", "table"), e.appendChild(r), r
                }, SVGProLevelsFilter.prototype.getTableValue = function(t, e, r, n, o) {
                    for (var h, l, m = 0, f = Math.min(t, e), c = Math.max(t, e), table = Array.call(null, {
                            length: 256
                        }), d = 0, y = o - n, v = e - t; m <= 256;) l = (h = m / 256) <= f ? v < 0 ? o : n : h >= c ? v < 0 ? n : o : n + y * Math.pow((h - t) / v, 1 / r), table[d] = l, d += 1, m += 256 / 255;
                    return table.join(" ")
                }, SVGProLevelsFilter.prototype.renderFrame = function(t) {
                    if (t || this.filterManager._mdf) {
                        var e, r = this.filterManager.effectElements;
                        this.feFuncRComposed && (t || r[3].p._mdf || r[4].p._mdf || r[5].p._mdf || r[6].p._mdf || r[7].p._mdf) && (e = this.getTableValue(r[3].p.v, r[4].p.v, r[5].p.v, r[6].p.v, r[7].p.v), this.feFuncRComposed.setAttribute("tableValues", e), this.feFuncGComposed.setAttribute("tableValues", e), this.feFuncBComposed.setAttribute("tableValues", e)), this.feFuncR && (t || r[10].p._mdf || r[11].p._mdf || r[12].p._mdf || r[13].p._mdf || r[14].p._mdf) && (e = this.getTableValue(r[10].p.v, r[11].p.v, r[12].p.v, r[13].p.v, r[14].p.v), this.feFuncR.setAttribute("tableValues", e)), this.feFuncG && (t || r[17].p._mdf || r[18].p._mdf || r[19].p._mdf || r[20].p._mdf || r[21].p._mdf) && (e = this.getTableValue(r[17].p.v, r[18].p.v, r[19].p.v, r[20].p.v, r[21].p.v), this.feFuncG.setAttribute("tableValues", e)), this.feFuncB && (t || r[24].p._mdf || r[25].p._mdf || r[26].p._mdf || r[27].p._mdf || r[28].p._mdf) && (e = this.getTableValue(r[24].p.v, r[25].p.v, r[26].p.v, r[27].p.v, r[28].p.v), this.feFuncB.setAttribute("tableValues", e)), this.feFuncA && (t || r[31].p._mdf || r[32].p._mdf || r[33].p._mdf || r[34].p._mdf || r[35].p._mdf) && (e = this.getTableValue(r[31].p.v, r[32].p.v, r[33].p.v, r[34].p.v, r[35].p.v), this.feFuncA.setAttribute("tableValues", e))
                    }
                }, SVGDropShadowEffect.prototype.renderFrame = function(t) {
                    if (t || this.filterManager._mdf) {
                        if ((t || this.filterManager.effectElements[4].p._mdf) && this.feGaussianBlur.setAttribute("stdDeviation", this.filterManager.effectElements[4].p.v / 4), t || this.filterManager.effectElements[0].p._mdf) {
                            var col = this.filterManager.effectElements[0].p.v;
                            this.feFlood.setAttribute("flood-color", rgbToHex(Math.round(255 * col[0]), Math.round(255 * col[1]), Math.round(255 * col[2])))
                        }
                        if ((t || this.filterManager.effectElements[1].p._mdf) && this.feFlood.setAttribute("flood-opacity", this.filterManager.effectElements[1].p.v / 255), t || this.filterManager.effectElements[2].p._mdf || this.filterManager.effectElements[3].p._mdf) {
                            var e = this.filterManager.effectElements[3].p.v,
                                r = (this.filterManager.effectElements[2].p.v - 90) * degToRads,
                                n = e * Math.cos(r),
                                o = e * Math.sin(r);
                            this.feOffset.setAttribute("dx", n), this.feOffset.setAttribute("dy", o)
                        }
                    }
                };
                var _svgMatteSymbols = [];

                function SVGMatte3Effect(t, e, r) {
                    this.initialized = !1, this.filterManager = e, this.filterElem = t, this.elem = r, r.matteElement = createNS("g"), r.matteElement.appendChild(r.layerElement), r.matteElement.appendChild(r.transformedElement), r.baseElement = r.matteElement
                }

                function SVGEffects(t) {
                    var i, e, r = t.data.ef ? t.data.ef.length : 0,
                        n = createElementID(),
                        o = filtersFactory.createFilter(n, !0),
                        h = 0;
                    for (this.filters = [], i = 0; i < r; i += 1) e = null, 20 === t.data.ef[i].ty ? (h += 1, e = new SVGTintFilter(o, t.effectsManager.effectElements[i])) : 21 === t.data.ef[i].ty ? (h += 1, e = new SVGFillFilter(o, t.effectsManager.effectElements[i])) : 22 === t.data.ef[i].ty ? e = new SVGStrokeEffect(t, t.effectsManager.effectElements[i]) : 23 === t.data.ef[i].ty ? (h += 1, e = new SVGTritoneFilter(o, t.effectsManager.effectElements[i])) : 24 === t.data.ef[i].ty ? (h += 1, e = new SVGProLevelsFilter(o, t.effectsManager.effectElements[i])) : 25 === t.data.ef[i].ty ? (h += 1, e = new SVGDropShadowEffect(o, t.effectsManager.effectElements[i])) : 28 === t.data.ef[i].ty ? e = new SVGMatte3Effect(o, t.effectsManager.effectElements[i], t) : 29 === t.data.ef[i].ty && (h += 1, e = new SVGGaussianBlurEffect(o, t.effectsManager.effectElements[i])), e && this.filters.push(e);
                    h && (t.globalData.defs.appendChild(o), t.layerElement.setAttribute("filter", "url(" + locationHref + "#" + n + ")")), this.filters.length && t.addRenderableComponent(this)
                }

                function CVContextData() {
                    var i;
                    for (this.saved = [], this.cArrPos = 0, this.cTr = new Matrix, this.cO = 1, this.savedOp = createTypedArray("float32", 15), i = 0; i < 15; i += 1) this.saved[i] = createTypedArray("float32", 16);
                    this._length = 15
                }

                function CVBaseElement() {}

                function CVImageElement(data, t, e) {
                    this.assetData = t.getAssetData(data.refId), this.img = t.imageLoader.getAsset(this.assetData), this.initElement(data, t, e)
                }

                function CVCompElement(data, t, e) {
                    this.completeLayers = !1, this.layers = data.layers, this.pendingElements = [], this.elements = createSizedArray(this.layers.length), this.initElement(data, t, e), this.tm = data.tm ? PropertyFactory.getProp(this, data.tm, 0, t.frameRate, this) : {
                        _placeholder: !0
                    }
                }

                function CVMaskElement(data, element) {
                    var i;
                    this.data = data, this.element = element, this.masksProperties = this.data.masksProperties || [], this.viewData = createSizedArray(this.masksProperties.length);
                    var t = this.masksProperties.length,
                        e = !1;
                    for (i = 0; i < t; i += 1) "n" !== this.masksProperties[i].mode && (e = !0), this.viewData[i] = ShapePropertyFactory.getShapeProp(this.element, this.masksProperties[i], 3);
                    this.hasMasks = e, e && this.element.addRenderableComponent(this)
                }

                function CVShapeElement(data, t, e) {
                    this.shapes = [], this.shapesData = data.shapes, this.stylesList = [], this.itemsData = [], this.prevViewData = [], this.shapeModifiers = [], this.processedElements = [], this.transformsManager = new ShapeTransformManager, this.initElement(data, t, e)
                }

                function CVSolidElement(data, t, e) {
                    this.initElement(data, t, e)
                }

                function CVTextElement(data, t, e) {
                    this.textSpans = [], this.yOffset = 0, this.fillColorAnim = !1, this.strokeColorAnim = !1, this.strokeWidthAnim = !1, this.stroke = !1, this.fill = !1, this.justifyOffset = 0, this.currentRender = null, this.renderType = "canvas", this.values = {
                        fill: "rgba(0,0,0,0)",
                        stroke: "rgba(0,0,0,0)",
                        sWidth: 0,
                        fValue: ""
                    }, this.initElement(data, t, e)
                }

                function CVEffects() {}

                function HBaseElement() {}

                function HSolidElement(data, t, e) {
                    this.initElement(data, t, e)
                }

                function HCompElement(data, t, e) {
                    this.layers = data.layers, this.supports3d = !data.hasMask, this.completeLayers = !1, this.pendingElements = [], this.elements = this.layers ? createSizedArray(this.layers.length) : [], this.initElement(data, t, e), this.tm = data.tm ? PropertyFactory.getProp(this, data.tm, 0, t.frameRate, this) : {
                        _placeholder: !0
                    }
                }

                function HShapeElement(data, t, e) {
                    this.shapes = [], this.shapesData = data.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.shapesContainer = createNS("g"), this.initElement(data, t, e), this.prevViewData = [], this.currentBBox = {
                        x: 999999,
                        y: -999999,
                        h: 0,
                        w: 0
                    }
                }

                function HTextElement(data, t, e) {
                    this.textSpans = [], this.textPaths = [], this.currentBBox = {
                        x: 999999,
                        y: -999999,
                        h: 0,
                        w: 0
                    }, this.renderType = "svg", this.isMasked = !1, this.initElement(data, t, e)
                }

                function HImageElement(data, t, e) {
                    this.assetData = t.getAssetData(data.refId), this.initElement(data, t, e)
                }

                function HCameraElement(data, t, e) {
                    this.initFrame(), this.initBaseData(data, t, e), this.initHierarchy();
                    var r = PropertyFactory.getProp;
                    if (this.pe = r(this, data.pe, 0, 0, this), data.ks.p.s ? (this.px = r(this, data.ks.p.x, 1, 0, this), this.py = r(this, data.ks.p.y, 1, 0, this), this.pz = r(this, data.ks.p.z, 1, 0, this)) : this.p = r(this, data.ks.p, 1, 0, this), data.ks.a && (this.a = r(this, data.ks.a, 1, 0, this)), data.ks.or.k.length && data.ks.or.k[0].to) {
                        var i, n = data.ks.or.k.length;
                        for (i = 0; i < n; i += 1) data.ks.or.k[i].to = null, data.ks.or.k[i].ti = null
                    }
                    this.or = r(this, data.ks.or, 1, degToRads, this), this.or.sh = !0, this.rx = r(this, data.ks.rx, 0, degToRads, this), this.ry = r(this, data.ks.ry, 0, degToRads, this), this.rz = r(this, data.ks.rz, 0, degToRads, this), this.mat = new Matrix, this._prevMat = new Matrix, this._isFirstFrame = !0, this.finalTransform = {
                        mProp: this
                    }
                }

                function HEffects() {}
                SVGMatte3Effect.prototype.findSymbol = function(mask) {
                    for (var i = 0, t = _svgMatteSymbols.length; i < t;) {
                        if (_svgMatteSymbols[i] === mask) return _svgMatteSymbols[i];
                        i += 1
                    }
                    return null
                }, SVGMatte3Effect.prototype.replaceInParent = function(mask, t) {
                    var e = mask.layerElement.parentNode;
                    if (e) {
                        for (var r, n = e.children, i = 0, o = n.length; i < o && n[i] !== mask.layerElement;) i += 1;
                        i <= o - 2 && (r = n[i + 1]);
                        var h = createNS("use");
                        h.setAttribute("href", "#" + t), r ? e.insertBefore(h, r) : e.appendChild(h)
                    }
                }, SVGMatte3Effect.prototype.setElementAsMask = function(t, mask) {
                    if (!this.findSymbol(mask)) {
                        var e = createElementID(),
                            r = createNS("mask");
                        r.setAttribute("id", mask.layerId), r.setAttribute("mask-type", "alpha"), _svgMatteSymbols.push(mask);
                        var defs = t.globalData.defs;
                        defs.appendChild(r);
                        var symbol = createNS("symbol");
                        symbol.setAttribute("id", e), this.replaceInParent(mask, e), symbol.appendChild(mask.layerElement), defs.appendChild(symbol);
                        var n = createNS("use");
                        n.setAttribute("href", "#" + e), r.appendChild(n), mask.data.hd = !1, mask.show()
                    }
                    t.setMatte(mask.layerId)
                }, SVGMatte3Effect.prototype.initialize = function() {
                    for (var t = this.filterManager.effectElements[0].p.v, e = this.elem.comp.elements, i = 0, r = e.length; i < r;) e[i] && e[i].data.ind === t && this.setElementAsMask(this.elem, e[i]), i += 1;
                    this.initialized = !0
                }, SVGMatte3Effect.prototype.renderFrame = function() {
                    this.initialized || this.initialize()
                }, SVGEffects.prototype.renderFrame = function(t) {
                    var i, e = this.filters.length;
                    for (i = 0; i < e; i += 1) this.filters[i].renderFrame(t)
                }, CVContextData.prototype.duplicate = function() {
                    var t = 2 * this._length,
                        e = this.savedOp;
                    this.savedOp = createTypedArray("float32", t), this.savedOp.set(e);
                    var i = 0;
                    for (i = this._length; i < t; i += 1) this.saved[i] = createTypedArray("float32", 16);
                    this._length = t
                }, CVContextData.prototype.reset = function() {
                    this.cArrPos = 0, this.cTr.reset(), this.cO = 1
                }, CVBaseElement.prototype = {
                    createElements: function() {},
                    initRendererElement: function() {},
                    createContainerElements: function() {
                        this.canvasContext = this.globalData.canvasContext, this.renderableEffectsManager = new CVEffects(this)
                    },
                    createContent: function() {},
                    setBlendMode: function() {
                        var t = this.globalData;
                        if (t.blendMode !== this.data.bm) {
                            t.blendMode = this.data.bm;
                            var e = getBlendMode(this.data.bm);
                            t.canvasContext.globalCompositeOperation = e
                        }
                    },
                    createRenderableComponents: function() {
                        this.maskManager = new CVMaskElement(this.data, this)
                    },
                    hideElement: function() {
                        this.hidden || this.isInRange && !this.isTransparent || (this.hidden = !0)
                    },
                    showElement: function() {
                        this.isInRange && !this.isTransparent && (this.hidden = !1, this._isFirstFrame = !0, this.maskManager._isFirstFrame = !0)
                    },
                    renderFrame: function() {
                        if (!this.hidden && !this.data.hd) {
                            this.renderTransform(), this.renderRenderable(), this.setBlendMode();
                            var t = 0 === this.data.ty;
                            this.globalData.renderer.save(t), this.globalData.renderer.ctxTransform(this.finalTransform.mat.props), this.globalData.renderer.ctxOpacity(this.finalTransform.mProp.o.v), this.renderInnerContent(), this.globalData.renderer.restore(t), this.maskManager.hasMasks && this.globalData.renderer.restore(!0), this._isFirstFrame && (this._isFirstFrame = !1)
                        }
                    },
                    destroy: function() {
                        this.canvasContext = null, this.data = null, this.globalData = null, this.maskManager.destroy()
                    },
                    mHelper: new Matrix
                }, CVBaseElement.prototype.hide = CVBaseElement.prototype.hideElement, CVBaseElement.prototype.show = CVBaseElement.prototype.showElement, extendPrototype([BaseElement, TransformElement, CVBaseElement, HierarchyElement, FrameElement, RenderableElement], CVImageElement), CVImageElement.prototype.initElement = SVGShapeElement.prototype.initElement, CVImageElement.prototype.prepareFrame = IImageElement.prototype.prepareFrame, CVImageElement.prototype.createContent = function() {
                    if (this.img.width && (this.assetData.w !== this.img.width || this.assetData.h !== this.img.height)) {
                        var canvas = createTag("canvas");
                        canvas.width = this.assetData.w, canvas.height = this.assetData.h;
                        var t, e, r = canvas.getContext("2d"),
                            n = this.img.width,
                            o = this.img.height,
                            h = n / o,
                            l = this.assetData.w / this.assetData.h,
                            m = this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio;
                        h > l && "xMidYMid slice" === m || h < l && "xMidYMid slice" !== m ? t = (e = o) * l : e = (t = n) / l, r.drawImage(this.img, (n - t) / 2, (o - e) / 2, t, e, 0, 0, this.assetData.w, this.assetData.h), this.img = canvas
                    }
                }, CVImageElement.prototype.renderInnerContent = function() {
                    this.canvasContext.drawImage(this.img, 0, 0)
                }, CVImageElement.prototype.destroy = function() {
                    this.img = null
                }, extendPrototype([CanvasRenderer, ICompElement, CVBaseElement], CVCompElement), CVCompElement.prototype.renderInnerContent = function() {
                    var i, t = this.canvasContext;
                    for (t.beginPath(), t.moveTo(0, 0), t.lineTo(this.data.w, 0), t.lineTo(this.data.w, this.data.h), t.lineTo(0, this.data.h), t.lineTo(0, 0), t.clip(), i = this.layers.length - 1; i >= 0; i -= 1)(this.completeLayers || this.elements[i]) && this.elements[i].renderFrame()
                }, CVCompElement.prototype.destroy = function() {
                    var i;
                    for (i = this.layers.length - 1; i >= 0; i -= 1) this.elements[i] && this.elements[i].destroy();
                    this.layers = null, this.elements = null
                }, CVMaskElement.prototype.renderFrame = function() {
                    if (this.hasMasks) {
                        var i, t, e, data, r = this.element.finalTransform.mat,
                            n = this.element.canvasContext,
                            o = this.masksProperties.length;
                        for (n.beginPath(), i = 0; i < o; i += 1)
                            if ("n" !== this.masksProperties[i].mode) {
                                var h;
                                this.masksProperties[i].inv && (n.moveTo(0, 0), n.lineTo(this.element.globalData.compSize.w, 0), n.lineTo(this.element.globalData.compSize.w, this.element.globalData.compSize.h), n.lineTo(0, this.element.globalData.compSize.h), n.lineTo(0, 0)), data = this.viewData[i].v, t = r.applyToPointArray(data.v[0][0], data.v[0][1], 0), n.moveTo(t[0], t[1]);
                                var l = data._length;
                                for (h = 1; h < l; h += 1) e = r.applyToTriplePoints(data.o[h - 1], data.i[h], data.v[h]), n.bezierCurveTo(e[0], e[1], e[2], e[3], e[4], e[5]);
                                e = r.applyToTriplePoints(data.o[h - 1], data.i[0], data.v[0]), n.bezierCurveTo(e[0], e[1], e[2], e[3], e[4], e[5])
                            }
                        this.element.globalData.renderer.save(!0), n.clip()
                    }
                }, CVMaskElement.prototype.getMaskProperty = MaskElement.prototype.getMaskProperty, CVMaskElement.prototype.destroy = function() {
                    this.element = null
                }, extendPrototype([BaseElement, TransformElement, CVBaseElement, IShapeElement, HierarchyElement, FrameElement, RenderableElement], CVShapeElement), CVShapeElement.prototype.initElement = RenderableDOMElement.prototype.initElement, CVShapeElement.prototype.transformHelper = {
                    opacity: 1,
                    _opMdf: !1
                }, CVShapeElement.prototype.dashResetter = [], CVShapeElement.prototype.createContent = function() {
                    this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, !0, [])
                }, CVShapeElement.prototype.createStyleElement = function(data, t) {
                    var e = {
                            data: data,
                            type: data.ty,
                            preTransforms: this.transformsManager.addTransformSequence(t),
                            transforms: [],
                            elements: [],
                            closed: !0 === data.hd
                        },
                        r = {};
                    if ("fl" === data.ty || "st" === data.ty ? (r.c = PropertyFactory.getProp(this, data.c, 1, 255, this), r.c.k || (e.co = "rgb(" + bmFloor(r.c.v[0]) + "," + bmFloor(r.c.v[1]) + "," + bmFloor(r.c.v[2]) + ")")) : "gf" !== data.ty && "gs" !== data.ty || (r.s = PropertyFactory.getProp(this, data.s, 1, null, this), r.e = PropertyFactory.getProp(this, data.e, 1, null, this), r.h = PropertyFactory.getProp(this, data.h || {
                            k: 0
                        }, 0, .01, this), r.a = PropertyFactory.getProp(this, data.a || {
                            k: 0
                        }, 0, degToRads, this), r.g = new GradientProperty(this, data.g, this)), r.o = PropertyFactory.getProp(this, data.o, 0, .01, this), "st" === data.ty || "gs" === data.ty) {
                        if (e.lc = lineCapEnum[data.lc || 2], e.lj = lineJoinEnum[data.lj || 2], 1 == data.lj && (e.ml = data.ml), r.w = PropertyFactory.getProp(this, data.w, 0, null, this), r.w.k || (e.wi = r.w.v), data.d) {
                            var n = new DashProperty(this, data.d, "canvas", this);
                            r.d = n, r.d.k || (e.da = r.d.dashArray, e.do = r.d.dashoffset[0])
                        }
                    } else e.r = 2 === data.r ? "evenodd" : "nonzero";
                    return this.stylesList.push(e), r.style = e, r
                }, CVShapeElement.prototype.createGroupElement = function() {
                    return {
                        it: [],
                        prevViewData: []
                    }
                }, CVShapeElement.prototype.createTransformElement = function(data) {
                    return {
                        transform: {
                            opacity: 1,
                            _opMdf: !1,
                            key: this.transformsManager.getNewKey(),
                            op: PropertyFactory.getProp(this, data.o, 0, .01, this),
                            mProps: TransformPropertyFactory.getTransformProperty(this, data, this)
                        }
                    }
                }, CVShapeElement.prototype.createShapeElement = function(data) {
                    var t = new CVShapeData(this, data, this.stylesList, this.transformsManager);
                    return this.shapes.push(t), this.addShapeToModifiers(t), t
                }, CVShapeElement.prototype.reloadShapes = function() {
                    var i;
                    this._isFirstFrame = !0;
                    var t = this.itemsData.length;
                    for (i = 0; i < t; i += 1) this.prevViewData[i] = this.itemsData[i];
                    for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, !0, []), t = this.dynamicProperties.length, i = 0; i < t; i += 1) this.dynamicProperties[i].getValue();
                    this.renderModifiers(), this.transformsManager.processSequences(this._isFirstFrame)
                }, CVShapeElement.prototype.addTransformToStyleList = function(t) {
                    var i, e = this.stylesList.length;
                    for (i = 0; i < e; i += 1) this.stylesList[i].closed || this.stylesList[i].transforms.push(t)
                }, CVShapeElement.prototype.removeTransformFromStyleList = function() {
                    var i, t = this.stylesList.length;
                    for (i = 0; i < t; i += 1) this.stylesList[i].closed || this.stylesList[i].transforms.pop()
                }, CVShapeElement.prototype.closeStyles = function(t) {
                    var i, e = t.length;
                    for (i = 0; i < e; i += 1) t[i].closed = !0
                }, CVShapeElement.prototype.searchShapes = function(t, e, r, n, o) {
                    var i, h, l, m, f, c, d = t.length - 1,
                        y = [],
                        v = [],
                        P = [].concat(o);
                    for (i = d; i >= 0; i -= 1) {
                        if ((m = this.searchProcessedElement(t[i])) ? e[i] = r[m - 1] : t[i]._shouldRender = n, "fl" === t[i].ty || "st" === t[i].ty || "gf" === t[i].ty || "gs" === t[i].ty) m ? e[i].style.closed = !1 : e[i] = this.createStyleElement(t[i], P), y.push(e[i].style);
                        else if ("gr" === t[i].ty) {
                            if (m)
                                for (l = e[i].it.length, h = 0; h < l; h += 1) e[i].prevViewData[h] = e[i].it[h];
                            else e[i] = this.createGroupElement(t[i]);
                            this.searchShapes(t[i].it, e[i].it, e[i].prevViewData, n, P)
                        } else "tr" === t[i].ty ? (m || (c = this.createTransformElement(t[i]), e[i] = c), P.push(e[i]), this.addTransformToStyleList(e[i])) : "sh" === t[i].ty || "rc" === t[i].ty || "el" === t[i].ty || "sr" === t[i].ty ? m || (e[i] = this.createShapeElement(t[i])) : "tm" === t[i].ty || "rd" === t[i].ty || "pb" === t[i].ty ? (m ? (f = e[i]).closed = !1 : ((f = ShapeModifiers.getModifier(t[i].ty)).init(this, t[i]), e[i] = f, this.shapeModifiers.push(f)), v.push(f)) : "rp" === t[i].ty && (m ? (f = e[i]).closed = !0 : (f = ShapeModifiers.getModifier(t[i].ty), e[i] = f, f.init(this, t, i, e), this.shapeModifiers.push(f), n = !1), v.push(f));
                        this.addProcessedElement(t[i], i + 1)
                    }
                    for (this.removeTransformFromStyleList(), this.closeStyles(y), d = v.length, i = 0; i < d; i += 1) v[i].closed = !0
                }, CVShapeElement.prototype.renderInnerContent = function() {
                    this.transformHelper.opacity = 1, this.transformHelper._opMdf = !1, this.renderModifiers(), this.transformsManager.processSequences(this._isFirstFrame), this.renderShape(this.transformHelper, this.shapesData, this.itemsData, !0)
                }, CVShapeElement.prototype.renderShapeTransform = function(t, e) {
                    (t._opMdf || e.op._mdf || this._isFirstFrame) && (e.opacity = t.opacity, e.opacity *= e.op.v, e._opMdf = !0)
                }, CVShapeElement.prototype.drawLayer = function() {
                    var i, t, e, r, n, o, h, l, m, f = this.stylesList.length,
                        c = this.globalData.renderer,
                        d = this.globalData.canvasContext;
                    for (i = 0; i < f; i += 1)
                        if (("st" !== (l = (m = this.stylesList[i]).type) && "gs" !== l || 0 !== m.wi) && m.data._shouldRender && 0 !== m.coOp && 0 !== this.globalData.currentGlobalAlpha) {
                            for (c.save(), o = m.elements, "st" === l || "gs" === l ? (d.strokeStyle = "st" === l ? m.co : m.grd, d.lineWidth = m.wi, d.lineCap = m.lc, d.lineJoin = m.lj, d.miterLimit = m.ml || 0) : d.fillStyle = "fl" === l ? m.co : m.grd, c.ctxOpacity(m.coOp), "st" !== l && "gs" !== l && d.beginPath(), c.ctxTransform(m.preTransforms.finalTransform.props), e = o.length, t = 0; t < e; t += 1) {
                                for ("st" !== l && "gs" !== l || (d.beginPath(), m.da && (d.setLineDash(m.da), d.lineDashOffset = m.do)), n = (h = o[t].trNodes).length, r = 0; r < n; r += 1) "m" === h[r].t ? d.moveTo(h[r].p[0], h[r].p[1]) : "c" === h[r].t ? d.bezierCurveTo(h[r].pts[0], h[r].pts[1], h[r].pts[2], h[r].pts[3], h[r].pts[4], h[r].pts[5]) : d.closePath();
                                "st" !== l && "gs" !== l || (d.stroke(), m.da && d.setLineDash(this.dashResetter))
                            }
                            "st" !== l && "gs" !== l && d.fill(m.r), c.restore()
                        }
                }, CVShapeElement.prototype.renderShape = function(t, e, data, r) {
                    var i, n;
                    for (n = t, i = e.length - 1; i >= 0; i -= 1) "tr" === e[i].ty ? (n = data[i].transform, this.renderShapeTransform(t, n)) : "sh" === e[i].ty || "el" === e[i].ty || "rc" === e[i].ty || "sr" === e[i].ty ? this.renderPath(e[i], data[i]) : "fl" === e[i].ty ? this.renderFill(e[i], data[i], n) : "st" === e[i].ty ? this.renderStroke(e[i], data[i], n) : "gf" === e[i].ty || "gs" === e[i].ty ? this.renderGradientFill(e[i], data[i], n) : "gr" === e[i].ty ? this.renderShape(n, e[i].it, data[i].it) : e[i].ty;
                    r && this.drawLayer()
                }, CVShapeElement.prototype.renderStyledShape = function(t, e) {
                    if (this._isFirstFrame || e._mdf || t.transforms._mdf) {
                        var i, r, n, o = t.trNodes,
                            h = e.paths,
                            l = h._length;
                        o.length = 0;
                        var m = t.transforms.finalTransform;
                        for (n = 0; n < l; n += 1) {
                            var f = h.shapes[n];
                            if (f && f.v) {
                                for (r = f._length, i = 1; i < r; i += 1) 1 === i && o.push({
                                    t: "m",
                                    p: m.applyToPointArray(f.v[0][0], f.v[0][1], 0)
                                }), o.push({
                                    t: "c",
                                    pts: m.applyToTriplePoints(f.o[i - 1], f.i[i], f.v[i])
                                });
                                1 === r && o.push({
                                    t: "m",
                                    p: m.applyToPointArray(f.v[0][0], f.v[0][1], 0)
                                }), f.c && r && (o.push({
                                    t: "c",
                                    pts: m.applyToTriplePoints(f.o[i - 1], f.i[0], f.v[0])
                                }), o.push({
                                    t: "z"
                                }))
                            }
                        }
                        t.trNodes = o
                    }
                }, CVShapeElement.prototype.renderPath = function(t, e) {
                    if (!0 !== t.hd && t._shouldRender) {
                        var i, r = e.styledShapes.length;
                        for (i = 0; i < r; i += 1) this.renderStyledShape(e.styledShapes[i], e.sh)
                    }
                }, CVShapeElement.prototype.renderFill = function(t, e, r) {
                    var n = e.style;
                    (e.c._mdf || this._isFirstFrame) && (n.co = "rgb(" + bmFloor(e.c.v[0]) + "," + bmFloor(e.c.v[1]) + "," + bmFloor(e.c.v[2]) + ")"), (e.o._mdf || r._opMdf || this._isFirstFrame) && (n.coOp = e.o.v * r.opacity)
                }, CVShapeElement.prototype.renderGradientFill = function(t, e, r) {
                    var n, o = e.style;
                    if (!o.grd || e.g._mdf || e.s._mdf || e.e._mdf || 1 !== t.t && (e.h._mdf || e.a._mdf)) {
                        var i, h = this.globalData.canvasContext,
                            l = e.s.v,
                            m = e.e.v;
                        if (1 === t.t) n = h.createLinearGradient(l[0], l[1], m[0], m[1]);
                        else {
                            var f = Math.sqrt(Math.pow(l[0] - m[0], 2) + Math.pow(l[1] - m[1], 2)),
                                c = Math.atan2(m[1] - l[1], m[0] - l[0]),
                                d = e.h.v;
                            d >= 1 ? d = .99 : d <= -1 && (d = -.99);
                            var y = f * d,
                                v = Math.cos(c + e.a.v) * y + l[0],
                                P = Math.sin(c + e.a.v) * y + l[1];
                            n = h.createRadialGradient(v, P, 0, l[0], l[1], f)
                        }
                        var E = t.g.p,
                            x = e.g.c,
                            S = 1;
                        for (i = 0; i < E; i += 1) e.g._hasOpacity && e.g._collapsable && (S = e.g.o[2 * i + 1]), n.addColorStop(x[4 * i] / 100, "rgba(" + x[4 * i + 1] + "," + x[4 * i + 2] + "," + x[4 * i + 3] + "," + S + ")");
                        o.grd = n
                    }
                    o.coOp = e.o.v * r.opacity
                }, CVShapeElement.prototype.renderStroke = function(t, e, r) {
                    var n = e.style,
                        o = e.d;
                    o && (o._mdf || this._isFirstFrame) && (n.da = o.dashArray, n.do = o.dashoffset[0]), (e.c._mdf || this._isFirstFrame) && (n.co = "rgb(" + bmFloor(e.c.v[0]) + "," + bmFloor(e.c.v[1]) + "," + bmFloor(e.c.v[2]) + ")"), (e.o._mdf || r._opMdf || this._isFirstFrame) && (n.coOp = e.o.v * r.opacity), (e.w._mdf || this._isFirstFrame) && (n.wi = e.w.v)
                }, CVShapeElement.prototype.destroy = function() {
                    this.shapesData = null, this.globalData = null, this.canvasContext = null, this.stylesList.length = 0, this.itemsData.length = 0
                }, extendPrototype([BaseElement, TransformElement, CVBaseElement, HierarchyElement, FrameElement, RenderableElement], CVSolidElement), CVSolidElement.prototype.initElement = SVGShapeElement.prototype.initElement, CVSolidElement.prototype.prepareFrame = IImageElement.prototype.prepareFrame, CVSolidElement.prototype.renderInnerContent = function() {
                    var t = this.canvasContext;
                    t.fillStyle = this.data.sc, t.fillRect(0, 0, this.data.sw, this.data.sh)
                }, extendPrototype([BaseElement, TransformElement, CVBaseElement, HierarchyElement, FrameElement, RenderableElement, ITextElement], CVTextElement), CVTextElement.prototype.tHelper = createTag("canvas").getContext("2d"), CVTextElement.prototype.buildNewText = function() {
                    var t = this.textProperty.currentData;
                    this.renderedLetters = createSizedArray(t.l ? t.l.length : 0);
                    var e = !1;
                    t.fc ? (e = !0, this.values.fill = this.buildColor(t.fc)) : this.values.fill = "rgba(0,0,0,0)", this.fill = e;
                    var r = !1;
                    t.sc && (r = !0, this.values.stroke = this.buildColor(t.sc), this.values.sWidth = t.sw);
                    var i, n, o, h, l, m, f, c, d, y, v, P, E = this.globalData.fontManager.getFontByName(t.f),
                        x = t.l,
                        S = this.mHelper;
                    this.stroke = r, this.values.fValue = t.finalSize + "px " + this.globalData.fontManager.getFontByName(t.f).fFamily, n = t.finalText.length;
                    var A = this.data.singleShape,
                        C = .001 * t.tr * t.finalSize,
                        _ = 0,
                        T = 0,
                        k = !0,
                        D = 0;
                    for (i = 0; i < n; i += 1) {
                        for (h = (o = this.globalData.fontManager.getCharData(t.finalText[i], E.fStyle, this.globalData.fontManager.getFontByName(t.f).fFamily)) && o.data || {}, S.reset(), A && x[i].n && (_ = -C, T += t.yOffset, T += k ? 1 : 0, k = !1), d = (f = h.shapes ? h.shapes[0].it : []).length, S.scale(t.finalSize / 100, t.finalSize / 100), A && this.applyTextPropertiesToMatrix(t, S, x[i].line, _, T), v = createSizedArray(d), c = 0; c < d; c += 1) {
                            for (m = f[c].ks.k.i.length, y = f[c].ks.k, P = [], l = 1; l < m; l += 1) 1 === l && P.push(S.applyToX(y.v[0][0], y.v[0][1], 0), S.applyToY(y.v[0][0], y.v[0][1], 0)), P.push(S.applyToX(y.o[l - 1][0], y.o[l - 1][1], 0), S.applyToY(y.o[l - 1][0], y.o[l - 1][1], 0), S.applyToX(y.i[l][0], y.i[l][1], 0), S.applyToY(y.i[l][0], y.i[l][1], 0), S.applyToX(y.v[l][0], y.v[l][1], 0), S.applyToY(y.v[l][0], y.v[l][1], 0));
                            P.push(S.applyToX(y.o[l - 1][0], y.o[l - 1][1], 0), S.applyToY(y.o[l - 1][0], y.o[l - 1][1], 0), S.applyToX(y.i[0][0], y.i[0][1], 0), S.applyToY(y.i[0][0], y.i[0][1], 0), S.applyToX(y.v[0][0], y.v[0][1], 0), S.applyToY(y.v[0][0], y.v[0][1], 0)), v[c] = P
                        }
                        A && (_ += x[i].l, _ += C), this.textSpans[D] ? this.textSpans[D].elem = v : this.textSpans[D] = {
                            elem: v
                        }, D += 1
                    }
                }, CVTextElement.prototype.renderInnerContent = function() {
                    var i, t, e, r, n, o, h = this.canvasContext;
                    h.font = this.values.fValue, h.lineCap = "butt", h.lineJoin = "miter", h.miterLimit = 4, this.data.singleShape || this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag);
                    var l, m = this.textAnimator.renderedLetters,
                        f = this.textProperty.currentData.l;
                    t = f.length;
                    var c, d, y = null,
                        v = null,
                        P = null;
                    for (i = 0; i < t; i += 1)
                        if (!f[i].n) {
                            if ((l = m[i]) && (this.globalData.renderer.save(), this.globalData.renderer.ctxTransform(l.p), this.globalData.renderer.ctxOpacity(l.o)), this.fill) {
                                for (l && l.fc ? y !== l.fc && (y = l.fc, h.fillStyle = l.fc) : y !== this.values.fill && (y = this.values.fill, h.fillStyle = this.values.fill), r = (c = this.textSpans[i].elem).length, this.globalData.canvasContext.beginPath(), e = 0; e < r; e += 1)
                                    for (o = (d = c[e]).length, this.globalData.canvasContext.moveTo(d[0], d[1]), n = 2; n < o; n += 6) this.globalData.canvasContext.bezierCurveTo(d[n], d[n + 1], d[n + 2], d[n + 3], d[n + 4], d[n + 5]);
                                this.globalData.canvasContext.closePath(), this.globalData.canvasContext.fill()
                            }
                            if (this.stroke) {
                                for (l && l.sw ? P !== l.sw && (P = l.sw, h.lineWidth = l.sw) : P !== this.values.sWidth && (P = this.values.sWidth, h.lineWidth = this.values.sWidth), l && l.sc ? v !== l.sc && (v = l.sc, h.strokeStyle = l.sc) : v !== this.values.stroke && (v = this.values.stroke, h.strokeStyle = this.values.stroke), r = (c = this.textSpans[i].elem).length, this.globalData.canvasContext.beginPath(), e = 0; e < r; e += 1)
                                    for (o = (d = c[e]).length, this.globalData.canvasContext.moveTo(d[0], d[1]), n = 2; n < o; n += 6) this.globalData.canvasContext.bezierCurveTo(d[n], d[n + 1], d[n + 2], d[n + 3], d[n + 4], d[n + 5]);
                                this.globalData.canvasContext.closePath(), this.globalData.canvasContext.stroke()
                            }
                            l && this.globalData.renderer.restore()
                        }
                }, CVEffects.prototype.renderFrame = function() {}, HBaseElement.prototype = {
                    checkBlendMode: function() {},
                    initRendererElement: function() {
                        this.baseElement = createTag(this.data.tg || "div"), this.data.hasMask ? (this.svgElement = createNS("svg"), this.layerElement = createNS("g"), this.maskedElement = this.layerElement, this.svgElement.appendChild(this.layerElement), this.baseElement.appendChild(this.svgElement)) : this.layerElement = this.baseElement, styleDiv(this.baseElement)
                    },
                    createContainerElements: function() {
                        this.renderableEffectsManager = new CVEffects(this), this.transformedElement = this.baseElement, this.maskedElement = this.layerElement, this.data.ln && this.layerElement.setAttribute("id", this.data.ln), this.data.cl && this.layerElement.setAttribute("class", this.data.cl), 0 !== this.data.bm && this.setBlendMode()
                    },
                    renderElement: function() {
                        var t = this.transformedElement ? this.transformedElement.style : {};
                        if (this.finalTransform._matMdf) {
                            var e = this.finalTransform.mat.toCSS();
                            t.transform = e, t.webkitTransform = e
                        }
                        this.finalTransform._opMdf && (t.opacity = this.finalTransform.mProp.o.v)
                    },
                    renderFrame: function() {
                        this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = !1))
                    },
                    destroy: function() {
                        this.layerElement = null, this.transformedElement = null, this.matteElement && (this.matteElement = null), this.maskManager && (this.maskManager.destroy(), this.maskManager = null)
                    },
                    createRenderableComponents: function() {
                        this.maskManager = new MaskElement(this.data, this, this.globalData)
                    },
                    addEffects: function() {},
                    setMatte: function() {}
                }, HBaseElement.prototype.getBaseElement = SVGBaseElement.prototype.getBaseElement, HBaseElement.prototype.destroyBaseElement = HBaseElement.prototype.destroy, HBaseElement.prototype.buildElementParenting = HybridRenderer.prototype.buildElementParenting, extendPrototype([BaseElement, TransformElement, HBaseElement, HierarchyElement, FrameElement, RenderableDOMElement], HSolidElement), HSolidElement.prototype.createContent = function() {
                    var rect;
                    this.data.hasMask ? ((rect = createNS("rect")).setAttribute("width", this.data.sw), rect.setAttribute("height", this.data.sh), rect.setAttribute("fill", this.data.sc), this.svgElement.setAttribute("width", this.data.sw), this.svgElement.setAttribute("height", this.data.sh)) : ((rect = createTag("div")).style.width = this.data.sw + "px", rect.style.height = this.data.sh + "px", rect.style.backgroundColor = this.data.sc), this.layerElement.appendChild(rect)
                }, extendPrototype([HybridRenderer, ICompElement, HBaseElement], HCompElement), HCompElement.prototype._createBaseContainerElements = HCompElement.prototype.createContainerElements, HCompElement.prototype.createContainerElements = function() {
                    this._createBaseContainerElements(), this.data.hasMask ? (this.svgElement.setAttribute("width", this.data.w), this.svgElement.setAttribute("height", this.data.h), this.transformedElement = this.baseElement) : this.transformedElement = this.layerElement
                }, HCompElement.prototype.addTo3dContainer = function(t, e) {
                    for (var r, n = 0; n < e;) this.elements[n] && this.elements[n].getBaseElement && (r = this.elements[n].getBaseElement()), n += 1;
                    r ? this.layerElement.insertBefore(t, r) : this.layerElement.appendChild(t)
                }, extendPrototype([BaseElement, TransformElement, HSolidElement, SVGShapeElement, HBaseElement, HierarchyElement, FrameElement, RenderableElement], HShapeElement), HShapeElement.prototype._renderShapeFrame = HShapeElement.prototype.renderInnerContent, HShapeElement.prototype.createContent = function() {
                    var t;
                    if (this.baseElement.style.fontSize = 0, this.data.hasMask) this.layerElement.appendChild(this.shapesContainer), t = this.svgElement;
                    else {
                        t = createNS("svg");
                        var e = this.comp.data ? this.comp.data : this.globalData.compSize;
                        t.setAttribute("width", e.w), t.setAttribute("height", e.h), t.appendChild(this.shapesContainer), this.layerElement.appendChild(t)
                    }
                    this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.shapesContainer, 0, [], !0), this.filterUniqueShapes(), this.shapeCont = t
                }, HShapeElement.prototype.getTransformedPoint = function(t, e) {
                    var i, r = t.length;
                    for (i = 0; i < r; i += 1) e = t[i].mProps.v.applyToPointArray(e[0], e[1], 0);
                    return e
                }, HShapeElement.prototype.calculateShapeBoundingBox = function(t, e) {
                    var i, r, n, o, h, l = t.sh.v,
                        m = t.transformers,
                        f = l._length;
                    if (!(f <= 1)) {
                        for (i = 0; i < f - 1; i += 1) r = this.getTransformedPoint(m, l.v[i]), n = this.getTransformedPoint(m, l.o[i]), o = this.getTransformedPoint(m, l.i[i + 1]), h = this.getTransformedPoint(m, l.v[i + 1]), this.checkBounds(r, n, o, h, e);
                        l.c && (r = this.getTransformedPoint(m, l.v[i]), n = this.getTransformedPoint(m, l.o[i]), o = this.getTransformedPoint(m, l.i[0]), h = this.getTransformedPoint(m, l.v[0]), this.checkBounds(r, n, o, h, e))
                    }
                }, HShapeElement.prototype.checkBounds = function(t, e, r, n, o) {
                    this.getBoundsOfCurve(t, e, r, n);
                    var h = this.shapeBoundingBox;
                    o.x = bmMin(h.left, o.x), o.xMax = bmMax(h.right, o.xMax), o.y = bmMin(h.top, o.y), o.yMax = bmMax(h.bottom, o.yMax)
                }, HShapeElement.prototype.shapeBoundingBox = {
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 0
                }, HShapeElement.prototype.tempBoundingBox = {
                    x: 0,
                    xMax: 0,
                    y: 0,
                    yMax: 0,
                    width: 0,
                    height: 0
                }, HShapeElement.prototype.getBoundsOfCurve = function(t, e, r, n) {
                    for (var a, b, o, h, l, m, f, c = [
                            [t[0], n[0]],
                            [t[1], n[1]]
                        ], i = 0; i < 2; ++i) b = 6 * t[i] - 12 * e[i] + 6 * r[i], a = -3 * t[i] + 9 * e[i] - 9 * r[i] + 3 * n[i], o = 3 * e[i] - 3 * t[i], b |= 0, o |= 0, 0 == (a |= 0) && 0 === b || (0 === a ? (h = -o / b) > 0 && h < 1 && c[i].push(this.calculateF(h, t, e, r, n, i)) : (l = b * b - 4 * o * a) >= 0 && ((m = (-b + bmSqrt(l)) / (2 * a)) > 0 && m < 1 && c[i].push(this.calculateF(m, t, e, r, n, i)), (f = (-b - bmSqrt(l)) / (2 * a)) > 0 && f < 1 && c[i].push(this.calculateF(f, t, e, r, n, i))));
                    this.shapeBoundingBox.left = bmMin.apply(null, c[0]), this.shapeBoundingBox.top = bmMin.apply(null, c[1]), this.shapeBoundingBox.right = bmMax.apply(null, c[0]), this.shapeBoundingBox.bottom = bmMax.apply(null, c[1])
                }, HShapeElement.prototype.calculateF = function(t, e, r, n, o, i) {
                    return bmPow(1 - t, 3) * e[i] + 3 * bmPow(1 - t, 2) * t * r[i] + 3 * (1 - t) * bmPow(t, 2) * n[i] + bmPow(t, 3) * o[i]
                }, HShapeElement.prototype.calculateBoundingBox = function(t, e) {
                    var i, r = t.length;
                    for (i = 0; i < r; i += 1) t[i] && t[i].sh ? this.calculateShapeBoundingBox(t[i], e) : t[i] && t[i].it && this.calculateBoundingBox(t[i].it, e)
                }, HShapeElement.prototype.currentBoxContains = function(t) {
                    return this.currentBBox.x <= t.x && this.currentBBox.y <= t.y && this.currentBBox.width + this.currentBBox.x >= t.x + t.width && this.currentBBox.height + this.currentBBox.y >= t.y + t.height
                }, HShapeElement.prototype.renderInnerContent = function() {
                    if (this._renderShapeFrame(), !this.hidden && (this._isFirstFrame || this._mdf)) {
                        var t = this.tempBoundingBox,
                            e = 999999;
                        if (t.x = e, t.xMax = -e, t.y = e, t.yMax = -e, this.calculateBoundingBox(this.itemsData, t), t.width = t.xMax < t.x ? 0 : t.xMax - t.x, t.height = t.yMax < t.y ? 0 : t.yMax - t.y, this.currentBoxContains(t)) return;
                        var r = !1;
                        if (this.currentBBox.w !== t.width && (this.currentBBox.w = t.width, this.shapeCont.setAttribute("width", t.width), r = !0), this.currentBBox.h !== t.height && (this.currentBBox.h = t.height, this.shapeCont.setAttribute("height", t.height), r = !0), r || this.currentBBox.x !== t.x || this.currentBBox.y !== t.y) {
                            this.currentBBox.w = t.width, this.currentBBox.h = t.height, this.currentBBox.x = t.x, this.currentBBox.y = t.y, this.shapeCont.setAttribute("viewBox", this.currentBBox.x + " " + this.currentBBox.y + " " + this.currentBBox.w + " " + this.currentBBox.h);
                            var n = this.shapeCont.style,
                                o = "translate(" + this.currentBBox.x + "px," + this.currentBBox.y + "px)";
                            n.transform = o, n.webkitTransform = o
                        }
                    }
                }, extendPrototype([BaseElement, TransformElement, HBaseElement, HierarchyElement, FrameElement, RenderableDOMElement, ITextElement], HTextElement), HTextElement.prototype.createContent = function() {
                    if (this.isMasked = this.checkMasks(), this.isMasked) {
                        this.renderType = "svg", this.compW = this.comp.data.w, this.compH = this.comp.data.h, this.svgElement.setAttribute("width", this.compW), this.svgElement.setAttribute("height", this.compH);
                        var g = createNS("g");
                        this.maskedElement.appendChild(g), this.innerElem = g
                    } else this.renderType = "html", this.innerElem = this.layerElement;
                    this.checkParenting()
                }, HTextElement.prototype.buildNewText = function() {
                    var t = this.textProperty.currentData;
                    this.renderedLetters = createSizedArray(t.l ? t.l.length : 0);
                    var e = this.innerElem.style,
                        r = t.fc ? this.buildColor(t.fc) : "rgba(0,0,0,0)";
                    e.fill = r, e.color = r, t.sc && (e.stroke = this.buildColor(t.sc), e.strokeWidth = t.sw + "px");
                    var i, n, o = this.globalData.fontManager.getFontByName(t.f);
                    if (!this.globalData.fontManager.chars)
                        if (e.fontSize = t.finalSize + "px", e.lineHeight = t.finalSize + "px", o.fClass) this.innerElem.className = o.fClass;
                        else {
                            e.fontFamily = o.fFamily;
                            var h = t.fWeight,
                                l = t.fStyle;
                            e.fontStyle = l, e.fontWeight = h
                        }
                    var m, f, c, d = t.l;
                    n = d.length;
                    var y, v = this.mHelper,
                        P = "",
                        E = 0;
                    for (i = 0; i < n; i += 1) {
                        if (this.globalData.fontManager.chars ? (this.textPaths[E] ? m = this.textPaths[E] : ((m = createNS("path")).setAttribute("stroke-linecap", lineCapEnum[1]), m.setAttribute("stroke-linejoin", lineJoinEnum[2]), m.setAttribute("stroke-miterlimit", "4")), this.isMasked || (this.textSpans[E] ? c = (f = this.textSpans[E]).children[0] : ((f = createTag("div")).style.lineHeight = 0, (c = createNS("svg")).appendChild(m), styleDiv(f)))) : this.isMasked ? m = this.textPaths[E] ? this.textPaths[E] : createNS("text") : this.textSpans[E] ? (f = this.textSpans[E], m = this.textPaths[E]) : (styleDiv(f = createTag("span")), styleDiv(m = createTag("span")), f.appendChild(m)), this.globalData.fontManager.chars) {
                            var x, S = this.globalData.fontManager.getCharData(t.finalText[i], o.fStyle, this.globalData.fontManager.getFontByName(t.f).fFamily);
                            if (x = S ? S.data : null, v.reset(), x && x.shapes && (y = x.shapes[0].it, v.scale(t.finalSize / 100, t.finalSize / 100), P = this.createPathShape(v, y), m.setAttribute("d", P)), this.isMasked) this.innerElem.appendChild(m);
                            else {
                                if (this.innerElem.appendChild(f), x && x.shapes) {
                                    document.body.appendChild(c);
                                    var A = c.getBBox();
                                    c.setAttribute("width", A.width + 2), c.setAttribute("height", A.height + 2), c.setAttribute("viewBox", A.x - 1 + " " + (A.y - 1) + " " + (A.width + 2) + " " + (A.height + 2));
                                    var C = c.style,
                                        _ = "translate(" + (A.x - 1) + "px," + (A.y - 1) + "px)";
                                    C.transform = _, C.webkitTransform = _, d[i].yOffset = A.y - 1
                                } else c.setAttribute("width", 1), c.setAttribute("height", 1);
                                f.appendChild(c)
                            }
                        } else if (m.textContent = d[i].val, m.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), this.isMasked) this.innerElem.appendChild(m);
                        else {
                            this.innerElem.appendChild(f);
                            var T = m.style,
                                k = "translate3d(0," + -t.finalSize / 1.2 + "px,0)";
                            T.transform = k, T.webkitTransform = k
                        }
                        this.isMasked ? this.textSpans[E] = m : this.textSpans[E] = f, this.textSpans[E].style.display = "block", this.textPaths[E] = m, E += 1
                    }
                    for (; E < this.textSpans.length;) this.textSpans[E].style.display = "none", E += 1
                }, HTextElement.prototype.renderInnerContent = function() {
                    var t;
                    if (this.data.singleShape) {
                        if (!this._isFirstFrame && !this.lettersChangedFlag) return;
                        if (this.isMasked && this.finalTransform._matMdf) {
                            this.svgElement.setAttribute("viewBox", -this.finalTransform.mProp.p.v[0] + " " + -this.finalTransform.mProp.p.v[1] + " " + this.compW + " " + this.compH), t = this.svgElement.style;
                            var e = "translate(" + -this.finalTransform.mProp.p.v[0] + "px," + -this.finalTransform.mProp.p.v[1] + "px)";
                            t.transform = e, t.webkitTransform = e
                        }
                    }
                    if (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), this.lettersChangedFlag || this.textAnimator.lettersChangedFlag) {
                        var i, r, n, o, h, l = 0,
                            m = this.textAnimator.renderedLetters,
                            f = this.textProperty.currentData.l;
                        for (r = f.length, i = 0; i < r; i += 1) f[i].n ? l += 1 : (o = this.textSpans[i], h = this.textPaths[i], n = m[l], l += 1, n._mdf.m && (this.isMasked ? o.setAttribute("transform", n.m) : (o.style.webkitTransform = n.m, o.style.transform = n.m)), o.style.opacity = n.o, n.sw && n._mdf.sw && h.setAttribute("stroke-width", n.sw), n.sc && n._mdf.sc && h.setAttribute("stroke", n.sc), n.fc && n._mdf.fc && (h.setAttribute("fill", n.fc), h.style.color = n.fc));
                        if (this.innerElem.getBBox && !this.hidden && (this._isFirstFrame || this._mdf)) {
                            var c = this.innerElem.getBBox();
                            if (this.currentBBox.w !== c.width && (this.currentBBox.w = c.width, this.svgElement.setAttribute("width", c.width)), this.currentBBox.h !== c.height && (this.currentBBox.h = c.height, this.svgElement.setAttribute("height", c.height)), this.currentBBox.w !== c.width + 2 || this.currentBBox.h !== c.height + 2 || this.currentBBox.x !== c.x - 1 || this.currentBBox.y !== c.y - 1) {
                                this.currentBBox.w = c.width + 2, this.currentBBox.h = c.height + 2, this.currentBBox.x = c.x - 1, this.currentBBox.y = c.y - 1, this.svgElement.setAttribute("viewBox", this.currentBBox.x + " " + this.currentBBox.y + " " + this.currentBBox.w + " " + this.currentBBox.h), t = this.svgElement.style;
                                var d = "translate(" + this.currentBBox.x + "px," + this.currentBBox.y + "px)";
                                t.transform = d, t.webkitTransform = d
                            }
                        }
                    }
                }, extendPrototype([BaseElement, TransformElement, HBaseElement, HSolidElement, HierarchyElement, FrameElement, RenderableElement], HImageElement), HImageElement.prototype.createContent = function() {
                    var t = this.globalData.getAssetsPath(this.assetData),
                        img = new Image;
                    this.data.hasMask ? (this.imageElem = createNS("image"), this.imageElem.setAttribute("width", this.assetData.w + "px"), this.imageElem.setAttribute("height", this.assetData.h + "px"), this.imageElem.setAttributeNS("http://www.w3.org/1999/xlink", "href", t), this.layerElement.appendChild(this.imageElem), this.baseElement.setAttribute("width", this.assetData.w), this.baseElement.setAttribute("height", this.assetData.h)) : this.layerElement.appendChild(img), img.crossOrigin = "anonymous", img.src = t, this.data.ln && this.baseElement.setAttribute("id", this.data.ln)
                }, extendPrototype([BaseElement, FrameElement, HierarchyElement], HCameraElement), HCameraElement.prototype.setup = function() {
                    var i, t, e, r, n = this.comp.threeDElements.length;
                    for (i = 0; i < n; i += 1)
                        if ("3d" === (t = this.comp.threeDElements[i]).type) {
                            e = t.perspectiveElem.style, r = t.container.style;
                            var o = this.pe.v + "px",
                                h = "0px 0px 0px",
                                l = "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)";
                            e.perspective = o, e.webkitPerspective = o, r.transformOrigin = h, r.mozTransformOrigin = h, r.webkitTransformOrigin = h, e.transform = l, e.webkitTransform = l
                        }
                }, HCameraElement.prototype.createElements = function() {}, HCameraElement.prototype.hide = function() {}, HCameraElement.prototype.renderFrame = function() {
                    var i, t, e = this._isFirstFrame;
                    if (this.hierarchy)
                        for (t = this.hierarchy.length, i = 0; i < t; i += 1) e = this.hierarchy[i].finalTransform.mProp._mdf || e;
                    if (e || this.pe._mdf || this.p && this.p._mdf || this.px && (this.px._mdf || this.py._mdf || this.pz._mdf) || this.rx._mdf || this.ry._mdf || this.rz._mdf || this.or._mdf || this.a && this.a._mdf) {
                        if (this.mat.reset(), this.hierarchy)
                            for (i = t = this.hierarchy.length - 1; i >= 0; i -= 1) {
                                var r = this.hierarchy[i].finalTransform.mProp;
                                this.mat.translate(-r.p.v[0], -r.p.v[1], r.p.v[2]), this.mat.rotateX(-r.or.v[0]).rotateY(-r.or.v[1]).rotateZ(r.or.v[2]), this.mat.rotateX(-r.rx.v).rotateY(-r.ry.v).rotateZ(r.rz.v), this.mat.scale(1 / r.s.v[0], 1 / r.s.v[1], 1 / r.s.v[2]), this.mat.translate(r.a.v[0], r.a.v[1], r.a.v[2])
                            }
                        if (this.p ? this.mat.translate(-this.p.v[0], -this.p.v[1], this.p.v[2]) : this.mat.translate(-this.px.v, -this.py.v, this.pz.v), this.a) {
                            var n;
                            n = this.p ? [this.p.v[0] - this.a.v[0], this.p.v[1] - this.a.v[1], this.p.v[2] - this.a.v[2]] : [this.px.v - this.a.v[0], this.py.v - this.a.v[1], this.pz.v - this.a.v[2]];
                            var o = Math.sqrt(Math.pow(n[0], 2) + Math.pow(n[1], 2) + Math.pow(n[2], 2)),
                                h = [n[0] / o, n[1] / o, n[2] / o],
                                l = Math.sqrt(h[2] * h[2] + h[0] * h[0]),
                                m = Math.atan2(h[1], l),
                                f = Math.atan2(h[0], -h[2]);
                            this.mat.rotateY(f).rotateX(-m)
                        }
                        this.mat.rotateX(-this.rx.v).rotateY(-this.ry.v).rotateZ(this.rz.v), this.mat.rotateX(-this.or.v[0]).rotateY(-this.or.v[1]).rotateZ(this.or.v[2]), this.mat.translate(this.globalData.compSize.w / 2, this.globalData.compSize.h / 2, 0), this.mat.translate(0, 0, this.pe.v);
                        var c = !this._prevMat.equals(this.mat);
                        if ((c || this.pe._mdf) && this.comp.threeDElements) {
                            var d, y, v;
                            for (t = this.comp.threeDElements.length, i = 0; i < t; i += 1)
                                if ("3d" === (d = this.comp.threeDElements[i]).type) {
                                    if (c) {
                                        var P = this.mat.toCSS();
                                        (v = d.container.style).transform = P, v.webkitTransform = P
                                    }
                                    this.pe._mdf && ((y = d.perspectiveElem.style).perspective = this.pe.v + "px", y.webkitPerspective = this.pe.v + "px")
                                }
                            this.mat.clone(this._prevMat)
                        }
                    }
                    this._isFirstFrame = !1
                }, HCameraElement.prototype.prepareFrame = function(t) {
                    this.prepareProperties(t, !0)
                }, HCameraElement.prototype.destroy = function() {}, HCameraElement.prototype.getBaseElement = function() {
                    return null
                }, HEffects.prototype.renderFrame = function() {};
                var animationManager = function() {
                        var t = {},
                            e = [],
                            r = 0,
                            n = 0,
                            o = 0,
                            h = !0,
                            l = !1;

                        function m(t) {
                            for (var i = 0, r = t.target; i < n;) e[i].animation === r && (e.splice(i, 1), i -= 1, n -= 1, r.isPaused || d()), i += 1
                        }

                        function f(element, t) {
                            if (!element) return null;
                            for (var i = 0; i < n;) {
                                if (e[i].elem === element && null !== e[i].elem) return e[i].animation;
                                i += 1
                            }
                            var r = new AnimationItem;
                            return y(r, element), r.setData(element, t), r
                        }

                        function c() {
                            o += 1, E()
                        }

                        function d() {
                            o -= 1
                        }

                        function y(t, element) {
                            t.addEventListener("destroy", m), t.addEventListener("_active", c), t.addEventListener("_idle", d), e.push({
                                elem: element,
                                animation: t
                            }), n += 1
                        }

                        function v(t) {
                            var i, m = t - r;
                            for (i = 0; i < n; i += 1) e[i].animation.advanceTime(m);
                            r = t, o && !l ? window.requestAnimationFrame(v) : h = !0
                        }

                        function P(t) {
                            r = t, window.requestAnimationFrame(v)
                        }

                        function E() {
                            !l && o && h && (window.requestAnimationFrame(P), h = !1)
                        }
                        return t.registerAnimation = f, t.loadAnimation = function(t) {
                            var e = new AnimationItem;
                            return y(e, null), e.setParams(t), e
                        }, t.setSpeed = function(t, r) {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.setSpeed(t, r)
                        }, t.setDirection = function(t, r) {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.setDirection(t, r)
                        }, t.play = function(t) {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.play(t)
                        }, t.pause = function(t) {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.pause(t)
                        }, t.stop = function(t) {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.stop(t)
                        }, t.togglePause = function(t) {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.togglePause(t)
                        }, t.searchAnimations = function(t, e, r) {
                            var i, n = [].concat([].slice.call(document.getElementsByClassName("lottie")), [].slice.call(document.getElementsByClassName("bodymovin"))),
                                o = n.length;
                            for (i = 0; i < o; i += 1) r && n[i].setAttribute("data-bm-type", r), f(n[i], t);
                            if (e && 0 === o) {
                                r || (r = "svg");
                                var body = document.getElementsByTagName("body")[0];
                                body.innerText = "";
                                var div = createTag("div");
                                div.style.width = "100%", div.style.height = "100%", div.setAttribute("data-bm-type", r), body.appendChild(div), f(div, t)
                            }
                        }, t.resize = function() {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.resize()
                        }, t.goToAndStop = function(t, r, o) {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.goToAndStop(t, r, o)
                        }, t.destroy = function(t) {
                            var i;
                            for (i = n - 1; i >= 0; i -= 1) e[i].animation.destroy(t)
                        }, t.freeze = function() {
                            l = !0
                        }, t.unfreeze = function() {
                            l = !1, E()
                        }, t.setVolume = function(t, r) {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.setVolume(t, r)
                        }, t.mute = function(t) {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.mute(t)
                        }, t.unmute = function(t) {
                            var i;
                            for (i = 0; i < n; i += 1) e[i].animation.unmute(t)
                        }, t.getRegisteredAnimations = function() {
                            var i, t = e.length,
                                r = [];
                            for (i = 0; i < t; i += 1) r.push(e[i].animation);
                            return r
                        }, t
                    }(),
                    AnimationItem = function() {
                        this._cbs = [], this.name = "", this.path = "", this.isLoaded = !1, this.currentFrame = 0, this.currentRawFrame = 0, this.firstFrame = 0, this.totalFrames = 0, this.frameRate = 0, this.frameMult = 0, this.playSpeed = 1, this.playDirection = 1, this.playCount = 0, this.animationData = {}, this.assets = [], this.isPaused = !0, this.autoplay = !1, this.loop = !0, this.renderer = null, this.animationID = createElementID(), this.assetsPath = "", this.timeCompleted = 0, this.segmentPos = 0, this.isSubframeEnabled = subframeEnabled, this.segments = [], this._idle = !0, this._completedLoop = !1, this.projectInterface = ProjectInterface(), this.imagePreloader = new ImagePreloader, this.audioController = audioControllerFactory(), this.markers = [], this.configAnimation = this.configAnimation.bind(this), this.onSetupError = this.onSetupError.bind(this), this.onSegmentComplete = this.onSegmentComplete.bind(this)
                    };
                extendPrototype([BaseEvent], AnimationItem), AnimationItem.prototype.setParams = function(t) {
                    (t.wrapper || t.container) && (this.wrapper = t.wrapper || t.container);
                    var e = "svg";
                    switch (t.animType ? e = t.animType : t.renderer && (e = t.renderer), e) {
                        case "canvas":
                            this.renderer = new CanvasRenderer(this, t.rendererSettings);
                            break;
                        case "svg":
                            this.renderer = new SVGRenderer(this, t.rendererSettings);
                            break;
                        default:
                            this.renderer = new HybridRenderer(this, t.rendererSettings)
                    }
                    this.imagePreloader.setCacheType(e, this.renderer.globalData.defs), this.renderer.setProjectInterface(this.projectInterface), this.animType = e, "" === t.loop || null === t.loop || void 0 === t.loop || !0 === t.loop ? this.loop = !0 : !1 === t.loop ? this.loop = !1 : this.loop = parseInt(t.loop, 10), this.autoplay = !("autoplay" in t) || t.autoplay, this.name = t.name ? t.name : "", this.autoloadSegments = !Object.prototype.hasOwnProperty.call(t, "autoloadSegments") || t.autoloadSegments, this.assetsPath = t.assetsPath, this.initialSegment = t.initialSegment, t.audioFactory && this.audioController.setAudioFactory(t.audioFactory), t.animationData ? this.setupAnimation(t.animationData) : t.path && (-1 !== t.path.lastIndexOf("\\") ? this.path = t.path.substr(0, t.path.lastIndexOf("\\") + 1) : this.path = t.path.substr(0, t.path.lastIndexOf("/") + 1), this.fileName = t.path.substr(t.path.lastIndexOf("/") + 1), this.fileName = this.fileName.substr(0, this.fileName.lastIndexOf(".json")), dataManager.loadAnimation(t.path, this.configAnimation, this.onSetupError))
                }, AnimationItem.prototype.onSetupError = function() {
                    this.trigger("data_failed")
                }, AnimationItem.prototype.setupAnimation = function(data) {
                    dataManager.completeAnimation(data, this.configAnimation)
                }, AnimationItem.prototype.setData = function(t, e) {
                    e && "object" != typeof e && (e = JSON.parse(e));
                    var r = {
                            wrapper: t,
                            animationData: e
                        },
                        n = t.attributes;
                    r.path = n.getNamedItem("data-animation-path") ? n.getNamedItem("data-animation-path").value : n.getNamedItem("data-bm-path") ? n.getNamedItem("data-bm-path").value : n.getNamedItem("bm-path") ? n.getNamedItem("bm-path").value : "", r.animType = n.getNamedItem("data-anim-type") ? n.getNamedItem("data-anim-type").value : n.getNamedItem("data-bm-type") ? n.getNamedItem("data-bm-type").value : n.getNamedItem("bm-type") ? n.getNamedItem("bm-type").value : n.getNamedItem("data-bm-renderer") ? n.getNamedItem("data-bm-renderer").value : n.getNamedItem("bm-renderer") ? n.getNamedItem("bm-renderer").value : "canvas";
                    var o = n.getNamedItem("data-anim-loop") ? n.getNamedItem("data-anim-loop").value : n.getNamedItem("data-bm-loop") ? n.getNamedItem("data-bm-loop").value : n.getNamedItem("bm-loop") ? n.getNamedItem("bm-loop").value : "";
                    "false" === o ? r.loop = !1 : "true" === o ? r.loop = !0 : "" !== o && (r.loop = parseInt(o, 10));
                    var h = n.getNamedItem("data-anim-autoplay") ? n.getNamedItem("data-anim-autoplay").value : n.getNamedItem("data-bm-autoplay") ? n.getNamedItem("data-bm-autoplay").value : !n.getNamedItem("bm-autoplay") || n.getNamedItem("bm-autoplay").value;
                    r.autoplay = "false" !== h, r.name = n.getNamedItem("data-name") ? n.getNamedItem("data-name").value : n.getNamedItem("data-bm-name") ? n.getNamedItem("data-bm-name").value : n.getNamedItem("bm-name") ? n.getNamedItem("bm-name").value : "", "false" === (n.getNamedItem("data-anim-prerender") ? n.getNamedItem("data-anim-prerender").value : n.getNamedItem("data-bm-prerender") ? n.getNamedItem("data-bm-prerender").value : n.getNamedItem("bm-prerender") ? n.getNamedItem("bm-prerender").value : "") && (r.prerender = !1), this.setParams(r)
                }, AnimationItem.prototype.includeLayers = function(data) {
                    data.op > this.animationData.op && (this.animationData.op = data.op, this.totalFrames = Math.floor(data.op - this.animationData.ip));
                    var i, t, e = this.animationData.layers,
                        r = e.length,
                        n = data.layers,
                        o = n.length;
                    for (t = 0; t < o; t += 1)
                        for (i = 0; i < r;) {
                            if (e[i].id === n[t].id) {
                                e[i] = n[t];
                                break
                            }
                            i += 1
                        }
                    if ((data.chars || data.fonts) && (this.renderer.globalData.fontManager.addChars(data.chars), this.renderer.globalData.fontManager.addFonts(data.fonts, this.renderer.globalData.defs)), data.assets)
                        for (r = data.assets.length, i = 0; i < r; i += 1) this.animationData.assets.push(data.assets[i]);
                    this.animationData.__complete = !1, dataManager.completeAnimation(this.animationData, this.onSegmentComplete)
                }, AnimationItem.prototype.onSegmentComplete = function(data) {
                    this.animationData = data, expressionsPlugin && expressionsPlugin.initExpressions(this), this.loadNextSegment()
                }, AnimationItem.prototype.loadNextSegment = function() {
                    var t = this.animationData.segments;
                    if (!t || 0 === t.length || !this.autoloadSegments) return this.trigger("data_ready"), void(this.timeCompleted = this.totalFrames);
                    var e = t.shift();
                    this.timeCompleted = e.time * this.frameRate;
                    var r = this.path + this.fileName + "_" + this.segmentPos + ".json";
                    this.segmentPos += 1, dataManager.loadData(r, this.includeLayers.bind(this), function() {
                        this.trigger("data_failed")
                    }.bind(this))
                }, AnimationItem.prototype.loadSegments = function() {
                    this.animationData.segments || (this.timeCompleted = this.totalFrames), this.loadNextSegment()
                }, AnimationItem.prototype.imagesLoaded = function() {
                    this.trigger("loaded_images"), this.checkLoaded()
                }, AnimationItem.prototype.preloadImages = function() {
                    this.imagePreloader.setAssetsPath(this.assetsPath), this.imagePreloader.setPath(this.path), this.imagePreloader.loadAssets(this.animationData.assets, this.imagesLoaded.bind(this))
                }, AnimationItem.prototype.configAnimation = function(t) {
                    if (this.renderer) try {
                        this.animationData = t, this.initialSegment ? (this.totalFrames = Math.floor(this.initialSegment[1] - this.initialSegment[0]), this.firstFrame = Math.round(this.initialSegment[0])) : (this.totalFrames = Math.floor(this.animationData.op - this.animationData.ip), this.firstFrame = Math.round(this.animationData.ip)), this.renderer.configAnimation(t), t.assets || (t.assets = []), this.assets = this.animationData.assets, this.frameRate = this.animationData.fr, this.frameMult = this.animationData.fr / 1e3, this.renderer.searchExtraCompositions(t.assets), this.markers = markerParser(t.markers || []), this.trigger("config_ready"), this.preloadImages(), this.loadSegments(), this.updaFrameModifier(), this.waitForFontsLoaded(), this.isPaused && this.audioController.pause()
                    } catch (t) {
                        this.triggerConfigError(t)
                    }
                }, AnimationItem.prototype.waitForFontsLoaded = function() {
                    this.renderer && (this.renderer.globalData.fontManager.isLoaded ? this.checkLoaded() : setTimeout(this.waitForFontsLoaded.bind(this), 20))
                }, AnimationItem.prototype.checkLoaded = function() {
                    !this.isLoaded && this.renderer.globalData.fontManager.isLoaded && (this.imagePreloader.loadedImages() || "canvas" !== this.renderer.rendererType) && this.imagePreloader.loadedFootages() && (this.isLoaded = !0, expressionsPlugin && expressionsPlugin.initExpressions(this), this.renderer.initItems(), setTimeout(function() {
                        this.trigger("DOMLoaded")
                    }.bind(this), 0), this.gotoFrame(), this.autoplay && this.play())
                }, AnimationItem.prototype.resize = function() {
                    this.renderer.updateContainerSize()
                }, AnimationItem.prototype.setSubframe = function(t) {
                    this.isSubframeEnabled = !!t
                }, AnimationItem.prototype.gotoFrame = function() {
                    this.currentFrame = this.isSubframeEnabled ? this.currentRawFrame : ~~this.currentRawFrame, this.timeCompleted !== this.totalFrames && this.currentFrame > this.timeCompleted && (this.currentFrame = this.timeCompleted), this.trigger("enterFrame"), this.renderFrame(), this.trigger("drawnFrame")
                }, AnimationItem.prototype.renderFrame = function() {
                    if (!1 !== this.isLoaded && this.renderer) try {
                        this.renderer.renderFrame(this.currentFrame + this.firstFrame)
                    } catch (t) {
                        this.triggerRenderFrameError(t)
                    }
                }, AnimationItem.prototype.play = function(t) {
                    t && this.name !== t || !0 === this.isPaused && (this.isPaused = !1, this.audioController.resume(), this._idle && (this._idle = !1, this.trigger("_active")))
                }, AnimationItem.prototype.pause = function(t) {
                    t && this.name !== t || !1 === this.isPaused && (this.isPaused = !0, this._idle = !0, this.trigger("_idle"), this.audioController.pause())
                }, AnimationItem.prototype.togglePause = function(t) {
                    t && this.name !== t || (!0 === this.isPaused ? this.play() : this.pause())
                }, AnimationItem.prototype.stop = function(t) {
                    t && this.name !== t || (this.pause(), this.playCount = 0, this._completedLoop = !1, this.setCurrentRawFrameValue(0))
                }, AnimationItem.prototype.getMarkerData = function(t) {
                    for (var marker, i = 0; i < this.markers.length; i += 1)
                        if ((marker = this.markers[i]).payload && marker.payload.name === t) return marker;
                    return null
                }, AnimationItem.prototype.goToAndStop = function(t, e, r) {
                    if (!r || this.name === r) {
                        var n = Number(t);
                        if (isNaN(n)) {
                            var marker = this.getMarkerData(t);
                            marker && this.goToAndStop(marker.time, !0)
                        } else e ? this.setCurrentRawFrameValue(t) : this.setCurrentRawFrameValue(t * this.frameModifier);
                        this.pause()
                    }
                }, AnimationItem.prototype.goToAndPlay = function(t, e, r) {
                    if (!r || this.name === r) {
                        var n = Number(t);
                        if (isNaN(n)) {
                            var marker = this.getMarkerData(t);
                            marker && (marker.duration ? this.playSegments([marker.time, marker.time + marker.duration], !0) : this.goToAndStop(marker.time, !0))
                        } else this.goToAndStop(n, e, r);
                        this.play()
                    }
                }, AnimationItem.prototype.advanceTime = function(t) {
                    if (!0 !== this.isPaused && !1 !== this.isLoaded) {
                        var e = this.currentRawFrame + t * this.frameModifier,
                            r = !1;
                        e >= this.totalFrames - 1 && this.frameModifier > 0 ? this.loop && this.playCount !== this.loop ? e >= this.totalFrames ? (this.playCount += 1, this.checkSegments(e % this.totalFrames) || (this.setCurrentRawFrameValue(e % this.totalFrames), this._completedLoop = !0, this.trigger("loopComplete"))) : this.setCurrentRawFrameValue(e) : this.checkSegments(e > this.totalFrames ? e % this.totalFrames : 0) || (r = !0, e = this.totalFrames - 1) : e < 0 ? this.checkSegments(e % this.totalFrames) || (!this.loop || this.playCount-- <= 0 && !0 !== this.loop ? (r = !0, e = 0) : (this.setCurrentRawFrameValue(this.totalFrames + e % this.totalFrames), this._completedLoop ? this.trigger("loopComplete") : this._completedLoop = !0)) : this.setCurrentRawFrameValue(e), r && (this.setCurrentRawFrameValue(e), this.pause(), this.trigger("complete"))
                    }
                }, AnimationItem.prototype.adjustSegment = function(t, e) {
                    this.playCount = 0, t[1] < t[0] ? (this.frameModifier > 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(-1)), this.totalFrames = t[0] - t[1], this.timeCompleted = this.totalFrames, this.firstFrame = t[1], this.setCurrentRawFrameValue(this.totalFrames - .001 - e)) : t[1] > t[0] && (this.frameModifier < 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(1)), this.totalFrames = t[1] - t[0], this.timeCompleted = this.totalFrames, this.firstFrame = t[0], this.setCurrentRawFrameValue(.001 + e)), this.trigger("segmentStart")
                }, AnimationItem.prototype.setSegment = function(t, e) {
                    var r = -1;
                    this.isPaused && (this.currentRawFrame + this.firstFrame < t ? r = t : this.currentRawFrame + this.firstFrame > e && (r = e - t)), this.firstFrame = t, this.totalFrames = e - t, this.timeCompleted = this.totalFrames, -1 !== r && this.goToAndStop(r, !0)
                }, AnimationItem.prototype.playSegments = function(t, e) {
                    if (e && (this.segments.length = 0), "object" == typeof t[0]) {
                        var i, r = t.length;
                        for (i = 0; i < r; i += 1) this.segments.push(t[i])
                    } else this.segments.push(t);
                    this.segments.length && e && this.adjustSegment(this.segments.shift(), 0), this.isPaused && this.play()
                }, AnimationItem.prototype.resetSegments = function(t) {
                    this.segments.length = 0, this.segments.push([this.animationData.ip, this.animationData.op]), t && this.checkSegments(0)
                }, AnimationItem.prototype.checkSegments = function(t) {
                    return !!this.segments.length && (this.adjustSegment(this.segments.shift(), t), !0)
                }, AnimationItem.prototype.destroy = function(t) {
                    t && this.name !== t || !this.renderer || (this.renderer.destroy(), this.imagePreloader.destroy(), this.trigger("destroy"), this._cbs = null, this.onEnterFrame = null, this.onLoopComplete = null, this.onComplete = null, this.onSegmentStart = null, this.onDestroy = null, this.renderer = null, this.renderer = null, this.imagePreloader = null, this.projectInterface = null)
                }, AnimationItem.prototype.setCurrentRawFrameValue = function(t) {
                    this.currentRawFrame = t, this.gotoFrame()
                }, AnimationItem.prototype.setSpeed = function(t) {
                    this.playSpeed = t, this.updaFrameModifier()
                }, AnimationItem.prototype.setDirection = function(t) {
                    this.playDirection = t < 0 ? -1 : 1, this.updaFrameModifier()
                }, AnimationItem.prototype.setVolume = function(t, e) {
                    e && this.name !== e || this.audioController.setVolume(t)
                }, AnimationItem.prototype.getVolume = function() {
                    return this.audioController.getVolume()
                }, AnimationItem.prototype.mute = function(t) {
                    t && this.name !== t || this.audioController.mute()
                }, AnimationItem.prototype.unmute = function(t) {
                    t && this.name !== t || this.audioController.unmute()
                }, AnimationItem.prototype.updaFrameModifier = function() {
                    this.frameModifier = this.frameMult * this.playSpeed * this.playDirection, this.audioController.setRate(this.playSpeed * this.playDirection)
                }, AnimationItem.prototype.getPath = function() {
                    return this.path
                }, AnimationItem.prototype.getAssetsPath = function(t) {
                    var path = "";
                    if (t.e) path = t.p;
                    else if (this.assetsPath) {
                        var e = t.p; - 1 !== e.indexOf("images/") && (e = e.split("/")[1]), path = this.assetsPath + e
                    } else path = this.path, path += t.u ? t.u : "", path += t.p;
                    return path
                }, AnimationItem.prototype.getAssetData = function(t) {
                    for (var i = 0, e = this.assets.length; i < e;) {
                        if (t === this.assets[i].id) return this.assets[i];
                        i += 1
                    }
                    return null
                }, AnimationItem.prototype.hide = function() {
                    this.renderer.hide()
                }, AnimationItem.prototype.show = function() {
                    this.renderer.show()
                }, AnimationItem.prototype.getDuration = function(t) {
                    return t ? this.totalFrames : this.totalFrames / this.frameRate
                }, AnimationItem.prototype.trigger = function(t) {
                    if (this._cbs && this._cbs[t]) switch (t) {
                        case "enterFrame":
                        case "drawnFrame":
                            this.triggerEvent(t, new BMEnterFrameEvent(t, this.currentFrame, this.totalFrames, this.frameModifier));
                            break;
                        case "loopComplete":
                            this.triggerEvent(t, new BMCompleteLoopEvent(t, this.loop, this.playCount, this.frameMult));
                            break;
                        case "complete":
                            this.triggerEvent(t, new BMCompleteEvent(t, this.frameMult));
                            break;
                        case "segmentStart":
                            this.triggerEvent(t, new BMSegmentStartEvent(t, this.firstFrame, this.totalFrames));
                            break;
                        case "destroy":
                            this.triggerEvent(t, new BMDestroyEvent(t, this));
                            break;
                        default:
                            this.triggerEvent(t)
                    }
                    "enterFrame" === t && this.onEnterFrame && this.onEnterFrame.call(this, new BMEnterFrameEvent(t, this.currentFrame, this.totalFrames, this.frameMult)), "loopComplete" === t && this.onLoopComplete && this.onLoopComplete.call(this, new BMCompleteLoopEvent(t, this.loop, this.playCount, this.frameMult)), "complete" === t && this.onComplete && this.onComplete.call(this, new BMCompleteEvent(t, this.frameMult)), "segmentStart" === t && this.onSegmentStart && this.onSegmentStart.call(this, new BMSegmentStartEvent(t, this.firstFrame, this.totalFrames)), "destroy" === t && this.onDestroy && this.onDestroy.call(this, new BMDestroyEvent(t, this))
                }, AnimationItem.prototype.triggerRenderFrameError = function(t) {
                    var e = new BMRenderFrameErrorEvent(t, this.currentFrame);
                    this.triggerEvent("error", e), this.onError && this.onError.call(this, e)
                }, AnimationItem.prototype.triggerConfigError = function(t) {
                    var e = new BMConfigErrorEvent(t, this.currentFrame);
                    this.triggerEvent("error", e), this.onError && this.onError.call(this, e)
                };
                var Expressions = function() {
                    var t = {
                        initExpressions: function(t) {
                            var e = 0,
                                r = [];
                            t.renderer.compInterface = CompExpressionInterface(t.renderer), t.renderer.globalData.projectInterface.registerComposition(t.renderer), t.renderer.globalData.pushExpression = function() {
                                e += 1
                            }, t.renderer.globalData.popExpression = function() {
                                0 == (e -= 1) && function() {
                                    var i, t = r.length;
                                    for (i = 0; i < t; i += 1) r[i].release();
                                    r.length = 0
                                }()
                            }, t.renderer.globalData.registerExpressionProperty = function(t) {
                                -1 === r.indexOf(t) && r.push(t)
                            }
                        }
                    };
                    return t
                }();
                expressionsPlugin = Expressions;
                var ExpressionManager = function() {
                        var ob = {},
                            Math = BMMath,
                            window = null,
                            document = null,
                            XMLHttpRequest = null,
                            fetch = null,
                            frames = null;

                        function $bm_isInstanceOfArray(t) {
                            return t.constructor === Array || t.constructor === Float32Array
                        }

                        function isNumerable(t, e) {
                            return "number" === t || "boolean" === t || "string" === t || e instanceof Number
                        }

                        function $bm_neg(a) {
                            var t = typeof a;
                            if ("number" === t || "boolean" === t || a instanceof Number) return -a;
                            if ($bm_isInstanceOfArray(a)) {
                                var i, e = a.length,
                                    r = [];
                                for (i = 0; i < e; i += 1) r[i] = -a[i];
                                return r
                            }
                            return a.propType ? a.v : -a
                        }
                        var easeInBez = BezierFactory.getBezierEasing(.333, 0, .833, .833, "easeIn").get,
                            easeOutBez = BezierFactory.getBezierEasing(.167, .167, .667, 1, "easeOut").get,
                            easeInOutBez = BezierFactory.getBezierEasing(.33, 0, .667, 1, "easeInOut").get;

                        function sum(a, b) {
                            var t = typeof a,
                                e = typeof b;
                            if ("string" === t || "string" === e) return a + b;
                            if (isNumerable(t, a) && isNumerable(e, b)) return a + b;
                            if ($bm_isInstanceOfArray(a) && isNumerable(e, b)) return (a = a.slice(0))[0] += b, a;
                            if (isNumerable(t, a) && $bm_isInstanceOfArray(b)) return (b = b.slice(0))[0] = a + b[0], b;
                            if ($bm_isInstanceOfArray(a) && $bm_isInstanceOfArray(b)) {
                                for (var i = 0, r = a.length, n = b.length, o = []; i < r || i < n;)("number" == typeof a[i] || a[i] instanceof Number) && ("number" == typeof b[i] || b[i] instanceof Number) ? o[i] = a[i] + b[i] : o[i] = void 0 === b[i] ? a[i] : a[i] || b[i], i += 1;
                                return o
                            }
                            return 0
                        }
                        var add = sum;

                        function sub(a, b) {
                            var t = typeof a,
                                e = typeof b;
                            if (isNumerable(t, a) && isNumerable(e, b)) return "string" === t && (a = parseInt(a, 10)), "string" === e && (b = parseInt(b, 10)), a - b;
                            if ($bm_isInstanceOfArray(a) && isNumerable(e, b)) return (a = a.slice(0))[0] -= b, a;
                            if (isNumerable(t, a) && $bm_isInstanceOfArray(b)) return (b = b.slice(0))[0] = a - b[0], b;
                            if ($bm_isInstanceOfArray(a) && $bm_isInstanceOfArray(b)) {
                                for (var i = 0, r = a.length, n = b.length, o = []; i < r || i < n;)("number" == typeof a[i] || a[i] instanceof Number) && ("number" == typeof b[i] || b[i] instanceof Number) ? o[i] = a[i] - b[i] : o[i] = void 0 === b[i] ? a[i] : a[i] || b[i], i += 1;
                                return o
                            }
                            return 0
                        }

                        function mul(a, b) {
                            var t, i, e, r = typeof a,
                                n = typeof b;
                            if (isNumerable(r, a) && isNumerable(n, b)) return a * b;
                            if ($bm_isInstanceOfArray(a) && isNumerable(n, b)) {
                                for (e = a.length, t = createTypedArray("float32", e), i = 0; i < e; i += 1) t[i] = a[i] * b;
                                return t
                            }
                            if (isNumerable(r, a) && $bm_isInstanceOfArray(b)) {
                                for (e = b.length, t = createTypedArray("float32", e), i = 0; i < e; i += 1) t[i] = a * b[i];
                                return t
                            }
                            return 0
                        }

                        function div(a, b) {
                            var t, i, e, r = typeof a,
                                n = typeof b;
                            if (isNumerable(r, a) && isNumerable(n, b)) return a / b;
                            if ($bm_isInstanceOfArray(a) && isNumerable(n, b)) {
                                for (e = a.length, t = createTypedArray("float32", e), i = 0; i < e; i += 1) t[i] = a[i] / b;
                                return t
                            }
                            if (isNumerable(r, a) && $bm_isInstanceOfArray(b)) {
                                for (e = b.length, t = createTypedArray("float32", e), i = 0; i < e; i += 1) t[i] = a / b[i];
                                return t
                            }
                            return 0
                        }

                        function mod(a, b) {
                            return "string" == typeof a && (a = parseInt(a, 10)), "string" == typeof b && (b = parseInt(b, 10)), a % b
                        }
                        var $bm_sum = sum,
                            $bm_sub = sub,
                            $bm_mul = mul,
                            $bm_div = div,
                            $bm_mod = mod;

                        function clamp(t, e, r) {
                            if (e > r) {
                                var n = r;
                                r = e, e = n
                            }
                            return Math.min(Math.max(t, e), r)
                        }

                        function radiansToDegrees(t) {
                            return t / degToRads
                        }
                        var radians_to_degrees = radiansToDegrees;

                        function degreesToRadians(t) {
                            return t * degToRads
                        }
                        var degrees_to_radians = radiansToDegrees,
                            helperLengthArray = [0, 0, 0, 0, 0, 0];

                        function length(t, e) {
                            if ("number" == typeof t || t instanceof Number) return e = e || 0, Math.abs(t - e);
                            var i;
                            e || (e = helperLengthArray);
                            var r = Math.min(t.length, e.length),
                                n = 0;
                            for (i = 0; i < r; i += 1) n += Math.pow(e[i] - t[i], 2);
                            return Math.sqrt(n)
                        }

                        function normalize(t) {
                            return div(t, length(t))
                        }

                        function rgbToHsl(t) {
                            var e, s, r = t[0],
                                g = t[1],
                                b = t[2],
                                n = Math.max(r, g, b),
                                o = Math.min(r, g, b),
                                h = (n + o) / 2;
                            if (n === o) e = 0, s = 0;
                            else {
                                var l = n - o;
                                switch (s = h > .5 ? l / (2 - n - o) : l / (n + o), n) {
                                    case r:
                                        e = (g - b) / l + (g < b ? 6 : 0);
                                        break;
                                    case g:
                                        e = (b - r) / l + 2;
                                        break;
                                    case b:
                                        e = (r - g) / l + 4
                                }
                                e /= 6
                            }
                            return [e, s, h, t[3]]
                        }

                        function hue2rgb(p, q, t) {
                            return t < 0 && (t += 1), t > 1 && (t -= 1), t < 1 / 6 ? p + 6 * (q - p) * t : t < .5 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p
                        }

                        function hslToRgb(t) {
                            var e, g, b, r = t[0],
                                s = t[1],
                                n = t[2];
                            if (0 === s) e = n, b = n, g = n;
                            else {
                                var q = n < .5 ? n * (1 + s) : n + s - n * s,
                                    p = 2 * n - q;
                                e = hue2rgb(p, q, r + 1 / 3), g = hue2rgb(p, q, r), b = hue2rgb(p, q, r - 1 / 3)
                            }
                            return [e, g, b, t[3]]
                        }

                        function linear(t, e, r, n, o) {
                            if (void 0 !== n && void 0 !== o || (n = e, o = r, e = 0, r = 1), r < e) {
                                var h = r;
                                r = e, e = h
                            }
                            if (t <= e) return n;
                            if (t >= r) return o;
                            var i, l = r === e ? 0 : (t - e) / (r - e);
                            if (!n.length) return n + (o - n) * l;
                            var m = n.length,
                                f = createTypedArray("float32", m);
                            for (i = 0; i < m; i += 1) f[i] = n[i] + (o[i] - n[i]) * l;
                            return f
                        }

                        function random(t, e) {
                            if (void 0 === e && (void 0 === t ? (t = 0, e = 1) : (e = t, t = void 0)), e.length) {
                                var i, r = e.length;
                                t || (t = createTypedArray("float32", r));
                                var n = createTypedArray("float32", r),
                                    o = BMMath.random();
                                for (i = 0; i < r; i += 1) n[i] = t[i] + o * (e[i] - t[i]);
                                return n
                            }
                            return void 0 === t && (t = 0), t + BMMath.random() * (e - t)
                        }

                        function createPath(t, e, r, n) {
                            var i, o = t.length,
                                path = shapePool.newElement();
                            path.setPathData(!!n, o);
                            var h, l, m = [0, 0];
                            for (i = 0; i < o; i += 1) h = e && e[i] ? e[i] : m, l = r && r[i] ? r[i] : m, path.setTripleAt(t[i][0], t[i][1], l[0] + t[i][0], l[1] + t[i][1], h[0] + t[i][0], h[1] + t[i][1], i, !0);
                            return path
                        }

                        function initiateExpression(elem, data, property) {
                            var val = data.x,
                                needsVelocity = /velocity(?![\w\d])/.test(val),
                                _needsRandom = -1 !== val.indexOf("random"),
                                elemType = elem.data.ty,
                                transform, $bm_transform, content, effect, thisProperty = property;
                            thisProperty.valueAtTime = thisProperty.getValueAtTime, Object.defineProperty(thisProperty, "value", {
                                get: function() {
                                    return thisProperty.v
                                }
                            }), elem.comp.frameDuration = 1 / elem.comp.globalData.frameRate, elem.comp.displayStartTime = 0;
                            var inPoint = elem.data.ip / elem.comp.globalData.frameRate,
                                outPoint = elem.data.op / elem.comp.globalData.frameRate,
                                width = elem.data.sw ? elem.data.sw : 0,
                                height = elem.data.sh ? elem.data.sh : 0,
                                name = elem.data.nm,
                                loopIn, loop_in, loopOut, loop_out, smooth, toWorld, fromWorld, fromComp, toComp, fromCompToSurface, position, rotation, anchorPoint, scale, thisLayer, thisComp, mask, valueAtTime, velocityAtTime, scoped_bm_rt, expression_function = eval("[function _expression_function(){" + val + ";scoped_bm_rt=$bm_rt}]")[0],
                                numKeys = property.kf ? data.k.length : 0,
                                active = !this.data || !0 !== this.data.hd,
                                wiggle = function(t, e) {
                                    var r, n, o = this.pv.length ? this.pv.length : 1,
                                        h = createTypedArray("float32", o),
                                        l = Math.floor(5 * time);
                                    for (r = 0, n = 0; r < l;) {
                                        for (n = 0; n < o; n += 1) h[n] += -e + 2 * e * BMMath.random();
                                        r += 1
                                    }
                                    var m = 5 * time,
                                        f = m - Math.floor(m),
                                        c = createTypedArray("float32", o);
                                    if (o > 1) {
                                        for (n = 0; n < o; n += 1) c[n] = this.pv[n] + h[n] + (-e + 2 * e * BMMath.random()) * f;
                                        return c
                                    }
                                    return this.pv + h[0] + (-e + 2 * e * BMMath.random()) * f
                                }.bind(this);

                            function loopInDuration(t, e) {
                                return loopIn(t, e, !0)
                            }

                            function loopOutDuration(t, e) {
                                return loopOut(t, e, !0)
                            }
                            thisProperty.loopIn && (loopIn = thisProperty.loopIn.bind(thisProperty), loop_in = loopIn), thisProperty.loopOut && (loopOut = thisProperty.loopOut.bind(thisProperty), loop_out = loopOut), thisProperty.smooth && (smooth = thisProperty.smooth.bind(thisProperty)), this.getValueAtTime && (valueAtTime = this.getValueAtTime.bind(this)), this.getVelocityAtTime && (velocityAtTime = this.getVelocityAtTime.bind(this));
                            var comp = elem.comp.globalData.projectInterface.bind(elem.comp.globalData.projectInterface),
                                time, velocity, value, text, textIndex, textTotal, selectorValue;

                            function lookAt(t, e) {
                                var r = [e[0] - t[0], e[1] - t[1], e[2] - t[2]],
                                    n = Math.atan2(r[0], Math.sqrt(r[1] * r[1] + r[2] * r[2])) / degToRads;
                                return [-Math.atan2(r[1], r[2]) / degToRads, n, 0]
                            }

                            function easeOut(t, e, r, n, o) {
                                return applyEase(easeOutBez, t, e, r, n, o)
                            }

                            function easeIn(t, e, r, n, o) {
                                return applyEase(easeInBez, t, e, r, n, o)
                            }

                            function ease(t, e, r, n, o) {
                                return applyEase(easeInOutBez, t, e, r, n, o)
                            }

                            function applyEase(t, e, r, n, o, h) {
                                void 0 === o ? (o = r, h = n) : e = (e - r) / (n - r), e > 1 ? e = 1 : e < 0 && (e = 0);
                                var l = t(e);
                                if ($bm_isInstanceOfArray(o)) {
                                    var m, f = o.length,
                                        c = createTypedArray("float32", f);
                                    for (m = 0; m < f; m += 1) c[m] = (h[m] - o[m]) * l + o[m];
                                    return c
                                }
                                return (h - o) * l + o
                            }

                            function nearestKey(time) {
                                var t, e, r, n = data.k.length;
                                if (data.k.length && "number" != typeof data.k[0])
                                    if (e = -1, (time *= elem.comp.globalData.frameRate) < data.k[0].t) e = 1, r = data.k[0].t;
                                    else {
                                        for (t = 0; t < n - 1; t += 1) {
                                            if (time === data.k[t].t) {
                                                e = t + 1, r = data.k[t].t;
                                                break
                                            }
                                            if (time > data.k[t].t && time < data.k[t + 1].t) {
                                                time - data.k[t].t > data.k[t + 1].t - time ? (e = t + 2, r = data.k[t + 1].t) : (e = t + 1, r = data.k[t].t);
                                                break
                                            }
                                        } - 1 === e && (e = t + 1, r = data.k[t].t)
                                    }
                                else e = 0, r = 0;
                                var o = {};
                                return o.index = e, o.time = r / elem.comp.globalData.frameRate, o
                            }

                            function key(t) {
                                var e, r, n;
                                if (!data.k.length || "number" == typeof data.k[0]) throw new Error("The property has no keyframe at index " + t);
                                t -= 1, e = {
                                    time: data.k[t].t / elem.comp.globalData.frameRate,
                                    value: []
                                };
                                var o = Object.prototype.hasOwnProperty.call(data.k[t], "s") ? data.k[t].s : data.k[t - 1].e;
                                for (n = o.length, r = 0; r < n; r += 1) e[r] = o[r], e.value[r] = o[r];
                                return e
                            }

                            function framesToTime(t, e) {
                                return e || (e = elem.comp.globalData.frameRate), t / e
                            }

                            function timeToFrames(t, e) {
                                return t || 0 === t || (t = time), e || (e = elem.comp.globalData.frameRate), t * e
                            }

                            function seedRandom(t) {
                                BMMath.seedrandom(randSeed + t)
                            }

                            function sourceRectAtTime() {
                                return elem.sourceRectAtTime()
                            }

                            function substring(t, e) {
                                return "string" == typeof value ? void 0 === e ? value.substring(t) : value.substring(t, e) : ""
                            }

                            function substr(t, e) {
                                return "string" == typeof value ? void 0 === e ? value.substr(t) : value.substr(t, e) : ""
                            }

                            function posterizeTime(t) {
                                time = 0 === t ? 0 : Math.floor(time * t) / t, value = valueAtTime(time)
                            }
                            var index = elem.data.ind,
                                hasParent = !(!elem.hierarchy || !elem.hierarchy.length),
                                parent, randSeed = Math.floor(1e6 * Math.random()),
                                globalData = elem.globalData;

                            function executeExpression(t) {
                                return value = t, this.frameExpressionId === elem.globalData.frameId && "textSelector" !== this.propType ? value : ("textSelector" === this.propType && (textIndex = this.textIndex, textTotal = this.textTotal, selectorValue = this.selectorValue), thisLayer || (text = elem.layerInterface.text, thisLayer = elem.layerInterface, thisComp = elem.comp.compInterface, toWorld = thisLayer.toWorld.bind(thisLayer), fromWorld = thisLayer.fromWorld.bind(thisLayer), fromComp = thisLayer.fromComp.bind(thisLayer), toComp = thisLayer.toComp.bind(thisLayer), mask = thisLayer.mask ? thisLayer.mask.bind(thisLayer) : null, fromCompToSurface = fromComp), transform || (transform = elem.layerInterface("ADBE Transform Group"), $bm_transform = transform, transform && (anchorPoint = transform.anchorPoint)), 4 !== elemType || content || (content = thisLayer("ADBE Root Vectors Group")), effect || (effect = thisLayer(4)), (hasParent = !(!elem.hierarchy || !elem.hierarchy.length)) && !parent && (parent = elem.hierarchy[0].layerInterface), time = this.comp.renderedFrame / this.comp.globalData.frameRate, _needsRandom && seedRandom(randSeed + time), needsVelocity && (velocity = velocityAtTime(time)), expression_function(), this.frameExpressionId = elem.globalData.frameId, "shape" === scoped_bm_rt.propType && (scoped_bm_rt = scoped_bm_rt.v), scoped_bm_rt)
                            }
                            return executeExpression
                        }
                        return ob.initiateExpression = initiateExpression, ob
                    }(),
                    expressionHelpers = {
                        searchExpressions: function(t, data, e) {
                            data.x && (e.k = !0, e.x = !0, e.initiateExpression = ExpressionManager.initiateExpression, e.effectsSequence.push(e.initiateExpression(t, data, e).bind(e)))
                        },
                        getSpeedAtTime: function(t) {
                            var e = this.getValueAtTime(t),
                                r = this.getValueAtTime(t + -.01),
                                n = 0;
                            if (e.length) {
                                var i;
                                for (i = 0; i < e.length; i += 1) n += Math.pow(r[i] - e[i], 2);
                                n = 100 * Math.sqrt(n)
                            } else n = 0;
                            return n
                        },
                        getVelocityAtTime: function(t) {
                            if (void 0 !== this.vel) return this.vel;
                            var e, i, r = -.001,
                                n = this.getValueAtTime(t),
                                o = this.getValueAtTime(t + r);
                            if (n.length)
                                for (e = createTypedArray("float32", n.length), i = 0; i < n.length; i += 1) e[i] = (o[i] - n[i]) / r;
                            else e = (o - n) / r;
                            return e
                        },
                        getValueAtTime: function(t) {
                            return t *= this.elem.globalData.frameRate, (t -= this.offsetTime) !== this._cachingAtTime.lastFrame && (this._cachingAtTime.lastIndex = this._cachingAtTime.lastFrame < t ? this._cachingAtTime.lastIndex : 0, this._cachingAtTime.value = this.interpolateValue(t, this._cachingAtTime), this._cachingAtTime.lastFrame = t), this._cachingAtTime.value
                        },
                        getStaticValueAtTime: function() {
                            return this.pv
                        },
                        setGroupProperty: function(t) {
                            this.propertyGroup = t
                        }
                    };
                ! function() {
                    function t(t, e, r) {
                        if (!this.k || !this.keyframes) return this.pv;
                        t = t ? t.toLowerCase() : "";
                        var n, o, i, h, l, m = this.comp.renderedFrame,
                            f = this.keyframes,
                            c = f[f.length - 1].t;
                        if (m <= c) return this.pv;
                        if (r ? o = c - (n = e ? Math.abs(c - this.elem.comp.globalData.frameRate * e) : Math.max(0, c - this.elem.data.ip)) : ((!e || e > f.length - 1) && (e = f.length - 1), n = c - (o = f[f.length - 1 - e].t)), "pingpong" === t) {
                            if (Math.floor((m - o) / n) % 2 != 0) return this.getValueAtTime((n - (m - o) % n + o) / this.comp.globalData.frameRate, 0)
                        } else {
                            if ("offset" === t) {
                                var d = this.getValueAtTime(o / this.comp.globalData.frameRate, 0),
                                    y = this.getValueAtTime(c / this.comp.globalData.frameRate, 0),
                                    v = this.getValueAtTime(((m - o) % n + o) / this.comp.globalData.frameRate, 0),
                                    P = Math.floor((m - o) / n);
                                if (this.pv.length) {
                                    for (h = (l = new Array(d.length)).length, i = 0; i < h; i += 1) l[i] = (y[i] - d[i]) * P + v[i];
                                    return l
                                }
                                return (y - d) * P + v
                            }
                            if ("continue" === t) {
                                var E = this.getValueAtTime(c / this.comp.globalData.frameRate, 0),
                                    x = this.getValueAtTime((c - .001) / this.comp.globalData.frameRate, 0);
                                if (this.pv.length) {
                                    for (h = (l = new Array(E.length)).length, i = 0; i < h; i += 1) l[i] = E[i] + (E[i] - x[i]) * ((m - c) / this.comp.globalData.frameRate) / 5e-4;
                                    return l
                                }
                                return E + (m - c) / .001 * (E - x)
                            }
                        }
                        return this.getValueAtTime(((m - o) % n + o) / this.comp.globalData.frameRate, 0)
                    }

                    function e(t, e, r) {
                        if (!this.k) return this.pv;
                        t = t ? t.toLowerCase() : "";
                        var n, o, i, h, l, m = this.comp.renderedFrame,
                            f = this.keyframes,
                            c = f[0].t;
                        if (m >= c) return this.pv;
                        if (r ? o = c + (n = e ? Math.abs(this.elem.comp.globalData.frameRate * e) : Math.max(0, this.elem.data.op - c)) : ((!e || e > f.length - 1) && (e = f.length - 1), n = (o = f[e].t) - c), "pingpong" === t) {
                            if (Math.floor((c - m) / n) % 2 == 0) return this.getValueAtTime(((c - m) % n + c) / this.comp.globalData.frameRate, 0)
                        } else {
                            if ("offset" === t) {
                                var d = this.getValueAtTime(c / this.comp.globalData.frameRate, 0),
                                    y = this.getValueAtTime(o / this.comp.globalData.frameRate, 0),
                                    v = this.getValueAtTime((n - (c - m) % n + c) / this.comp.globalData.frameRate, 0),
                                    P = Math.floor((c - m) / n) + 1;
                                if (this.pv.length) {
                                    for (h = (l = new Array(d.length)).length, i = 0; i < h; i += 1) l[i] = v[i] - (y[i] - d[i]) * P;
                                    return l
                                }
                                return v - (y - d) * P
                            }
                            if ("continue" === t) {
                                var E = this.getValueAtTime(c / this.comp.globalData.frameRate, 0),
                                    x = this.getValueAtTime((c + .001) / this.comp.globalData.frameRate, 0);
                                if (this.pv.length) {
                                    for (h = (l = new Array(E.length)).length, i = 0; i < h; i += 1) l[i] = E[i] + (E[i] - x[i]) * (c - m) / .001;
                                    return l
                                }
                                return E + (E - x) * (c - m) / .001
                            }
                        }
                        return this.getValueAtTime((n - ((c - m) % n + c)) / this.comp.globalData.frameRate, 0)
                    }

                    function r(t, e) {
                        if (!this.k) return this.pv;
                        if (t = .5 * (t || .4), (e = Math.floor(e || 5)) <= 1) return this.pv;
                        var r, n, o = this.comp.renderedFrame / this.comp.globalData.frameRate,
                            h = o - t,
                            l = e > 1 ? (o + t - h) / (e - 1) : 1,
                            i = 0,
                            m = 0;
                        for (r = this.pv.length ? createTypedArray("float32", this.pv.length) : 0; i < e;) {
                            if (n = this.getValueAtTime(h + i * l), this.pv.length)
                                for (m = 0; m < this.pv.length; m += 1) r[m] += n[m];
                            else r += n;
                            i += 1
                        }
                        if (this.pv.length)
                            for (m = 0; m < this.pv.length; m += 1) r[m] /= e;
                        else r /= e;
                        return r
                    }

                    function n(time) {
                        this._transformCachingAtTime || (this._transformCachingAtTime = {
                            v: new Matrix
                        });
                        var t = this._transformCachingAtTime.v;
                        if (t.cloneFromProps(this.pre.props), this.appliedTransformations < 1) {
                            var e = this.a.getValueAtTime(time);
                            t.translate(-e[0] * this.a.mult, -e[1] * this.a.mult, e[2] * this.a.mult)
                        }
                        if (this.appliedTransformations < 2) {
                            var r = this.s.getValueAtTime(time);
                            t.scale(r[0] * this.s.mult, r[1] * this.s.mult, r[2] * this.s.mult)
                        }
                        if (this.sk && this.appliedTransformations < 3) {
                            var n = this.sk.getValueAtTime(time),
                                o = this.sa.getValueAtTime(time);
                            t.skewFromAxis(-n * this.sk.mult, o * this.sa.mult)
                        }
                        if (this.r && this.appliedTransformations < 4) {
                            var h = this.r.getValueAtTime(time);
                            t.rotate(-h * this.r.mult)
                        } else if (!this.r && this.appliedTransformations < 4) {
                            var l = this.rz.getValueAtTime(time),
                                m = this.ry.getValueAtTime(time),
                                f = this.rx.getValueAtTime(time),
                                c = this.or.getValueAtTime(time);
                            t.rotateZ(-l * this.rz.mult).rotateY(m * this.ry.mult).rotateX(f * this.rx.mult).rotateZ(-c[2] * this.or.mult).rotateY(c[1] * this.or.mult).rotateX(c[0] * this.or.mult)
                        }
                        if (this.data.p && this.data.p.s) {
                            var d = this.px.getValueAtTime(time),
                                y = this.py.getValueAtTime(time);
                            if (this.data.p.z) {
                                var v = this.pz.getValueAtTime(time);
                                t.translate(d * this.px.mult, y * this.py.mult, -v * this.pz.mult)
                            } else t.translate(d * this.px.mult, y * this.py.mult, 0)
                        } else {
                            var P = this.p.getValueAtTime(time);
                            t.translate(P[0] * this.p.mult, P[1] * this.p.mult, -P[2] * this.p.mult)
                        }
                        return t
                    }

                    function o() {
                        return this.v.clone(new Matrix)
                    }
                    var h = TransformPropertyFactory.getTransformProperty;
                    TransformPropertyFactory.getTransformProperty = function(t, data, e) {
                        var r = h(t, data, e);
                        return r.dynamicProperties.length ? r.getValueAtTime = n.bind(r) : r.getValueAtTime = o.bind(r), r.setGroupProperty = expressionHelpers.setGroupProperty, r
                    };
                    var l = PropertyFactory.getProp;
                    PropertyFactory.getProp = function(n, data, o, h, m) {
                        var f = l(n, data, o, h, m);
                        f.kf ? f.getValueAtTime = expressionHelpers.getValueAtTime.bind(f) : f.getValueAtTime = expressionHelpers.getStaticValueAtTime.bind(f), f.setGroupProperty = expressionHelpers.setGroupProperty, f.loopOut = t, f.loopIn = e, f.smooth = r, f.getVelocityAtTime = expressionHelpers.getVelocityAtTime.bind(f), f.getSpeedAtTime = expressionHelpers.getSpeedAtTime.bind(f), f.numKeys = 1 === data.a ? data.k.length : 0, f.propertyIndex = data.ix;
                        var c = 0;
                        return 0 !== o && (c = createTypedArray("float32", 1 === data.a ? data.k[0].s.length : data.k.length)), f._cachingAtTime = {
                            lastFrame: initialDefaultFrame,
                            lastIndex: 0,
                            value: c
                        }, expressionHelpers.searchExpressions(n, data, f), f.k && m.addDynamicProperty(f), f
                    };
                    var m = ShapePropertyFactory.getConstructorFunction(),
                        f = ShapePropertyFactory.getKeyframedConstructorFunction();

                    function c() {}
                    c.prototype = {
                        vertices: function(t, time) {
                            this.k && this.getValue();
                            var i, e = this.v;
                            void 0 !== time && (e = this.getValueAtTime(time, 0));
                            var r = e._length,
                                n = e[t],
                                o = e.v,
                                h = createSizedArray(r);
                            for (i = 0; i < r; i += 1) h[i] = "i" === t || "o" === t ? [n[i][0] - o[i][0], n[i][1] - o[i][1]] : [n[i][0], n[i][1]];
                            return h
                        },
                        points: function(time) {
                            return this.vertices("v", time)
                        },
                        inTangents: function(time) {
                            return this.vertices("i", time)
                        },
                        outTangents: function(time) {
                            return this.vertices("o", time)
                        },
                        isClosed: function() {
                            return this.v.c
                        },
                        pointOnPath: function(t, time) {
                            var e = this.v;
                            void 0 !== time && (e = this.getValueAtTime(time, 0)), this._segmentsLength || (this._segmentsLength = bez.getSegmentsLength(e));
                            for (var r, n = this._segmentsLength, o = n.lengths, h = n.totalLength * t, i = 0, l = o.length, m = 0; i < l;) {
                                if (m + o[i].addedLength > h) {
                                    var f = i,
                                        c = e.c && i === l - 1 ? 0 : i + 1,
                                        d = (h - m) / o[i].addedLength;
                                    r = bez.getPointInSegment(e.v[f], e.v[c], e.o[f], e.i[c], d, o[i]);
                                    break
                                }
                                m += o[i].addedLength, i += 1
                            }
                            return r || (r = e.c ? [e.v[0][0], e.v[0][1]] : [e.v[e._length - 1][0], e.v[e._length - 1][1]]), r
                        },
                        vectorOnPath: function(t, time, e) {
                            1 == t ? t = this.v.c : 0 == t && (t = .999);
                            var r = this.pointOnPath(t, time),
                                n = this.pointOnPath(t + .001, time),
                                o = n[0] - r[0],
                                h = n[1] - r[1],
                                l = Math.sqrt(Math.pow(o, 2) + Math.pow(h, 2));
                            return 0 === l ? [0, 0] : "tangent" === e ? [o / l, h / l] : [-h / l, o / l]
                        },
                        tangentOnPath: function(t, time) {
                            return this.vectorOnPath(t, time, "tangent")
                        },
                        normalOnPath: function(t, time) {
                            return this.vectorOnPath(t, time, "normal")
                        },
                        setGroupProperty: expressionHelpers.setGroupProperty,
                        getValueAtTime: expressionHelpers.getStaticValueAtTime
                    }, extendPrototype([c], m), extendPrototype([c], f), f.prototype.getValueAtTime = function(t) {
                        return this._cachingAtTime || (this._cachingAtTime = {
                            shapeValue: shapePool.clone(this.pv),
                            lastIndex: 0,
                            lastTime: initialDefaultFrame
                        }), t *= this.elem.globalData.frameRate, (t -= this.offsetTime) !== this._cachingAtTime.lastTime && (this._cachingAtTime.lastIndex = this._cachingAtTime.lastTime < t ? this._caching.lastIndex : 0, this._cachingAtTime.lastTime = t, this.interpolateShape(t, this._cachingAtTime.shapeValue, this._cachingAtTime)), this._cachingAtTime.shapeValue
                    }, f.prototype.initiateExpression = ExpressionManager.initiateExpression;
                    var d = ShapePropertyFactory.getShapeProp;
                    ShapePropertyFactory.getShapeProp = function(t, data, e, r, n) {
                        var o = d(t, data, e, r, n);
                        return o.propertyIndex = data.ix, o.lock = !1, 3 === e ? expressionHelpers.searchExpressions(t, data.pt, o) : 4 === e && expressionHelpers.searchExpressions(t, data.ks, o), o.k && t.addDynamicProperty(o), o
                    }
                }(), TextProperty.prototype.getExpressionValue = function(t, text) {
                    var e = this.calculateExpression(text);
                    if (t.t !== e) {
                        var r = {};
                        return this.copyData(r, t), r.t = e.toString(), r.__complete = !1, r
                    }
                    return t
                }, TextProperty.prototype.searchProperty = function() {
                    var t = this.searchKeyframes(),
                        e = this.searchExpressions();
                    return this.kf = t || e, this.kf
                }, TextProperty.prototype.searchExpressions = function() {
                    return this.data.d.x ? (this.calculateExpression = ExpressionManager.initiateExpression.bind(this)(this.elem, this.data.d, this), this.addEffect(this.getExpressionValue.bind(this)), !0) : null
                };
                var ShapePathInterface = function(t, view, e) {
                        var r = view.sh;

                        function n(t) {
                            return "Shape" === t || "shape" === t || "Path" === t || "path" === t || "ADBE Vector Shape" === t || 2 === t ? n.path : null
                        }
                        var o = propertyGroupFactory(n, e);
                        return r.setGroupProperty(PropertyInterface("Path", o)), Object.defineProperties(n, {
                            path: {
                                get: function() {
                                    return r.k && r.getValue(), r
                                }
                            },
                            shape: {
                                get: function() {
                                    return r.k && r.getValue(), r
                                }
                            },
                            _name: {
                                value: t.nm
                            },
                            ix: {
                                value: t.ix
                            },
                            propertyIndex: {
                                value: t.ix
                            },
                            mn: {
                                value: t.mn
                            },
                            propertyGroup: {
                                value: e
                            }
                        }), n
                    },
                    propertyGroupFactory = function(t, e) {
                        return function(r) {
                            return (r = void 0 === r ? 1 : r) <= 0 ? t : e(r - 1)
                        }
                    },
                    PropertyInterface = function(t, e) {
                        var r = {
                            _name: t
                        };
                        return function(t) {
                            return (t = void 0 === t ? 1 : t) <= 0 ? r : e(t - 1)
                        }
                    },
                    ShapeExpressionInterface = function() {
                        function t(t, view, l) {
                            var i, v = [],
                                P = t ? t.length : 0;
                            for (i = 0; i < P; i += 1) "gr" === t[i].ty ? v.push(e(t[i], view[i], l)) : "fl" === t[i].ty ? v.push(r(t[i], view[i], l)) : "st" === t[i].ty ? v.push(o(t[i], view[i], l)) : "tm" === t[i].ty ? v.push(h(t[i], view[i], l)) : "tr" === t[i].ty || ("el" === t[i].ty ? v.push(m(t[i], view[i], l)) : "sr" === t[i].ty ? v.push(f(t[i], view[i], l)) : "sh" === t[i].ty ? v.push(ShapePathInterface(t[i], view[i], l)) : "rc" === t[i].ty ? v.push(c(t[i], view[i], l)) : "rd" === t[i].ty ? v.push(d(t[i], view[i], l)) : "rp" === t[i].ty ? v.push(y(t[i], view[i], l)) : "gf" === t[i].ty ? v.push(n(t[i], view[i], l)) : v.push((t[i], view[i], function() {
                                return null
                            })));
                            return v
                        }

                        function e(e, view, r) {
                            var n = function(t) {
                                switch (t) {
                                    case "ADBE Vectors Group":
                                    case "Contents":
                                    case 2:
                                        return n.content;
                                    default:
                                        return n.transform
                                }
                            };
                            n.propertyGroup = propertyGroupFactory(n, r);
                            var content = function(e, view, r) {
                                    var n, o = function(t) {
                                        for (var i = 0, e = n.length; i < e;) {
                                            if (n[i]._name === t || n[i].mn === t || n[i].propertyIndex === t || n[i].ix === t || n[i].ind === t) return n[i];
                                            i += 1
                                        }
                                        return "number" == typeof t ? n[t - 1] : null
                                    };
                                    o.propertyGroup = propertyGroupFactory(o, r), n = t(e.it, view.it, o.propertyGroup), o.numProperties = n.length;
                                    var h = l(e.it[e.it.length - 1], view.it[view.it.length - 1], o.propertyGroup);
                                    return o.transform = h, o.propertyIndex = e.cix, o._name = e.nm, o
                                }(e, view, n.propertyGroup),
                                o = l(e.it[e.it.length - 1], view.it[view.it.length - 1], n.propertyGroup);
                            return n.content = content, n.transform = o, Object.defineProperty(n, "_name", {
                                get: function() {
                                    return e.nm
                                }
                            }), n.numProperties = e.np, n.propertyIndex = e.ix, n.nm = e.nm, n.mn = e.mn, n
                        }

                        function r(t, view, e) {
                            function r(t) {
                                return "Color" === t || "color" === t ? r.color : "Opacity" === t || "opacity" === t ? r.opacity : null
                            }
                            return Object.defineProperties(r, {
                                color: {
                                    get: ExpressionPropertyInterface(view.c)
                                },
                                opacity: {
                                    get: ExpressionPropertyInterface(view.o)
                                },
                                _name: {
                                    value: t.nm
                                },
                                mn: {
                                    value: t.mn
                                }
                            }), view.c.setGroupProperty(PropertyInterface("Color", e)), view.o.setGroupProperty(PropertyInterface("Opacity", e)), r
                        }

                        function n(t, view, e) {
                            function r(t) {
                                return "Start Point" === t || "start point" === t ? r.startPoint : "End Point" === t || "end point" === t ? r.endPoint : "Opacity" === t || "opacity" === t ? r.opacity : null
                            }
                            return Object.defineProperties(r, {
                                startPoint: {
                                    get: ExpressionPropertyInterface(view.s)
                                },
                                endPoint: {
                                    get: ExpressionPropertyInterface(view.e)
                                },
                                opacity: {
                                    get: ExpressionPropertyInterface(view.o)
                                },
                                type: {
                                    get: function() {
                                        return "a"
                                    }
                                },
                                _name: {
                                    value: t.nm
                                },
                                mn: {
                                    value: t.mn
                                }
                            }), view.s.setGroupProperty(PropertyInterface("Start Point", e)), view.e.setGroupProperty(PropertyInterface("End Point", e)), view.o.setGroupProperty(PropertyInterface("Opacity", e)), r
                        }

                        function o(t, view, e) {
                            var i, r = propertyGroupFactory(m, e),
                                n = propertyGroupFactory(l, r);

                            function o(i) {
                                Object.defineProperty(l, t.d[i].nm, {
                                    get: ExpressionPropertyInterface(view.d.dataProps[i].p)
                                })
                            }
                            var h = t.d ? t.d.length : 0,
                                l = {};
                            for (i = 0; i < h; i += 1) o(i), view.d.dataProps[i].p.setGroupProperty(n);

                            function m(t) {
                                return "Color" === t || "color" === t ? m.color : "Opacity" === t || "opacity" === t ? m.opacity : "Stroke Width" === t || "stroke width" === t ? m.strokeWidth : null
                            }
                            return Object.defineProperties(m, {
                                color: {
                                    get: ExpressionPropertyInterface(view.c)
                                },
                                opacity: {
                                    get: ExpressionPropertyInterface(view.o)
                                },
                                strokeWidth: {
                                    get: ExpressionPropertyInterface(view.w)
                                },
                                dash: {
                                    get: function() {
                                        return l
                                    }
                                },
                                _name: {
                                    value: t.nm
                                },
                                mn: {
                                    value: t.mn
                                }
                            }), view.c.setGroupProperty(PropertyInterface("Color", r)), view.o.setGroupProperty(PropertyInterface("Opacity", r)), view.w.setGroupProperty(PropertyInterface("Stroke Width", r)), m
                        }

                        function h(t, view, e) {
                            function r(e) {
                                return e === t.e.ix || "End" === e || "end" === e ? r.end : e === t.s.ix ? r.start : e === t.o.ix ? r.offset : null
                            }
                            var n = propertyGroupFactory(r, e);
                            return r.propertyIndex = t.ix, view.s.setGroupProperty(PropertyInterface("Start", n)), view.e.setGroupProperty(PropertyInterface("End", n)), view.o.setGroupProperty(PropertyInterface("Offset", n)), r.propertyIndex = t.ix, r.propertyGroup = e, Object.defineProperties(r, {
                                start: {
                                    get: ExpressionPropertyInterface(view.s)
                                },
                                end: {
                                    get: ExpressionPropertyInterface(view.e)
                                },
                                offset: {
                                    get: ExpressionPropertyInterface(view.o)
                                },
                                _name: {
                                    value: t.nm
                                }
                            }), r.mn = t.mn, r
                        }

                        function l(t, view, e) {
                            function r(e) {
                                return t.a.ix === e || "Anchor Point" === e ? r.anchorPoint : t.o.ix === e || "Opacity" === e ? r.opacity : t.p.ix === e || "Position" === e ? r.position : t.r.ix === e || "Rotation" === e || "ADBE Vector Rotation" === e ? r.rotation : t.s.ix === e || "Scale" === e ? r.scale : t.sk && t.sk.ix === e || "Skew" === e ? r.skew : t.sa && t.sa.ix === e || "Skew Axis" === e ? r.skewAxis : null
                            }
                            var n = propertyGroupFactory(r, e);
                            return view.transform.mProps.o.setGroupProperty(PropertyInterface("Opacity", n)), view.transform.mProps.p.setGroupProperty(PropertyInterface("Position", n)), view.transform.mProps.a.setGroupProperty(PropertyInterface("Anchor Point", n)), view.transform.mProps.s.setGroupProperty(PropertyInterface("Scale", n)), view.transform.mProps.r.setGroupProperty(PropertyInterface("Rotation", n)), view.transform.mProps.sk && (view.transform.mProps.sk.setGroupProperty(PropertyInterface("Skew", n)), view.transform.mProps.sa.setGroupProperty(PropertyInterface("Skew Angle", n))), view.transform.op.setGroupProperty(PropertyInterface("Opacity", n)), Object.defineProperties(r, {
                                opacity: {
                                    get: ExpressionPropertyInterface(view.transform.mProps.o)
                                },
                                position: {
                                    get: ExpressionPropertyInterface(view.transform.mProps.p)
                                },
                                anchorPoint: {
                                    get: ExpressionPropertyInterface(view.transform.mProps.a)
                                },
                                scale: {
                                    get: ExpressionPropertyInterface(view.transform.mProps.s)
                                },
                                rotation: {
                                    get: ExpressionPropertyInterface(view.transform.mProps.r)
                                },
                                skew: {
                                    get: ExpressionPropertyInterface(view.transform.mProps.sk)
                                },
                                skewAxis: {
                                    get: ExpressionPropertyInterface(view.transform.mProps.sa)
                                },
                                _name: {
                                    value: t.nm
                                }
                            }), r.ty = "tr", r.mn = t.mn, r.propertyGroup = e, r
                        }

                        function m(t, view, e) {
                            function r(e) {
                                return t.p.ix === e ? r.position : t.s.ix === e ? r.size : null
                            }
                            var n = propertyGroupFactory(r, e);
                            r.propertyIndex = t.ix;
                            var o = "tm" === view.sh.ty ? view.sh.prop : view.sh;
                            return o.s.setGroupProperty(PropertyInterface("Size", n)), o.p.setGroupProperty(PropertyInterface("Position", n)), Object.defineProperties(r, {
                                size: {
                                    get: ExpressionPropertyInterface(o.s)
                                },
                                position: {
                                    get: ExpressionPropertyInterface(o.p)
                                },
                                _name: {
                                    value: t.nm
                                }
                            }), r.mn = t.mn, r
                        }

                        function f(t, view, e) {
                            function r(e) {
                                return t.p.ix === e ? r.position : t.r.ix === e ? r.rotation : t.pt.ix === e ? r.points : t.or.ix === e || "ADBE Vector Star Outer Radius" === e ? r.outerRadius : t.os.ix === e ? r.outerRoundness : !t.ir || t.ir.ix !== e && "ADBE Vector Star Inner Radius" !== e ? t.is && t.is.ix === e ? r.innerRoundness : null : r.innerRadius
                            }
                            var n = propertyGroupFactory(r, e),
                                o = "tm" === view.sh.ty ? view.sh.prop : view.sh;
                            return r.propertyIndex = t.ix, o.or.setGroupProperty(PropertyInterface("Outer Radius", n)), o.os.setGroupProperty(PropertyInterface("Outer Roundness", n)), o.pt.setGroupProperty(PropertyInterface("Points", n)), o.p.setGroupProperty(PropertyInterface("Position", n)), o.r.setGroupProperty(PropertyInterface("Rotation", n)), t.ir && (o.ir.setGroupProperty(PropertyInterface("Inner Radius", n)), o.is.setGroupProperty(PropertyInterface("Inner Roundness", n))), Object.defineProperties(r, {
                                position: {
                                    get: ExpressionPropertyInterface(o.p)
                                },
                                rotation: {
                                    get: ExpressionPropertyInterface(o.r)
                                },
                                points: {
                                    get: ExpressionPropertyInterface(o.pt)
                                },
                                outerRadius: {
                                    get: ExpressionPropertyInterface(o.or)
                                },
                                outerRoundness: {
                                    get: ExpressionPropertyInterface(o.os)
                                },
                                innerRadius: {
                                    get: ExpressionPropertyInterface(o.ir)
                                },
                                innerRoundness: {
                                    get: ExpressionPropertyInterface(o.is)
                                },
                                _name: {
                                    value: t.nm
                                }
                            }), r.mn = t.mn, r
                        }

                        function c(t, view, e) {
                            function r(e) {
                                return t.p.ix === e ? r.position : t.r.ix === e ? r.roundness : t.s.ix === e || "Size" === e || "ADBE Vector Rect Size" === e ? r.size : null
                            }
                            var n = propertyGroupFactory(r, e),
                                o = "tm" === view.sh.ty ? view.sh.prop : view.sh;
                            return r.propertyIndex = t.ix, o.p.setGroupProperty(PropertyInterface("Position", n)), o.s.setGroupProperty(PropertyInterface("Size", n)), o.r.setGroupProperty(PropertyInterface("Rotation", n)), Object.defineProperties(r, {
                                position: {
                                    get: ExpressionPropertyInterface(o.p)
                                },
                                roundness: {
                                    get: ExpressionPropertyInterface(o.r)
                                },
                                size: {
                                    get: ExpressionPropertyInterface(o.s)
                                },
                                _name: {
                                    value: t.nm
                                }
                            }), r.mn = t.mn, r
                        }

                        function d(t, view, e) {
                            function r(e) {
                                return t.r.ix === e || "Round Corners 1" === e ? r.radius : null
                            }
                            var n = propertyGroupFactory(r, e),
                                o = view;
                            return r.propertyIndex = t.ix, o.rd.setGroupProperty(PropertyInterface("Radius", n)), Object.defineProperties(r, {
                                radius: {
                                    get: ExpressionPropertyInterface(o.rd)
                                },
                                _name: {
                                    value: t.nm
                                }
                            }), r.mn = t.mn, r
                        }

                        function y(t, view, e) {
                            function r(e) {
                                return t.c.ix === e || "Copies" === e ? r.copies : t.o.ix === e || "Offset" === e ? r.offset : null
                            }
                            var n = propertyGroupFactory(r, e),
                                o = view;
                            return r.propertyIndex = t.ix, o.c.setGroupProperty(PropertyInterface("Copies", n)), o.o.setGroupProperty(PropertyInterface("Offset", n)), Object.defineProperties(r, {
                                copies: {
                                    get: ExpressionPropertyInterface(o.c)
                                },
                                offset: {
                                    get: ExpressionPropertyInterface(o.o)
                                },
                                _name: {
                                    value: t.nm
                                }
                            }), r.mn = t.mn, r
                        }
                        return function(e, view, r) {
                            var n;

                            function o(t) {
                                if ("number" == typeof t) return 0 === (t = void 0 === t ? 1 : t) ? r : n[t - 1];
                                for (var i = 0, e = n.length; i < e;) {
                                    if (n[i]._name === t) return n[i];
                                    i += 1
                                }
                                return null
                            }
                            return o.propertyGroup = propertyGroupFactory(o, (function() {
                                return r
                            })), n = t(e, view, o.propertyGroup), o.numProperties = n.length, o._name = "Contents", o
                        }
                    }(),
                    TextExpressionInterface = function(t) {
                        var e, r;

                        function n(t) {
                            return "ADBE Text Document" === t ? n.sourceText : null
                        }
                        return Object.defineProperty(n, "sourceText", {
                            get: function() {
                                t.textProperty.getValue();
                                var n = t.textProperty.currentData.t;
                                return n !== e && (t.textProperty.currentData.t = e, (r = new String(n)).value = n || new String(n)), r
                            }
                        }), n
                    },
                    LayerExpressionInterface = function() {
                        function t(time) {
                            var t = new Matrix;
                            return void 0 !== time ? this._elem.finalTransform.mProp.getValueAtTime(time).clone(t) : this._elem.finalTransform.mProp.applyToMatrix(t), t
                        }

                        function e(t, time) {
                            var e = this.getMatrix(time);
                            return e.props[12] = 0, e.props[13] = 0, e.props[14] = 0, this.applyPoint(e, t)
                        }

                        function r(t, time) {
                            var e = this.getMatrix(time);
                            return this.applyPoint(e, t)
                        }

                        function n(t, time) {
                            var e = this.getMatrix(time);
                            return e.props[12] = 0, e.props[13] = 0, e.props[14] = 0, this.invertPoint(e, t)
                        }

                        function o(t, time) {
                            var e = this.getMatrix(time);
                            return this.invertPoint(e, t)
                        }

                        function h(t, e) {
                            if (this._elem.hierarchy && this._elem.hierarchy.length) {
                                var i, r = this._elem.hierarchy.length;
                                for (i = 0; i < r; i += 1) this._elem.hierarchy[i].finalTransform.mProp.applyToMatrix(t)
                            }
                            return t.applyToPointArray(e[0], e[1], e[2] || 0)
                        }

                        function l(t, e) {
                            if (this._elem.hierarchy && this._elem.hierarchy.length) {
                                var i, r = this._elem.hierarchy.length;
                                for (i = 0; i < r; i += 1) this._elem.hierarchy[i].finalTransform.mProp.applyToMatrix(t)
                            }
                            return t.inversePoint(e)
                        }

                        function m(t) {
                            var e = new Matrix;
                            if (e.reset(), this._elem.finalTransform.mProp.applyToMatrix(e), this._elem.hierarchy && this._elem.hierarchy.length) {
                                var i, r = this._elem.hierarchy.length;
                                for (i = 0; i < r; i += 1) this._elem.hierarchy[i].finalTransform.mProp.applyToMatrix(e);
                                return e.inversePoint(t)
                            }
                            return e.inversePoint(t)
                        }

                        function f() {
                            return [1, 1, 1, 1]
                        }
                        return function(c) {
                            var d;

                            function y(t) {
                                switch (t) {
                                    case "ADBE Root Vectors Group":
                                    case "Contents":
                                    case 2:
                                        return y.shapeInterface;
                                    case 1:
                                    case 6:
                                    case "Transform":
                                    case "transform":
                                    case "ADBE Transform Group":
                                        return d;
                                    case 4:
                                    case "ADBE Effect Parade":
                                    case "effects":
                                    case "Effects":
                                        return y.effect;
                                    case "ADBE Text Properties":
                                        return y.textInterface;
                                    default:
                                        return null
                                }
                            }
                            y.getMatrix = t, y.invertPoint = l, y.applyPoint = h, y.toWorld = r, y.toWorldVec = e, y.fromWorld = o, y.fromWorldVec = n, y.toComp = r, y.fromComp = m, y.sampleImage = f, y.sourceRectAtTime = c.sourceRectAtTime.bind(c), y._elem = c;
                            var v = getDescriptor(d = TransformExpressionInterface(c.finalTransform.mProp), "anchorPoint");
                            return Object.defineProperties(y, {
                                hasParent: {
                                    get: function() {
                                        return c.hierarchy.length
                                    }
                                },
                                parent: {
                                    get: function() {
                                        return c.hierarchy[0].layerInterface
                                    }
                                },
                                rotation: getDescriptor(d, "rotation"),
                                scale: getDescriptor(d, "scale"),
                                position: getDescriptor(d, "position"),
                                opacity: getDescriptor(d, "opacity"),
                                anchorPoint: v,
                                anchor_point: v,
                                transform: {
                                    get: function() {
                                        return d
                                    }
                                },
                                active: {
                                    get: function() {
                                        return c.isInRange
                                    }
                                }
                            }), y.startTime = c.data.st, y.index = c.data.ind, y.source = c.data.refId, y.height = 0 === c.data.ty ? c.data.h : 100, y.width = 0 === c.data.ty ? c.data.w : 100, y.inPoint = c.data.ip / c.comp.globalData.frameRate, y.outPoint = c.data.op / c.comp.globalData.frameRate, y._name = c.data.nm, y.registerMaskInterface = function(t) {
                                y.mask = new MaskManagerInterface(t, c)
                            }, y.registerEffectsInterface = function(t) {
                                y.effect = t
                            }, y
                        }
                    }(),
                    FootageInterface = (dataInterfaceFactory = function(t) {
                        function e(t) {
                            return "Outline" === t ? e.outlineInterface() : null
                        }
                        return e._name = "Outline", e.outlineInterface = function(t) {
                            var e = "",
                                r = t.getFootageData();

                            function n(t) {
                                if (r[t]) return e = t, "object" == typeof(r = r[t]) ? n : r;
                                var o = t.indexOf(e);
                                if (-1 !== o) {
                                    var h = parseInt(t.substr(o + e.length), 10);
                                    return "object" == typeof(r = r[h]) ? n : r
                                }
                                return ""
                            }
                            return function() {
                                return e = "", r = t.getFootageData(), n
                            }
                        }(t), e
                    }, function(t) {
                        function e(t) {
                            return "Data" === t ? e.dataInterface : null
                        }
                        return e._name = "Data", e.dataInterface = dataInterfaceFactory(t), e
                    }),
                    dataInterfaceFactory, CompExpressionInterface = function(t) {
                        function e(e) {
                            for (var i = 0, r = t.layers.length; i < r;) {
                                if (t.layers[i].nm === e || t.layers[i].ind === e) return t.elements[i].layerInterface;
                                i += 1
                            }
                            return null
                        }
                        return Object.defineProperty(e, "_name", {
                            value: t.data.nm
                        }), e.layer = e, e.pixelAspect = 1, e.height = t.data.h || t.globalData.compSize.h, e.width = t.data.w || t.globalData.compSize.w, e.pixelAspect = 1, e.frameDuration = 1 / t.globalData.frameRate, e.displayStartTime = 0, e.numLayers = t.layers.length, e
                    },
                    TransformExpressionInterface = function(t) {
                        function e(t) {
                            switch (t) {
                                case "scale":
                                case "Scale":
                                case "ADBE Scale":
                                case 6:
                                    return e.scale;
                                case "rotation":
                                case "Rotation":
                                case "ADBE Rotation":
                                case "ADBE Rotate Z":
                                case 10:
                                    return e.rotation;
                                case "ADBE Rotate X":
                                    return e.xRotation;
                                case "ADBE Rotate Y":
                                    return e.yRotation;
                                case "position":
                                case "Position":
                                case "ADBE Position":
                                case 2:
                                    return e.position;
                                case "ADBE Position_0":
                                    return e.xPosition;
                                case "ADBE Position_1":
                                    return e.yPosition;
                                case "ADBE Position_2":
                                    return e.zPosition;
                                case "anchorPoint":
                                case "AnchorPoint":
                                case "Anchor Point":
                                case "ADBE AnchorPoint":
                                case 1:
                                    return e.anchorPoint;
                                case "opacity":
                                case "Opacity":
                                case 11:
                                    return e.opacity;
                                default:
                                    return null
                            }
                        }
                        var r, n, o, h;
                        return Object.defineProperty(e, "rotation", {
                            get: ExpressionPropertyInterface(t.r || t.rz)
                        }), Object.defineProperty(e, "zRotation", {
                            get: ExpressionPropertyInterface(t.rz || t.r)
                        }), Object.defineProperty(e, "xRotation", {
                            get: ExpressionPropertyInterface(t.rx)
                        }), Object.defineProperty(e, "yRotation", {
                            get: ExpressionPropertyInterface(t.ry)
                        }), Object.defineProperty(e, "scale", {
                            get: ExpressionPropertyInterface(t.s)
                        }), t.p ? h = ExpressionPropertyInterface(t.p) : (r = ExpressionPropertyInterface(t.px), n = ExpressionPropertyInterface(t.py), t.pz && (o = ExpressionPropertyInterface(t.pz))), Object.defineProperty(e, "position", {
                            get: function() {
                                return t.p ? h() : [r(), n(), o ? o() : 0]
                            }
                        }), Object.defineProperty(e, "xPosition", {
                            get: ExpressionPropertyInterface(t.px)
                        }), Object.defineProperty(e, "yPosition", {
                            get: ExpressionPropertyInterface(t.py)
                        }), Object.defineProperty(e, "zPosition", {
                            get: ExpressionPropertyInterface(t.pz)
                        }), Object.defineProperty(e, "anchorPoint", {
                            get: ExpressionPropertyInterface(t.a)
                        }), Object.defineProperty(e, "opacity", {
                            get: ExpressionPropertyInterface(t.o)
                        }), Object.defineProperty(e, "skew", {
                            get: ExpressionPropertyInterface(t.sk)
                        }), Object.defineProperty(e, "skewAxis", {
                            get: ExpressionPropertyInterface(t.sa)
                        }), Object.defineProperty(e, "orientation", {
                            get: ExpressionPropertyInterface(t.or)
                        }), e
                    },
                    ProjectInterface = function() {
                        function t(t) {
                            this.compositions.push(t)
                        }
                        return function() {
                            function e(t) {
                                for (var i = 0, e = this.compositions.length; i < e;) {
                                    if (this.compositions[i].data && this.compositions[i].data.nm === t) return this.compositions[i].prepareFrame && this.compositions[i].data.xt && this.compositions[i].prepareFrame(this.currentFrame), this.compositions[i].compInterface;
                                    i += 1
                                }
                                return null
                            }
                            return e.compositions = [], e.currentFrame = 0, e.registerComposition = t, e
                        }
                    }(),
                    EffectsExpressionInterface = function() {
                        function t(data, r, n, o) {
                            function h(t) {
                                for (var e = data.ef, i = 0, r = e.length; i < r;) {
                                    if (t === e[i].nm || t === e[i].mn || t === e[i].ix) return 5 === e[i].ty ? m[i] : m[i]();
                                    i += 1
                                }
                                throw new Error
                            }
                            var i, l = propertyGroupFactory(h, n),
                                m = [],
                                f = data.ef.length;
                            for (i = 0; i < f; i += 1) 5 === data.ef[i].ty ? m.push(t(data.ef[i], r.effectElements[i], r.effectElements[i].propertyGroup, o)) : m.push(e(r.effectElements[i], data.ef[i].ty, o, l));
                            return "ADBE Color Control" === data.mn && Object.defineProperty(h, "color", {
                                get: function() {
                                    return m[0]()
                                }
                            }), Object.defineProperties(h, {
                                numProperties: {
                                    get: function() {
                                        return data.np
                                    }
                                },
                                _name: {
                                    value: data.nm
                                },
                                propertyGroup: {
                                    value: l
                                }
                            }), h.enabled = 0 !== data.en, h.active = h.enabled, h
                        }

                        function e(element, t, e, r) {
                            var n = ExpressionPropertyInterface(element.p);
                            return element.p.setGroupProperty && element.p.setGroupProperty(PropertyInterface("", r)),
                                function() {
                                    return 10 === t ? e.comp.compInterface(element.p.v) : n()
                                }
                        }
                        return {
                            createEffectsInterface: function(e, r) {
                                if (e.effectsManager) {
                                    var i, n = [],
                                        o = e.data.ef,
                                        h = e.effectsManager.effectElements.length;
                                    for (i = 0; i < h; i += 1) n.push(t(o[i], e.effectsManager.effectElements[i], r, e));
                                    var l = e.data.ef || [],
                                        m = function(t) {
                                            for (i = 0, h = l.length; i < h;) {
                                                if (t === l[i].nm || t === l[i].mn || t === l[i].ix) return n[i];
                                                i += 1
                                            }
                                            return null
                                        };
                                    return Object.defineProperty(m, "numProperties", {
                                        get: function() {
                                            return l.length
                                        }
                                    }), m
                                }
                                return null
                            }
                        }
                    }(),
                    MaskManagerInterface = function() {
                        function t(mask, data) {
                            this._mask = mask, this._data = data
                        }
                        return Object.defineProperty(t.prototype, "maskPath", {
                                get: function() {
                                    return this._mask.prop.k && this._mask.prop.getValue(), this._mask.prop
                                }
                            }), Object.defineProperty(t.prototype, "maskOpacity", {
                                get: function() {
                                    return this._mask.op.k && this._mask.op.getValue(), 100 * this._mask.op.v
                                }
                            }),
                            function(e) {
                                var i, r = createSizedArray(e.viewData.length),
                                    n = e.viewData.length;
                                for (i = 0; i < n; i += 1) r[i] = new t(e.viewData[i], e.masksProperties[i]);
                                return function(t) {
                                    for (i = 0; i < n;) {
                                        if (e.masksProperties[i].nm === t) return r[i];
                                        i += 1
                                    }
                                    return null
                                }
                            }
                    }(),
                    ExpressionPropertyInterface = function() {
                        var t = {
                                pv: 0,
                                v: 0,
                                mult: 1
                            },
                            e = {
                                pv: [0, 0, 0],
                                v: [0, 0, 0],
                                mult: 1
                            };

                        function r(t, e, r) {
                            Object.defineProperty(t, "velocity", {
                                get: function() {
                                    return e.getVelocityAtTime(e.comp.currentFrame)
                                }
                            }), t.numKeys = e.keyframes ? e.keyframes.length : 0, t.key = function(n) {
                                if (!t.numKeys) return 0;
                                var o = "";
                                o = "s" in e.keyframes[n - 1] ? e.keyframes[n - 1].s : "e" in e.keyframes[n - 2] ? e.keyframes[n - 2].e : e.keyframes[n - 2].s;
                                var h = "unidimensional" === r ? new Number(o) : Object.assign({}, o);
                                return h.time = e.keyframes[n - 1].t / e.elem.comp.globalData.frameRate, h.value = "unidimensional" === r ? o[0] : o, h
                            }, t.valueAtTime = e.getValueAtTime, t.speedAtTime = e.getSpeedAtTime, t.velocityAtTime = e.getVelocityAtTime, t.propertyGroup = e.propertyGroup
                        }

                        function n() {
                            return t
                        }
                        return function(o) {
                            return o ? "unidimensional" === o.propType ? function(e) {
                                e && "pv" in e || (e = t);
                                var n = 1 / e.mult,
                                    o = e.pv * n,
                                    h = new Number(o);
                                return h.value = o, r(h, e, "unidimensional"),
                                    function() {
                                        return e.k && e.getValue(), o = e.v * n, h.value !== o && ((h = new Number(o)).value = o, r(h, e, "unidimensional")), h
                                    }
                            }(o) : function(t) {
                                t && "pv" in t || (t = e);
                                var n = 1 / t.mult,
                                    o = t.data && t.data.l || t.pv.length,
                                    h = createTypedArray("float32", o),
                                    l = createTypedArray("float32", o);
                                return h.value = l, r(h, t, "multidimensional"),
                                    function() {
                                        t.k && t.getValue();
                                        for (var i = 0; i < o; i += 1) l[i] = t.v[i] * n, h[i] = l[i];
                                        return h
                                    }
                            }(o) : n
                        }
                    }(),
                    TextExpressionSelectorPropFactory = function() {
                        function t(t, e) {
                            return this.textIndex = t + 1, this.textTotal = e, this.v = this.getValue() * this.mult, this.v
                        }
                        return function(e, data) {
                            this.pv = 1, this.comp = e.comp, this.elem = e, this.mult = .01, this.propType = "textSelector", this.textTotal = data.totalChars, this.selectorValue = 100, this.lastValue = [1, 1, 1], this.k = !0, this.x = !0, this.getValue = ExpressionManager.initiateExpression.bind(this)(e, data, this), this.getMult = t, this.getVelocityAtTime = expressionHelpers.getVelocityAtTime, this.kf ? this.getValueAtTime = expressionHelpers.getValueAtTime.bind(this) : this.getValueAtTime = expressionHelpers.getStaticValueAtTime.bind(this), this.setGroupProperty = expressionHelpers.setGroupProperty
                        }
                    }(),
                    propertyGetTextProp = TextSelectorProp.getTextSelectorProp;

                function SliderEffect(data, t, e) {
                    this.p = PropertyFactory.getProp(t, data.v, 0, 0, e)
                }

                function AngleEffect(data, t, e) {
                    this.p = PropertyFactory.getProp(t, data.v, 0, 0, e)
                }

                function ColorEffect(data, t, e) {
                    this.p = PropertyFactory.getProp(t, data.v, 1, 0, e)
                }

                function PointEffect(data, t, e) {
                    this.p = PropertyFactory.getProp(t, data.v, 1, 0, e)
                }

                function LayerIndexEffect(data, t, e) {
                    this.p = PropertyFactory.getProp(t, data.v, 0, 0, e)
                }

                function MaskIndexEffect(data, t, e) {
                    this.p = PropertyFactory.getProp(t, data.v, 0, 0, e)
                }

                function CheckboxEffect(data, t, e) {
                    this.p = PropertyFactory.getProp(t, data.v, 0, 0, e)
                }

                function NoValueEffect() {
                    this.p = {}
                }

                function EffectsManager(data, element) {
                    var i, t = data.ef || [];
                    this.effectElements = [];
                    var e, r = t.length;
                    for (i = 0; i < r; i += 1) e = new GroupEffect(t[i], element), this.effectElements.push(e)
                }

                function GroupEffect(data, element) {
                    this.init(data, element)
                }
                TextSelectorProp.getTextSelectorProp = function(t, data, e) {
                    return 1 === data.t ? new TextExpressionSelectorPropFactory(t, data, e) : propertyGetTextProp(t, data, e)
                }, extendPrototype([DynamicPropertyContainer], GroupEffect), GroupEffect.prototype.getValue = GroupEffect.prototype.iterateDynamicProperties, GroupEffect.prototype.init = function(data, element) {
                    var i;
                    this.data = data, this.effectElements = [], this.initDynamicPropertyContainer(element);
                    var t, e = this.data.ef.length,
                        r = this.data.ef;
                    for (i = 0; i < e; i += 1) {
                        switch (t = null, r[i].ty) {
                            case 0:
                                t = new SliderEffect(r[i], element, this);
                                break;
                            case 1:
                                t = new AngleEffect(r[i], element, this);
                                break;
                            case 2:
                                t = new ColorEffect(r[i], element, this);
                                break;
                            case 3:
                                t = new PointEffect(r[i], element, this);
                                break;
                            case 4:
                            case 7:
                                t = new CheckboxEffect(r[i], element, this);
                                break;
                            case 10:
                                t = new LayerIndexEffect(r[i], element, this);
                                break;
                            case 11:
                                t = new MaskIndexEffect(r[i], element, this);
                                break;
                            case 5:
                                t = new EffectsManager(r[i], element, this);
                                break;
                            default:
                                t = new NoValueEffect(r[i], element, this)
                        }
                        t && this.effectElements.push(t)
                    }
                };
                var lottie = {};

                function setLocationHref(t) {
                    locationHref = t
                }

                function searchAnimations() {
                    !0 === standalone ? animationManager.searchAnimations(animationData, standalone, renderer) : animationManager.searchAnimations()
                }

                function setSubframeRendering(t) {
                    subframeEnabled = t
                }

                function setIDPrefix(t) {
                    idPrefix = t
                }

                function loadAnimation(t) {
                    return !0 === standalone && (t.animationData = JSON.parse(animationData)), animationManager.loadAnimation(t)
                }

                function setQuality(t) {
                    if ("string" == typeof t) switch (t) {
                        case "high":
                            defaultCurveSegments = 200;
                            break;
                        default:
                        case "medium":
                            defaultCurveSegments = 50;
                            break;
                        case "low":
                            defaultCurveSegments = 10
                    } else !isNaN(t) && t > 1 && (defaultCurveSegments = t);
                    roundValues(!(defaultCurveSegments >= 50))
                }

                function inBrowser() {
                    return "undefined" != typeof navigator
                }

                function installPlugin(t, e) {
                    "expressions" === t && (expressionsPlugin = e)
                }

                function getFactory(t) {
                    switch (t) {
                        case "propertyFactory":
                            return PropertyFactory;
                        case "shapePropertyFactory":
                            return ShapePropertyFactory;
                        case "matrix":
                            return Matrix;
                        default:
                            return null
                    }
                }

                function checkReady() {
                    "complete" === document.readyState && (clearInterval(readyStateCheckInterval), searchAnimations())
                }

                function getQueryVariable(t) {
                    for (var e = queryString.split("&"), i = 0; i < e.length; i += 1) {
                        var r = e[i].split("=");
                        if (decodeURIComponent(r[0]) == t) return decodeURIComponent(r[1])
                    }
                    return null
                }
                lottie.play = animationManager.play, lottie.pause = animationManager.pause, lottie.setLocationHref = setLocationHref, lottie.togglePause = animationManager.togglePause, lottie.setSpeed = animationManager.setSpeed, lottie.setDirection = animationManager.setDirection, lottie.stop = animationManager.stop, lottie.searchAnimations = searchAnimations, lottie.registerAnimation = animationManager.registerAnimation, lottie.loadAnimation = loadAnimation, lottie.setSubframeRendering = setSubframeRendering, lottie.resize = animationManager.resize, lottie.goToAndStop = animationManager.goToAndStop, lottie.destroy = animationManager.destroy, lottie.setQuality = setQuality, lottie.inBrowser = inBrowser, lottie.installPlugin = installPlugin, lottie.freeze = animationManager.freeze, lottie.unfreeze = animationManager.unfreeze, lottie.setVolume = animationManager.setVolume, lottie.mute = animationManager.mute, lottie.unmute = animationManager.unmute, lottie.getRegisteredAnimations = animationManager.getRegisteredAnimations, lottie.useWebWorker = function(t) {
                    _useWebWorker = t
                }, lottie.setIDPrefix = setIDPrefix, lottie.__getFactory = getFactory, lottie.version = "5.8.1";
                var standalone = "__[STANDALONE]__",
                    animationData = "__[ANIMATIONDATA]__",
                    renderer = "",
                    queryString;
                if (standalone) {
                    var scripts = document.getElementsByTagName("script"),
                        index = scripts.length - 1,
                        myScript = scripts[index] || {
                            src: ""
                        };
                    queryString = myScript.src.replace(/^[^\?]+\??/, ""), renderer = getQueryVariable("renderer")
                }
                var readyStateCheckInterval = setInterval(checkReady, 100);
                return lottie
            }, void 0 === (__WEBPACK_AMD_DEFINE_RESULT__ = function() {
                return factory(root)
            }.call(exports, __webpack_require__, exports, module)) || (module.exports = __WEBPACK_AMD_DEFINE_RESULT__))
        }
    }
]);