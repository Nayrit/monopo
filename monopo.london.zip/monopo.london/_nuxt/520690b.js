(window.webpackJsonp = window.webpackJsonp || []).push([
    [37, 4, 5, 9, 11, 12, 15, 16, 19, 25, 26], {
        444: function(t, e, o) {
            "use strict";

            function n(t) {
                var e = 0,
                    o = 0;
                do {
                    e += t.offsetTop, o += t.offsetLeft, t = t.offsetParent
                } while (t);
                return {
                    top: e,
                    left: o
                }
            }
            o.d(e, "a", (function() {
                return n
            }))
        },
        445: function(t, e, o) {
            "use strict";
            var n = o(6),
                r = o(446);
            n({
                target: "String",
                proto: !0,
                forced: o(447)("anchor")
            }, {
                anchor: function(t) {
                    return r(this, "a", "name", t)
                }
            })
        },
        446: function(t, e, o) {
            var n = o(10),
                r = o(52),
                c = o(32),
                l = /"/g,
                h = n("".replace);
            t.exports = function(t, e, o, n) {
                var d = c(r(t)),
                    m = "<" + e;
                return "" !== o && (m += " " + o + '="' + h(c(n), l, "&quot;") + '"'), m + ">" + d + "</" + e + ">"
            }
        },
        447: function(t, e, o) {
            var n = o(12);
            t.exports = function(t) {
                return n((function() {
                    var e = "" [t]('"');
                    return e !== e.toLowerCase() || e.split('"').length > 3
                }))
            }
        },
        448: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(38), o(39);
            var n = o(17),
                r = (o(101), o(16), o(25), o(445), o(46)),
                c = o(4),
                l = o(14),
                h = o(444),
                d = o(450);

            function m(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var f = {
                    name: "PixiImage",
                    props: {
                        field: {
                            type: Object,
                            default: null,
                            required: !0
                        },
                        fieldReveal: {
                            type: Object,
                            default: null
                        },
                        useBrush: {
                            type: Boolean,
                            default: !1
                        },
                        useMask: {
                            type: Boolean,
                            default: !1
                        },
                        useHover: {
                            type: Boolean,
                            default: !1
                        },
                        hide: {
                            type: Boolean,
                            default: !1
                        },
                        debug: {
                            type: Boolean,
                            default: !1
                        },
                        parallax: {
                            type: Number,
                            default: 0
                        },
                        screenPos: {
                            type: Number,
                            default: .5
                        }
                    },
                    data: function() {
                        return {
                            isLoaded: !1
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? m(Object(source), !0).forEach((function(e) {
                                Object(n.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : m(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(l.d)("window", {
                        isTouch: "isTouch",
                        winWidth: "width",
                        winHeight: "height"
                    })),
                    watch: {
                        hide: "onHideChange"
                    },
                    created: function() {
                        this.cursorPos = {
                            x: 0,
                            y: 0
                        }, this.delta = {
                            x: 0,
                            y: 0,
                            v: 0
                        }, this.mouseX = 0, this.mouseY = 0, this.scale = 0, this.smoothScale = 0, this._onPointerEnter = this.onPointerEnter.bind(this), this._onPointerMove = this.onPointerMove.bind(this), this._onPointerLeave = this.onPointerLeave.bind(this)
                    },
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            t.getContainer(), t.container && !t.isTouch && (t.width = t.$el.offsetWidth, t.height = t.$el.offsetHeight, t.offsets = Object(h.a)(t.$el), t.computedSize = Object(d.a)(t.field.dimensions.width, t.field.dimensions.height, t.width, t.height, !1), t.offsetX = Math.round(.5 * (t.width - t.computedSize.width)), t.offsetY = Math.round(.5 * (t.height - t.computedSize.height)), t.init()), t.observer = new IntersectionObserver((function(e) {
                                e.forEach((function(e) {
                                    e.isIntersecting && (t.$refs.img.onload = function() {
                                        t.isLoaded = !0, t.image && r.a.to(t.image, {
                                            duration: 1.2,
                                            alpha: 1,
                                            ease: c.c.easeOut,
                                            onComplete: function() {
                                                t.containerMask.removeChild(t.background), t.background.destroy(), t.background = null
                                            }
                                        })
                                    }, t.$refs.img.src = t.$refs.img.dataset.src, t.$refs.img.srcset = t.$refs.img.dataset.srcset, !t.image && t.containerMask && t.createImage(), t.observer.unobserve(e.target), t.observer.disconnect())
                                }))
                            })), t.observer.observe(t.$el), t.$eventHub.$on("resize", t.resize), t.$eventHub.$on("update", t.update), (t.useBrush || t.useHover) && (t.$el.addEventListener("pointerenter", t._onPointerEnter), window.addEventListener("pointermove", t._onPointerMove), t.$el.addEventListener("pointerleave", t._onPointerLeave))
                        }))
                    },
                    beforeDestroy: function() {
                        this.$refs.img && this.observer && (this.observer.unobserve(this.$el), this.observer.disconnect()), this.containerMask && this.container.removeChild(this.containerMask), this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update), (this.useBrush || this.useHover) && (this.$el.removeEventListener("pointerenter", this._onPointerEnter), window.removeEventListener("pointermove", this._onPointerMove), this.$el.removeEventListener("pointerleave", this._onPointerLeave))
                    },
                    methods: {
                        getContainer: function() {
                            for (var t = this; t.$parent;) {
                                if (t.$parent.container && t.$parent.container instanceof this.$PIXI.Container) {
                                    this.container = t.$parent.container;
                                    break
                                }
                                t = t.$parent
                            }
                            if (!this.container) return console.warn("No pixi application founded for this Object. This component must be a child/subchild of a Pixi application", this)
                        },
                        init: function() {
                            this.containerMask = new this.$PIXI.Container, this.containerMask.position.x = this.offsets.left, this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.hide && (this.containerMask.alpha = 0), this.container.addChild(this.containerMask), this.background = new this.$PIXI.Sprite.from(this.field.thumb.url), this.background.anchor.set(0), this.background.width = this.width, this.background.height = this.height, this.containerMask.addChild(this.background), this.useMask && (this.mask = new this.$PIXI.Graphics, this.containerMask.addChild(this.mask), this.mask.beginFill("0x000000"), this.mask.drawRect(0, 0, this.width, this.height), this.mask.endFill(), this.containerMask.mask = this.mask)
                        },
                        createImage: function() {
                            this.image = new this.$PIXI.Sprite.from(window.devicePixelRatio > 1 ? this.field.retina.url : this.field.url), this.containerMask.addChild(this.image), this.image.anchor.set(.5), this.image.width = this.computedSize.width, this.image.height = this.computedSize.height, this.image.position.x = this.offsetX + this.computedSize.width / 2, this.image.position.y = this.offsetY + this.computedSize.height / 2, this.image.alpha = 0, this.useBrush && this.fieldReveal && this.fieldReveal.url && (this.brush = new this.$PIXI.Graphics, this.containerMask.addChild(this.brush), this.brush.beginFill(16777215), this.brush.drawCircle(0, 0, 60), this.brush.endFill(), this.brush.scale.x = 0, this.brush.scale.y = 0, this.imageToReveal = new this.$PIXI.Sprite.from(window.devicePixelRatio > 1 ? this.fieldReveal.retina.url : this.fieldReveal.url), this.containerMask.addChild(this.imageToReveal), this.imageToReveal.anchor.set(0), this.imageToReveal.width = this.computedSize.width, this.imageToReveal.height = this.computedSize.height, this.imageToReveal.position.x = this.offsetX, this.imageToReveal.position.y = this.offsetY, this.imageToReveal.mask = this.brush)
                        },
                        resize: function() {
                            this.isTouch || (this.width = this.$el.offsetWidth, this.height = this.$el.offsetHeight, this.offsets = Object(h.a)(this.$el), this.computedSize = Object(d.a)(this.field.dimensions.width, this.field.dimensions.height, this.width, this.height, !1), this.offsetX = Math.round(.5 * (this.width - this.computedSize.width)), this.offsetY = Math.round(.5 * (this.height - this.computedSize.height)), this.containerMask.position.x = this.offsets.left, this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.useMask && (this.mask.clear(), this.mask.beginFill("0x000000"), this.mask.drawRect(0, 0, this.width, this.height), this.mask.endFill()), this.background && (this.background.width = this.width, this.background.height = this.height), this.image && (this.image.width = this.computedSize.width, this.image.height = this.computedSize.height, this.image.position.x = this.offsetX + this.computedSize.width / 2, this.image.position.y = this.offsetY + this.computedSize.height / 2), this.imageToReveal && (this.imageToReveal.width = this.computedSize.width, this.imageToReveal.height = this.computedSize.height, this.imageToReveal.position.x = this.offsetX, this.imageToReveal.position.y = this.offsetY))
                        },
                        update: function() {
                            this.containerMask && (this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, 0 !== this.parallax && (this.containerMask.position.y += this.containerMask.position.y * this.parallax - this.offsets.top * this.parallax), this.brush && (this.cursorPos.x += .1 * (this.mouseX - this.cursorPos.x), this.cursorPos.y += .1 * (this.mouseY - this.cursorPos.y), this.isEnter && (this.delta.x = Math.abs(this.mouseX - this.cursorPos.x), this.delta.y = Math.abs(this.mouseY - this.cursorPos.y), this.delta.v = this.delta.x > this.delta.y ? this.delta.x : this.delta.y, this.scale = 1 + this.delta.v / 100), this.smoothScale += .1 * (this.scale - this.smoothScale), this.brush.scale.x = this.smoothScale, this.brush.scale.y = this.smoothScale, this.brush.position.x = this.cursorPos.x, this.brush.position.y = this.cursorPos.y))
                        },
                        onPointerEnter: function(t) {
                            this.image && (this.isEnter = !0, this.useBrush && this.fieldReveal && this.fieldReveal.url && (this.cursorPos.x = t.clientX - this.offsets.left, this.cursorPos.y = t.clientY - this.containerMask.position.y, this.animFadeRT && (this.animFadeRT.pause(), this.animFadeRT = null)), this.useHover && (this.savedScale = this.image.scale.x, r.a.to(this.image.scale, {
                                duration: .6,
                                x: this.savedScale + .05,
                                y: this.savedScale + .05,
                                ease: c.c.easeOut
                            })))
                        },
                        onPointerMove: function(t) {
                            this.isEnter && this.useBrush && (this.mouseX = t.clientX - this.offsets.left, this.mouseY = t.clientY - this.containerMask.position.y)
                        },
                        onPointerLeave: function() {
                            var t = this;
                            this.image && (this.useHover && r.a.to(this.image.scale, {
                                duration: .6,
                                x: this.savedScale,
                                y: this.savedScale,
                                ease: c.c.easeOut
                            }), this.useBrush && this.brush && (this.animFadeRT = r.a.to(this, {
                                duration: .6,
                                smoothScale: 0,
                                scale: 0,
                                ease: c.c.easeOut,
                                onComplete: function() {
                                    t.isEnter = !1, t.animFadeRT = null
                                }
                            })))
                        },
                        onHideChange: function() {
                            var t = this.hide ? 0 : 1;
                            r.a.to(this.containerMask, {
                                duration: .6,
                                alpha: t,
                                ease: c.c.easeOut
                            })
                        }
                    }
                },
                v = f,
                x = (o(452), o(26)),
                component = Object(x.a)(v, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "c-PixiImage",
                        class: {
                            "is-loaded": t.isLoaded
                        },
                        style: {
                            backgroundImage: t.isTouch ? "url(" + t.field.thumb.url + ")" : ""
                        }
                    }, [o("img", {
                        ref: "img",
                        staticClass: "c-PixiImage-img",
                        attrs: {
                            "data-src": t.field.url,
                            "data-srcset": t.field.retina.url,
                            alt: t.field.alt ? t.field.alt : " ",
                            draggable: "false",
                            ondragstart: "return false;"
                        }
                    })])
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        449: function(t, e, o) {
            var content = o(453);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("76dd5624", content, !0, {
                sourceMap: !1
            })
        },
        450: function(t, e, o) {
            "use strict";

            function n(t, e, o, n, r) {
                var c = [o / t, n / e];
                return {
                    width: t * (c = r ? Math.min(c[0], c[1]) : Math.max(c[0], c[1])),
                    height: e * c
                }
            }
            o.d(e, "a", (function() {
                return n
            }))
        },
        451: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(16), o(38), o(25), o(39);
            var n = o(17),
                r = (o(101), o(14)),
                c = o(102);

            function l(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var h = {
                    name: "StickyElement",
                    props: {
                        active: {
                            type: Boolean,
                            default: !0
                        },
                        inside: {
                            type: Boolean,
                            default: !0
                        },
                        gapTop: {
                            type: Number,
                            default: 0
                        },
                        gapBottom: {
                            type: Number,
                            default: 0
                        }
                    },
                    data: function() {
                        return {
                            activeClass: ""
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? l(Object(source), !0).forEach((function(e) {
                                Object(n.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : l(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(r.d)("window", ["isTouch"])),
                    watch: {
                        active: "onActiveChange",
                        gapTop: "resize",
                        gapBottom: "resize"
                    },
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            if (t.$eventHub.$on("resize", t.resize), t.$eventHub.$on("update", t.update), t.parent = t.getStickyParent(), !t.parent) return console.warn("No parent founded for this Sticky Element. This component must be a child/subchild of a js-sticky-container", t);
                            t.$nextTick((function() {
                                t.resize()
                            }))
                        }))
                    },
                    beforeDestroy: function() {
                        this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update)
                    },
                    methods: {
                        onActiveChange: function() {
                            this.active && this.update()
                        },
                        getStickyParent: function() {
                            for (var element = this.$el.parentNode; !element.classList.contains("js-sticky-container");) element = element.parentNode;
                            return element
                        },
                        resize: function() {
                            this.parent && (this.width = this.$el.offsetWidth, this.height = this.$el.offsetHeight, this.top = this.$el.offsetTop, this.parentTop = Object(c.a)(this.parent), this.parentHeight = this.parent.offsetHeight, this.triggerTop = this.parentTop + this.top - this.gapTop, this.triggerBottom = this.parentTop + this.parentHeight - this.height - this.gapTop - this.gapBottom)
                        },
                        update: function() {
                            this.parent && this.active && (this.$el.style.transform = this.transform, this.scrollVal = this.isTouch ? this.$root.scrollTop : this.$root.smoothScroll, this.scrollVal >= this.triggerTop && this.scrollVal < this.triggerBottom ? (this.activeClass = "is-sticky", this.isTouch || (this.inside ? this.transform = "translateY(".concat(this.scrollVal - this.triggerTop, "px) translateZ(0)") : this.transform = "translateY(".concat(-this.triggerTop, "px) translateZ(0)"))) : this.scrollVal > this.triggerBottom ? (this.activeClass = "is-sticky-end", this.isTouch || (this.inside ? this.transform = "translateY(".concat(this.triggerBottom - this.triggerTop, "px) translateZ(0)") : this.transform = "translateY(".concat(-this.scrollVal + this.triggerBottom - this.triggerTop, "px) translateZ(0)"))) : (this.activeClass = "", this.isTouch || (this.inside ? this.transform = "translateY(0px) translateZ(0)" : this.transform = "translateY(".concat(-this.scrollVal, "px) translateZ(0)"))))
                        }
                    }
                },
                d = h,
                m = o(26),
                component = Object(m.a)(d, (function() {
                    var t = this,
                        e = t.$createElement;
                    return (t._self._c || e)("div", {
                        class: t.activeClass
                    }, [t._t("default")], 2)
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        452: function(t, e, o) {
            "use strict";
            o(449)
        },
        453: function(t, e, o) {
            var n = o(54)(!1);
            n.push([t.i, ".c-PixiImage{position:relative;background-size:cover}.c-PixiImage-img{position:absolute;top:0;left:0;width:100%;height:100%;opacity:0;transform:translateZ(0);display:none}.is-touch .c-PixiImage-img{display:block}.c-PixiImage.is-loaded .c-PixiImage-img{opacity:1;transition:opacity .8s cubic-bezier(.165,.84,.44,1)}.c-PixiImage.is-loaded.is-disabled .c-PixiImage-img{transition:none}", ""]), t.exports = n
        },
        454: function(t, e, o) {
            "use strict";

            function n(t, e, o, n, r) {
                return (r - t) * (n - o) / (e - t) + o
            }
            o.d(e, "a", (function() {
                return n
            }))
        },
        455: function(t, e, o) {
            "use strict";
            o.r(e);
            o(47);
            var n = {
                    name: "CursorTrigger",
                    props: {
                        active: {
                            type: Boolean,
                            default: !0
                        },
                        name: {
                            type: String,
                            default: ""
                        },
                        value: {
                            type: String,
                            default: ""
                        }
                    },
                    watch: {
                        active: "onActiveChange",
                        name: "onNameChange"
                    },
                    methods: {
                        onMouseEnter: function(t) {
                            this.active && (this.$eventHub.$emit("cursor:enter", this.name, this.value, t), this.isHover = !0)
                        },
                        onMouseLeave: function() {
                            this.active && (this.$eventHub.$emit("cursor:leave", this.name), this.isHover = !1)
                        },
                        onActiveChange: function() {
                            this.active || this.$eventHub.$emit("cursor:leave", this.name)
                        },
                        onNameChange: function(t, e) {
                            this.active && this.isHover && (this.$eventHub.$emit("cursor:leave", e), this.$eventHub.$emit("cursor:enter", t, this.value))
                        }
                    }
                },
                r = o(26),
                component = Object(r.a)(n, (function() {
                    var t = this,
                        e = t.$createElement;
                    return (t._self._c || e)("div", {
                        on: {
                            "&pointerenter": function(e) {
                                return t.onMouseEnter.apply(null, arguments)
                            },
                            "&pointerleave": function(e) {
                                return t.onMouseLeave.apply(null, arguments)
                            }
                        }
                    }, [t._t("default")], 2)
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        456: function(t, e, o) {
            "use strict";
            o(35), o(29), o(31), o(16), o(38), o(25), o(39);
            var n = o(17),
                r = (o(47), o(14));

            function c(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }

            function l(t) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = null != arguments[i] ? arguments[i] : {};
                    i % 2 ? c(Object(source), !0).forEach((function(e) {
                        Object(n.a)(t, e, source[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : c(Object(source)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                    }))
                }
                return t
            }
            var h = {
                computed: l(l({}, Object(r.d)(["layout"])), Object(r.d)("main", ["isPageReady"])),
                head: function() {
                    return {
                        title: this.document.meta_title ? this.document.meta_title : this.layout.meta_title,
                        meta: [{
                            hid: "description",
                            name: "description",
                            content: this.document.meta_description ? this.document.meta_description : this.layout.meta_description
                        }, {
                            hid: "og:title",
                            property: "og:title",
                            content: this.document.meta_title ? this.document.meta_title : this.layout.meta_title
                        }, {
                            hid: "og:description",
                            property: "og:description",
                            content: this.document.meta_description ? this.document.meta_description : this.layout.meta_description
                        }, {
                            hid: "og:image",
                            property: "og:image",
                            content: this.document.share_image && this.document.share_image.url ? this.document.share_image.url : this.layout.share_image ? this.layout.share_image.url : null
                        }, {
                            hid: "twitter:title",
                            name: "og:description",
                            content: this.document.meta_title ? this.document.meta_title : this.layout.meta_title
                        }, {
                            hid: "twitter:description",
                            name: "og:description",
                            content: this.document.meta_description ? this.document.meta_description : this.layout.meta_description
                        }, {
                            hid: "twitter:image:src",
                            name: "twitter:image:src",
                            content: this.document.share_image && this.document.share_image.url ? this.document.share_image.url : this.layout.share_image ? this.layout.share_image.url : null
                        }],
                        bodyAttrs: {
                            class: "is-" + this.$route.name
                        }
                    }
                },
                mounted: function() {
                    var t = this;
                    this.$nextTick((function() {
                        t.$eventHub.$emit("page:mounted")
                    }))
                }
            };
            e.a = h
        },
        457: function(t, e, o) {
            var content = o(464);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("d6b434f8", content, !0, {
                sourceMap: !1
            })
        },
        458: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(16), o(38), o(25), o(39);
            var n = o(17),
                r = o(14),
                c = o(454);

            function l(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var h = {
                    name: "IntroGradient",
                    props: {
                        options: {
                            type: Object,
                            required: !0
                        },
                        ruler: {
                            type: Boolean,
                            default: !0
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? l(Object(source), !0).forEach((function(e) {
                                Object(n.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : l(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(r.d)("window", ["width", "height"])),
                    created: function() {
                        this.force = 5, this.seed = .18, this.smoothForce = this.force, this.smoothSeed = this.seed
                    },
                    mounted: function() {
                        this.$eventHub.$on("resize", this.resize), this.$eventHub.$on("update", this.update)
                    },
                    beforeDestroy: function() {
                        this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update)
                    },
                    methods: {
                        onPointerMove: function(t) {
                            this.x = t.clientX / this.width, this.y = t.clientY / this.height, this.force = Object(c.a)(0, 1, 0, 5, this.x), this.seed = Object(c.a)(0, 1, -1, 1, this.y)
                        },
                        resize: function() {
                            this.ruler && (this.heightRuler = this.$refs.ruler.offsetHeight)
                        },
                        update: function() {
                            if (this.smoothForce += .1 * (this.force - this.smoothForce), this.smoothSeed += .1 * (this.seed - this.smoothSeed), this.$refs.gradient.displacement = this.smoothForce, this.$refs.gradient.seed = this.smoothSeed, this.heightRuler) {
                                var t = this.x * this.heightRuler;
                                this.$refs.cursorX.style.transform = "translateY(".concat(t, "px) translateZ(0)");
                                var e = this.y * this.heightRuler;
                                this.$refs.cursorY.style.transform = "translateY(".concat(e, "px) translateZ(0)")
                            }
                        }
                    }
                },
                d = h,
                m = (o(463), o(26)),
                component = Object(m.a)(d, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("section", {
                        staticClass: "js-section c-IntroGradient",
                        on: {
                            pointermove: t.onPointerMove
                        }
                    }, [o("monopo-gradient", {
                        ref: "gradient",
                        staticClass: "c-IntroGradient-canvas",
                        attrs: {
                            color1: t.options.color1,
                            color2: t.options.color2,
                            color3: t.options.color3,
                            color4: t.options.color4,
                            colorsize: t.options.colorsize,
                            colorspacing: t.options.colorspacing,
                            colorrotation: t.options.colorrotation,
                            colorspread: t.options.colorspread,
                            coloroffset: t.options.coloroffset,
                            displacement: t.options.displacement,
                            seed: t.options.seed,
                            position: t.options.position,
                            zoom: t.options.zoom,
                            spacing: t.options.spacing,
                            noretina: "true"
                        }
                    }), t._v(" "), t.ruler ? [o("div", {
                        ref: "ruler",
                        staticClass: "c-IntroGradient-ruler"
                    }, [t._l(2, (function(e) {
                        return o("div", {
                            key: e,
                            staticClass: "c-IntroGradient-ruler-cm"
                        }, t._l(9, (function(i) {
                            return o("div", {
                                key: i,
                                staticClass: "c-IntroGradient-ruler-mm"
                            })
                        })), 0)
                    })), t._v(" "), o("div", {
                        staticClass: "c-IntroGradient-ruler-cm"
                    }), t._v(" "), o("div", {
                        ref: "cursorY",
                        staticClass: "c-IntroGradient-ruler-cursor"
                    })], 2), t._v(" "), o("div", {
                        staticClass: "c-IntroGradient-ruler c-IntroGradient-ruler--alt"
                    }, [t._l(2, (function(e) {
                        return o("div", {
                            key: e,
                            staticClass: "c-IntroGradient-ruler-cm"
                        }, t._l(9, (function(i) {
                            return o("div", {
                                key: i,
                                staticClass: "c-IntroGradient-ruler-mm"
                            })
                        })), 0)
                    })), t._v(" "), o("div", {
                        staticClass: "c-IntroGradient-ruler-cm"
                    }), t._v(" "), o("div", {
                        ref: "cursorX",
                        staticClass: "c-IntroGradient-ruler-cursor"
                    })], 2)] : t._e(), t._v(" "), t._t("default")], 2)
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        459: function(t, e, o) {
            var content = o(468);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("b29c51b8", content, !0, {
                sourceMap: !1
            })
        },
        460: function(t, e, o) {
            var content = o(470);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("2bbe5424", content, !0, {
                sourceMap: !1
            })
        },
        461: function(t, e, o) {
            "use strict";
            o.r(e);
            o(16), o(25), o(69);
            var n = o(102),
                r = {
                    name: "PixiColor",
                    props: {
                        color: {
                            type: String,
                            default: "#ffffff"
                        },
                        debug: {
                            type: Boolean,
                            default: !1
                        }
                    },
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            t.getContainerBg(), t.containerBg && t.init(), t.resizeObserver = new ResizeObserver((function(e) {
                                e.forEach((function(e) {
                                    e.contentRect && (t.resize(), clearTimeout(t.timerResize), t.timerResize = setTimeout((function() {
                                        t.$eventHub.$emit("resize")
                                    }), 100))
                                }))
                            })), t.resizeObserver.observe(t.$el), t.$eventHub.$on("update", t.update)
                        }))
                    },
                    beforeDestroy: function() {
                        this.graphic && this.containerBg.removeChild(this.graphic), this.$eventHub.$off("update", this.update)
                    },
                    methods: {
                        getContainerBg: function() {
                            for (var t = this; t.$parent;) {
                                if (t.$parent.containerBg && t.$parent.containerBg instanceof this.$PIXI.Container) {
                                    this.containerBg = t.$parent.containerBg;
                                    break
                                }
                                t = t.$parent
                            }
                            if (!this.containerBg) return console.warn("No pixi application founded for this Object. This component must be a child/subchild of a Pixi application", this)
                        },
                        getStickyParent: function() {
                            for (var element = this.$el.parentNode; !element.classList.contains("js-sticky-container");) element = element.parentNode;
                            return element
                        },
                        init: function() {
                            this.width = this.$el.offsetWidth, this.height = this.$el.offsetHeight, this.graphic = new this.$PIXI.Graphics, this.graphic.beginFill("0x" + this.color.substring(1, this.color.length)), this.graphic.drawRect(0, 0, this.width, this.height), this.graphic.endFill(), this.containerBg.addChild(this.graphic)
                        },
                        resize: function() {
                            this.width = this.$el.offsetWidth, this.height = this.$el.offsetHeight, this.offsetTop = Object(n.a)(this.$el), this.graphic.clear(), this.graphic.beginFill("0x" + this.color.substring(1, this.color.length)), this.graphic.drawRect(0, 0, this.width, this.height), this.graphic.endFill(), this.graphic.position.y = this.offsetTop - this.$root.smoothScroll
                        },
                        update: function() {
                            this.graphic && (this.graphic.position.y = this.offsetTop - this.$root.smoothScroll)
                        }
                    }
                },
                c = (o(467), o(26)),
                component = Object(c.a)(r, (function() {
                    var t = this,
                        e = t.$createElement;
                    return (t._self._c || e)("div", {
                        staticClass: "c-PixiColor"
                    }, [t._t("default")], 2)
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        462: function(t, e, o) {
            "use strict";
            o.r(e);
            o(16), o(25);
            var n = {
                    name: "LazyImg",
                    props: {
                        field: {
                            type: Object,
                            default: null,
                            required: !0
                        },
                        full: {
                            type: Boolean,
                            default: !1
                        },
                        disabled: {
                            type: Boolean,
                            default: !1
                        }
                    },
                    data: function() {
                        return {
                            isLoaded: !1
                        }
                    },
                    watch: {
                        field: "onFieldChange"
                    },
                    created: function() {
                        this.disabled && (this.isLoaded = !0)
                    },
                    mounted: function() {
                        var t = this;
                        this.observer = new IntersectionObserver((function(e) {
                            e.forEach((function(e) {
                                if (e.isIntersecting) {
                                    var image = e.target;
                                    image.onload = function() {
                                        t.isLoaded = !0
                                    }, image.src = t.field.url, image.srcset = t.field.retina.url, t.observer.unobserve(image), t.observer.disconnect()
                                }
                            }))
                        })), this.observer.observe(this.$refs.img)
                    },
                    beforeDestroy: function() {
                        this.$refs.img && this.observer && (this.observer.unobserve(this.$refs.img), this.observer.disconnect())
                    },
                    methods: {
                        onFieldChange: function() {
                            this.$refs.img.src = this.field.url, this.$refs.img.srcset = this.field.retina.url
                        }
                    }
                },
                r = (o(469), o(26)),
                component = Object(r.a)(n, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "c-LazyImg",
                        class: {
                            "is-loaded": t.isLoaded, "is-full": t.full, "is-disabled": t.disabled
                        },
                        style: {
                            backgroundImage: "url(" + t.field.thumb.url + ")",
                            width: t.field.dimensions.width,
                            height: t.field.dimensions.height
                        }
                    }, [o("img", {
                        ref: "img",
                        staticClass: "c-LazyImg-img",
                        attrs: {
                            "data-src": t.field.url,
                            "data-srcset": t.field.retina.url,
                            alt: t.field.alt ? t.field.alt : " ",
                            draggable: "false",
                            ondragstart: "return false;"
                        }
                    })])
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        463: function(t, e, o) {
            "use strict";
            o(457)
        },
        464: function(t, e, o) {
            var n = o(54)(!1);
            n.push([t.i, '.c-IntroGradient{position:relative;width:100%}.c-IntroGradient-canvas{position:absolute;top:0;left:0;width:100%;height:100%}.c-IntroGradient-ruler{position:absolute;top:50%;left:3.9vw;padding-left:15px;transform:translateY(-50%)}@media only screen and (max-width:767px){.c-IntroGradient-ruler{display:none}}.c-IntroGradient-ruler--alt{left:auto;right:3.9vw;padding-left:0;padding-right:15px}.c-IntroGradient-ruler-cursor{position:absolute;top:0;left:0;border-top:3px solid transparent;border-bottom:3px solid transparent;border-left:5px solid #fff;margin-top:-3px;transition:transform .8s cubic-bezier(.165,.84,.44,1)}.c-IntroGradient-ruler--alt .c-IntroGradient-ruler-cursor{left:auto;right:0;border-right:5px solid #fff;border-left:none}.c-IntroGradient-ruler-cm{position:relative;width:6px;margin-top:16px}.c-IntroGradient-ruler-cm:first-child,.c-IntroGradient-ruler-cm:first-child .c-IntroGradient-ruler-mm:first-child{margin-top:0}.c-IntroGradient-ruler-cm:before{content:"";position:absolute;top:0;left:0;width:6px;height:1px;background:#fff}.c-IntroGradient-ruler-mm{width:2px;height:1px;background:#fff;margin-top:16px}', ""]), t.exports = n
        },
        466: function(t, e, o) {
            "use strict";
            o.r(e);
            o(16), o(25);
            var n = o(477),
                r = o.n(n),
                c = {
                    name: "CirclesLottie",
                    props: {
                        white: {
                            type: Boolean,
                            default: !0
                        }
                    },
                    mounted: function() {
                        var t = this;
                        this.animation = r.a.loadAnimation({
                            container: this.$el,
                            renderer: "canvas",
                            loop: !1,
                            autoplay: !1,
                            path: this.white ? "/circles/white.json" : "/circles/black.json"
                        }), this.$nextTick((function() {
                            t.observer = new IntersectionObserver((function(e) {
                                e.forEach((function(e) {
                                    e.isIntersecting ? t.animation.play() : t.animation.pause()
                                }))
                            })), t.observer.observe(t.$el)
                        }))
                    },
                    beforeDestroy: function() {
                        this.animation.destroy()
                    }
                },
                l = o(26),
                component = Object(l.a)(c, (function() {
                    var t = this.$createElement;
                    return (this._self._c || t)("div", {
                        staticClass: "c-Circles"
                    })
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        467: function(t, e, o) {
            "use strict";
            o(459)
        },
        468: function(t, e, o) {
            var n = o(54)(!1);
            n.push([t.i, ".c-PixiColor{display:block}", ""]), t.exports = n
        },
        469: function(t, e, o) {
            "use strict";
            o(460)
        },
        470: function(t, e, o) {
            var n = o(54)(!1);
            n.push([t.i, ".c-LazyImg{background-size:cover;overflow:clip;transform:translateZ(0)}.c-LazyImg.is-full{position:absolute;top:0;left:0;width:100%;height:100%}.c-LazyImg-img{opacity:0;transform:translateZ(0);display:block}.c-LazyImg.is-full .c-LazyImg-img{position:absolute;top:0;left:0;width:100%;height:100%}.c-LazyImg.is-loaded .c-LazyImg-img{display:block;opacity:1;transition:opacity .8s cubic-bezier(.165,.84,.44,1)}.c-LazyImg.is-loaded.is-disabled .c-LazyImg-img{transition:none}", ""]), t.exports = n
        },
        472: function(t, e, o) {
            var content = o(481);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("f0b475f8", content, !0, {
                sourceMap: !1
            })
        },
        475: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(16), o(38), o(25), o(39);
            var n = o(17),
                r = (o(101), o(14)),
                c = o(102);

            function l(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var h = {
                    name: "AppearObject",
                    props: {
                        active: {
                            type: Boolean,
                            default: !0
                        },
                        once: {
                            type: Boolean,
                            default: !0
                        },
                        ratio: {
                            type: Number,
                            default: .2
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? l(Object(source), !0).forEach((function(e) {
                                Object(n.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : l(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(r.d)("window", ["isTouch", "height"])),
                    created: function() {
                        this.show = !1
                    },
                    mounted: function() {
                        this.$eventHub.$on("resize", this.resize), this.$eventHub.$on("update", this.update), this.resize()
                    },
                    beforeDestroy: function() {
                        this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update)
                    },
                    methods: {
                        resize: function() {
                            this.isTouch && (this.show = !0, this.$el.classList.add("is-appear")), this.offsetY = Object(c.a)(this.$el);
                            var t = this.height - this.height * this.ratio;
                            this.trigger = this.offsetY - t
                        },
                        update: function() {
                            this.once && this.show || this.isTouch || !this.active || (!this.show && this.$root.smoothScroll >= this.trigger && (this.show = !0, this.$el.classList.add("is-appear")), this.once || this.show && this.$root.smoothScroll < this.trigger && (this.show = !1, this.$el.classList.remove("is-appear")))
                        }
                    }
                },
                d = h,
                m = o(26),
                component = Object(m.a)(d, (function() {
                    var t = this,
                        e = t.$createElement;
                    return (t._self._c || e)("div", [t._t("default")], 2)
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        476: function(t, e, o) {
            "use strict";
            o.r(e);
            var n = o(448),
                r = o(455),
                c = {
                    name: "PixiGallery",
                    components: {
                        PixiImage: n.default,
                        CursorTrigger: r.default
                    },
                    props: {
                        items: {
                            type: Array,
                            default: null,
                            required: !0
                        }
                    },
                    data: function() {
                        return {
                            currentIndex: 0
                        }
                    },
                    computed: {
                        nbItems: function() {
                            return this.items ? this.items.length : 0
                        }
                    },
                    methods: {
                        goToPrevItem: function() {
                            this.currentIndex - 1 < 0 ? this.currentIndex = this.nbItems - 1 : this.currentIndex--
                        },
                        goToNextItem: function() {
                            this.currentIndex++, this.currentIndex = this.currentIndex % this.nbItems
                        },
                        displayIndex: function(t) {
                            return t < 10 ? "0" + t : t
                        }
                    }
                },
                l = (o(480), o(26)),
                component = Object(l.a)(c, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "c-PixiGallery"
                    }, [o("div", {
                        staticClass: "c-PixiGallery-content",
                        style: {
                            paddingTop: "56.25%"
                        }
                    }, [t._l(t.items, (function(e, i) {
                        return [e.image.url ? o("PixiImage", {
                            key: i,
                            staticClass: "c-PixiGallery-img",
                            class: {
                                "is-active": t.currentIndex === i
                            },
                            attrs: {
                                hide: t.currentIndex !== i,
                                "use-mask": !0,
                                field: e.image
                            }
                        }) : t._e()]
                    }))], 2), t._v(" "), o("CursorTrigger", {
                        staticClass: "c-PixiGallery-prev",
                        attrs: {
                            name: "prev"
                        }
                    }, [o("button", {
                        staticClass: "c-PixiGallery-prev-btn t-btn",
                        attrs: {
                            type: "button"
                        },
                        on: {
                            click: t.goToPrevItem
                        }
                    })]), t._v(" "), o("CursorTrigger", {
                        staticClass: "c-PixiGallery-next",
                        attrs: {
                            name: "next"
                        }
                    }, [o("button", {
                        staticClass: "c-PixiGallery-next-btn t-btn",
                        attrs: {
                            type: "button"
                        },
                        on: {
                            click: t.goToNextItem
                        }
                    })]), t._v(" "), o("div", {
                        staticClass: "c-PixiGallery-legend t-text--sm"
                    }, [o("span", [t._v(t._s(t.displayIndex(t.currentIndex + 1)))]), t._v(" /\n        "), o("span", [t._v(t._s(t.displayIndex(t.nbItems)))])])], 1)
                }), [], !1, null, null, null);
            e.default = component.exports;
            installComponents(component, {
                PixiImage: o(448).default,
                CursorTrigger: o(455).default
            })
        },
        480: function(t, e, o) {
            "use strict";
            o(472)
        },
        481: function(t, e, o) {
            var n = o(54)(!1);
            n.push([t.i, ".c-PixiGallery{position:relative}.c-PixiGallery-content{position:relative;height:0;width:100%}.c-PixiGallery-img{position:absolute;top:0;left:0;width:100%;height:100%}@media only screen and (max-width:767px){.c-PixiGallery-img{opacity:0;transform:translateZ(0);transition:opacity .8s cubic-bezier(.165,.84,.44,1)}}@media only screen and (max-width:767px){.c-PixiGallery-img.is-active{opacity:1}}.c-PixiGallery-next,.c-PixiGallery-prev{width:50%;height:100%;position:absolute;top:0;left:0}.c-PixiGallery-next-btn,.c-PixiGallery-prev-btn{width:100%;height:100%;position:absolute;top:0;left:0}.c-PixiGallery-next{left:auto;right:0}.c-PixiGallery-legend{color:#7f7f7f;margin-top:12px}", ""]), t.exports = n
        },
        482: function(t, e, o) {
            var content = o(497);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("2fec3778", content, !0, {
                sourceMap: !1
            })
        },
        496: function(t, e, o) {
            "use strict";
            o(482)
        },
        497: function(t, e, o) {
            var n = o(54)(!1);
            n.push([t.i, ".c-TeamCircles{position:relative}.c-TeamCircles-img{position:absolute;top:0;left:0;width:100%;height:100%;display:none}@media only screen and (max-width:979px){.c-TeamCircles-img{display:block}}", ""]), t.exports = n
        },
        514: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(16), o(38), o(25), o(39);
            var n = o(17),
                r = (o(445), o(14)),
                c = o(444);

            function l(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var h = {
                    name: "TeamCircles",
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? l(Object(source), !0).forEach((function(e) {
                                Object(n.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : l(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(r.d)("window", {
                        isTouch: "isTouch",
                        winHeight: "height"
                    })),
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            t.getContainer(), t.container && (t.width = t.$el.offsetWidth, t.height = t.$el.offsetHeight, t.offsets = Object(c.a)(t.$el), t.init()), t.$eventHub.$on("resize", t.resize), t.$eventHub.$on("update", t.update)
                        }))
                    },
                    beforeDestroy: function() {
                        this.containerMask && this.container.removeChild(this.containerMask), this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update)
                    },
                    methods: {
                        getContainer: function() {
                            for (var t = this; t.$parent;) {
                                if (t.$parent.container && t.$parent.container instanceof this.$PIXI.Container) {
                                    this.container = t.$parent.container;
                                    break
                                }
                                t = t.$parent
                            }
                            if (!this.container) return console.warn("No pixi application founded for this Object. This component must be a child/subchild of a Pixi application", this)
                        },
                        init: function() {
                            this.isTouch || (this.containerMask = new this.$PIXI.Container, this.containerMask.position.x = this.offsets.left, this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.container.addChild(this.containerMask), this.ringOne = new this.$PIXI.Sprite.from("/team/ring-1.png"), this.containerMask.addChild(this.ringOne), this.ringOne.anchor.set(.5), this.ringOne.width = this.width, this.ringOne.height = this.height, this.ringOne.position.x = this.width / 2, this.ringOne.position.y = this.height / 2, this.ringTwo = new this.$PIXI.Sprite.from("/team/ring-2.png"), this.containerMask.addChild(this.ringTwo), this.ringTwo.anchor.set(.5), this.ringTwo.width = this.width, this.ringTwo.height = this.height, this.ringTwo.position.x = this.width / 2, this.ringTwo.position.y = this.height / 2, this.ringThree = new this.$PIXI.Sprite.from("/team/ring-3.png"), this.containerMask.addChild(this.ringThree), this.ringThree.anchor.set(.5), this.ringThree.width = this.width, this.ringThree.height = this.height, this.ringThree.position.x = this.width / 2, this.ringThree.position.y = this.height / 2, this.logo = new this.$PIXI.Sprite.from("/team/logo.png"), this.containerMask.addChild(this.logo), this.logo.anchor.set(.5), this.logo.width = this.width, this.logo.height = this.height, this.logo.position.x = this.width / 2, this.logo.position.y = this.height / 2)
                        },
                        resize: function() {
                            this.isTouch || (this.width = this.$el.offsetWidth, this.height = this.$el.offsetHeight, this.offsets = Object(c.a)(this.$el), this.containerMask.position.x = this.offsets.left, this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.triggerTop = this.offsets.top - this.winHeight, this.triggerBottom = this.triggerTop + this.winHeight + this.height)
                        },
                        update: function() {
                            this.containerMask && (this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.$root.smoothScroll >= this.triggerTop && this.$root.smoothScroll < this.triggerBottom && (this.ringOne.rotation = .2 * (this.$root.smoothScroll - this.triggerTop) / 360, this.ringTwo.rotation = .15 * -(this.$root.smoothScroll - this.triggerTop) / 360, this.ringThree.rotation = .1 * (this.$root.smoothScroll - this.triggerTop) / 360))
                        }
                    }
                },
                d = h,
                m = (o(496), o(26)),
                component = Object(m.a)(d, (function() {
                    var t = this,
                        e = t.$createElement;
                    t._self._c;
                    return t._m(0)
                }), [function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "c-TeamCircles"
                    }, [o("img", {
                        staticClass: "c-TeamCircles-img",
                        attrs: {
                            src: "/team/ring-1.png",
                            alt: "",
                            width: "1264",
                            height: "1264"
                        }
                    }), t._v(" "), o("img", {
                        staticClass: "c-TeamCircles-img",
                        attrs: {
                            src: "/team/ring-2.png",
                            alt: "",
                            width: "1264",
                            height: "1264"
                        }
                    }), t._v(" "), o("img", {
                        staticClass: "c-TeamCircles-img",
                        attrs: {
                            src: "/team/ring-3.png",
                            alt: "",
                            width: "1264",
                            height: "1264"
                        }
                    }), t._v(" "), o("img", {
                        staticClass: "c-TeamCircles-img",
                        attrs: {
                            src: "/team/logo.png",
                            alt: "",
                            width: "1264",
                            height: "1264"
                        }
                    })])
                }], !1, null, null, null);
            e.default = component.exports
        },
        530: function(t, e, o) {
            var content = o(557);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("0846be71", content, !0, {
                sourceMap: !1
            })
        },
        556: function(t, e, o) {
            "use strict";
            o(530)
        },
        557: function(t, e, o) {
            var n = o(54)(!1);
            n.push([t.i, '.c-Team{background:#fff}.c-Team-intro{height:100vh;color:#fff;display:flex;align-items:center;justify-content:center}.c-Team-intro-inner{position:relative}.c-Team-intro-title{margin-bottom:70px}@media only screen and (max-width:767px){.c-Team-intro-title{text-align:center}}.c-Team-intro-title-line{display:block;opacity:0;transform:translateX(-2vw) translateZ(0);transition:opacity 1.2s cubic-bezier(.165,.84,.44,1) .4s,transform 1.2s cubic-bezier(.165,.84,.44,1) .4s}.c-Team-intro-title-line--1{margin-left:16.51vw;transform:translateX(2vw) translateZ(0)}@media only screen and (max-width:767px){.c-Team-intro-title-line--1{margin-left:0}}.c-Team-intro-title-line--2{margin-left:10.416vw;transform:translateX(-2vw) translateZ(0)}@media only screen and (max-width:767px){.c-Team-intro-title-line--2{margin-left:0}}.is-page-ready .c-Team-intro-title-line{opacity:1;transform:translateZ(0)}.c-Team-intro-foot{position:absolute;bottom:70px;left:0;opacity:0;transform:translateZ(0);transition:opacity 1.2s cubic-bezier(.165,.84,.44,1) .4s}.is-page-ready .c-Team-intro-foot{opacity:1}@media only screen and (max-width:767px){.c-Team-intro-foot{bottom:25px}}.c-Team-intro-foot-info{text-transform:uppercase;text-align:justify;-moz-text-align-last:justify;text-align-last:justify}@media only screen and (max-width:767px){.c-Team-intro-foot-text{display:none}}.c-Team-intro-scroll{position:absolute;bottom:50px;right:3.9vw;display:block;margin-right:15px;width:17px;height:52.5px}@media only screen and (max-width:767px){.c-Team-intro-scroll{right:3.65vw;bottom:25px;margin-right:0}}.c-Team-intro-scroll img{width:100%;height:100%}.c-Team-members{margin-top:150px;margin-bottom:150px}@media only screen and (max-width:979px){.c-Team-members{margin-top:100px;margin-bottom:100px}}@media only screen and (max-width:767px){.c-Team-members{margin-top:60px;margin-bottom:60px}}.c-Team-members-title{position:relative}.c-Team-item{display:block;margin-top:125px}@media only screen and (max-width:979px){.c-Team-item{margin-top:80px}}@media only screen and (max-width:767px){.c-Team-item{margin-top:30px}}.c-Team-item:first-child,.c-Team-item:nth-child(2){margin-top:0}@media only screen and (max-width:767px){.c-Team-item:first-child,.c-Team-item:nth-child(2){margin-top:40px}}.c-Team-item-img{position:relative}.c-Team-item-img:before{position:relative;content:"";display:block;height:0;width:100%;padding-top:135.1145038168%}.c-Team-item-info{margin-top:20px;border-top:1px solid #000}@media only screen and (max-width:767px){.c-Team-item-info{margin-top:15px}}.c-Team-item-info-title{margin-top:20px}@media only screen and (max-width:767px){.c-Team-item-info-title{margin-top:15px}}.c-Team-item-info-roles{margin-top:14px;color:#7f7f7f}.c-Team-item-info-roles li{display:flex;align-items:center;margin-top:5px}.c-Team-item-info-roles li:before{content:"";display:inline-block;height:0;width:0;border-radius:0;background:transparent;border-top:3px solid transparent;border-bottom:3px solid transparent;border-left:5px solid;margin-right:7px;margin-left:0}.c-Team-weare{padding-top:200px;padding-bottom:200px;color:#fff}.is-touch .c-Team-weare{background:#000}@media only screen and (max-width:979px){.c-Team-weare{padding-top:100px;padding-bottom:100px}}@media only screen and (max-width:767px){.c-Team-weare{padding-top:60px;padding-bottom:60px}}.c-Team-weare-title{position:relative;text-transform:uppercase;font-size:5.7291666667vw;line-height:1}@media only screen and (max-width:767px){.c-Team-weare-title{font-size:9.0666666667vw;padding-bottom:110px}}.c-Team-weare-title-line{position:relative;display:block;opacity:0;transform:translateY(40px) translateZ(0)}.c-Team-weare-title-line:first-child{transition:opacity 1.2s cubic-bezier(.165,.84,.44,1) .1s,transform 1.2s cubic-bezier(.165,.84,.44,1) .1s}.c-Team-weare-title-line:nth-child(2){transition:opacity 1.2s cubic-bezier(.165,.84,.44,1) .2s,transform 1.2s cubic-bezier(.165,.84,.44,1) .2s}.c-Team-weare-title-line:nth-child(3){transition:opacity 1.2s cubic-bezier(.165,.84,.44,1) .3s,transform 1.2s cubic-bezier(.165,.84,.44,1) .3s}.c-Team-weare-title-line:nth-child(4){transition:opacity 1.2s cubic-bezier(.165,.84,.44,1) .4s,transform 1.2s cubic-bezier(.165,.84,.44,1) .4s}.c-Team-weare-title-line:nth-child(5){transition:opacity 1.2s cubic-bezier(.165,.84,.44,1) .5s,transform 1.2s cubic-bezier(.165,.84,.44,1) .5s}.is-appear .c-Team-weare-title-line{opacity:1;transform:translateZ(0)}.c-Team-weare-title-line--2,.c-Team-weare-title-line--3{text-align:right}@media only screen and (max-width:767px){.c-Team-weare-title-line--2,.c-Team-weare-title-line--3{text-align:left}}.c-Team-weare-title-line--2 img,.c-Team-weare-title-line--3 img{left:0;right:auto}.c-Team-weare-title-line img{position:absolute;top:13%;right:0;height:74%;width:auto}@media only screen and (max-width:767px){.c-Team-weare-title-line img{display:none}}.c-Team-weare-title-img{display:none}@media only screen and (max-width:767px){.c-Team-weare-title-img{position:relative;position:absolute;width:80%;bottom:0;right:0;display:block}.c-Team-weare-title-img:before{position:relative;content:"";display:block;height:0;width:100%;padding-top:56.1904761905%}}.c-Team-weare-foot{margin-top:60px;border-top:1px solid #fff;padding-top:70px}@media only screen and (max-width:767px){.c-Team-weare-foot{padding-top:40px}}.c-Team-weare-baseline{display:block;text-align:justify;-moz-text-align-last:justify;text-align-last:justify;text-transform:uppercase}@media only screen and (max-width:767px){.c-Team-weare-baseline{margin-bottom:25px}}.c-Team-section{margin:200px 0}@media only screen and (max-width:979px){.c-Team-section{margin:100px 0}}@media only screen and (max-width:767px){.c-Team-section{margin:60px 0}}.c-Team-section-inner{border-top:1px solid #000;padding-top:75px}@media only screen and (max-width:979px){.c-Team-section-inner{padding-top:40px}}@media only screen and (max-width:767px){.c-Team-section-inner{padding-top:30px}}.c-Team-section-info{display:flex;align-items:flex-start;color:#7f7f7f;text-transform:uppercase}@media only screen and (max-width:979px){.c-Team-section-info{margin-bottom:15px}}@media only screen and (max-width:767px){.c-Team-section-info{margin-bottom:15px}}.c-Team-section-info:before{content:"";display:inline-block;height:0;width:0;border-radius:0;background:transparent;border-top:3px solid transparent;border-bottom:3px solid transparent;border-left:5px solid #000;margin-right:7px;margin-top:6px}.c-Team-section-title{margin-bottom:110px;text-transform:uppercase}@media only screen and (max-width:767px){.c-Team-section-title{margin-bottom:30px}}.c-Team-section-img{width:100%;height:0}.c-Team-section-bold{font-weight:700}@media only screen and (max-width:767px){.c-Team-section-bold{margin-top:20px;margin-bottom:40px}}@media only screen and (max-width:767px){.c-Team-section-columns{-moz-column-count:2;column-count:2}}.c-Team-founders-names{text-transform:uppercase}.c-Team-network{padding-top:100px;padding-bottom:170px;color:#fff}.is-touch .c-Team-network{background:#000}@media only screen and (max-width:979px){.c-Team-network{padding-top:80px;padding-bottom:100px}}@media only screen and (max-width:767px){.c-Team-network{padding-top:60px;padding-bottom:60px}}.c-Team-network-img,.c-Team-network-img:before{position:relative;width:100%}.c-Team-network-img:before{content:"";display:block;height:0;padding-top:100%}@media only screen and (max-width:767px){.c-Team-network-item{margin-top:25px}}.c-Team-network-info{margin-top:60px;border-top:1px solid #fff;padding-top:35px}@media only screen and (max-width:767px){.c-Team-network-info{margin-top:40px;padding-top:0}}.c-Team-network-members{font-weight:700}.c-Team-network-link{margin-top:15px}@media only screen and (max-width:767px){.c-Team-network-link{margin-top:10px}}.c-Team-contact-info{padding-left:12px;border-left:1px solid}.c-Team-contact-info-title{margin-bottom:25px}@media only screen and (max-width:767px){.c-Team-contact-column{margin-top:50px}.c-Team-contact-column:first-child{margin-top:0}}.c-Team-contact-circles{display:block;width:23.22vw;height:auto;margin:80px auto 0}@media only screen and (max-width:767px){.c-Team-contact-circles{display:none}}', ""]), t.exports = n
        },
        577: function(t, e, o) {
            "use strict";
            o.r(e);
            var n = o(17),
                r = o(18),
                c = (o(75), o(275), o(35), o(29), o(31), o(16), o(38), o(25), o(39), o(46)),
                l = o(4),
                h = o(14),
                d = o(451),
                m = o(448),
                f = o(461),
                v = o(476),
                x = o(458),
                w = o(514),
                y = o(462),
                T = o(466),
                _ = o(475),
                C = o(456);

            function $(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }

            function O(t) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = null != arguments[i] ? arguments[i] : {};
                    i % 2 ? $(Object(source), !0).forEach((function(e) {
                        Object(n.a)(t, e, source[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : $(Object(source)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                    }))
                }
                return t
            }
            var k = {
                    name: "Team",
                    components: {
                        StickyElement: d.default,
                        PixiImage: m.default,
                        PixiColor: f.default,
                        PixiGallery: v.default,
                        IntroGradient: x.default,
                        TeamCircles: w.default,
                        LazyImg: y.default,
                        CirclesLottie: T.default,
                        AppearObject: _.default
                    },
                    mixins: [C.a],
                    asyncData: function(t) {
                        return Object(r.a)(regeneratorRuntime.mark((function e() {
                            var o, n, r;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return o = t.$prismic, t.store, n = t.error, e.prev = 1, e.next = 4, o.api.query(o.predicates.at("document.type", "team"));
                                    case 4:
                                        return r = e.sent.results[0].data, e.abrupt("return", {
                                            document: r
                                        });
                                    case 8:
                                        e.prev = 8, e.t0 = e.catch(1), n({
                                            statusCode: 404,
                                            message: "Page not found"
                                        });
                                    case 11:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [1, 8]
                            ])
                        })))()
                    },
                    computed: O(O(O({}, Object(h.d)(["members"])), Object(h.d)("main", ["isPageReady"])), Object(h.d)("window", ["minHeight"])),
                    methods: {
                        getGradientOptions: function(text) {
                            var t = (new DOMParser).parseFromString(text, "text/html").getElementsByTagName("monopo-gradient")[0];
                            return {
                                color1: t.getAttribute("color1"),
                                color2: t.getAttribute("color2"),
                                color3: t.getAttribute("color3"),
                                color4: t.getAttribute("color4"),
                                colorsize: t.getAttribute("colorsize"),
                                colorspacing: t.getAttribute("colorspacing"),
                                colorrotation: t.getAttribute("colorrotation"),
                                colorspread: t.getAttribute("colorspread"),
                                coloroffset: t.getAttribute("coloroffset"),
                                displacement: t.getAttribute("displacement"),
                                seed: t.getAttribute("seed"),
                                position: t.getAttribute("position"),
                                zoom: t.getAttribute("zoom"),
                                spacing: t.getAttribute("spacing") || 5
                            }
                        },
                        onScroll: function() {
                            c.a.to(window, {
                                scrollTo: this.minHeight,
                                duration: .6,
                                ease: l.c.easeInOut
                            })
                        }
                    }
                },
                P = (o(556), o(26)),
                component = Object(P.a)(k, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "c-Team",
                        class: {
                            "is-page-ready": t.isPageReady
                        }
                    }, [o("IntroGradient", {
                        staticClass: "c-Team-intro",
                        style: {
                            height: t.minHeight + "px"
                        },
                        attrs: {
                            options: t.getGradientOptions(t.document.gradient)
                        }
                    }, [o("div", {
                        staticClass: "c-Team-intro-inner"
                    }, [o("h1", {
                        staticClass: "c-Team-intro-title t-h1"
                    }, [o("span", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.title[0].line_one),
                            expression: "$prismic.asText(document.title[0].line_one)"
                        }],
                        staticClass: "c-Team-intro-title-line c-Team-intro-title-line--0"
                    }, [t._v(t._s(t.$prismic.asText(t.document.title[0].line_one)))]), t._v(" "), o("span", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.title[0].line_two),
                            expression: "$prismic.asText(document.title[0].line_two)"
                        }],
                        staticClass: "c-Team-intro-title-line c-Team-intro-title-line--1"
                    }, [t._v(t._s(t.$prismic.asText(t.document.title[0].line_two)))]), t._v(" "), o("span", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.title[0].line_three),
                            expression: "$prismic.asText(document.title[0].line_three)"
                        }],
                        staticClass: "c-Team-intro-title-line c-Team-intro-title-line--2"
                    }, [t._v(t._s(t.$prismic.asText(t.document.title[0].line_three)))])])]), t._v(" "), o("div", {
                        staticClass: "c-Team-intro-foot container"
                    }, [o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "col-3of24 offset-6of24 col-md-5of24 offset-md-1of24 col-sm-6of12 offset-sm-0"
                    }, [o("p", {
                        staticClass: "c-Team-intro-foot-info t-text--sm"
                    }, [t._v("\n                        " + t._s(t.document.baseline) + "\n                    ")])]), t._v(" "), o("div", {
                        staticClass: "c-Team-intro-foot-text col-5of24 col-md-7of24 offset-5of24"
                    }, [o("PrismicRichText", {
                        staticClass: "t-wysiwyg t-text",
                        attrs: {
                            field: t.document.introduction_text
                        }
                    })], 1)])]), t._v(" "), o("button", {
                        staticClass: "c-Team-intro-scroll t-btn",
                        attrs: {
                            type: "button"
                        },
                        on: {
                            click: t.onScroll
                        }
                    }, [o("img", {
                        attrs: {
                            src: "/arrow_scroll.png",
                            width: "34",
                            height: "105",
                            alt: "scroll down"
                        }
                    })])]), t._v(" "), o("section", {
                        staticClass: "js-sticky-container c-Team-members container"
                    }, [o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "js-section col-4of24 col-sm-9of12"
                    }, [o("StickyElement", {
                        staticClass: "c-Team-title",
                        attrs: {
                            "gap-top": 70
                        }
                    }, [o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "col-1of4 col-sm-1of9"
                    }, [o("span", {
                        staticClass: "t-h2"
                    }, [t._v("→")])]), t._v(" "), o("div", {
                        staticClass: "col-3of4 col-sm-8of9"
                    }, [o("h2", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.members_title),
                            expression: "$prismic.asText(document.members_title)"
                        }],
                        staticClass: "t-h2"
                    }, [t._v("\n                                " + t._s(t.$prismic.asText(t.document.members_title)) + "\n                            ")])])])])], 1), t._v(" "), o("div", {
                        staticClass: "col-17of24 offset-3of24 col-sm-10of12 offset-sm-2of12"
                    }, [o("div", {
                        staticClass: "row"
                    }, t._l(t.members, (function(e, i) {
                        return o("NuxtLink", {
                            key: e.uid,
                            staticClass: "c-Team-item t-link js-section col-8of17 col-sm-10of10 offset-sm-0",
                            class: {
                                "offset-1of17": i % 2 == 1
                            },
                            attrs: {
                                to: {
                                    name: "team-slug",
                                    params: {
                                        slug: e.uid
                                    }
                                }
                            }
                        }, [o("PixiImage", {
                            staticClass: "c-Team-item-img",
                            attrs: {
                                "use-mask": !0,
                                "use-hover": !0,
                                field: e.data.image
                            }
                        }), t._v(" "), o("div", {
                            staticClass: "c-Team-item-info"
                        }, [o("h3", {
                            directives: [{
                                name: "italic",
                                rawName: "v-italic",
                                value: t.$prismic.asText(e.data.name),
                                expression: "$prismic.asText(member.data.name)"
                            }],
                            staticClass: "c-Team-item-info-title t-h4"
                        }, [t._v("\n                                " + t._s(t.$prismic.asText(e.data.name)) + "\n                            ")]), t._v(" "), o("ul", {
                            staticClass: "c-Team-item-info-roles t-list t-h6 t-h6--spacing"
                        }, t._l(e.data.roles, (function(e, n) {
                            return o("li", {
                                key: n
                            }, [t._v("\n                                    " + t._s(e.label) + "\n                                ")])
                        })), 0)])], 1)
                    })), 1)])])]), t._v(" "), o("PixiColor", {
                        staticClass: "js-section c-Team-weare container",
                        attrs: {
                            color: "#000000"
                        }
                    }, [o("div", {
                        staticClass: "row center"
                    }, [o("div", {
                        staticClass: "col-20of24 col-sm-12of12"
                    }, [o("AppearObject", {
                        staticClass: "c-Team-weare-title t-h1"
                    }, [o("div", {
                        staticClass: "c-Team-weare-title-img"
                    }, [o("LazyImg", {
                        attrs: {
                            field: t.document.we_are_image,
                            full: !0
                        }
                    })], 1), t._v(" "), o("span", {
                        staticClass: "c-Team-weare-title-line c-Team-weare-title-line--0"
                    }, [o("span", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.document.we_are_title[0].line_one,
                            expression: "document.we_are_title[0].line_one"
                        }]
                    }, [t._v(t._s(t.document.we_are_title[0].line_one))]), o("img", {
                        attrs: {
                            src: "/team/all-1.png",
                            alt: "",
                            width: "554",
                            height: "169"
                        }
                    })]), t._v(" "), o("span", {
                        staticClass: "c-Team-weare-title-line c-Team-weare-title-line--1"
                    }, [o("span", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.document.we_are_title[0].line_two,
                            expression: "document.we_are_title[0].line_two"
                        }]
                    }, [t._v(t._s(t.document.we_are_title[0].line_two))]), o("img", {
                        attrs: {
                            src: "/team/all-2.png",
                            alt: "",
                            width: "1604",
                            height: "169"
                        }
                    })]), t._v(" "), o("span", {
                        staticClass: "c-Team-weare-title-line c-Team-weare-title-line--2"
                    }, [o("img", {
                        attrs: {
                            src: "/team/all-3.png",
                            alt: "",
                            width: "1166",
                            height: "169"
                        }
                    }), o("span", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.document.we_are_title[0].line_three,
                            expression: "document.we_are_title[0].line_three"
                        }]
                    }, [t._v(t._s(t.document.we_are_title[0].line_three))])]), t._v(" "), o("span", {
                        staticClass: "c-Team-weare-title-line c-Team-weare-title-line--3"
                    }, [o("img", {
                        attrs: {
                            src: "/team/all-4.png",
                            alt: "",
                            width: "368",
                            height: "169"
                        }
                    }), o("span", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.document.we_are_title[0].line_four,
                            expression: "document.we_are_title[0].line_four"
                        }]
                    }, [t._v(t._s(t.document.we_are_title[0].line_four))])])])], 1)]), t._v(" "), o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "col-10of24 offset-12of24 col-md-14of24 offset-md-8of24 col-sm-12of12 offset-sm-0"
                    }, [o("div", {
                        staticClass: "c-Team-weare-foot"
                    }, [o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "col-4of10 col-md-4of14 col-sm-8of12"
                    }, [o("span", {
                        staticClass: "c-Team-weare-baseline t-text--sm"
                    }, [t._v(t._s(t.document.we_are_baseline))])]), t._v(" "), o("div", {
                        staticClass: "col-4of10 offset-1of10 col-md-8of14 offset-md-2of14 col-sm-9of12 offset-sm-1of12"
                    }, [o("PrismicRichText", {
                        staticClass: "c-Team-section-bold t-wysiwyg t-text",
                        attrs: {
                            field: t.document.we_are_text
                        }
                    })], 1)])])])])]), t._v(" "), o("section", {
                        staticClass: "js-section c-Team-section container"
                    }, [o("div", {
                        staticClass: "c-Team-section-inner"
                    }, [o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "col-2of24 col-md-24of24 col-sm-12of12"
                    }, [o("span", {
                        staticClass: "c-Team-section-info t-text"
                    }, [t._v(t._s(t.document.tokyo_founders_date))])]), t._v(" "), o("div", {
                        staticClass: "col-10of24 col-md-12of24 col-sm-12of12"
                    }, [o("h2", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.tokyo_founders_title),
                            expression: "$prismic.asText(document.tokyo_founders_title)"
                        }],
                        staticClass: "c-Team-section-title t-h2"
                    }, [t._v("\n                        " + t._s(t.$prismic.asText(t.document.tokyo_founders_title)) + "\n                    ")]), t._v(" "), o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "col-4of10 col-md-5of12 col-sm-6of12"
                    }, [o("ul", {
                        staticClass: "c-Team-founders-names t-list t-text"
                    }, t._l(t.document.tokyo_founders, (function(e, i) {
                        return o("li", {
                            key: i
                        }, [t._v("\n                                    " + t._s(e.name) + "\n                                ")])
                    })), 0)]), t._v(" "), o("div", {
                        staticClass: "col-5of10 offset-1of10 col-md-7of12 offset-md-0 col-sm-11of12 offset-sm-1of12"
                    }, [o("PrismicRichText", {
                        staticClass: "c-Team-section-bold t-wysiwyg t-text",
                        attrs: {
                            field: t.document.tokyo_founders_text
                        }
                    })], 1)])]), t._v(" "), o("div", {
                        staticClass: "col-10of24 offset-2of24 col-sm-12of12 offset-sm-0"
                    }, [o("PixiImage", {
                        staticClass: "c-Team-section-img",
                        style: {
                            paddingTop: t.document.tokyo_founders_image.dimensions.height / t.document.tokyo_founders_image.dimensions.width * 100 + "%"
                        },
                        attrs: {
                            field: t.document.tokyo_founders_image
                        }
                    })], 1)])])]), t._v(" "), o("section", {
                        staticClass: "js-section c-Team-section container"
                    }, [o("div", {
                        staticClass: "c-Team-section-inner"
                    }, [o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "col-2of24 col-md-24of24 col-sm-12of12"
                    }, [o("span", {
                        staticClass: "c-Team-section-info t-text"
                    }, [t._v(t._s(t.document.london_founders_date))])]), t._v(" "), o("div", {
                        staticClass: "col-10of24 col-md-12of24 col-sm-12of12"
                    }, [o("h2", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.london_founders_title),
                            expression: "$prismic.asText(document.london_founders_title)"
                        }],
                        staticClass: "c-Team-section-title t-h2"
                    }, [t._v("\n                        " + t._s(t.$prismic.asText(t.document.london_founders_title)) + "\n                    ")]), t._v(" "), o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "col-4of10 col-md-5of12 col-sm-6of12"
                    }, [o("ul", {
                        staticClass: "c-Team-founders-names t-list t-text"
                    }, t._l(t.document.london_founders, (function(e, i) {
                        return o("li", {
                            key: i
                        }, [t._v("\n                                    " + t._s(e.name) + "\n                                ")])
                    })), 0)]), t._v(" "), o("div", {
                        staticClass: "col-5of10 offset-1of10 col-md-7of12 offset-md-0 col-sm-11of12 offset-sm-1of12"
                    }, [o("PrismicRichText", {
                        staticClass: "c-Team-section-bold t-wysiwyg t-text",
                        attrs: {
                            field: t.document.london_founders_text
                        }
                    })], 1)])]), t._v(" "), o("div", {
                        staticClass: "col-7of24 offset-4of24 col-sm-12of12 offset-sm-0"
                    }, [o("PixiImage", {
                        staticClass: "c-Team-section-img",
                        style: {
                            paddingTop: t.document.london_founders_image.dimensions.height / t.document.london_founders_image.dimensions.width * 100 + "%"
                        },
                        attrs: {
                            field: t.document.london_founders_image
                        }
                    })], 1)])])]), t._v(" "), o("PixiColor", {
                        staticClass: "js-section c-Team-network container",
                        attrs: {
                            color: "#000000"
                        }
                    }, [o("div", {
                        staticClass: "row center"
                    }, [o("div", {
                        staticClass: "col-8of24 col-sm-12of12"
                    }, [o("TeamCircles", {
                        staticClass: "c-Team-network-img"
                    })], 1)]), t._v(" "), o("div", {
                        staticClass: "row center"
                    }, [o("div", {
                        staticClass: "col-16of24 col-md-24of24 col-sm-12of12"
                    }, [o("div", {
                        staticClass: "c-Team-network-info"
                    }, [o("div", {
                        staticClass: "row"
                    }, t._l(t.document.places, (function(e, i) {
                        return o("div", {
                            key: i,
                            staticClass: "c-Team-network-item col-4of16 col-md-6of24 col-sm-12of12 offset-sm-0"
                        }, [o("PrismicRichText", {
                            staticClass: "c-Team-network-members t-wysiwyg t-text--lg",
                            attrs: {
                                field: e.number_of_members
                            }
                        }), t._v(" "), e.link_label ? o("PrismicLink", {
                            staticClass: "c-Team-network-link t-link-tertiary",
                            attrs: {
                                field: e.link
                            }
                        }, [o("span", {
                            staticClass: "t-link-tertiary-icon"
                        }, [t._v("↗")]), t._v(" "), o("span", {
                            staticClass: "t-link-tertiary-label"
                        }, [t._v(t._s(e.link_label))])]) : t._e()], 1)
                    })), 0)])])])]), t._v(" "), o("section", {
                        staticClass: "js-section c-Team-section container"
                    }, [o("div", {
                        staticClass: "c-Team-section-inner"
                    }, [o("div", {
                        staticClass: "row"
                    }, [t._m(0), t._v(" "), o("div", {
                        staticClass: "col-10of24 col-md-12of24 col-sm-12of12"
                    }, [o("h2", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.community_title),
                            expression: "$prismic.asText(document.community_title)"
                        }],
                        staticClass: "c-Team-section-title t-h2"
                    }, [t._v("\n                        " + t._s(t.$prismic.asText(t.document.community_title)) + "\n                    ")]), t._v(" "), o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "col-3of10 col-md-7of12 col-sm-10of12"
                    }, [o("PrismicRichText", {
                        staticClass: "t-wysiwyg t-text",
                        attrs: {
                            field: t.document.community_text
                        }
                    })], 1), t._v(" "), o("div", {
                        staticClass: "col-5of10 offset-2of10 col-md-4of12 offset-md-1of12 col-sm-11of12 offset-sm-1of12"
                    }, [o("ul", {
                        staticClass: "c-Team-section-bold c-Team-section-columns t-list t-text"
                    }, t._l(t.document.community_list, (function(e, i) {
                        return o("li", {
                            key: i
                        }, [t._v("\n                                    " + t._s(e.label) + "\n                                ")])
                    })), 0)])])]), t._v(" "), o("div", {
                        staticClass: "col-10of24 offset-2of24  col-sm-12of12 offset-sm-0"
                    }, [o("PixiImage", {
                        staticClass: "c-Team-section-img",
                        style: {
                            paddingTop: t.document.community_image.dimensions.height / t.document.community_image.dimensions.width * 100 + "%"
                        },
                        attrs: {
                            field: t.document.community_image
                        }
                    })], 1)])])]), t._v(" "), o("section", {
                        staticClass: "js-section c-Team-section container"
                    }, [o("div", {
                        staticClass: "c-Team-section-inner"
                    }, [o("div", {
                        staticClass: "row"
                    }, [t._m(1), t._v(" "), o("div", {
                        staticClass: "col-7of24 col-md-9of24 col-sm-12of12"
                    }, [o("h2", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.studio_title),
                            expression: "$prismic.asText(document.studio_title)"
                        }],
                        staticClass: "c-Team-section-title t-h2"
                    }, [t._v("\n                        " + t._s(t.$prismic.asText(t.document.studio_title)) + "\n                    ")])]), t._v(" "), o("div", {
                        staticClass: "col-14of24 offset-1of24 col-sm-12of12 offset-sm-0"
                    }, [o("PixiGallery", {
                        attrs: {
                            items: t.document.studio_gallery
                        }
                    })], 1)])])]), t._v(" "), o("section", {
                        staticClass: "js-section c-Team-section container"
                    }, [o("div", {
                        staticClass: "c-Team-section-inner"
                    }, [o("div", {
                        staticClass: "row"
                    }, [t._m(2), t._v(" "), o("div", {
                        staticClass: "col-7of24 col-sm-12of12"
                    }, [o("h2", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.jobs_title),
                            expression: "$prismic.asText(document.jobs_title)"
                        }],
                        staticClass: "c-Team-section-title t-h2"
                    }, [t._v("\n                        " + t._s(t.$prismic.asText(t.document.jobs_title)) + "\n                    ")])]), t._v(" "), o("div", {
                        staticClass: "col-11of24 offset-2of24 col-md-14of24 offset-md-1of24 col-sm-12of12 offset-sm-0"
                    }, [o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "c-Team-contact-column col-6of11 col-md-7of14 col-sm-12of12"
                    }, [o("div", {
                        staticClass: "c-Team-contact-info"
                    }, [o("h2", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.careers_title),
                            expression: "$prismic.asText(document.careers_title)"
                        }],
                        staticClass: "c-Team-contact-info-title t-h5 t-h5--bold"
                    }, [t._v("\n                                    " + t._s(t.$prismic.asText(t.document.careers_title)) + "\n                                ")]), t._v(" "), o("PrismicRichText", {
                        staticClass: "t-wysiwyg t-text",
                        attrs: {
                            field: t.document.careers_paragraph
                        }
                    })], 1)]), t._v(" "), o("div", {
                        staticClass: "c-Team-contact-column col-4of11 offset-1of11 col-md-6of14 offset-md-1of14 col-sm-12of12 offset-sm-0"
                    }, [o("div", {
                        staticClass: "c-Team-contact-info"
                    }, [o("h2", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.$prismic.asText(t.document.freelance_title),
                            expression: "$prismic.asText(document.freelance_title)"
                        }],
                        staticClass: "c-Team-contact-info-title t-h5 t-h5--bold"
                    }, [t._v("\n                                    " + t._s(t.$prismic.asText(t.document.freelance_title)) + "\n                                ")]), t._v(" "), o("PrismicRichText", {
                        staticClass: "t-wysiwyg t-text",
                        attrs: {
                            field: t.document.freelance_paragraph
                        }
                    })], 1)])]), t._v(" "), o("CirclesLottie", {
                        staticClass: "c-Team-contact-circles"
                    })], 1)])])])], 1)
                }), [function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "col-2of24 col-md-24of24 col-sm-12of12"
                    }, [o("span", {
                        staticClass: "c-Team-section-info t-text"
                    }, [t._v("LDN"), o("br"), t._v("TKY"), o("br"), t._v("NYC")])])
                }, function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "col-2of24 col-md-24of24 col-sm-12of12"
                    }, [o("span", {
                        staticClass: "c-Team-section-info t-text"
                    }, [t._v("STUDIO"), o("br"), t._v("LIFE")])])
                }, function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "col-2of24 col-md-24of24 col-sm-12of12"
                    }, [o("span", {
                        staticClass: "c-Team-section-info t-text"
                    }, [t._v("JOBS")])])
                }], !1, null, null, null);
            e.default = component.exports;
            installComponents(component, {
                IntroGradient: o(458).default,
                StickyElement: o(451).default,
                PixiImage: o(448).default,
                LazyImg: o(462).default,
                AppearObject: o(475).default,
                PixiColor: o(461).default,
                TeamCircles: o(514).default,
                PixiGallery: o(476).default,
                CirclesLottie: o(466).default
            })
        }
    }
]);