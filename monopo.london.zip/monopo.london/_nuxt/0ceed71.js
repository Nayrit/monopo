(window.webpackJsonp = window.webpackJsonp || []).push([
    [39, 10, 11, 19, 25], {
        444: function(t, e, o) {
            "use strict";

            function r(t) {
                var e = 0,
                    o = 0;
                do {
                    e += t.offsetTop, o += t.offsetLeft, t = t.offsetParent
                } while (t);
                return {
                    top: e,
                    left: o
                }
            }
            o.d(e, "a", (function() {
                return r
            }))
        },
        445: function(t, e, o) {
            "use strict";
            var r = o(6),
                n = o(446);
            r({
                target: "String",
                proto: !0,
                forced: o(447)("anchor")
            }, {
                anchor: function(t) {
                    return n(this, "a", "name", t)
                }
            })
        },
        446: function(t, e, o) {
            var r = o(10),
                n = o(52),
                c = o(32),
                l = /"/g,
                h = r("".replace);
            t.exports = function(t, e, o, r) {
                var d = c(n(t)),
                    f = "<" + e;
                return "" !== o && (f += " " + o + '="' + h(c(r), l, "&quot;") + '"'), f + ">" + d + "</" + e + ">"
            }
        },
        447: function(t, e, o) {
            var r = o(12);
            t.exports = function(t) {
                return r((function() {
                    var e = "" [t]('"');
                    return e !== e.toLowerCase() || e.split('"').length > 3
                }))
            }
        },
        448: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(38), o(39);
            var r = o(17),
                n = (o(101), o(16), o(25), o(445), o(46)),
                c = o(4),
                l = o(14),
                h = o(444),
                d = o(450);

            function f(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var m = {
                    name: "PixiImage",
                    props: {
                        field: {
                            type: Object,
                            default: null,
                            required: !0
                        },
                        fieldReveal: {
                            type: Object,
                            default: null
                        },
                        useBrush: {
                            type: Boolean,
                            default: !1
                        },
                        useMask: {
                            type: Boolean,
                            default: !1
                        },
                        useHover: {
                            type: Boolean,
                            default: !1
                        },
                        hide: {
                            type: Boolean,
                            default: !1
                        },
                        debug: {
                            type: Boolean,
                            default: !1
                        },
                        parallax: {
                            type: Number,
                            default: 0
                        },
                        screenPos: {
                            type: Number,
                            default: .5
                        }
                    },
                    data: function() {
                        return {
                            isLoaded: !1
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? f(Object(source), !0).forEach((function(e) {
                                Object(r.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : f(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(l.d)("window", {
                        isTouch: "isTouch",
                        winWidth: "width",
                        winHeight: "height"
                    })),
                    watch: {
                        hide: "onHideChange"
                    },
                    created: function() {
                        this.cursorPos = {
                            x: 0,
                            y: 0
                        }, this.delta = {
                            x: 0,
                            y: 0,
                            v: 0
                        }, this.mouseX = 0, this.mouseY = 0, this.scale = 0, this.smoothScale = 0, this._onPointerEnter = this.onPointerEnter.bind(this), this._onPointerMove = this.onPointerMove.bind(this), this._onPointerLeave = this.onPointerLeave.bind(this)
                    },
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            t.getContainer(), t.container && !t.isTouch && (t.width = t.$el.offsetWidth, t.height = t.$el.offsetHeight, t.offsets = Object(h.a)(t.$el), t.computedSize = Object(d.a)(t.field.dimensions.width, t.field.dimensions.height, t.width, t.height, !1), t.offsetX = Math.round(.5 * (t.width - t.computedSize.width)), t.offsetY = Math.round(.5 * (t.height - t.computedSize.height)), t.init()), t.observer = new IntersectionObserver((function(e) {
                                e.forEach((function(e) {
                                    e.isIntersecting && (t.$refs.img.onload = function() {
                                        t.isLoaded = !0, t.image && n.a.to(t.image, {
                                            duration: 1.2,
                                            alpha: 1,
                                            ease: c.c.easeOut,
                                            onComplete: function() {
                                                t.containerMask.removeChild(t.background), t.background.destroy(), t.background = null
                                            }
                                        })
                                    }, t.$refs.img.src = t.$refs.img.dataset.src, t.$refs.img.srcset = t.$refs.img.dataset.srcset, !t.image && t.containerMask && t.createImage(), t.observer.unobserve(e.target), t.observer.disconnect())
                                }))
                            })), t.observer.observe(t.$el), t.$eventHub.$on("resize", t.resize), t.$eventHub.$on("update", t.update), (t.useBrush || t.useHover) && (t.$el.addEventListener("pointerenter", t._onPointerEnter), window.addEventListener("pointermove", t._onPointerMove), t.$el.addEventListener("pointerleave", t._onPointerLeave))
                        }))
                    },
                    beforeDestroy: function() {
                        this.$refs.img && this.observer && (this.observer.unobserve(this.$el), this.observer.disconnect()), this.containerMask && this.container.removeChild(this.containerMask), this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update), (this.useBrush || this.useHover) && (this.$el.removeEventListener("pointerenter", this._onPointerEnter), window.removeEventListener("pointermove", this._onPointerMove), this.$el.removeEventListener("pointerleave", this._onPointerLeave))
                    },
                    methods: {
                        getContainer: function() {
                            for (var t = this; t.$parent;) {
                                if (t.$parent.container && t.$parent.container instanceof this.$PIXI.Container) {
                                    this.container = t.$parent.container;
                                    break
                                }
                                t = t.$parent
                            }
                            if (!this.container) return console.warn("No pixi application founded for this Object. This component must be a child/subchild of a Pixi application", this)
                        },
                        init: function() {
                            this.containerMask = new this.$PIXI.Container, this.containerMask.position.x = this.offsets.left, this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.hide && (this.containerMask.alpha = 0), this.container.addChild(this.containerMask), this.background = new this.$PIXI.Sprite.from(this.field.thumb.url), this.background.anchor.set(0), this.background.width = this.width, this.background.height = this.height, this.containerMask.addChild(this.background), this.useMask && (this.mask = new this.$PIXI.Graphics, this.containerMask.addChild(this.mask), this.mask.beginFill("0x000000"), this.mask.drawRect(0, 0, this.width, this.height), this.mask.endFill(), this.containerMask.mask = this.mask)
                        },
                        createImage: function() {
                            this.image = new this.$PIXI.Sprite.from(window.devicePixelRatio > 1 ? this.field.retina.url : this.field.url), this.containerMask.addChild(this.image), this.image.anchor.set(.5), this.image.width = this.computedSize.width, this.image.height = this.computedSize.height, this.image.position.x = this.offsetX + this.computedSize.width / 2, this.image.position.y = this.offsetY + this.computedSize.height / 2, this.image.alpha = 0, this.useBrush && this.fieldReveal && this.fieldReveal.url && (this.brush = new this.$PIXI.Graphics, this.containerMask.addChild(this.brush), this.brush.beginFill(16777215), this.brush.drawCircle(0, 0, 60), this.brush.endFill(), this.brush.scale.x = 0, this.brush.scale.y = 0, this.imageToReveal = new this.$PIXI.Sprite.from(window.devicePixelRatio > 1 ? this.fieldReveal.retina.url : this.fieldReveal.url), this.containerMask.addChild(this.imageToReveal), this.imageToReveal.anchor.set(0), this.imageToReveal.width = this.computedSize.width, this.imageToReveal.height = this.computedSize.height, this.imageToReveal.position.x = this.offsetX, this.imageToReveal.position.y = this.offsetY, this.imageToReveal.mask = this.brush)
                        },
                        resize: function() {
                            this.isTouch || (this.width = this.$el.offsetWidth, this.height = this.$el.offsetHeight, this.offsets = Object(h.a)(this.$el), this.computedSize = Object(d.a)(this.field.dimensions.width, this.field.dimensions.height, this.width, this.height, !1), this.offsetX = Math.round(.5 * (this.width - this.computedSize.width)), this.offsetY = Math.round(.5 * (this.height - this.computedSize.height)), this.containerMask.position.x = this.offsets.left, this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.useMask && (this.mask.clear(), this.mask.beginFill("0x000000"), this.mask.drawRect(0, 0, this.width, this.height), this.mask.endFill()), this.background && (this.background.width = this.width, this.background.height = this.height), this.image && (this.image.width = this.computedSize.width, this.image.height = this.computedSize.height, this.image.position.x = this.offsetX + this.computedSize.width / 2, this.image.position.y = this.offsetY + this.computedSize.height / 2), this.imageToReveal && (this.imageToReveal.width = this.computedSize.width, this.imageToReveal.height = this.computedSize.height, this.imageToReveal.position.x = this.offsetX, this.imageToReveal.position.y = this.offsetY))
                        },
                        update: function() {
                            this.containerMask && (this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, 0 !== this.parallax && (this.containerMask.position.y += this.containerMask.position.y * this.parallax - this.offsets.top * this.parallax), this.brush && (this.cursorPos.x += .1 * (this.mouseX - this.cursorPos.x), this.cursorPos.y += .1 * (this.mouseY - this.cursorPos.y), this.isEnter && (this.delta.x = Math.abs(this.mouseX - this.cursorPos.x), this.delta.y = Math.abs(this.mouseY - this.cursorPos.y), this.delta.v = this.delta.x > this.delta.y ? this.delta.x : this.delta.y, this.scale = 1 + this.delta.v / 100), this.smoothScale += .1 * (this.scale - this.smoothScale), this.brush.scale.x = this.smoothScale, this.brush.scale.y = this.smoothScale, this.brush.position.x = this.cursorPos.x, this.brush.position.y = this.cursorPos.y))
                        },
                        onPointerEnter: function(t) {
                            this.image && (this.isEnter = !0, this.useBrush && this.fieldReveal && this.fieldReveal.url && (this.cursorPos.x = t.clientX - this.offsets.left, this.cursorPos.y = t.clientY - this.containerMask.position.y, this.animFadeRT && (this.animFadeRT.pause(), this.animFadeRT = null)), this.useHover && (this.savedScale = this.image.scale.x, n.a.to(this.image.scale, {
                                duration: .6,
                                x: this.savedScale + .05,
                                y: this.savedScale + .05,
                                ease: c.c.easeOut
                            })))
                        },
                        onPointerMove: function(t) {
                            this.isEnter && this.useBrush && (this.mouseX = t.clientX - this.offsets.left, this.mouseY = t.clientY - this.containerMask.position.y)
                        },
                        onPointerLeave: function() {
                            var t = this;
                            this.image && (this.useHover && n.a.to(this.image.scale, {
                                duration: .6,
                                x: this.savedScale,
                                y: this.savedScale,
                                ease: c.c.easeOut
                            }), this.useBrush && this.brush && (this.animFadeRT = n.a.to(this, {
                                duration: .6,
                                smoothScale: 0,
                                scale: 0,
                                ease: c.c.easeOut,
                                onComplete: function() {
                                    t.isEnter = !1, t.animFadeRT = null
                                }
                            })))
                        },
                        onHideChange: function() {
                            var t = this.hide ? 0 : 1;
                            n.a.to(this.containerMask, {
                                duration: .6,
                                alpha: t,
                                ease: c.c.easeOut
                            })
                        }
                    }
                },
                v = m,
                y = (o(452), o(26)),
                component = Object(y.a)(v, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "c-PixiImage",
                        class: {
                            "is-loaded": t.isLoaded
                        },
                        style: {
                            backgroundImage: t.isTouch ? "url(" + t.field.thumb.url + ")" : ""
                        }
                    }, [o("img", {
                        ref: "img",
                        staticClass: "c-PixiImage-img",
                        attrs: {
                            "data-src": t.field.url,
                            "data-srcset": t.field.retina.url,
                            alt: t.field.alt ? t.field.alt : " ",
                            draggable: "false",
                            ondragstart: "return false;"
                        }
                    })])
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        449: function(t, e, o) {
            var content = o(453);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("76dd5624", content, !0, {
                sourceMap: !1
            })
        },
        450: function(t, e, o) {
            "use strict";

            function r(t, e, o, r, n) {
                var c = [o / t, r / e];
                return {
                    width: t * (c = n ? Math.min(c[0], c[1]) : Math.max(c[0], c[1])),
                    height: e * c
                }
            }
            o.d(e, "a", (function() {
                return r
            }))
        },
        451: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(16), o(38), o(25), o(39);
            var r = o(17),
                n = (o(101), o(14)),
                c = o(102);

            function l(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var h = {
                    name: "StickyElement",
                    props: {
                        active: {
                            type: Boolean,
                            default: !0
                        },
                        inside: {
                            type: Boolean,
                            default: !0
                        },
                        gapTop: {
                            type: Number,
                            default: 0
                        },
                        gapBottom: {
                            type: Number,
                            default: 0
                        }
                    },
                    data: function() {
                        return {
                            activeClass: ""
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? l(Object(source), !0).forEach((function(e) {
                                Object(r.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : l(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(n.d)("window", ["isTouch"])),
                    watch: {
                        active: "onActiveChange",
                        gapTop: "resize",
                        gapBottom: "resize"
                    },
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            if (t.$eventHub.$on("resize", t.resize), t.$eventHub.$on("update", t.update), t.parent = t.getStickyParent(), !t.parent) return console.warn("No parent founded for this Sticky Element. This component must be a child/subchild of a js-sticky-container", t);
                            t.$nextTick((function() {
                                t.resize()
                            }))
                        }))
                    },
                    beforeDestroy: function() {
                        this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update)
                    },
                    methods: {
                        onActiveChange: function() {
                            this.active && this.update()
                        },
                        getStickyParent: function() {
                            for (var element = this.$el.parentNode; !element.classList.contains("js-sticky-container");) element = element.parentNode;
                            return element
                        },
                        resize: function() {
                            this.parent && (this.width = this.$el.offsetWidth, this.height = this.$el.offsetHeight, this.top = this.$el.offsetTop, this.parentTop = Object(c.a)(this.parent), this.parentHeight = this.parent.offsetHeight, this.triggerTop = this.parentTop + this.top - this.gapTop, this.triggerBottom = this.parentTop + this.parentHeight - this.height - this.gapTop - this.gapBottom)
                        },
                        update: function() {
                            this.parent && this.active && (this.$el.style.transform = this.transform, this.scrollVal = this.isTouch ? this.$root.scrollTop : this.$root.smoothScroll, this.scrollVal >= this.triggerTop && this.scrollVal < this.triggerBottom ? (this.activeClass = "is-sticky", this.isTouch || (this.inside ? this.transform = "translateY(".concat(this.scrollVal - this.triggerTop, "px) translateZ(0)") : this.transform = "translateY(".concat(-this.triggerTop, "px) translateZ(0)"))) : this.scrollVal > this.triggerBottom ? (this.activeClass = "is-sticky-end", this.isTouch || (this.inside ? this.transform = "translateY(".concat(this.triggerBottom - this.triggerTop, "px) translateZ(0)") : this.transform = "translateY(".concat(-this.scrollVal + this.triggerBottom - this.triggerTop, "px) translateZ(0)"))) : (this.activeClass = "", this.isTouch || (this.inside ? this.transform = "translateY(0px) translateZ(0)" : this.transform = "translateY(".concat(-this.scrollVal, "px) translateZ(0)"))))
                        }
                    }
                },
                d = h,
                f = o(26),
                component = Object(f.a)(d, (function() {
                    var t = this,
                        e = t.$createElement;
                    return (t._self._c || e)("div", {
                        class: t.activeClass
                    }, [t._t("default")], 2)
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        452: function(t, e, o) {
            "use strict";
            o(449)
        },
        453: function(t, e, o) {
            var r = o(54)(!1);
            r.push([t.i, ".c-PixiImage{position:relative;background-size:cover}.c-PixiImage-img{position:absolute;top:0;left:0;width:100%;height:100%;opacity:0;transform:translateZ(0);display:none}.is-touch .c-PixiImage-img{display:block}.c-PixiImage.is-loaded .c-PixiImage-img{opacity:1;transition:opacity .8s cubic-bezier(.165,.84,.44,1)}.c-PixiImage.is-loaded.is-disabled .c-PixiImage-img{transition:none}", ""]), t.exports = r
        },
        454: function(t, e, o) {
            "use strict";

            function r(t, e, o, r, n) {
                return (n - t) * (r - o) / (e - t) + o
            }
            o.d(e, "a", (function() {
                return r
            }))
        },
        456: function(t, e, o) {
            "use strict";
            o(35), o(29), o(31), o(16), o(38), o(25), o(39);
            var r = o(17),
                n = (o(47), o(14));

            function c(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }

            function l(t) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = null != arguments[i] ? arguments[i] : {};
                    i % 2 ? c(Object(source), !0).forEach((function(e) {
                        Object(r.a)(t, e, source[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : c(Object(source)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                    }))
                }
                return t
            }
            var h = {
                computed: l(l({}, Object(n.d)(["layout"])), Object(n.d)("main", ["isPageReady"])),
                head: function() {
                    return {
                        title: this.document.meta_title ? this.document.meta_title : this.layout.meta_title,
                        meta: [{
                            hid: "description",
                            name: "description",
                            content: this.document.meta_description ? this.document.meta_description : this.layout.meta_description
                        }, {
                            hid: "og:title",
                            property: "og:title",
                            content: this.document.meta_title ? this.document.meta_title : this.layout.meta_title
                        }, {
                            hid: "og:description",
                            property: "og:description",
                            content: this.document.meta_description ? this.document.meta_description : this.layout.meta_description
                        }, {
                            hid: "og:image",
                            property: "og:image",
                            content: this.document.share_image && this.document.share_image.url ? this.document.share_image.url : this.layout.share_image ? this.layout.share_image.url : null
                        }, {
                            hid: "twitter:title",
                            name: "og:description",
                            content: this.document.meta_title ? this.document.meta_title : this.layout.meta_title
                        }, {
                            hid: "twitter:description",
                            name: "og:description",
                            content: this.document.meta_description ? this.document.meta_description : this.layout.meta_description
                        }, {
                            hid: "twitter:image:src",
                            name: "twitter:image:src",
                            content: this.document.share_image && this.document.share_image.url ? this.document.share_image.url : this.layout.share_image ? this.layout.share_image.url : null
                        }],
                        bodyAttrs: {
                            class: "is-" + this.$route.name
                        }
                    }
                },
                mounted: function() {
                    var t = this;
                    this.$nextTick((function() {
                        t.$eventHub.$emit("page:mounted")
                    }))
                }
            };
            e.a = h
        },
        457: function(t, e, o) {
            var content = o(464);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("d6b434f8", content, !0, {
                sourceMap: !1
            })
        },
        458: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(16), o(38), o(25), o(39);
            var r = o(17),
                n = o(14),
                c = o(454);

            function l(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var h = {
                    name: "IntroGradient",
                    props: {
                        options: {
                            type: Object,
                            required: !0
                        },
                        ruler: {
                            type: Boolean,
                            default: !0
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? l(Object(source), !0).forEach((function(e) {
                                Object(r.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : l(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(n.d)("window", ["width", "height"])),
                    created: function() {
                        this.force = 5, this.seed = .18, this.smoothForce = this.force, this.smoothSeed = this.seed
                    },
                    mounted: function() {
                        this.$eventHub.$on("resize", this.resize), this.$eventHub.$on("update", this.update)
                    },
                    beforeDestroy: function() {
                        this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update)
                    },
                    methods: {
                        onPointerMove: function(t) {
                            this.x = t.clientX / this.width, this.y = t.clientY / this.height, this.force = Object(c.a)(0, 1, 0, 5, this.x), this.seed = Object(c.a)(0, 1, -1, 1, this.y)
                        },
                        resize: function() {
                            this.ruler && (this.heightRuler = this.$refs.ruler.offsetHeight)
                        },
                        update: function() {
                            if (this.smoothForce += .1 * (this.force - this.smoothForce), this.smoothSeed += .1 * (this.seed - this.smoothSeed), this.$refs.gradient.displacement = this.smoothForce, this.$refs.gradient.seed = this.smoothSeed, this.heightRuler) {
                                var t = this.x * this.heightRuler;
                                this.$refs.cursorX.style.transform = "translateY(".concat(t, "px) translateZ(0)");
                                var e = this.y * this.heightRuler;
                                this.$refs.cursorY.style.transform = "translateY(".concat(e, "px) translateZ(0)")
                            }
                        }
                    }
                },
                d = h,
                f = (o(463), o(26)),
                component = Object(f.a)(d, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("section", {
                        staticClass: "js-section c-IntroGradient",
                        on: {
                            pointermove: t.onPointerMove
                        }
                    }, [o("monopo-gradient", {
                        ref: "gradient",
                        staticClass: "c-IntroGradient-canvas",
                        attrs: {
                            color1: t.options.color1,
                            color2: t.options.color2,
                            color3: t.options.color3,
                            color4: t.options.color4,
                            colorsize: t.options.colorsize,
                            colorspacing: t.options.colorspacing,
                            colorrotation: t.options.colorrotation,
                            colorspread: t.options.colorspread,
                            coloroffset: t.options.coloroffset,
                            displacement: t.options.displacement,
                            seed: t.options.seed,
                            position: t.options.position,
                            zoom: t.options.zoom,
                            spacing: t.options.spacing,
                            noretina: "true"
                        }
                    }), t._v(" "), t.ruler ? [o("div", {
                        ref: "ruler",
                        staticClass: "c-IntroGradient-ruler"
                    }, [t._l(2, (function(e) {
                        return o("div", {
                            key: e,
                            staticClass: "c-IntroGradient-ruler-cm"
                        }, t._l(9, (function(i) {
                            return o("div", {
                                key: i,
                                staticClass: "c-IntroGradient-ruler-mm"
                            })
                        })), 0)
                    })), t._v(" "), o("div", {
                        staticClass: "c-IntroGradient-ruler-cm"
                    }), t._v(" "), o("div", {
                        ref: "cursorY",
                        staticClass: "c-IntroGradient-ruler-cursor"
                    })], 2), t._v(" "), o("div", {
                        staticClass: "c-IntroGradient-ruler c-IntroGradient-ruler--alt"
                    }, [t._l(2, (function(e) {
                        return o("div", {
                            key: e,
                            staticClass: "c-IntroGradient-ruler-cm"
                        }, t._l(9, (function(i) {
                            return o("div", {
                                key: i,
                                staticClass: "c-IntroGradient-ruler-mm"
                            })
                        })), 0)
                    })), t._v(" "), o("div", {
                        staticClass: "c-IntroGradient-ruler-cm"
                    }), t._v(" "), o("div", {
                        ref: "cursorX",
                        staticClass: "c-IntroGradient-ruler-cursor"
                    })], 2)] : t._e(), t._v(" "), t._t("default")], 2)
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        463: function(t, e, o) {
            "use strict";
            o(457)
        },
        464: function(t, e, o) {
            var r = o(54)(!1);
            r.push([t.i, '.c-IntroGradient{position:relative;width:100%}.c-IntroGradient-canvas{position:absolute;top:0;left:0;width:100%;height:100%}.c-IntroGradient-ruler{position:absolute;top:50%;left:3.9vw;padding-left:15px;transform:translateY(-50%)}@media only screen and (max-width:767px){.c-IntroGradient-ruler{display:none}}.c-IntroGradient-ruler--alt{left:auto;right:3.9vw;padding-left:0;padding-right:15px}.c-IntroGradient-ruler-cursor{position:absolute;top:0;left:0;border-top:3px solid transparent;border-bottom:3px solid transparent;border-left:5px solid #fff;margin-top:-3px;transition:transform .8s cubic-bezier(.165,.84,.44,1)}.c-IntroGradient-ruler--alt .c-IntroGradient-ruler-cursor{left:auto;right:0;border-right:5px solid #fff;border-left:none}.c-IntroGradient-ruler-cm{position:relative;width:6px;margin-top:16px}.c-IntroGradient-ruler-cm:first-child,.c-IntroGradient-ruler-cm:first-child .c-IntroGradient-ruler-mm:first-child{margin-top:0}.c-IntroGradient-ruler-cm:before{content:"";position:absolute;top:0;left:0;width:6px;height:1px;background:#fff}.c-IntroGradient-ruler-mm{width:2px;height:1px;background:#fff;margin-top:16px}', ""]), t.exports = r
        },
        465: function(t, e, o) {
            var content = o(474);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("f12a7d78", content, !0, {
                sourceMap: !1
            })
        },
        471: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(38), o(39);
            var r = o(17),
                n = (o(101), o(74), o(56), o(16), o(25), o(69), o(14)),
                c = o(444);

            function l(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var h = {
                    name: "DefaultSlider",
                    props: {
                        isMagnetic: {
                            type: Boolean,
                            default: !1
                        },
                        initOffset: {
                            type: Number,
                            default: 0
                        },
                        securityCulling: {
                            type: Number,
                            default: 40
                        },
                        gap: {
                            type: Number,
                            default: 30
                        }
                    },
                    data: function() {
                        return {
                            isDrag: !1,
                            dragStart: !1
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? l(Object(source), !0).forEach((function(e) {
                                Object(r.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : l(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(n.d)("window", ["width", "isTouch"])),
                    created: function() {
                        this.currentItem = 0, this.x = 0, this.targetX = 0, this.offsetX = [], this.enabled = []
                    },
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            t.$items = Array.from(t.$el.querySelectorAll(".js-item")), t.nbItems = t.$items.length, t.$items.forEach((function(e, i) {
                                t.enabled[i] = !1
                            })), t.$eventHub.$on("resize", t.resize), t.$eventHub.$on("update", t.update), t.resize()
                        }))
                    },
                    beforeDestroy: function() {
                        this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update)
                    },
                    methods: {
                        resize: function() {
                            var t = this;
                            if (this.nbItems) {
                                for (this.$items = Array.from(this.$el.querySelectorAll(".js-item")), this.containerWidth = this.$el.offsetWidth, this.containerOffsetLeft = Object(c.a)(this.$el).left, this.contentWidth = 0, this.$items.forEach((function(e, i) {
                                        t.itemWidth = e.offsetWidth, t.contentWidth += t.itemWidth, t.offsetX[i] = Object(c.a)(e).left - t.containerOffsetLeft, 0 !== i && (t.contentWidth += t.gap, t.offsetX[i] += t.gap)
                                    })), this.initOffset && 0 === this.targetX && (this.targetX = -this.initOffset * this.itemWidth + this.containerWidth / 2), this.i = 0; this.i < this.nbItems; this.i++) this.x = this.targetX, this.$items[this.i].style.transform = "translate3d(".concat(this.x, "px, 0px, 0px)");
                                this.multiplier = this.isTouch ? 1.6 : 1
                            }
                        },
                        onDragStart: function() {
                            this.dragStart = !0, this.dragStartItem = this.currentItem, this.pointerEvent = this.isTouch && "mousedown" !== event.type ? event.touches[0] || event.changedTouches[0] : event, this.oldX = this.targetX, this.startX = this.pointerEvent.pageX
                        },
                        onDrag: function() {
                            this.dragStart && (this.pointerEvent = this.isTouch && "mousemove" !== event.type ? event.touches[0] || event.changedTouches[0] : event, Math.abs(this.startX - this.pointerEvent.pageX) > 10 && (this.isDrag = !0), this.isDrag && event.cancelable && event.preventDefault(), this.targetX = this.oldX + (this.pointerEvent.pageX - this.startX) * this.multiplier)
                        },
                        onDragEnd: function() {
                            var t = this;
                            this.dragStart = !1, this.isDrag && setTimeout((function() {
                                t.isMagnetic && (t.dragStartItem === t.currentItem && -t.targetX > t.offsetX[t.currentItem] + 80 ? t.nextItem() : t.dragStartItem === t.currentItem && -t.targetX < t.offsetX[t.currentItem] - 80 ? t.prevItem() : t.targetX = -t.offsetX[t.currentItem]), t.isDrag = !1
                            }), 100)
                        },
                        update: function() {
                            for (this.lockAxisX(), this.x += Math.round(.1 * (this.targetX - this.x) * 1e3) / 1e3, this.i = 0; this.i < this.nbItems; this.i++) this.x + this.offsetX[this.i] + this.itemWidth + this.securityCulling < 0 || this.x + this.offsetX[this.i] - this.containerWidth - this.securityCulling > 0 ? this.enabled[this.i] && (this.$items[this.i].classList.add("is-disabled"), this.enabled[this.i] = !1, this.$items[this.i].style.transform = "translate3d(".concat(this.x, "px, 0px, 0px)")) : (this.enabled[this.i] || (this.enabled[this.i] = !0, this.$items[this.i].classList.remove("is-disabled")), this.$items[this.i].style.transform = "translate3d(".concat(this.x, "px, 0px, 0px)")), this.currentItem !== this.i && -this.x > this.offsetX[this.i] - this.itemWidth / 2 && -this.x < this.offsetX[this.i] - this.itemWidth / 2 + this.itemWidth && (this.currentItem = this.i)
                        },
                        lockAxisX: function() {
                            this.targetX < -this.contentWidth + this.containerWidth - this.offsetX[0] && (this.targetX = -this.contentWidth + this.containerWidth - this.offsetX[0]), this.targetX > 0 && (this.targetX = 0)
                        },
                        prevItem: function() {
                            this.targetX = -(this.offsetX[this.currentItem - 1] ? this.offsetX[this.currentItem - 1] : this.offsetX[0])
                        },
                        nextItem: function() {
                            this.targetX = -(this.offsetX[this.currentItem + 1] ? this.offsetX[this.currentItem + 1] : this.offsetX[this.nbItems - 1])
                        },
                        goToItem: function(t) {
                            var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                            if (void 0 !== this.offsetX[t] && (this.targetX = this.offsetX[0] - this.offsetX[t], e))
                                for (this.i = 0; this.i < this.nbItems; this.i++) this.x = this.targetX, this.$items[this.i].style.transform = "translate3d(".concat(this.x, "px, 0px, 0px)")
                        }
                    }
                },
                d = h,
                f = (o(473), o(26)),
                component = Object(f.a)(d, (function() {
                    var t = this,
                        e = t.$createElement;
                    return (t._self._c || e)("div", {
                        staticClass: "c-DefaultSlider",
                        class: {
                            "is-drag": t.dragStart
                        },
                        on: {
                            mousedown: t.onDragStart,
                            "&touchstart": function(e) {
                                return t.onDragStart.apply(null, arguments)
                            },
                            mousemove: t.onDrag,
                            touchmove: t.onDrag,
                            mouseup: t.onDragEnd,
                            "&touchend": function(e) {
                                return t.onDragEnd.apply(null, arguments)
                            },
                            "&touchleave": function(e) {
                                return t.onDragEnd.apply(null, arguments)
                            },
                            mouseleave: t.onDragEnd
                        }
                    }, [t._t("default")], 2)
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        473: function(t, e, o) {
            "use strict";
            o(465)
        },
        474: function(t, e, o) {
            var r = o(54)(!1);
            r.push([t.i, ".c-DefaultSlider{cursor:-webkit-grab;cursor:grab}.c-DefaultSlider.is-drag{cursor:-webkit-grabbing;cursor:grabbing}", ""]), t.exports = r
        },
        531: function(t, e, o) {
            var content = o(559);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("5800f225", content, !0, {
                sourceMap: !1
            })
        },
        558: function(t, e, o) {
            "use strict";
            o(531)
        },
        559: function(t, e, o) {
            var r = o(54)(!1);
            r.push([t.i, '.c-Works{background:#fff}.c-Works-intro{height:65vh;padding-bottom:65px;background:#000;color:#fff;display:flex;align-items:flex-end}@media only screen and (max-width:767px){.c-Works-intro{height:auto;padding-top:150px}}.c-Works-intro-inner{position:relative}.c-Works-intro-title{margin-bottom:10px;opacity:.5;opacity:0;transform:translateY(40px) translateZ(0);transition:opacity .8s cubic-bezier(.165,.84,.44,1) .4s,transform .8s cubic-bezier(.165,.84,.44,1) .4s}.is-page-ready .c-Works-intro-title{opacity:1;transform:translateY(0) translateZ(0)}.c-Works-intro-subtitle-jp{display:inline-block;margin-left:5px;font-family:"Noto Sans CJK JP",Helvetica,Roboto,Arial,sans-serif}.c-Works-intro-subtitle-line{opacity:0;transform:translateY(40px) translateZ(0)}.c-Works-intro-subtitle-line--1{transition:opacity .8s cubic-bezier(.165,.84,.44,1) .5s,transform .8s cubic-bezier(.165,.84,.44,1) .5s}.c-Works-intro-subtitle-line--2{transition:opacity .8s cubic-bezier(.165,.84,.44,1) .6s,transform .8s cubic-bezier(.165,.84,.44,1) .6s}.c-Works-intro-subtitle-line--3{transition:opacity .8s cubic-bezier(.165,.84,.44,1) .7s,transform .8s cubic-bezier(.165,.84,.44,1) .7s}.c-Works-intro-subtitle-line--4{transition:opacity .8s cubic-bezier(.165,.84,.44,1) .8s,transform .8s cubic-bezier(.165,.84,.44,1) .8s}.c-Works-intro-subtitle-line--5{transition:opacity .8s cubic-bezier(.165,.84,.44,1) .9s,transform .8s cubic-bezier(.165,.84,.44,1) .9s}.is-page-ready .c-Works-intro-subtitle-line{opacity:1;transform:translateY(0) translateZ(0)}.c-Works-intro-body{border-left:1px solid #fff;padding-left:10px;opacity:0;transform:translateY(40px) translateZ(0);transition:opacity .8s cubic-bezier(.165,.84,.44,1) .4s,transform .8s cubic-bezier(.165,.84,.44,1) .4s}@media only screen and (max-width:767px){.c-Works-intro-body{margin-top:50px}}.is-page-ready .c-Works-intro-body{opacity:1;transform:translateY(0) translateZ(0)}.c-Works-intro-scroll{display:block;margin-left:auto;width:17px;height:52.5px;opacity:0;transform:translateY(40px) translateZ(0);transition:opacity .8s cubic-bezier(.165,.84,.44,1) .4s,transform .8s cubic-bezier(.165,.84,.44,1) .4s}.c-Works-intro-scroll img{width:100%;height:100%}@media only screen and (max-width:767px){.c-Works-intro-scroll{display:none}}.is-page-ready .c-Works-intro-scroll{opacity:1;transform:translateY(0) translateZ(0)}.c-Works-content{margin-top:150px;margin-bottom:150px}@media only screen and (max-width:979px){.c-Works-content{margin-top:100px;margin-bottom:100px}}@media only screen and (max-width:767px){.c-Works-content{margin-top:60px;margin-bottom:60px}}.c-Works-item{display:block;margin-top:150px;opacity:1;transform:translateZ(0);transition:opacity .8s cubic-bezier(.165,.84,.44,1)}@media only screen and (max-width:979px){.c-Works-item{margin-top:80px;margin-top:60px}}.c-Works-item.is-hide{opacity:0}.c-Works-item:first-child,.c-Works-item:nth-child(2){margin-top:0}@media only screen and (max-width:767px){.c-Works-item:first-child,.c-Works-item:nth-child(2){margin-top:60px}}.c-Works-item:nth-child(2n){position:relative;top:150px}.is-touch .c-Works-item:nth-child(2n){top:0}.c-Works-item--collection{margin-top:0!important}.c-Works-item--collection:nth-child(2n){top:0!important}.c-Works-item-img{position:relative}.c-Works-item-img:before{position:relative;content:"";display:block;height:0;width:100%;padding-top:119.5833333333%}.c-Works-item-info{margin-top:30px;border-top:1px solid #000}.c-Works-item-info-categories{display:flex;margin-top:15px;color:#7f7f7f;flex-wrap:wrap}.c-Works-item-info-categories li{display:flex;align-items:center}.c-Works-item-info-categories li:before{content:"";display:inline-block;height:3px;width:3px;background:currentColor;border-radius:50%;margin-left:10px;margin-right:10px}.c-Works-item-info-categories li:first-child:before{content:"";display:inline-block;height:0;width:0;border-radius:0;background:transparent;border-top:3px solid transparent;border-bottom:3px solid transparent;border-left:5px solid;margin-right:7px;margin-left:0}.c-Works-item-info-title{margin-top:20px}.c-Works-filters{position:relative}.c-Works-filters-ruler{position:absolute;top:0;left:10px}@media only screen and (max-width:767px){.c-Works-filters-ruler{display:none}}.c-Works-filters-ruler-cm{position:relative;width:6px;margin-top:8px}.c-Works-filters-ruler-cm:first-child{margin-top:7px}.c-Works-filters-ruler-cm:before{content:"";position:absolute;top:0;left:0;width:6px;height:1px;background:#000}.c-Works-filters-ruler-mm{width:2px;height:1px;background:#000;margin-top:8px}@media only screen and (max-width:767px){.c-Works-filters-list{display:none}}.c-Works-filters-list li{margin-top:22px;display:flex;align-items:center}.c-Works-filters-list li:first-child{margin-top:0}.c-Works-filters-list-btn{white-space:nowrap;opacity:.4}.c-Works-filters-list-btn,.c-Works-filters-list-btn:before{transform:translateZ(0);transition:opacity .6s cubic-bezier(.165,.84,.44,1)}.c-Works-filters-list-btn:before{content:"";display:inline-block;height:0;width:0;border-top:3px solid transparent;border-bottom:3px solid transparent;border-left:5px solid #000;margin-right:30px;margin-top:1px;opacity:0}.c-Works-filters-list-btn.is-active,.c-Works-filters-list-btn.is-active:before,.c-Works-filters-list-btn:hover{opacity:1}.c-Works-filters-select{display:none}@media only screen and (max-width:767px){.c-Works-filters-select{display:block}}.c-Works-collection{margin-bottom:150px}@media only screen and (max-width:767px){.c-Works-collection{margin-bottom:60px;overflow:hidden}}.c-Works-collection-head{border-top:1px solid #000;padding-top:34px;display:flex;justify-content:space-between;align-items:center}@media only screen and (max-width:767px){.c-Works-collection-head{padding-top:20px}}.c-Works-collection-head-titles{width:100%;flex:1}.c-Works-collection-head-title{display:block;position:relative;overflow:hidden;text-transform:uppercase;margin-top:5px}.c-Works-collection-head-title-item{display:block;position:absolute;top:0;left:0;opacity:0;transform:translateY(100%) translateZ(0)}.c-Works-collection-head-title-item.is-active{opacity:1;transform:translateY(0) translateZ(0)}.c-Works-collection-head-title-item.is-active,.c-Works-collection-head-title-item.is-out{transition:opacity .8s cubic-bezier(.165,.84,.44,1),transform .8s cubic-bezier(.165,.84,.44,1)}.c-Works-collection-head-title-item.is-out{opacity:0;transform:translateY(-100%) translateZ(0)}.c-Works-collection-head-title-item:first-child{position:relative}.c-Works-collection-head-subtitle{display:block;position:relative;overflow:hidden}.c-Works-collection-head-subtitle-item{display:block;position:absolute;top:0;left:0;opacity:0;transform:translateY(100%) translateZ(0)}.c-Works-collection-head-subtitle-item.is-active{opacity:1;transform:translateY(0) translateZ(0);transition:opacity .8s cubic-bezier(.165,.84,.44,1),transform .8s cubic-bezier(.165,.84,.44,1)}.c-Works-collection-head-subtitle-item.is-out{opacity:0;transform:translateY(-100%) translateZ(0);transition:opacity .8s cubic-bezier(.165,.84,.44,1),transform .8s cubic-bezier(.165,.84,.44,1)}.c-Works-collection-head-subtitle-item:first-child{position:relative}.c-Works-collection-refresh{display:flex;align-items:center;text-transform:uppercase;text-align:left}@media only screen and (max-width:767px){.c-Works-collection-refresh-label{display:none}}.c-Works-collection-refresh-icon{position:relative;display:flex;align-items:center;justify-content:center;width:65px;height:65px;margin-left:10px}.c-Works-collection-refresh-icon:before{content:"";position:absolute;top:0;left:0;width:100%;height:100%;border:1px solid rgba(0,0,0,.4);border-radius:50%;transform:translateZ(0);transition:transform .6s cubic-bezier(.165,.84,.44,1)}.c-Works-collection-refresh:hover .c-Works-collection-refresh-icon:before{transform:scale(1.1) translateZ(0)}.c-Works-collection-content{margin-top:60px;opacity:1;transform:translateZ(0);transition:opacity .8s cubic-bezier(.165,.84,.44,1)}@media only screen and (max-width:767px){.c-Works-collection-content{margin-top:30px;display:block;white-space:nowrap;font-size:0}.c-Works-collection-content .js-item{display:inline-block;white-space:normal;vertical-align:top}}.c-Works-collection.is-hide .c-Works-collection-content{opacity:0}', ""]), t.exports = r
        },
        578: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(38), o(39);
            var r = o(17),
                n = o(18),
                c = (o(75), o(275), o(31), o(16), o(276), o(47), o(69), o(25), o(37), o(65), o(64), o(85), o(46)),
                l = o(4),
                h = o(14),
                d = o(186),
                f = o(448),
                m = o(153),
                v = o(451),
                y = o(458),
                k = o(471),
                x = o(456);

            function w(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }

            function O(t) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = null != arguments[i] ? arguments[i] : {};
                    i % 2 ? w(Object(source), !0).forEach((function(e) {
                        Object(r.a)(t, e, source[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : w(Object(source)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                    }))
                }
                return t
            }
            c.a.registerPlugin(d.a);
            var W = {
                    name: "Work",
                    components: {
                        PixiImage: f.default,
                        ParallaxObject: m.default,
                        StickyElement: v.default,
                        IntroGradient: y.default,
                        DefaultSlider: k.default
                    },
                    mixins: [x.a],
                    asyncData: function(t) {
                        return Object(n.a)(regeneratorRuntime.mark((function e() {
                            var o, r, n;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return o = t.$prismic, t.store, r = t.error, e.prev = 1, e.next = 4, o.api.query(o.predicates.at("document.type", "works"), {
                                            fetchLinks: ["project.thumbnail", "project.title", "project.categories"]
                                        });
                                    case 4:
                                        return n = e.sent.results[0].data, e.abrupt("return", {
                                            document: n
                                        });
                                    case 8:
                                        e.prev = 8, e.t0 = e.catch(1), r({
                                            statusCode: 404,
                                            message: "Page not found"
                                        });
                                    case 11:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [1, 8]
                            ])
                        })))()
                    },
                    data: function() {
                        return {
                            currentCategory: "",
                            selectCategory: "",
                            projectHide: !1,
                            currentCollection: 0,
                            currentCollectionTitle: 0,
                            oldCollectionTitle: -1,
                            collectionHide: !1,
                            titleReady: !1
                        }
                    },
                    computed: O(O(O(O({}, Object(h.d)(["categories", "projects"])), Object(h.d)("main", ["isPageReady", "isFontLoaded"])), Object(h.d)("window", ["height"])), {}, {
                        filteredProjects: function() {
                            var t = this;
                            return this.projects.filter((function(e) {
                                return !(t.currentCategory || !e.data.visibility) || e.data.categories.find((function(o) {
                                    return o.category.uid === t.currentCategory && e.data.visibility
                                }))
                            }))
                        },
                        collection: function() {
                            return this.document.collections[this.currentCollection]
                        },
                        collectionItems: function() {
                            var t = this,
                                e = [];
                            return e.push(this.collection.collection_project_one), e.push(this.collection.collection_project_two), e.push(this.collection.collection_project_three), e.forEach((function(o, i) {
                                t.$set(e[i], "isHide", !1)
                            })), e
                        }
                    }),
                    watch: {
                        selectCategory: "onSelectChange",
                        isFontLoaded: "splitTitle"
                    },
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            t.splitTitle()
                        }))
                    },
                    methods: {
                        onScroll: function() {
                            c.a.to(window, {
                                scrollTo: .65 * this.height,
                                duration: .6,
                                ease: l.c.easeInOut
                            })
                        },
                        categoryName: function(t) {
                            return this.categories.find((function(e) {
                                return e.uid === t
                            })).data.name
                        },
                        onSelectChange: function() {
                            var t = this;
                            this.projectHide = !0, c.a.to(window, {
                                scrollTo: .65 * this.height,
                                duration: .6,
                                ease: l.c.easeInOut
                            }), setTimeout((function() {
                                t.currentCategory = t.selectCategory, t.$nextTick((function() {
                                    t.$eventHub.$emit("scrollSection:update"), t.$eventHub.$emit("resize"), t.projectHide = !1
                                }))
                            }), 800)
                        },
                        onCategoryChange: function(t) {
                            var e = this;
                            this.projectHide = !0, c.a.to(window, {
                                scrollTo: .65 * this.height,
                                duration: .6,
                                ease: l.c.easeInOut
                            }), setTimeout((function() {
                                e.currentCategory = t, e.$nextTick((function() {
                                    e.$eventHub.$emit("scrollSection:update"), e.$eventHub.$emit("resize"), e.projectHide = !1
                                }))
                            }), 800)
                        },
                        onCollectionChange: function() {
                            var t = this;
                            this.collectionHide = !0, this.oldCollectionTitle = this.currentCollection, this.currentCollectionTitle += 1, this.currentCollectionTitle = this.currentCollectionTitle % this.document.collections.length, this.collectionItems.forEach((function(t, i) {
                                setTimeout((function() {
                                    t.isHide = !0
                                }), 100 * i)
                            })), setTimeout((function() {
                                t.currentCollection += 1, t.currentCollection = t.currentCollection % t.document.collections.length, t.collectionItems.forEach((function(t, i) {
                                    t.isHide = !0
                                })), t.$nextTick((function() {
                                    t.collectionHide = !1, t.oldCollectionTitle = -1, t.$refs.slider.resize(), t.$refs.slider.x = 0, t.$refs.slider.targetX = 0, t.collectionItems.forEach((function(t, i) {
                                        setTimeout((function() {
                                            t.isHide = !1
                                        }), 100 * i)
                                    }))
                                }))
                            }), 600)
                        },
                        getGradientOptions: function(text) {
                            var t = (new DOMParser).parseFromString(text, "text/html").getElementsByTagName("monopo-gradient")[0];
                            return {
                                color1: t.getAttribute("color1"),
                                color2: t.getAttribute("color2"),
                                color3: t.getAttribute("color3"),
                                color4: t.getAttribute("color4"),
                                colorsize: t.getAttribute("colorsize"),
                                colorspacing: t.getAttribute("colorspacing"),
                                colorrotation: t.getAttribute("colorrotation"),
                                colorspread: t.getAttribute("colorspread"),
                                coloroffset: t.getAttribute("coloroffset"),
                                displacement: t.getAttribute("displacement"),
                                seed: t.getAttribute("seed"),
                                position: t.getAttribute("position"),
                                zoom: t.getAttribute("zoom"),
                                spacing: t.getAttribute("spacing") || 5
                            }
                        },
                        splitTitle: function() {
                            var t = this;
                            this.isFontLoaded && (this.titleSplited = new d.a(this.$refs.title, {
                                type: "lines",
                                linesClass: "c-Works-intro-subtitle-line c-Works-intro-subtitle-line--++"
                            }), this.titleSplited.lines.forEach((function(e) {
                                t.setItalic(e)
                            })), setTimeout((function() {
                                t.titleReady = !0
                            }), 40))
                        },
                        setItalic: function(t) {
                            var e = t.textContent.split(" ").map((function(t) {
                                for (var e = t.split(""), i = 0, o = e[i], r = null; o;) {
                                    if (("o" === o.toLowerCase() || "i" === o.toLowerCase()) && e[i - 1] && "y" !== e[i - 1].toLowerCase()) {
                                        r = o;
                                        break
                                    }
                                    i++, o = e[i]
                                }
                                return r ? e.map((function(t) {
                                    return t === o ? "<i>" + t + "</i>" : t
                                })).join("") : e.join("")
                            }));
                            t.innerHTML = e.join(" ")
                        }
                    }
                },
                C = (o(558), o(26)),
                component = Object(C.a)(W, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "c-Works",
                        class: {
                            "is-page-ready": t.isPageReady && t.titleReady
                        }
                    }, [o("IntroGradient", {
                        staticClass: "js-section c-Works-intro container",
                        attrs: {
                            ruler: !1,
                            options: t.getGradientOptions(t.document.gradient)
                        }
                    }, [o("div", {
                        staticClass: "c-Works-intro-inner row bottom"
                    }, [o("div", {
                        staticClass: "col-22of24 col-sm-12of12 offset-sm-0"
                    }, [o("div", {
                        staticClass: "row bottom"
                    }, [o("div", {
                        staticClass: "col-12of22 col-sm-12of12"
                    }, [o("h1", {
                        ref: "title",
                        staticClass: "c-Works-intro-subtitle t-h1"
                    }, [t._v("\n                            " + t._s(t.$prismic.asText(t.document.title)) + "\n                            ")])]), t._v(" "), o("div", {
                        staticClass: "col-6of22 offset-2of22 col-md-8of22 col-sm-10of12 offset-sm-0"
                    }, [o("PrismicRichText", {
                        staticClass: "c-Works-intro-body c-wysiwyg t-text",
                        attrs: {
                            field: t.document.paragraph
                        }
                    })], 1)])]), t._v(" "), o("div", {
                        staticClass: "col-1of24 offset-1of24"
                    }, [o("button", {
                        staticClass: "c-Works-intro-scroll t-btn",
                        attrs: {
                            type: "button"
                        },
                        on: {
                            click: t.onScroll
                        }
                    }, [o("img", {
                        attrs: {
                            src: "/arrow_scroll.png",
                            width: "34",
                            height: "105",
                            alt: "scroll down"
                        }
                    })])])])]), t._v(" "), o("div", {
                        staticClass: "js-sticky-container c-Works-content container"
                    }, [o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "js-section col-3of24 col-sm-12of12"
                    }, [o("StickyElement", {
                        staticClass: "c-Works-filters",
                        attrs: {
                            "gap-top": 150
                        }
                    }, [o("div", {
                        staticClass: "c-Works-filters-ruler"
                    }, [t._l(t.categories, (function(e, i) {
                        return o("div", {
                            key: i,
                            staticClass: "c-Works-filters-ruler-cm"
                        }, t._l(4, (function(t) {
                            return o("div", {
                                key: t,
                                staticClass: "c-Works-filters-ruler-mm"
                            })
                        })), 0)
                    })), t._v(" "), o("div", {
                        staticClass: "c-Works-filters-ruler-cm"
                    })], 2), t._v(" "), o("ul", {
                        staticClass: "c-Works-filters-list t-list"
                    }, [o("li", [o("button", {
                        staticClass: "c-Works-filters-list-btn t-btn t-h6 t-h6--spacing",
                        class: {
                            "is-active": "" === t.currentCategory
                        },
                        attrs: {
                            type: "button"
                        },
                        on: {
                            click: function(e) {
                                return t.onCategoryChange("")
                            }
                        }
                    }, [t._v("\n                                All\n                            ")])]), t._v(" "), t._l(t.categories, (function(e, i) {
                        return o("li", {
                            key: i
                        }, [o("button", {
                            staticClass: "c-Works-filters-list-btn t-btn t-h6 t-h6--spacing",
                            class: {
                                "is-active": t.currentCategory === e.uid
                            },
                            attrs: {
                                type: "button"
                            },
                            on: {
                                click: function(o) {
                                    return t.onCategoryChange(e.uid)
                                }
                            }
                        }, [t._v("\n                                " + t._s(t.$prismic.asText(e.data.name)) + "\n                            ")])])
                    }))], 2), t._v(" "), o("div", {
                        staticClass: "c-Works-filters-select t-input--select-container"
                    }, [o("select", {
                        directives: [{
                            name: "model",
                            rawName: "v-model",
                            value: t.selectCategory,
                            expression: "selectCategory"
                        }],
                        staticClass: "t-input--select t-h6",
                        attrs: {
                            name: "category"
                        },
                        on: {
                            change: function(e) {
                                var o = Array.prototype.filter.call(e.target.options, (function(t) {
                                    return t.selected
                                })).map((function(t) {
                                    return "_value" in t ? t._value : t.value
                                }));
                                t.selectCategory = e.target.multiple ? o : o[0]
                            }
                        }
                    }, [o("option", {
                        attrs: {
                            value: ""
                        }
                    }, [t._v("\n                                All\n                            ")]), t._v(" "), t._l(t.categories, (function(e, i) {
                        return o("option", {
                            key: i,
                            domProps: {
                                value: e.uid
                            }
                        }, [t._v("\n                                " + t._s(t.$prismic.asText(e.data.name)) + "\n                            ")])
                    }))], 2)])])], 1), t._v(" "), o("div", {
                        staticClass: "col-18of24 offset-3of24 col-sm-12of12 offset-sm-0"
                    }, [o("div", {
                        staticClass: "row"
                    }, t._l(t.filteredProjects, (function(e, i) {
                        return o("NuxtLink", {
                            key: e.uid,
                            staticClass: "c-Works-item t-link js-section col-8of18 col-sm-12of12 offset-sm-0",
                            class: {
                                "offset-2of18": i % 2 == 1, "is-hide": t.projectHide
                            },
                            attrs: {
                                to: {
                                    name: "work-slug",
                                    params: {
                                        slug: e.uid
                                    }
                                }
                            }
                        }, [o("ParallaxObject", {
                            attrs: {
                                ratio: i % 2 == 1 ? .1 : null
                            }
                        }, [o("PixiImage", {
                            staticClass: "c-Works-item-img",
                            attrs: {
                                hide: t.projectHide,
                                "use-brush": !0,
                                parallax: i % 2 == 1 ? .1 : 0,
                                field: e.data.thumbnail[0].image,
                                "field-reveal": e.data.thumbnail[0].image_reveal
                            }
                        }), t._v(" "), o("div", {
                            staticClass: "c-Works-item-info"
                        }, [o("ul", {
                            staticClass: "c-Works-item-info-categories t-list t-h6 t-h6--spacing"
                        }, t._l(e.data.categories, (function(e) {
                            return o("li", {
                                key: e.category.slug
                            }, [t._v("\n                                        " + t._s(t.$prismic.asText(e.category.data.name)) + "\n                                    ")])
                        })), 0), t._v(" "), o("h3", {
                            directives: [{
                                name: "italic",
                                rawName: "v-italic",
                                value: t.$prismic.asText(e.data.title),
                                expression: "$prismic.asText(project.data.title)"
                            }],
                            staticClass: "c-Works-item-info-title t-h4"
                        }, [t._v("\n                                    " + t._s(t.$prismic.asText(e.data.title)) + "\n                                ")])])], 1)], 1)
                    })), 1)])])]), t._v(" "), o("div", {
                        staticClass: "c-Works-collection container"
                    }, [o("div", {
                        staticClass: "row center"
                    }, [o("div", {
                        staticClass: "js-section col-20of24 col-md-24of24 col-sm-12of12"
                    }, [o("div", {
                        staticClass: "c-Works-collection-head"
                    }, [o("div", {
                        staticClass: "c-Works-collection-head-titles"
                    }, [o("span", {
                        staticClass: "c-Works-collection-head-subtitle t-text"
                    }, t._l(t.document.collections, (function(e, i) {
                        return o("span", {
                            key: i,
                            staticClass: "c-Works-collection-head-subtitle-item",
                            class: {
                                "is-active": t.currentCollectionTitle === i, "is-out": t.oldCollectionTitle === i
                            }
                        }, [t._v(t._s(t.$prismic.asText(e.collection_subtitle)))])
                    })), 0), t._v(" "), o("h2", {
                        staticClass: "c-Works-collection-head-title t-h2"
                    }, t._l(t.document.collections, (function(e, i) {
                        return o("span", {
                            directives: [{
                                name: "italic",
                                rawName: "v-italic",
                                value: t.$prismic.asText(e.collection_title),
                                expression: "$prismic.asText(item.collection_title)"
                            }],
                            key: i,
                            staticClass: "c-Works-collection-head-title-item",
                            class: {
                                "is-active": t.currentCollectionTitle === i, "is-out": t.oldCollectionTitle === i
                            }
                        }, [t._v(t._s(t.$prismic.asText(e.collection_title)))])
                    })), 0)]), t._v(" "), o("button", {
                        staticClass: "c-Works-collection-refresh t-btn t-text--sm",
                        attrs: {
                            type: "button"
                        },
                        on: {
                            click: t.onCollectionChange
                        }
                    }, [t._m(0), t._v(" "), o("span", {
                        staticClass: "c-Works-collection-refresh-icon"
                    }, [o("svg", {
                        attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            width: "24",
                            height: "28",
                            viewBox: "0 0 53.929 61.238"
                        }
                    }, [o("path", {
                        attrs: {
                            stroke: "#000",
                            fill: "none",
                            d: "M26.965 9.811a24.465 24.465 0 1016.429 6.338",
                            "stroke-width": "5"
                        }
                    }), t._v(" "), o("path", {
                        attrs: {
                            stroke: "#000",
                            fill: "none",
                            d: "M28.463 8.867l-7.894-5.125-.543.836 7.08 4.596-4.597 7.08.836.542 5.126-7.894-.023-.014z",
                            "stroke-width": "2.99961"
                        }
                    })])])])]), t._v(" "), o("DefaultSlider", {
                        ref: "slider",
                        staticClass: "c-Works-collection-content row"
                    }, t._l(t.collectionItems, (function(e, i) {
                        return o("NuxtLink", {
                            key: "collection-" + t.currentCollection + "-" + e.uid,
                            staticClass: "js-item c-Works-item c-Works-item--collection col-6of20 t-link col-sm-9of12",
                            class: {
                                "offset-1of20 offset-sm-1of12": i > 0, "is-hide": e.isHide
                            },
                            attrs: {
                                to: {
                                    name: "work-slug",
                                    params: {
                                        slug: e.uid
                                    }
                                },
                                draggable: "false"
                            }
                        }, [o("PixiImage", {
                            staticClass: "c-Works-item-img",
                            attrs: {
                                hide: e.isHide,
                                "use-brush": !0,
                                field: e.data.thumbnail[0].image,
                                "field-reveal": e.data.thumbnail[0].image_reveal
                            }
                        }), t._v(" "), o("div", {
                            staticClass: "c-Works-item-info"
                        }, [o("ul", {
                            staticClass: "c-Works-item-info-categories t-list t-h6 t-h6--spacing"
                        }, t._l(e.data.categories, (function(e) {
                            return o("li", {
                                key: e.category.slug
                            }, [t._v("\n                                    " + t._s(t.$prismic.asText(t.categoryName(e.category.uid))) + "\n                                ")])
                        })), 0), t._v(" "), o("h3", {
                            directives: [{
                                name: "italic",
                                rawName: "v-italic",
                                value: t.$prismic.asText(e.data.title),
                                expression: "$prismic.asText(project.data.title)"
                            }],
                            staticClass: "c-Works-item-info-title t-h4"
                        }, [t._v("\n                                " + t._s(t.$prismic.asText(e.data.title)) + "\n                            ")])])], 1)
                    })), 1)], 1)])])], 1)
                }), [function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("span", {
                        staticClass: "c-Works-collection-refresh-label"
                    }, [t._v("Click here to discover"), o("br"), t._v("more collections")])
                }], !1, null, null, null);
            e.default = component.exports;
            installComponents(component, {
                IntroGradient: o(458).default,
                StickyElement: o(451).default,
                PixiImage: o(448).default,
                ParallaxObject: o(153).default,
                DefaultSlider: o(471).default
            })
        }
    }
]);