(window.webpackJsonp = window.webpackJsonp || []).push([
    [31, 9, 18, 19, 20, 25], {
        444: function(t, e, o) {
            "use strict";

            function n(t) {
                var e = 0,
                    o = 0;
                do {
                    e += t.offsetTop, o += t.offsetLeft, t = t.offsetParent
                } while (t);
                return {
                    top: e,
                    left: o
                }
            }
            o.d(e, "a", (function() {
                return n
            }))
        },
        445: function(t, e, o) {
            "use strict";
            var n = o(6),
                r = o(446);
            n({
                target: "String",
                proto: !0,
                forced: o(447)("anchor")
            }, {
                anchor: function(t) {
                    return r(this, "a", "name", t)
                }
            })
        },
        446: function(t, e, o) {
            var n = o(10),
                r = o(52),
                h = o(32),
                c = /"/g,
                l = n("".replace);
            t.exports = function(t, e, o, n) {
                var d = h(r(t)),
                    f = "<" + e;
                return "" !== o && (f += " " + o + '="' + l(h(n), c, "&quot;") + '"'), f + ">" + d + "</" + e + ">"
            }
        },
        447: function(t, e, o) {
            var n = o(12);
            t.exports = function(t) {
                return n((function() {
                    var e = "" [t]('"');
                    return e !== e.toLowerCase() || e.split('"').length > 3
                }))
            }
        },
        448: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(38), o(39);
            var n = o(17),
                r = (o(101), o(16), o(25), o(445), o(46)),
                h = o(4),
                c = o(14),
                l = o(444),
                d = o(450);

            function f(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var m = {
                    name: "PixiImage",
                    props: {
                        field: {
                            type: Object,
                            default: null,
                            required: !0
                        },
                        fieldReveal: {
                            type: Object,
                            default: null
                        },
                        useBrush: {
                            type: Boolean,
                            default: !1
                        },
                        useMask: {
                            type: Boolean,
                            default: !1
                        },
                        useHover: {
                            type: Boolean,
                            default: !1
                        },
                        hide: {
                            type: Boolean,
                            default: !1
                        },
                        debug: {
                            type: Boolean,
                            default: !1
                        },
                        parallax: {
                            type: Number,
                            default: 0
                        },
                        screenPos: {
                            type: Number,
                            default: .5
                        }
                    },
                    data: function() {
                        return {
                            isLoaded: !1
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? f(Object(source), !0).forEach((function(e) {
                                Object(n.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : f(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(c.d)("window", {
                        isTouch: "isTouch",
                        winWidth: "width",
                        winHeight: "height"
                    })),
                    watch: {
                        hide: "onHideChange"
                    },
                    created: function() {
                        this.cursorPos = {
                            x: 0,
                            y: 0
                        }, this.delta = {
                            x: 0,
                            y: 0,
                            v: 0
                        }, this.mouseX = 0, this.mouseY = 0, this.scale = 0, this.smoothScale = 0, this._onPointerEnter = this.onPointerEnter.bind(this), this._onPointerMove = this.onPointerMove.bind(this), this._onPointerLeave = this.onPointerLeave.bind(this)
                    },
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            t.getContainer(), t.container && !t.isTouch && (t.width = t.$el.offsetWidth, t.height = t.$el.offsetHeight, t.offsets = Object(l.a)(t.$el), t.computedSize = Object(d.a)(t.field.dimensions.width, t.field.dimensions.height, t.width, t.height, !1), t.offsetX = Math.round(.5 * (t.width - t.computedSize.width)), t.offsetY = Math.round(.5 * (t.height - t.computedSize.height)), t.init()), t.observer = new IntersectionObserver((function(e) {
                                e.forEach((function(e) {
                                    e.isIntersecting && (t.$refs.img.onload = function() {
                                        t.isLoaded = !0, t.image && r.a.to(t.image, {
                                            duration: 1.2,
                                            alpha: 1,
                                            ease: h.c.easeOut,
                                            onComplete: function() {
                                                t.containerMask.removeChild(t.background), t.background.destroy(), t.background = null
                                            }
                                        })
                                    }, t.$refs.img.src = t.$refs.img.dataset.src, t.$refs.img.srcset = t.$refs.img.dataset.srcset, !t.image && t.containerMask && t.createImage(), t.observer.unobserve(e.target), t.observer.disconnect())
                                }))
                            })), t.observer.observe(t.$el), t.$eventHub.$on("resize", t.resize), t.$eventHub.$on("update", t.update), (t.useBrush || t.useHover) && (t.$el.addEventListener("pointerenter", t._onPointerEnter), window.addEventListener("pointermove", t._onPointerMove), t.$el.addEventListener("pointerleave", t._onPointerLeave))
                        }))
                    },
                    beforeDestroy: function() {
                        this.$refs.img && this.observer && (this.observer.unobserve(this.$el), this.observer.disconnect()), this.containerMask && this.container.removeChild(this.containerMask), this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update), (this.useBrush || this.useHover) && (this.$el.removeEventListener("pointerenter", this._onPointerEnter), window.removeEventListener("pointermove", this._onPointerMove), this.$el.removeEventListener("pointerleave", this._onPointerLeave))
                    },
                    methods: {
                        getContainer: function() {
                            for (var t = this; t.$parent;) {
                                if (t.$parent.container && t.$parent.container instanceof this.$PIXI.Container) {
                                    this.container = t.$parent.container;
                                    break
                                }
                                t = t.$parent
                            }
                            if (!this.container) return console.warn("No pixi application founded for this Object. This component must be a child/subchild of a Pixi application", this)
                        },
                        init: function() {
                            this.containerMask = new this.$PIXI.Container, this.containerMask.position.x = this.offsets.left, this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.hide && (this.containerMask.alpha = 0), this.container.addChild(this.containerMask), this.background = new this.$PIXI.Sprite.from(this.field.thumb.url), this.background.anchor.set(0), this.background.width = this.width, this.background.height = this.height, this.containerMask.addChild(this.background), this.useMask && (this.mask = new this.$PIXI.Graphics, this.containerMask.addChild(this.mask), this.mask.beginFill("0x000000"), this.mask.drawRect(0, 0, this.width, this.height), this.mask.endFill(), this.containerMask.mask = this.mask)
                        },
                        createImage: function() {
                            this.image = new this.$PIXI.Sprite.from(window.devicePixelRatio > 1 ? this.field.retina.url : this.field.url), this.containerMask.addChild(this.image), this.image.anchor.set(.5), this.image.width = this.computedSize.width, this.image.height = this.computedSize.height, this.image.position.x = this.offsetX + this.computedSize.width / 2, this.image.position.y = this.offsetY + this.computedSize.height / 2, this.image.alpha = 0, this.useBrush && this.fieldReveal && this.fieldReveal.url && (this.brush = new this.$PIXI.Graphics, this.containerMask.addChild(this.brush), this.brush.beginFill(16777215), this.brush.drawCircle(0, 0, 60), this.brush.endFill(), this.brush.scale.x = 0, this.brush.scale.y = 0, this.imageToReveal = new this.$PIXI.Sprite.from(window.devicePixelRatio > 1 ? this.fieldReveal.retina.url : this.fieldReveal.url), this.containerMask.addChild(this.imageToReveal), this.imageToReveal.anchor.set(0), this.imageToReveal.width = this.computedSize.width, this.imageToReveal.height = this.computedSize.height, this.imageToReveal.position.x = this.offsetX, this.imageToReveal.position.y = this.offsetY, this.imageToReveal.mask = this.brush)
                        },
                        resize: function() {
                            this.isTouch || (this.width = this.$el.offsetWidth, this.height = this.$el.offsetHeight, this.offsets = Object(l.a)(this.$el), this.computedSize = Object(d.a)(this.field.dimensions.width, this.field.dimensions.height, this.width, this.height, !1), this.offsetX = Math.round(.5 * (this.width - this.computedSize.width)), this.offsetY = Math.round(.5 * (this.height - this.computedSize.height)), this.containerMask.position.x = this.offsets.left, this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.useMask && (this.mask.clear(), this.mask.beginFill("0x000000"), this.mask.drawRect(0, 0, this.width, this.height), this.mask.endFill()), this.background && (this.background.width = this.width, this.background.height = this.height), this.image && (this.image.width = this.computedSize.width, this.image.height = this.computedSize.height, this.image.position.x = this.offsetX + this.computedSize.width / 2, this.image.position.y = this.offsetY + this.computedSize.height / 2), this.imageToReveal && (this.imageToReveal.width = this.computedSize.width, this.imageToReveal.height = this.computedSize.height, this.imageToReveal.position.x = this.offsetX, this.imageToReveal.position.y = this.offsetY))
                        },
                        update: function() {
                            this.containerMask && (this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, 0 !== this.parallax && (this.containerMask.position.y += this.containerMask.position.y * this.parallax - this.offsets.top * this.parallax), this.brush && (this.cursorPos.x += .1 * (this.mouseX - this.cursorPos.x), this.cursorPos.y += .1 * (this.mouseY - this.cursorPos.y), this.isEnter && (this.delta.x = Math.abs(this.mouseX - this.cursorPos.x), this.delta.y = Math.abs(this.mouseY - this.cursorPos.y), this.delta.v = this.delta.x > this.delta.y ? this.delta.x : this.delta.y, this.scale = 1 + this.delta.v / 100), this.smoothScale += .1 * (this.scale - this.smoothScale), this.brush.scale.x = this.smoothScale, this.brush.scale.y = this.smoothScale, this.brush.position.x = this.cursorPos.x, this.brush.position.y = this.cursorPos.y))
                        },
                        onPointerEnter: function(t) {
                            this.image && (this.isEnter = !0, this.useBrush && this.fieldReveal && this.fieldReveal.url && (this.cursorPos.x = t.clientX - this.offsets.left, this.cursorPos.y = t.clientY - this.containerMask.position.y, this.animFadeRT && (this.animFadeRT.pause(), this.animFadeRT = null)), this.useHover && (this.savedScale = this.image.scale.x, r.a.to(this.image.scale, {
                                duration: .6,
                                x: this.savedScale + .05,
                                y: this.savedScale + .05,
                                ease: h.c.easeOut
                            })))
                        },
                        onPointerMove: function(t) {
                            this.isEnter && this.useBrush && (this.mouseX = t.clientX - this.offsets.left, this.mouseY = t.clientY - this.containerMask.position.y)
                        },
                        onPointerLeave: function() {
                            var t = this;
                            this.image && (this.useHover && r.a.to(this.image.scale, {
                                duration: .6,
                                x: this.savedScale,
                                y: this.savedScale,
                                ease: h.c.easeOut
                            }), this.useBrush && this.brush && (this.animFadeRT = r.a.to(this, {
                                duration: .6,
                                smoothScale: 0,
                                scale: 0,
                                ease: h.c.easeOut,
                                onComplete: function() {
                                    t.isEnter = !1, t.animFadeRT = null
                                }
                            })))
                        },
                        onHideChange: function() {
                            var t = this.hide ? 0 : 1;
                            r.a.to(this.containerMask, {
                                duration: .6,
                                alpha: t,
                                ease: h.c.easeOut
                            })
                        }
                    }
                },
                v = m,
                y = (o(452), o(26)),
                component = Object(y.a)(v, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "c-PixiImage",
                        class: {
                            "is-loaded": t.isLoaded
                        },
                        style: {
                            backgroundImage: t.isTouch ? "url(" + t.field.thumb.url + ")" : ""
                        }
                    }, [o("img", {
                        ref: "img",
                        staticClass: "c-PixiImage-img",
                        attrs: {
                            "data-src": t.field.url,
                            "data-srcset": t.field.retina.url,
                            alt: t.field.alt ? t.field.alt : " ",
                            draggable: "false",
                            ondragstart: "return false;"
                        }
                    })])
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        449: function(t, e, o) {
            var content = o(453);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("76dd5624", content, !0, {
                sourceMap: !1
            })
        },
        450: function(t, e, o) {
            "use strict";

            function n(t, e, o, n, r) {
                var h = [o / t, n / e];
                return {
                    width: t * (h = r ? Math.min(h[0], h[1]) : Math.max(h[0], h[1])),
                    height: e * h
                }
            }
            o.d(e, "a", (function() {
                return n
            }))
        },
        451: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(16), o(38), o(25), o(39);
            var n = o(17),
                r = (o(101), o(14)),
                h = o(102);

            function c(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var l = {
                    name: "StickyElement",
                    props: {
                        active: {
                            type: Boolean,
                            default: !0
                        },
                        inside: {
                            type: Boolean,
                            default: !0
                        },
                        gapTop: {
                            type: Number,
                            default: 0
                        },
                        gapBottom: {
                            type: Number,
                            default: 0
                        }
                    },
                    data: function() {
                        return {
                            activeClass: ""
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? c(Object(source), !0).forEach((function(e) {
                                Object(n.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : c(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(r.d)("window", ["isTouch"])),
                    watch: {
                        active: "onActiveChange",
                        gapTop: "resize",
                        gapBottom: "resize"
                    },
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            if (t.$eventHub.$on("resize", t.resize), t.$eventHub.$on("update", t.update), t.parent = t.getStickyParent(), !t.parent) return console.warn("No parent founded for this Sticky Element. This component must be a child/subchild of a js-sticky-container", t);
                            t.$nextTick((function() {
                                t.resize()
                            }))
                        }))
                    },
                    beforeDestroy: function() {
                        this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update)
                    },
                    methods: {
                        onActiveChange: function() {
                            this.active && this.update()
                        },
                        getStickyParent: function() {
                            for (var element = this.$el.parentNode; !element.classList.contains("js-sticky-container");) element = element.parentNode;
                            return element
                        },
                        resize: function() {
                            this.parent && (this.width = this.$el.offsetWidth, this.height = this.$el.offsetHeight, this.top = this.$el.offsetTop, this.parentTop = Object(h.a)(this.parent), this.parentHeight = this.parent.offsetHeight, this.triggerTop = this.parentTop + this.top - this.gapTop, this.triggerBottom = this.parentTop + this.parentHeight - this.height - this.gapTop - this.gapBottom)
                        },
                        update: function() {
                            this.parent && this.active && (this.$el.style.transform = this.transform, this.scrollVal = this.isTouch ? this.$root.scrollTop : this.$root.smoothScroll, this.scrollVal >= this.triggerTop && this.scrollVal < this.triggerBottom ? (this.activeClass = "is-sticky", this.isTouch || (this.inside ? this.transform = "translateY(".concat(this.scrollVal - this.triggerTop, "px) translateZ(0)") : this.transform = "translateY(".concat(-this.triggerTop, "px) translateZ(0)"))) : this.scrollVal > this.triggerBottom ? (this.activeClass = "is-sticky-end", this.isTouch || (this.inside ? this.transform = "translateY(".concat(this.triggerBottom - this.triggerTop, "px) translateZ(0)") : this.transform = "translateY(".concat(-this.scrollVal + this.triggerBottom - this.triggerTop, "px) translateZ(0)"))) : (this.activeClass = "", this.isTouch || (this.inside ? this.transform = "translateY(0px) translateZ(0)" : this.transform = "translateY(".concat(-this.scrollVal, "px) translateZ(0)"))))
                        }
                    }
                },
                d = l,
                f = o(26),
                component = Object(f.a)(d, (function() {
                    var t = this,
                        e = t.$createElement;
                    return (t._self._c || e)("div", {
                        class: t.activeClass
                    }, [t._t("default")], 2)
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        452: function(t, e, o) {
            "use strict";
            o(449)
        },
        453: function(t, e, o) {
            var n = o(54)(!1);
            n.push([t.i, ".c-PixiImage{position:relative;background-size:cover}.c-PixiImage-img{position:absolute;top:0;left:0;width:100%;height:100%;opacity:0;transform:translateZ(0);display:none}.is-touch .c-PixiImage-img{display:block}.c-PixiImage.is-loaded .c-PixiImage-img{opacity:1;transition:opacity .8s cubic-bezier(.165,.84,.44,1)}.c-PixiImage.is-loaded.is-disabled .c-PixiImage-img{transition:none}", ""]), t.exports = n
        },
        454: function(t, e, o) {
            "use strict";

            function n(t, e, o, n, r) {
                return (r - t) * (n - o) / (e - t) + o
            }
            o.d(e, "a", (function() {
                return n
            }))
        },
        455: function(t, e, o) {
            "use strict";
            o.r(e);
            o(47);
            var n = {
                    name: "CursorTrigger",
                    props: {
                        active: {
                            type: Boolean,
                            default: !0
                        },
                        name: {
                            type: String,
                            default: ""
                        },
                        value: {
                            type: String,
                            default: ""
                        }
                    },
                    watch: {
                        active: "onActiveChange",
                        name: "onNameChange"
                    },
                    methods: {
                        onMouseEnter: function(t) {
                            this.active && (this.$eventHub.$emit("cursor:enter", this.name, this.value, t), this.isHover = !0)
                        },
                        onMouseLeave: function() {
                            this.active && (this.$eventHub.$emit("cursor:leave", this.name), this.isHover = !1)
                        },
                        onActiveChange: function() {
                            this.active || this.$eventHub.$emit("cursor:leave", this.name)
                        },
                        onNameChange: function(t, e) {
                            this.active && this.isHover && (this.$eventHub.$emit("cursor:leave", e), this.$eventHub.$emit("cursor:enter", t, this.value))
                        }
                    }
                },
                r = o(26),
                component = Object(r.a)(n, (function() {
                    var t = this,
                        e = t.$createElement;
                    return (t._self._c || e)("div", {
                        on: {
                            "&pointerenter": function(e) {
                                return t.onMouseEnter.apply(null, arguments)
                            },
                            "&pointerleave": function(e) {
                                return t.onMouseLeave.apply(null, arguments)
                            }
                        }
                    }, [t._t("default")], 2)
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        488: function(t, e, o) {
            var content = o(510);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("4d62f044", content, !0, {
                sourceMap: !1
            })
        },
        509: function(t, e, o) {
            "use strict";
            o(488)
        },
        510: function(t, e, o) {
            var n = o(54)(!1);
            n.push([t.i, ".c-PixiIntro{position:relative;height:100vh;width:100%;overflow:hidden;color:#fff}.c-PixiIntro-gradient{position:fixed;top:0;left:0;width:100%;height:100%;visibility:hidden}.is-touch .c-PixiIntro-gradient{visibility:visible}.c-PixiIntro-inner{position:relative;display:flex;align-items:center;justify-content:center;width:100%;height:100%}.c-PixiIntro-title{display:none}.c-PixiIntro-title-line,.is-touch .c-PixiIntro-title{display:block}.c-PixiIntro-title-line--1{margin-left:16.51vw}.c-PixiIntro-title-line--2{margin-left:10.416vw}.c-PixiIntro-foot{position:absolute;width:100%;bottom:0;left:0;padding-bottom:35px;transform:translateY(100%) translateZ(0)}@media only screen and (max-width:767px){.c-PixiIntro-foot{padding-bottom:30px}}.is-page-ready .c-PixiIntro-foot{transform:translateZ(0);transition:transform 1.2s cubic-bezier(.165,.84,.44,1) .4s}.c-PixiIntro-foot-circles{align-self:flex-end}@media only screen and (max-width:767px){.c-PixiIntro-foot-circles,.c-PixiIntro-foot-item{display:none}.c-PixiIntro-foot-item:first-child{display:block}}.c-PixiIntro-foot-item-subtitle{display:block;opacity:.5}.c-PixiIntro-foot-scroll{display:block;margin-left:auto;width:17px;height:52.5px}.c-PixiIntro-foot-scroll img{width:100%;height:100%}", ""]), t.exports = n
        },
        521: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(16), o(38), o(25), o(39);
            var n = o(17),
                r = (o(445), o(69), o(14)),
                h = o(46),
                c = o(4),
                l = o(454);

            function d(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }

            function f(t) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = null != arguments[i] ? arguments[i] : {};
                    i % 2 ? d(Object(source), !0).forEach((function(e) {
                        Object(n.a)(t, e, source[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : d(Object(source)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                    }))
                }
                return t
            }
            var m = {
                    name: "PixiIntro",
                    props: {
                        options: {
                            type: Object,
                            required: !0
                        },
                        title: {
                            type: Object,
                            default: null
                        },
                        titleJapanese: {
                            type: Object,
                            default: null
                        },
                        manifesto: {
                            type: Array,
                            default: null
                        }
                    },
                    computed: f(f({}, Object(r.d)("window", ["width", "height", "minHeight", "isTouch"])), Object(r.d)("main", ["isFontLoaded", "isPageReady"])),
                    watch: {
                        isFontLoaded: "init",
                        isPageReady: "animate"
                    },
                    created: function() {
                        this.padding = 100, this.circleMaskRadius = 125, this.force = 5, this.seed = .18, this.smoothForce = this.force, this.smoothSeed = this.seed, this._onPointerMove = this.onPointerMove.bind(this)
                    },
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            t.isTouch ? t.$eventHub.$emit("page:mounted") : (t.smoothPositionX = t.width / 2, t.smoothPositionY = t.minHeight / 2, t.position = {
                                x: t.width / 2,
                                y: t.minHeight / 2
                            }, t.getContainerBg(), t.containerBg && (t.textureCanvas = new t.$PIXI.Texture.from(t.$refs.gradient.shadowRoot.querySelector("canvas")), t.gradient = t.$PIXI.Sprite.from(t.textureCanvas), t.containerBg.addChild(t.gradient)), t.$eventHub.$on("update", t.update), t.$eventHub.$on("resize", t.resize), t.mainContainer = new t.$PIXI.Container, t.$root.pixiApp.stage.addChild(t.mainContainer), t.lense = t.$PIXI.Sprite.from("/lense.png"), t.mainContainer.addChild(t.lense), t.lense.anchor.set(.5), t.lense.position.x = t.width / 2, t.lense.position.y = t.minHeight / 2, t.englishContainer = new t.$PIXI.Container, t.mainContainer.addChild(t.englishContainer), t.superContainer = new t.$PIXI.Container, t.mainContainer.addChild(t.superContainer), t.background = new t.$PIXI.Graphics, t.background.beginFill("0xFF0000"), t.background.drawRect(0, 0, t.width, t.minHeight), t.background.endFill(), t.background.alpha = 0, t.superContainer.addChild(t.background), t.japaneseContainer = new t.$PIXI.Container, t.superContainer.addChild(t.japaneseContainer), t.superContainerTwo = new t.$PIXI.Container, t.mainContainer.addChild(t.superContainerTwo), t.backgroundTwo = new t.$PIXI.Graphics, t.backgroundTwo.beginFill("0xFF0000"), t.backgroundTwo.drawRect(0, 0, t.width, t.minHeight), t.backgroundTwo.endFill(), t.backgroundTwo.alpha = 0, t.superContainerTwo.addChild(t.backgroundTwo), t.containerEffect = new t.$PIXI.Container, t.superContainerTwo.addChild(t.containerEffect), t.effectMask = t.$PIXI.Sprite.from("/mask.png"), t.effectMask.anchor.set(.5), t.effectMask.position.x = t.width / 2, t.effectMask.position.y = t.minHeight / 2, t.mainContainer.addChild(t.effectMask), t.superContainerTwo.mask = t.effectMask, t.circleMask = new t.$PIXI.Graphics, t.circleMask.beginFill(16777215), t.circleMask.drawCircle(0, 0, t.circleMaskRadius), t.circleMask.endFill(), t.circleMask.position.x = t.width / 2, t.circleMask.position.y = t.minHeight / 2, t.mainContainer.addChild(t.circleMask), t.superContainer.mask = t.circleMask, t.inverseCircleMask = new t.$PIXI.Graphics, t.inverseCircleMask.beginFill(16777215), t.inverseCircleMask.drawRect(0, 0, t.width, t.minHeight), t.inverseCircleMask.beginHole(), t.inverseCircleMask.drawCircle(t.width / 2, t.minHeight / 2, t.circleMaskRadius), t.inverseCircleMask.endHole(), t.inverseCircleMask.endFill(), t.mainContainer.addChild(t.inverseCircleMask), t.englishContainer.mask = t.inverseCircleMask, t.displacementSprite = t.$PIXI.Sprite.from("/displace.png"), t.displacementFilter = new t.$PIXI.filters.DisplacementFilter(t.displacementSprite), t.mainContainer.addChild(t.displacementSprite), t.RGBSplitFilter = new t.$RGBSplitFilter([-2, 2], [1, 1], [2, -2]), t.superContainerTwo.filters = [t.displacementFilter, t.RGBSplitFilter], t.superContainer.filters = [t.displacementFilter], t.displacementFilter.scale.x = 20, t.displacementFilter.scale.y = 20, t.displacementSprite.anchor.set(.5), window.addEventListener("pointermove", t._onPointerMove), t.isFontLoaded && t.init())
                        }))
                    },
                    beforeDestroy: function() {
                        this.$eventHub.$off("update", this.update), this.$eventHub.$off("resize", this.resize), window.removeEventListener("pointermove", this._onPointerMove), this.$root.pixiApp.stage && this.mainContainer && (this.$root.pixiApp.stage.removeChild(this.mainContainer), this.containerBg.removeChild(this.gradient))
                    },
                    methods: {
                        getContainerBg: function() {
                            for (var t = this; t.$parent;) {
                                if (t.$parent.containerBg && t.$parent.containerBg instanceof this.$PIXI.Container) {
                                    this.containerBg = t.$parent.containerBg;
                                    break
                                }
                                t = t.$parent
                            }
                            if (!this.containerBg) return console.warn("No pixi application founded for this Object. This component must be a child/subchild of a Pixi application", this)
                        },
                        init: function() {
                            var t = this;
                            !this.isTouch && this.isFontLoaded && (this.fontStyle = {
                                fontFamily: "Roobert",
                                fontSize: "max(5.9895833333vw, 47px)",
                                fill: "#FFFFFF",
                                padding: this.padding,
                                trim: !0
                            }, this.lineOne = new this.$PIXI.Text(this.title.line_one, this.fontStyle), this.lineOne.position.x = 0, this.lineOne.position.y = 0, this.englishContainer.addChild(this.lineOne), this.lineTwo = new this.$PIXI.Text(this.title.line_two, this.fontStyle), this.lineTwo.x = 16.51 * this.width / 100, this.lineTwo.y = this.lineOne.y + 1.4 * this.lineOne.height, this.englishContainer.addChild(this.lineTwo), this.lineThree = new this.$PIXI.Text(this.title.line_three, this.fontStyle), this.lineThree.x = 10.416 * this.width / 100, this.lineThree.y = this.lineOne.y + 1.4 * this.lineOne.height * 2, this.englishContainer.addChild(this.lineThree), this.englishContainer.position.x = this.width / 2 - this.englishContainer.width / 2, this.englishContainer.position.y = this.minHeight / 2 - this.englishContainer.height / 2, this.fontStyleJP = {
                                fontFamily: "Noto Sans CJK JP",
                                fontSize: "max(5vw, 39px)",
                                fill: "#FFFFFF",
                                padding: this.padding,
                                trim: !0
                            }, this.lineOneJP = new this.$PIXI.Text(this.titleJapanese.line_one, this.fontStyleJP), this.lineOneJP.x = 0, this.lineOneJP.y = 0, this.japaneseContainer.addChild(this.lineOneJP), this.lineTwoJP = new this.$PIXI.Text(this.titleJapanese.line_two, this.fontStyleJP), this.lineTwoJP.x = 16.51 * this.width / 100, this.lineTwoJP.y = this.lineOne.y + 1.4 * this.lineOne.height, this.japaneseContainer.addChild(this.lineTwoJP), this.lineThreeJP = new this.$PIXI.Text(this.titleJapanese.line_three, this.fontStyleJP), this.lineThreeJP.x = 10.416 * this.width / 100, this.lineThreeJP.y = this.lineOne.y + 1.4 * this.lineOne.height * 2, this.japaneseContainer.addChild(this.lineThreeJP), this.japaneseContainer.position.x = this.width / 2 - this.japaneseContainer.width / 2, this.japaneseContainer.position.y = this.minHeight / 2 - this.japaneseContainer.height / 2, this.lineOneEffect = new this.$PIXI.Text(this.titleJapanese.line_one, this.fontStyleJP), this.lineOneEffect.x = 0, this.lineOneEffect.y = 0, this.containerEffect.addChild(this.lineOneEffect), this.lineTwoEffect = new this.$PIXI.Text(this.titleJapanese.line_two, this.fontStyleJP), this.lineTwoEffect.x = 16.51 * this.width / 100, this.lineTwoEffect.y = this.lineOne.y + 1.4 * this.lineOne.height, this.containerEffect.addChild(this.lineTwoEffect), this.lineThreeEffect = new this.$PIXI.Text(this.titleJapanese.line_three, this.fontStyleJP), this.lineThreeEffect.x = 10.416 * this.width / 100, this.lineThreeEffect.y = this.lineOne.y + 1.4 * this.lineOne.height * 2, this.containerEffect.addChild(this.lineThreeEffect), this.containerEffect.position.x = this.width / 2 - this.containerEffect.width / 2, this.containerEffect.position.y = this.minHeight / 2 - this.containerEffect.height / 2, setTimeout((function() {
                                t.$eventHub.$emit("page:mounted")
                            }), 100))
                        },
                        update: function() {
                            if (this.smoothForce += .1 * (this.force - this.smoothForce), this.smoothSeed += .1 * (this.seed - this.smoothSeed), this.$refs.gradient && (this.$refs.gradient.displacement = this.smoothForce, this.$refs.gradient.seed = this.smoothSeed), this.textureCanvas.update(), !this.isTouch) {
                                var t = Object(l.a)(0, this.minHeight / 3, 1, 0, Math.abs(this.$root.smoothScroll));
                                this.$refs.intro.style.opacity = t, this.$refs.intro.style.visibility = 0 === t ? "hidden" : "visible", this.mainContainer.alpha = Object(l.a)(0, this.minHeight / 3 * 2, 1, 0, Math.abs(this.$root.smoothScroll)), 0 === this.mainContainer.alpha ? this.mainContainer.visible = !1 : this.mainContainer.visible = !0, this.lineOne && (this.lineOne.x = .05 * -Math.abs(this.$root.smoothScroll), this.lineTwo.x = 16.51 * this.width / 100 + .05 * Math.abs(this.$root.smoothScroll), this.lineThree.x = 10.416 * this.width / 100 - .05 * Math.abs(this.$root.smoothScroll), this.lineOneJP.x = .05 * -Math.abs(this.$root.smoothScroll), this.lineTwoJP.x = 16.51 * this.width / 100 + .05 * Math.abs(this.$root.smoothScroll), this.lineThreeJP.x = 10.416 * this.width / 100 - .05 * Math.abs(this.$root.smoothScroll), this.lineOneEffect.x = .05 * -Math.abs(this.$root.smoothScroll), this.lineTwoEffect.x = 16.51 * this.width / 100 + .05 * Math.abs(this.$root.smoothScroll), this.lineThreeEffect.x = 10.416 * this.width / 100 - .05 * Math.abs(this.$root.smoothScroll)), this.position.y >= this.minHeight || (this.smoothPositionX += .1 * (this.position.x - this.smoothPositionX), this.smoothPositionY += .1 * (this.position.y - this.smoothPositionY), this.lense.position.x = this.smoothPositionX, this.lense.position.y = this.smoothPositionY, this.circleMask.position.x = this.smoothPositionX, this.circleMask.position.y = this.smoothPositionY, this.effectMask.position.x = this.smoothPositionX, this.effectMask.position.y = this.smoothPositionY, this.inverseCircleMask.clear(), this.inverseCircleMask.beginFill(16777215), this.inverseCircleMask.drawRect(0, 0, this.width, this.minHeight), this.inverseCircleMask.beginHole(), this.inverseCircleMask.drawCircle(this.smoothPositionX, this.smoothPositionY, this.circleMaskRadius), this.inverseCircleMask.endHole(), this.inverseCircleMask.endFill(), this.displacementSprite && this.displacementSprite.position.set(this.smoothPositionX, this.smoothPositionY))
                            }
                        },
                        resize: function() {
                            !this.isTouch && this.fontStyle && (this.fontStyle.fontSize = 5.9895833333 * this.width / 100 + "px", this.fontStyleJP.fontSize = 5 * this.width / 100 + "px", this.lineOne.style.fontSize = this.fontStyle.fontSize, this.lineTwo.style.fontSize = this.fontStyle.fontSize, this.lineThree.style.fontSize = this.fontStyle.fontSize, this.lineOneJP.style.fontSize = this.fontStyleJP.fontSize, this.lineTwoJP.style.fontSize = this.fontStyleJP.fontSize, this.lineThreeJP.style.fontSize = this.fontStyleJP.fontSize, this.lineOneEffect.style.fontSize = this.fontStyleJP.fontSize, this.lineTwoEffect.style.fontSize = this.fontStyleJP.fontSize, this.lineThreeEffect.style.fontSize = this.fontStyleJP.fontSize, this.lineTwo.x = 16.51 * this.width / 100, this.lineTwo.y = this.lineOne.y + 1.4 * this.lineOne.height, this.lineThree.x = 10.416 * this.width / 100, this.lineThree.y = this.lineOne.y + 1.4 * this.lineOne.height * 2, this.englishContainer.position.x = this.width / 2 - this.englishContainer.width / 2, this.englishContainer.position.y = this.minHeight / 2 - this.englishContainer.height / 2, this.lineTwoJP.x = 16.51 * this.width / 100, this.lineTwoJP.y = this.lineOne.y + 1.4 * this.lineOne.height, this.lineThreeJP.x = 10.416 * this.width / 100, this.lineThreeJP.y = this.lineOne.y + 1.4 * this.lineOne.height * 2, this.japaneseContainer.position.x = this.width / 2 - this.japaneseContainer.width / 2, this.japaneseContainer.position.y = this.minHeight / 2 - this.japaneseContainer.height / 2, this.lineTwoEffect.x = 16.51 * this.width / 100, this.lineTwoEffect.y = this.lineOne.y + 1.4 * this.lineOne.height, this.lineThreeEffect.x = 10.416 * this.width / 100, this.lineThreeEffect.y = this.lineOne.y + 1.4 * this.lineOne.height * 2, this.containerEffect.position.x = this.width / 2 - this.containerEffect.width / 2, this.containerEffect.position.y = this.minHeight / 2 - this.containerEffect.height / 2)
                        },
                        onPointerMove: function(t) {
                            this.position = {
                                x: t.clientX,
                                y: t.clientY
                            }, this.force = Object(l.a)(0, 1, 0, 5, t.clientX / this.width), this.seed = Object(l.a)(0, 1, -1, 1, t.clientY / this.minHeight)
                        },
                        onScroll: function() {
                            h.a.to(window, {
                                scrollTo: this.minHeight,
                                duration: .6,
                                ease: c.c.easeInOut
                            })
                        },
                        animate: function() {
                            if (!this.isTouch && this.isPageReady) {
                                this.timeline = h.a.timeline();
                                var t = .1 * this.width;
                                this.timeline.from(this.lineOne, {
                                    x: this.lineOne.x - t,
                                    alpha: 0,
                                    duration: 1.2,
                                    delay: .4,
                                    ease: c.c.easeOut
                                }), this.timeline.from(this.lineTwo, {
                                    x: this.lineTwo.x + t,
                                    alpha: 0,
                                    duration: 1.2,
                                    ease: c.c.easeOut
                                }, "<"), this.timeline.from(this.lineThree, {
                                    x: this.lineThree.x - t,
                                    alpha: 0,
                                    duration: 1.2,
                                    ease: c.c.easeOut
                                }, "<"), this.timeline.from(this.lineOneJP, {
                                    x: this.lineOne.x - t,
                                    alpha: 0,
                                    duration: 1.2,
                                    ease: c.c.easeOut
                                }, "<"), this.timeline.from(this.lineTwoJP, {
                                    x: this.lineTwo.x + t,
                                    alpha: 0,
                                    duration: 1.2,
                                    ease: c.c.easeOut
                                }, "<"), this.timeline.from(this.lineThreeJP, {
                                    x: this.lineThree.x - t,
                                    alpha: 0,
                                    duration: 1.2,
                                    ease: c.c.easeOut
                                }, "<"), this.timeline.from(this.lineOneEffect, {
                                    x: this.lineOne.x - t,
                                    alpha: 0,
                                    duration: 1.2,
                                    ease: c.c.easeOut
                                }, "<"), this.timeline.from(this.lineTwoEffect, {
                                    x: this.lineTwo.x + t,
                                    alpha: 0,
                                    duration: 1.2,
                                    ease: c.c.easeOut
                                }, "<"), this.timeline.from(this.lineThreeEffect, {
                                    x: this.lineThree.x - t,
                                    alpha: 0,
                                    duration: 1.2,
                                    ease: c.c.easeOut
                                }, "<"), this.timeline.play()
                            }
                        }
                    }
                },
                v = (o(509), o(26)),
                component = Object(v.a)(m, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("section", [o("monopo-gradient", {
                        ref: "gradient",
                        staticClass: "c-PixiIntro-gradient",
                        style: {
                            height: t.minHeight + "px"
                        },
                        attrs: {
                            color1: t.options.color1,
                            color2: t.options.color2,
                            color3: t.options.color3,
                            color4: t.options.color4,
                            colorsize: t.options.colorsize,
                            colorspacing: t.options.colorspacing,
                            colorrotation: t.options.colorrotation,
                            colorspread: t.options.colorspread,
                            coloroffset: t.options.coloroffset,
                            displacement: t.options.displacement,
                            seed: t.options.seed,
                            position: t.options.position,
                            zoom: t.options.zoom,
                            spacing: t.options.spacing,
                            noretina: "true"
                        }
                    }), t._v(" "), o("div", {
                        ref: "intro",
                        staticClass: "c-PixiIntro container",
                        style: {
                            height: t.minHeight + "px"
                        }
                    }, [o("div", {
                        staticClass: "c-PixiIntro-inner"
                    }, [o("h1", {
                        staticClass: "c-PixiIntro-title t-h1"
                    }, [o("span", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.title.line_one,
                            expression: "title.line_one"
                        }],
                        staticClass: "c-PixiIntro-title-line c-PixiIntro-title-line--0"
                    }, [t._v(t._s(t.title.line_one))]), t._v(" "), o("span", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.title.line_two,
                            expression: "title.line_two"
                        }],
                        staticClass: "c-PixiIntro-title-line c-PixiIntro-title-line--1"
                    }, [t._v(t._s(t.title.line_two))]), t._v(" "), o("span", {
                        directives: [{
                            name: "italic",
                            rawName: "v-italic",
                            value: t.title.line_three,
                            expression: "title.line_three"
                        }],
                        staticClass: "c-PixiIntro-title-line c-PixiIntro-title-line--2"
                    }, [t._v(t._s(t.title.line_three))])]), t._v(" "), o("div", {
                        staticClass: "c-PixiIntro-foot"
                    }, [o("div", {
                        staticClass: "row bottom"
                    }, [t._m(0), t._v(" "), o("div", {
                        staticClass: "col-16of24 col-sm-10of12"
                    }, [o("div", {
                        staticClass: "row"
                    }, t._l(t.manifesto, (function(e, i) {
                        return o("div", {
                            key: i,
                            staticClass: "c-PixiIntro-foot-item t-text--lg col-4of16 col-sm-10of10",
                            class: {
                                "offset-2of16": i > 0
                            }
                        }, [o("strong", [t._v(t._s(t.$prismic.asText(e.manifesto_title)))]), t._v(" "), o("span", {
                            staticClass: "c-PixiIntro-foot-item-subtitle"
                        }, [t._v(t._s(e.manifesto_text))])])
                    })), 0)]), t._v(" "), o("div", {
                        staticClass: "col-2of24 col-sm-2of12"
                    }, [o("button", {
                        staticClass: "c-PixiIntro-foot-scroll t-btn",
                        attrs: {
                            type: "button"
                        },
                        on: {
                            click: t.onScroll
                        }
                    }, [o("img", {
                        attrs: {
                            src: "/arrow_scroll.png",
                            width: "34",
                            height: "105",
                            alt: "scroll down"
                        }
                    })])])])])])])], 1)
                }), [function() {
                    var t = this.$createElement,
                        e = this._self._c || t;
                    return e("div", {
                        staticClass: "c-PixiIntro-foot-circles col-6of24"
                    }, [e("img", {
                        attrs: {
                            src: "/footer-circles.svg",
                            alt: "",
                            width: "36",
                            height: "18"
                        }
                    })])
                }], !1, null, null, null);
            e.default = component.exports
        },
        522: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(38), o(39);
            var n = o(17),
                r = (o(16), o(25), o(445), o(46)),
                h = o(4),
                c = o(14),
                l = o(444),
                d = o(102);

            function f(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }
            var m = {
                    name: "PixiHomeProjects",
                    props: {
                        fields: {
                            type: Array,
                            required: !0
                        }
                    },
                    computed: function(t) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? f(Object(source), !0).forEach((function(e) {
                                Object(n.a)(t, e, source[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : f(Object(source)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                            }))
                        }
                        return t
                    }({}, Object(c.d)("window", ["isTouch", "minHeight"])),
                    mounted: function() {
                        var t = this;
                        this.$nextTick((function() {
                            t.getContainer(), t.parent = t.getStickyParent(), t.container && !t.isTouch && (t.width = t.$el.offsetWidth, t.height = t.$el.offsetHeight, t.offsets = Object(l.a)(t.$el), t.init(), t.$eventHub.$on("resize", t.resize), t.$eventHub.$on("update", t.update))
                        }))
                    },
                    beforeDestroy: function() {
                        this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update), this.containerMask && this.container.removeChild(this.containerMask)
                    },
                    methods: {
                        getContainer: function() {
                            for (var t = this; t.$parent;) {
                                if (t.$parent.container && t.$parent.container instanceof this.$PIXI.Container) {
                                    this.container = t.$parent.container;
                                    break
                                }
                                t = t.$parent
                            }
                            if (!this.container) return console.warn("No pixi application founded for this Object. This component must be a child/subchild of a Pixi application", this)
                        },
                        getStickyParent: function() {
                            for (var element = this.$el.parentNode; !element.classList.contains("js-sticky-container");) element = element.parentNode;
                            return element || console.warn("No sticky parent founded for this Object. This component must be a child/subchild of a js-sticky-container", this)
                        },
                        init: function() {
                            var t = this;
                            this.containerMask = new this.$PIXI.Container, this.containerMask.position.x = this.offsets.left, this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.container.addChild(this.containerMask), this.mask = new this.$PIXI.Graphics, this.containerMask.addChild(this.mask), this.mask.beginFill("0x000000"), this.mask.drawRect(0, 0, this.width, this.height), this.mask.endFill(), this.containerMask.mask = this.mask, this.imagesContainer = [], this.imagesMasks = [], this.images = [], this.fields.forEach((function(e, i) {
                                var o = new t.$PIXI.Container;
                                t.containerMask.addChild(o), o.position.x = 0, o.position.y = i * t.height, t.imagesContainer.push(o);
                                var mask = new t.$PIXI.Graphics;
                                o.addChild(mask), mask.beginFill("0x000000"), mask.drawRect(0, 0, t.width, t.height), mask.endFill(), o.mask = mask, t.imagesMasks.push(mask);
                                var image = new t.$PIXI.Sprite.from(e.project.data.image_homepage.url);
                                o.addChild(image), image.anchor.set(.5), image.width = t.width, image.height = t.height, image.position.x = t.width / 2, image.position.y = t.height / 2, t.images.push(image)
                            }))
                        },
                        resize: function() {
                            var t = this;
                            this.isTouch || (this.width = this.$el.offsetWidth, this.height = this.$el.offsetHeight, this.offsets = Object(l.a)(this.$el), this.mask.clear(), this.mask.beginFill("0x000000"), this.mask.drawRect(0, 0, this.width, this.height), this.mask.endFill(), this.containerMask.position.x = this.offsets.left, this.parentTop = Object(d.a)(this.parent), this.parentHeight = this.parent.offsetHeight, this.triggerTop = this.parentTop, this.triggerBottom = this.parentHeight, this.images.length && (this.images.forEach((function(image, i) {
                                image.width = t.width, image.height = t.height, image.position.x = t.width / 2, image.position.y = t.height / 2
                            })), this.imageScale = this.width / 950, this.imagesMasks.forEach((function(mask, i) {
                                mask.clear(), mask.beginFill("0x000000"), mask.drawRect(0, 0, t.width, t.height), mask.endFill()
                            }))))
                        },
                        update: function() {
                            var t = this;
                            this.containerMask && (this.$root.smoothScroll >= this.triggerTop && this.$root.smoothScroll < this.triggerBottom ? (this.containerMask.position.y = this.offsets.top - this.triggerTop, this.imagesContainer.forEach((function(e, i) {
                                e.position.y = i * t.height - (t.$root.smoothScroll - t.triggerTop) / (t.parentHeight / (t.height * t.images.length))
                            })), this.images.forEach((function(image, i) {
                                image.position.y = t.height / 2 + .1 * (t.$root.smoothScroll - t.triggerTop) - t.minHeight * i * .1
                            }))) : this.$root.smoothScroll > this.triggerBottom ? (this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll + this.triggerBottom - this.triggerTop, this.imagesContainer.forEach((function(e, i) {
                                e.position.y = i * t.height - (t.triggerBottom - t.triggerTop) / (t.parentHeight / (t.height * t.images.length))
                            }))) : (this.containerMask.position.y = this.offsets.top - this.$root.smoothScroll, this.imagesContainer.forEach((function(e, i) {
                                e.position.y = i * t.height
                            }))))
                        },
                        onPointerEnter: function() {
                            var t = this;
                            this.images.forEach((function(image, i) {
                                r.a.to(image.scale, {
                                    duration: .6,
                                    x: t.imageScale + .1,
                                    y: t.imageScale + .1,
                                    ease: h.c.easeOut
                                })
                            }))
                        },
                        onPointerLeave: function() {
                            var t = this;
                            this.images.forEach((function(image, i) {
                                r.a.to(image.scale, {
                                    duration: .6,
                                    x: t.imageScale,
                                    y: t.imageScale,
                                    ease: h.c.easeOut
                                })
                            }))
                        }
                    }
                },
                v = m,
                y = o(26),
                component = Object(y.a)(v, (function() {
                    var t = this,
                        e = t.$createElement;
                    return (t._self._c || e)("div", {
                        staticClass: "c-PixiHomeProjects",
                        on: {
                            pointerenter: t.onPointerEnter,
                            pointerleave: t.onPointerLeave
                        }
                    })
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        534: function(t, e, o) {
            var content = o(566);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [t.i, content, ""]
            ]), content.locals && (t.exports = content.locals);
            (0, o(55).default)("2065e928", content, !0, {
                sourceMap: !1
            })
        },
        565: function(t, e, o) {
            "use strict";
            o(534)
        },
        566: function(t, e, o) {
            var n = o(54)(!1);
            n.push([t.i, '.c-Home{background:#000}.c-Home-content{position:relative;width:100%}.c-Home-sticky{position:absolute;top:0;left:0;width:100%;height:100vh;display:flex;align-items:center;pointer-events:none}.is-touch .c-Home-sticky.is-sticky{position:fixed}.is-touch .c-Home-sticky.is-sticky-end{top:auto;bottom:0}@media only screen and (max-width:767px){.c-Home-sticky{padding-top:75px;align-items:flex-start}}.c-Home-sticky-images{position:absolute;top:0;left:0;width:100%;height:100%;display:flex;align-items:center}.is-touch .c-Home-sticky-images{display:none}.c-Home-sticky-images-content{pointer-events:auto}.c-Home-sticky-legend{opacity:.5}.c-Home-sticky-titles{margin-top:15px;position:relative;text-transform:uppercase}.c-Home-sticky-titles-item{position:absolute;top:0;left:0;opacity:0;transform:translateZ(0);transition:transform .4s cubic-bezier(.895,.03,.685,.22),opacity .4s cubic-bezier(.895,.03,.685,.22)}.c-Home-sticky-titles-item.is-active{opacity:1;transition:transform .8s cubic-bezier(.165,.84,.44,1) .4s,opacity .8s cubic-bezier(.165,.84,.44,1) .4s}.c-Home-sticky-titles-item.is-prev{transform:translateY(-40px) translateZ(0)}.c-Home-sticky-titles-item.is-next{transform:translateY(40px) translateZ(0)}.c-Home-sticky-categories{display:flex;margin-top:15px;opacity:.5}.c-Home-sticky-categories li{display:flex;align-items:center}.c-Home-sticky-categories li:before{content:"";display:inline-block;height:3px;width:3px;background:currentColor;border-radius:50%;margin-left:10px;margin-right:10px}.c-Home-sticky-categories li:first-child:before{content:none}.c-Home-sticky-link{display:none;align-items:center;justify-content:flex-end}@media only screen and (max-width:767px){.c-Home-sticky-link{position:absolute;top:50%;right:3.65vw;transform:translateY(-50%)}}.c-Home-sticky-link a{pointer-events:auto}@media only screen and (max-width:767px){.c-Home-sticky-link-label{display:none}}.c-Home-sticky-btn{position:absolute;bottom:13vh;left:50%;transform:translateX(-50%);pointer-events:auto;white-space:nowrap}@media only screen and (min-width:1441px){.c-Home-sticky-btn{bottom:8vh}}@media only screen and (max-width:767px){.c-Home-sticky-btn{bottom:75px}}@media only screen and (max-width:767px){.c-Home-ruler-container{display:none}}.c-Home-ruler{position:relative;padding-left:15px}.c-Home-ruler-cursor{position:absolute;top:0;left:0;border-top:3px solid transparent;border-bottom:3px solid transparent;border-left:5px solid #fff;margin-top:-3px;transition:transform .8s cubic-bezier(.165,.84,.44,1)}.c-Home-ruler-cm{position:relative;width:6px;margin-top:16px}.c-Home-ruler-cm:first-child,.c-Home-ruler-cm:first-child .c-Home-ruler-mm:first-child{margin-top:0}.c-Home-ruler-cm:before{content:"";position:absolute;top:0;left:0;width:6px;height:1px;background:#fff}.c-Home-ruler-mm{width:2px;height:1px;background:#fff;margin-top:16px}.c-Home-project{display:flex;align-items:center;height:100vh;width:100%}.c-Home-project-inner{display:none}.is-touch .c-Home-project-inner{display:block}.c-Home-project-image{position:relative}.c-Home-project-image:before{position:relative;content:"";display:block;height:0;width:100%;padding-top:62.5263157895%}', ""]), t.exports = n
        },
        581: function(t, e, o) {
            "use strict";
            o.r(e);
            o(35), o(29), o(31), o(38), o(39);
            var n = o(17),
                r = o(18),
                h = (o(75), o(275), o(47), o(16), o(25), o(69), o(276), o(521)),
                c = o(451),
                l = o(455),
                d = o(522),
                f = o(14),
                m = o(46),
                v = o(4),
                y = o(102);

            function w(object, t) {
                var e = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(object);
                    t && (o = o.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(object, t).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }

            function x(t) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = null != arguments[i] ? arguments[i] : {};
                    i % 2 ? w(Object(source), !0).forEach((function(e) {
                        Object(n.a)(t, e, source[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : w(Object(source)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                    }))
                }
                return t
            }
            var P = {
                    name: "Home",
                    components: {
                        PixiIntro: h.default,
                        PixiHomeProjects: d.default,
                        StickyElement: c.default,
                        CursorTrigger: l.default
                    },
                    asyncData: function(t) {
                        return Object(r.a)(regeneratorRuntime.mark((function e() {
                            var o, n, r;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return o = t.$prismic, t.store, n = t.error, e.prev = 1, e.next = 4, o.api.query(o.predicates.at("document.type", "homepage"), {
                                            fetchLinks: ["project.image_homepage", "project.gradient", "project.title", "project.categories"]
                                        });
                                    case 4:
                                        return r = e.sent.results[0].data, e.abrupt("return", {
                                            document: r
                                        });
                                    case 8:
                                        e.prev = 8, e.t0 = e.catch(1), n({
                                            statusCode: 404,
                                            message: "Page not found"
                                        });
                                    case 11:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [1, 8]
                            ])
                        })))()
                    },
                    data: function() {
                        return {
                            currentIndex: 0,
                            rulerSectionHeight: 0
                        }
                    },
                    head: function() {
                        return {
                            bodyAttrs: {
                                class: "is-" + this.$route.name
                            }
                        }
                    },
                    computed: x(x(x(x(x({}, Object(f.d)(["categories"])), Object(f.d)("main", ["isPageReady"])), Object(f.d)("window", ["isTouch", "height", "minHeight"])), Object(f.c)("window", ["halfHeight"])), {}, {
                        trueIndex: function() {
                            return this.currentIndex > 0 ? this.currentIndex - 1 : 0
                        }
                    }),
                    watch: {
                        currentIndex: "onIndexChange"
                    },
                    created: function() {
                        this._onWheel = this.onWheel.bind(this)
                    },
                    mounted: function() {
                        var t = this;
                        window.addEventListener("wheel", this._onWheel), this.$eventHub.$on("resize", this.resize), this.$eventHub.$on("update", this.update), this.$nextTick((function() {
                            t.$gradient = t.$el.getElementsByTagName("monopo-gradient")[0]
                        }))
                    },
                    beforeDestroy: function() {
                        window.removeEventListener("wheel", this._onWheel), this.$eventHub.$off("resize", this.resize), this.$eventHub.$off("update", this.update), clearTimeout(this.timerWheel), this.scrollAnimation && this.scrollAnimation.kill()
                    },
                    methods: {
                        resize: function() {
                            var t = this;
                            this.cuePoints = [], this.cuePoints.push(-this.halfHeight), this.$refs.project.forEach((function(e) {
                                var o = Object(y.a)(e) - t.halfHeight;
                                t.cuePoints.push(o)
                            })), this.$refs.ruler && (this.rulerSectionHeight = this.$refs.ruler.offsetHeight / (this.document.projects.length - 1))
                        },
                        update: function() {
                            var t = this;
                            this.cuePoints && (this.scrollVal = this.isTouch ? this.$root.scrollTop : this.$root.smoothScroll, this.cuePoints.forEach((function(e, i) {
                                t.nextCuePoint = t.cuePoints[i + 1] ? t.cuePoints[i + 1] : 9999999, t.scrollVal > e && t.scrollVal < t.nextCuePoint && t.currentIndex !== i && (t.currentIndex = i)
                            })))
                        },
                        onWheel: function() {
                            var t = this;
                            this.isTouch || (clearTimeout(this.timerWheel), this.scrollAnimation && this.scrollAnimation.kill(), this.timerWheel = setTimeout((function() {
                                if (!(t.scrollVal > t.$root.scrollHeight - t.height - t.$root.footerHeight)) {
                                    var e = t.cuePoints[t.currentIndex] + t.halfHeight;
                                    t.scrollAnimation = m.a.to(window, {
                                        duration: .3,
                                        scrollTo: e,
                                        easing: v.c.easeInOut
                                    })
                                }
                            }), 300))
                        },
                        displayIndex: function(t) {
                            return t < 10 ? "0" + t : t
                        },
                        categoryName: function(t) {
                            return this.categories.find((function(e) {
                                return e.uid === t
                            })).data.name
                        },
                        onIndexChange: function() {
                            var t;
                            t = 0 === this.currentIndex ? this.getColorsOptions(this.document.gradient) : this.getColorsOptions(this.document.projects[this.currentIndex - 1].project.data.gradient), this.animColors(t)
                        },
                        animColors: function(t) {
                            this.$gradient && (m.a.to(this.$gradient, {
                                duration: .8,
                                color1: t.color1,
                                ease: v.c.easeOut
                            }), m.a.to(this.$gradient, {
                                duration: .8,
                                color2: t.color2,
                                ease: v.c.easeOut
                            }), m.a.to(this.$gradient, {
                                duration: .8,
                                color3: t.color3,
                                ease: v.c.easeOut
                            }), m.a.to(this.$gradient, {
                                duration: .8,
                                color4: t.color4,
                                ease: v.c.easeOut
                            }))
                        },
                        getColorsOptions: function(text) {
                            var t = (new DOMParser).parseFromString(text, "text/html").getElementsByTagName("monopo-gradient")[0];
                            return {
                                color1: t.getAttribute("color1"),
                                color2: t.getAttribute("color2"),
                                color3: t.getAttribute("color3"),
                                color4: t.getAttribute("color4")
                            }
                        },
                        getGradientOptions: function(text) {
                            var t = (new DOMParser).parseFromString(text, "text/html").getElementsByTagName("monopo-gradient")[0];
                            return {
                                color1: t.getAttribute("color1"),
                                color2: t.getAttribute("color2"),
                                color3: t.getAttribute("color3"),
                                color4: t.getAttribute("color4"),
                                colorsize: t.getAttribute("colorsize"),
                                colorspacing: t.getAttribute("colorspacing"),
                                colorrotation: t.getAttribute("colorrotation"),
                                colorspread: t.getAttribute("colorspread"),
                                coloroffset: t.getAttribute("coloroffset"),
                                displacement: t.getAttribute("displacement"),
                                seed: t.getAttribute("seed"),
                                position: t.getAttribute("position"),
                                zoom: t.getAttribute("zoom"),
                                spacing: t.getAttribute("spacing") || 5
                            }
                        }
                    }
                },
                k = (o(565), o(26)),
                component = Object(k.a)(P, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "c-Home",
                        class: {
                            "is-page-ready": t.isPageReady
                        }
                    }, [o("PixiIntro", {
                        attrs: {
                            options: t.getGradientOptions(t.document.gradient),
                            title: t.document.title[0],
                            "title-japanese": t.document.title_japanese[0],
                            manifesto: t.document.manifesto
                        }
                    }), t._v(" "), o("div", {
                        staticClass: "js-sticky-container c-Home-content",
                        style: {
                            height: t.document.projects.length * t.minHeight + "px"
                        }
                    }, [t._l(t.document.projects, (function(e) {
                        return o("div", {
                            key: e.project.uid,
                            ref: "project",
                            refInFor: !0,
                            staticClass: "js-section c-Home-project",
                            style: {
                                height: t.minHeight + "px"
                            }
                        }, [o("div", {
                            staticClass: "c-Home-project-inner container"
                        }, [o("div", {
                            staticClass: "row"
                        }, [o("div", {
                            staticClass: "col-13of24 offset-6of24 col-sm-12of12 offset-sm-0"
                        }, [o("CursorTrigger", {
                            attrs: {
                                name: "case"
                            }
                        }, [o("NuxtLink", {
                            staticClass: "t-link",
                            attrs: {
                                to: {
                                    name: "work-slug",
                                    params: {
                                        slug: e.project.uid
                                    }
                                }
                            }
                        }, [o("PixiImage", {
                            staticClass: "c-Home-project-image",
                            attrs: {
                                field: e.project.data.image_homepage,
                                "use-mask": !0,
                                "use-hover": !0
                            }
                        })], 1)], 1)], 1)])])])
                    })), t._v(" "), o("StickyElement", {
                        staticClass: "c-Home-sticky",
                        style: {
                            height: t.minHeight + "px"
                        },
                        attrs: {
                            inside: !1
                        }
                    }, [o("div", {
                        staticClass: "c-Home-sticky-images container"
                    }, [o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        staticClass: "col-13of24 offset-6of24 col-sm-12of12 offset-sm-0"
                    }, [o("CursorTrigger", {
                        staticClass: "c-Home-sticky-images-content",
                        attrs: {
                            name: "case"
                        }
                    }, [o("NuxtLink", {
                        staticClass: "t-link",
                        attrs: {
                            to: {
                                name: "work-slug",
                                params: {
                                    slug: t.document.projects[t.trueIndex].project.uid
                                }
                            }
                        }
                    }, [o("PixiHomeProjects", {
                        staticClass: "c-Home-project-image",
                        attrs: {
                            fields: t.document.projects
                        }
                    })], 1)], 1)], 1)])]), t._v(" "), o("div", {
                        staticClass: "container"
                    }, [o("div", {
                        staticClass: "row"
                    }, [o("div", {
                        ref: "ruler",
                        staticClass: "c-Home-ruler-container col-1of24 offset-2of24"
                    }, [o("div", {
                        staticClass: "c-Home-ruler"
                    }, [t._l(t.document.projects.length - 1, (function(e) {
                        return o("div", {
                            key: e,
                            staticClass: "c-Home-ruler-cm"
                        }, t._l(9, (function(i) {
                            return o("div", {
                                key: i,
                                staticClass: "c-Home-ruler-mm"
                            })
                        })), 0)
                    })), t._v(" "), o("div", {
                        staticClass: "c-Home-ruler-cm"
                    }), t._v(" "), o("div", {
                        staticClass: "c-Home-ruler-cursor",
                        style: {
                            transform: "translateY(" + t.rulerSectionHeight * t.trueIndex + "px) translateZ(0)"
                        }
                    })], 2)]), t._v(" "), o("div", {
                        staticClass: "col-9of24 col-sm-12of12"
                    }, [o("div", {
                        staticClass: "t-text--sm"
                    }, [t._v("\n                            RECENT WORK\n                        ")]), t._v(" "), o("div", {
                        staticClass: "c-Home-sticky-titles"
                    }, t._l(t.document.projects, (function(e, i) {
                        return o("div", {
                            key: i,
                            staticClass: "c-Home-sticky-titles-item",
                            class: {
                                "is-active": t.trueIndex === i, "is-prev": t.trueIndex > i, "is-next": t.trueIndex < i
                            }
                        }, [o("h3", {
                            directives: [{
                                name: "italic",
                                rawName: "v-italic",
                                value: t.$prismic.asText(e.project.data.title),
                                expression: "$prismic.asText(project.project.data.title)"
                            }],
                            staticClass: "c-Home-sticky-title t-h3"
                        }, [t._v("\n                                    " + t._s(t.$prismic.asText(e.project.data.title)) + "\n                                ")]), t._v(" "), o("ul", {
                            staticClass: "c-Home-sticky-categories t-list t-h6 t-h6--spacing"
                        }, t._l(e.project.data.categories, (function(e) {
                            return o("li", {
                                key: e.category.slug
                            }, [t._v("\n                                        " + t._s(t.$prismic.asText(t.categoryName(e.category.uid))) + "\n                                    ")])
                        })), 0)])
                    })), 0)]), t._v(" "), o("div", {
                        staticClass: "c-Home-sticky-link col-7of24 offset-3of24"
                    }, [o("NuxtLink", {
                        staticClass: "t-link-primary",
                        attrs: {
                            to: {
                                name: "work-slug",
                                params: {
                                    slug: t.document.projects[t.trueIndex].project.uid
                                }
                            }
                        }
                    }, [o("span", {
                        staticClass: "t-link-primary-icon"
                    })])], 1)]), t._v(" "), o("NuxtLink", {
                        staticClass: "c-Home-sticky-btn t-btn-primary",
                        attrs: {
                            to: {
                                name: "work"
                            }
                        }
                    }, [o("span", [t._v("Discover all projects")]), t._v(" "), o("span", {
                        staticClass: "t-btn-primary-arrow"
                    }, [t._v("→")])])], 1)])], 2)], 1)
                }), [], !1, null, null, null);
            e.default = component.exports;
            installComponents(component, {
                PixiIntro: o(521).default,
                PixiImage: o(448).default,
                CursorTrigger: o(455).default,
                PixiHomeProjects: o(522).default,
                StickyElement: o(451).default
            })
        }
    }
]);